import argparse
import csv
import json
import urllib.request
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
OLLAMA_URL = 'http://localhost:11434/api/chat'
MODEL = 'qwen3:4b'
MAX_CHANGE_FRACTION = 0.5

def load_vocab(speaker: str) -> dict:
    p = ROOT / 'data' / speaker / 'vocab.json'
    if not p.exists():
        return {}
    return json.loads(p.read_text(encoding='utf-8'))
_PEOPLE_KEYS = ('people', 'names')

def _bucket(vocab: dict, *keys: str) -> list:
    out: list = []
    for k in keys:
        v = vocab.get(k)
        if isinstance(v, list):
            out += v
    return out

def vocab_words(vocab: dict) -> list[str]:
    return _bucket(vocab, *_PEOPLE_KEYS) + _bucket(vocab, 'places') + _bucket(vocab, 'brands_apps') + _bucket(vocab, 'foods') + _bucket(vocab, 'spelled')

def build_system_prompt(vocab: dict) -> str:
    words = vocab_words(vocab)
    confusions = '\n'.join((f'  - "{a}" is usually "{b}"' for a, b in (vocab.get('confusions') or {}).items()))
    patterns = '\n'.join((f'  - {p}' for p in vocab.get('speech_patterns') or []))
    return f"You clean up speech-recognition output for one specific speaker.\n\nThe speaker's personal vocabulary (names spelled exactly like this):\n{', '.join(words)}\n\nKnown recognizer mistakes for this speaker:\n{confusions}\n\nThe speaker's speech patterns (the recognizer mishears these ways):\n{patterns}\n\nRules:\n1. Fix ONLY clear recognition errors: wrong names, obvious sound-confusions\n   consistent with the patterns above, and small grammar slips (makes/make).\n2. NEVER rephrase, reorder, summarise, or add words. Keep the speaker's wording.\n3. If the text looks correct, return it UNCHANGED.\n4. Reply with the corrected text only. No explanations, no quotes."

def _word_change_fraction(a: str, b: str) -> float:
    aw, bw = (a.lower().split(), b.lower().split())
    if not aw:
        return 1.0
    import difflib
    same = sum((m.size for m in difflib.SequenceMatcher(a=aw, b=bw).get_matching_blocks()))
    return 1.0 - same / max(len(aw), len(bw))

def apply_confusion_table(text: str, vocab: dict) -> str:
    import re
    table = vocab.get('confusions') or {}
    for wrong, right in sorted(table.items(), key=lambda kv: -len(kv[0])):
        if not wrong:
            continue
        pat = re.escape(wrong)
        if wrong[0].isalnum() or wrong[0] == '_':
            pat = '\\b' + pat
        if wrong[-1].isalnum() or wrong[-1] == '_':
            pat = pat + '\\b'
        text = re.sub(pat, lambda _m, r=right: r, text, flags=re.IGNORECASE)
    return text

def correct(text: str, vocab: dict, model: str=MODEL, timeout: float=60.0, use_llm: bool=True) -> str:
    if not text.strip():
        return text
    text = apply_confusion_table(text, vocab)
    if not use_llm:
        return text
    body = json.dumps({'model': model, 'messages': [{'role': 'system', 'content': build_system_prompt(vocab)}, {'role': 'user', 'content': text}], 'stream': False, 'options': {'temperature': 0.0}}).encode('utf-8')
    req = urllib.request.Request(OLLAMA_URL, data=body, headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            out = json.loads(resp.read())['message']['content'].strip()
    except Exception:
        return text
    if '</think>' in out:
        out = out.split('</think>')[-1].strip()
    out = out.strip('"').strip()
    if not out or _word_change_fraction(text, out) > MAX_CHANGE_FRACTION:
        return text
    return out

def main() -> None:
    parser = argparse.ArgumentParser(description='Evaluate the corrector on a results csv.')
    parser.add_argument('--eval', type=Path, required=True, help='per-utterance csv from benchmark.py')
    parser.add_argument('--speaker', required=True)
    parser.add_argument('--model', default=MODEL)
    parser.add_argument('--out', type=Path, default=ROOT / 'results' / 'corrector_eval.csv')
    args = parser.parse_args()
    import jiwer
    from transformers.models.whisper.english_normalizer import EnglishTextNormalizer
    normalize = EnglishTextNormalizer({})
    vocab = load_vocab(args.speaker)
    rows = list(csv.DictReader(args.eval.open(encoding='utf-8-sig', newline='')))
    fixed = broken = 0
    for i, r in enumerate(rows, start=1):
        corrected_raw = correct(r['raw_hypothesis'], vocab, model=args.model)
        r['corrected'] = normalize(corrected_raw)
        r['corrected_raw'] = corrected_raw
        before_ok = r['reference'] == r['hypothesis']
        after_ok = r['reference'] == r['corrected']
        fixed += not before_ok and after_ok
        broken += before_ok and (not after_ok)
        print(f'  {i}/{len(rows)}', end='\r', flush=True)
    print(' ' * 24, end='\r')
    refs = [r['reference'] for r in rows]
    wer_before = jiwer.wer(refs, [r['hypothesis'] for r in rows])
    wer_after = jiwer.wer(refs, [r['corrected'] for r in rows])
    print(f'WER before correction: {wer_before:.1%}')
    print(f'WER after  correction: {wer_after:.1%}')
    print(f'clips fixed: {fixed}   clips broken: {broken}')
    with args.out.open('w', encoding='utf-8', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f'wrote {args.out}')

# RESTORED ENTRY POINT.
#
# Without this the file is a module that defines main() and never calls it: run
# as a script it imports, defines, and exits 0 having printed nothing. Kara
# starts four of these as child processes and reads their output, so a missing
# __main__ is not a crash anywhere -- it is a subprocess that "succeeds"
# instantly and produces nothing, which is the hardest possible shape of
# failure to see.
#
# setup.ps1 records that `package.py --strip` removed these blocks and that
# record.py's had to be restored for --list-devices to list anything. The same
# strip took the rest, and they were never put back.
if __name__ == '__main__':
    main()
