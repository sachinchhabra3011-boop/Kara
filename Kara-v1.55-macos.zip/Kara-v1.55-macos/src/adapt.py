import argparse
import csv
import json
import re
import shutil
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent

def queue_path(speaker: str) -> Path:
    return ROOT / 'data' / speaker / 'adapt_queue.jsonl'
_SPELLED_OUT = re.compile('(?:(?<![^\\W\\d_])[^\\W\\d_]-){2,}[^\\W\\d_](?![^\\W\\d_])')

def looks_spelled_out(text: str) -> bool:
    return bool(_SPELLED_OUT.search(text or ''))

def log_correction(speaker: str, wav_path: str, asr_output: str, accepted: str, trust: str='harvested') -> None:
    if not accepted.strip():
        return
    if looks_spelled_out(accepted):
        return
    rec = {'wav_path': wav_path, 'asr_output': asr_output, 'accepted': accepted, 'trust': trust, 'logged_at': datetime.now(timezone.utc).isoformat(timespec='seconds')}
    path = queue_path(speaker)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(rec, ensure_ascii=False) + '\n')

def read_queue(speaker: str) -> list[dict]:
    path = queue_path(speaker)
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text(encoding='utf-8').splitlines() if line.strip()]

def harvest(speaker: str, final_text: str) -> dict:
    import pairing
    import utterances
    rows = [r for r in sorted(utterances.load_index(speaker), key=lambda r: r.get('at', 0)) if r.get('mode') == 'dictation' and (not r.get('harvested')) and (r.get('asr') or '').strip()]
    if not rows:
        return {'paired': 0, 'corrected': 0, 'unchanged': 0, 'unmatched': 0}
    results = pairing.align(rows, final_text)
    counts = {'paired': len(results), 'corrected': 0, 'unchanged': 0, 'unmatched': 0}
    for row, res in zip(rows, results):
        counts[res['status']] = counts.get(res['status'], 0) + 1
        if res['status'] == 'corrected':
            log_correction(speaker, row.get('wav', ''), res['asr'], res['corrected'], trust='harvested')
            utterances.note_correction(speaker, row['id'], res['corrected'])
        utterances.mark_harvested(speaker, row['id'])
    return counts

def training_pairs(speaker: str) -> list[dict]:
    out = []
    for r in read_queue(speaker):
        if trust_rank(r) < TRAIN_FLOOR:
            continue
        wav = (r.get('wav_path') or '').strip()
        if not wav or not (ROOT / wav).exists():
            continue
        text = (r.get('accepted') or '').strip()
        if not text:
            continue
        if looks_spelled_out(text):
            continue
        out.append({**r, 'wav_path': wav})
    return out
SUGGEST_AFTER_PAIRS = 25

def retrain_suggestion(speaker: str) -> dict:
    pairs = training_pairs(speaker)
    n = len(pairs)
    if n >= SUGGEST_AFTER_PAIRS:
        reason = f'{n} corrections are waiting. Training on them teaches Kara the words it got wrong for you.'
    else:
        reason = f'{n} of {SUGGEST_AFTER_PAIRS} corrections so far — not enough to be worth the time yet.'
    return {'pairs': n, 'enough': n >= SUGGEST_AFTER_PAIRS, 'reason': reason}

def build_training_manifest(speaker: str, dest: Path | None=None, exclude: list[dict] | None=None, include_practice: bool=False) -> tuple[Path, int]:
    import atomicio
    import record
    dest = dest or ROOT / 'data' / speaker / 'adapt_manifest.csv'
    pairs = training_pairs(speaker)
    if exclude:
        struck = {((r.get('wav_path') or '').strip(), (r.get('accepted') or '').strip()) for r in exclude}
        pairs = [p for p in pairs if ((p.get('wav_path') or '').strip(), (p.get('accepted') or '').strip()) not in struck]
    rows = []
    for i, p in enumerate(pairs):
        wav = ROOT / p['wav_path']
        try:
            import soundfile as sf
            info = sf.info(str(wav))
            dur = info.frames / float(info.samplerate)
        except Exception:
            dur = 0.0
        rows.append({'prompt_id': f'adapt-{i:05d}', 'prompt_set': 'adapt', 'prompt_text': p['accepted'], 'wav_path': p['wav_path'], 'duration_s': f'{dur:.2f}', 'peak': '', 'recorded_at': p.get('logged_at', '')})
    if include_practice:
        import csv as _csv
        import practice as _practice
        pm = _practice.clips_manifest(speaker)
        if pm.exists():
            with pm.open(encoding='utf-8-sig', newline='') as f:
                for r in _csv.DictReader(f):
                    if not (r.get('prompt_text') or '').strip():
                        continue
                    if not (ROOT / (r.get('wav_path') or '')).exists():
                        continue
                    rows.append({k: r.get(k, '') for k in record.FIELDS})
    atomicio.write_csv(dest, record.FIELDS, rows, backup=True)
    return (dest, len(rows))
PROMOTE_AFTER = 3
TRUST_RANK = {'prompted': 4, 'spelled': 3, 'commanded': 2, 'panel': 1, 'harvested': 0}
LEGACY_TRUST = 'harvested'
TRAIN_FLOOR = TRUST_RANK['commanded']
PROMOTE_FLOOR = TRUST_RANK['commanded']

def trust_of(row: dict) -> str:
    t = (row.get('trust') or '').strip()
    if t in TRUST_RANK:
        return t
    if t == 'edited':
        return LEGACY_TRUST
    return LEGACY_TRUST

def trust_rank(row: dict) -> int:
    return TRUST_RANK.get(trust_of(row), 0)
PROMOTING_TRUST = tuple((k for k, v in TRUST_RANK.items() if v >= PROMOTE_FLOOR))

def confusion_candidates(speaker: str, min_count: int=PROMOTE_AFTER) -> dict[str, str]:
    counts: dict[tuple[str, str], int] = {}
    for r in read_queue(speaker):
        if trust_rank(r) < PROMOTE_FLOOR:
            continue
        heard = (r.get('asr_output') or '').strip().lower()
        meant = (r.get('accepted') or '').strip()
        if not heard or not meant:
            continue
        if len(heard.split()) != 1 or len(meant.split()) != 1:
            continue
        if heard == meant.lower():
            continue
        counts[heard, meant] = counts.get((heard, meant), 0) + 1
    out: dict[str, str] = {}
    for (heard, meant), n in sorted(counts.items(), key=lambda kv: -kv[1]):
        if n < min_count or heard in out:
            continue
        out[heard] = meant
    return {h: m for h, m in out.items() if m.lower() not in out}

def merge_into_vocab(speaker: str, pairs: dict[str, str], dry_run: bool=False) -> dict[str, str]:
    p = ROOT / 'data' / speaker / 'vocab.json'
    try:
        vocab = json.loads(p.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return {}
    existing = vocab.get('confusions') or {}
    added = {h: m for h, m in pairs.items() if h not in existing}
    if added and (not dry_run):
        existing.update(added)
        vocab['confusions'] = existing
        import atomicio
        atomicio.write_json(p, vocab, backup=True)
    return added

def score_on_frozen(speaker: str, adapter: Path | None, model: str='medium', bf16: bool=False) -> float:
    import subprocess
    import sys
    frozen = ROOT / 'data' / speaker / 'frozen_test.json'
    if not frozen.exists():
        raise SystemExit(f'No frozen test set for {speaker}. Create it FIRST:\n  adapt.py --speaker {speaker} freeze-test --split results/{speaker}_split.json\nWithout it there is nothing to gate against.')
    import osbridge
    py = osbridge.python_exe(Path(sys.executable))
    cmd = [str(py), str(ROOT / 'src' / 'benchmark.py'), '--speaker', speaker, '--models', model, '--test-split', str(frozen), '--no-safeguards']
    if adapter:
        cmd += ['--adapter', str(adapter)]
    if bf16:
        cmd.append('--bf16')
    proc = subprocess.run(cmd, capture_output=True, encoding='utf-8', errors='replace', creationflags=osbridge.NO_WINDOW)
    if proc.returncode != 0:
        raise SystemExit(f"benchmark failed:\n{(proc.stderr or '')[-800:]}")
    summary = ROOT / 'results' / 'summary.csv'
    if not summary.exists():
        raise SystemExit('benchmark wrote no summary.csv')
    with summary.open(encoding='utf-8-sig', newline='') as f:
        rows = list(csv.DictReader(f))
    if not rows:
        raise SystemExit('benchmark summary is empty')
    return float(rows[0]['wer'])

def evaluate(speaker: str, candidate: Path, model: str='medium', margin: float=0.0, bf16: bool=False) -> dict:
    import profiles
    current = profiles.adapter_for(speaker, model)
    cur_wer = score_on_frozen(speaker, current, model, bf16)
    cand_wer = score_on_frozen(speaker, candidate, model, bf16)
    passed = gate(cur_wer, cand_wer, margin)
    result = {'current': str(current) if current else None, 'candidate': str(candidate), 'current_wer': cur_wer, 'candidate_wer': cand_wer, 'margin': margin, 'deploy': passed}
    try:
        import analytics
        import profiles as _profiles
        analytics.record(speaker, {'model': model, 'candidate': Path(candidate).name, 'current_wer': cur_wer, 'candidate_wer': cand_wer, 'margin': margin, 'deploy': passed, 'clips': _profiles.clip_count(speaker)})
    except Exception:
        pass
    return result

def gate(current_wer: float, candidate_wer: float, margin: float=0.0) -> bool:
    return candidate_wer < current_wer - margin

def status(speaker: str) -> None:
    q = read_queue(speaker)
    by_trust: dict[str, int] = {}
    for r in q:
        by_trust[trust_of(r)] = by_trust.get(trust_of(r), 0) + 1
    print(f'adaptation queue for {speaker}: {len(q)} pairs')
    print('  by provenance (strongest first):')
    for name in sorted(TRUST_RANK, key=lambda k: -TRUST_RANK[k]):
        n = by_trust.get(name, 0)
        if not n:
            continue
        marks = []
        if TRUST_RANK[name] >= TRAIN_FLOOR:
            marks.append('trainable')
        if TRUST_RANK[name] >= PROMOTE_FLOOR:
            marks.append('can promote a rule')
        note = '  (' + ', '.join(marks) + ')' if marks else '  (evidence only)'
        print(f'    {name:<10} {n:>4}{note}')
    print(f'  train-worthy (provenance + audio on disk): {len(training_pairs(speaker))}')
    try:
        import practice
        n_practice = practice.clip_count(speaker)
        if n_practice:
            print(f'  practice clips (prompted, in their own manifest): {n_practice}')
    except Exception:
        pass
    with_audio = sum((1 for r in q if (r.get('wav_path') or '').strip()))
    print(f'  with audio attached: {with_audio}')
    import utterances
    inv = utterances.inventory(speaker)
    print(f"  retained utterances: {inv['count']} of {inv['keep']} ({inv['seconds']}s, {inv['bytes'] / 1024:.0f} KB)")
    pairs = confusion_candidates(speaker)
    print(f'  confusion pairs ready ({len(pairs)}):')
    for heard, meant in list(pairs.items())[:10]:
        print(f'    {heard} -> {meant}')
    frozen = ROOT / 'data' / speaker / 'frozen_test.json'
    print(f"  frozen held-out test: {('present' if frozen.exists() else 'NOT SET -- create before first retrain')}")

def freeze_test(speaker: str, split_json: Path) -> None:
    dst = ROOT / 'data' / speaker / 'frozen_test.json'
    shutil.copy(split_json, dst)
    ids = json.loads(dst.read_text())['test_ids']
    print(f'froze {len(ids)} clips as the permanent gate test -> {dst}')
    print('These clips are now off-limits to all future training.')

def main() -> None:
    parser = argparse.ArgumentParser(description='Adaptation queue + deploy gate.')
    parser.add_argument('--speaker', required=True)
    sub = parser.add_subparsers(dest='cmd', required=True)
    sub.add_parser('status')
    ds = sub.add_parser('dataset', help='write the adaptation clips as a manifest')
    ds.add_argument('--out', type=Path, default=None)
    lc = sub.add_parser('learn', help='fold observed corrections into vocab.json')
    lc.add_argument('--min-count', type=int, default=PROMOTE_AFTER)
    lc.add_argument('--apply', action='store_true', help='actually write them (default is a dry run)')
    ev = sub.add_parser('evaluate', help='score a candidate against the frozen set')
    ev.add_argument('--candidate', type=Path, required=True)
    ev.add_argument('--model', default='medium')
    ev.add_argument('--margin', type=float, default=0.0, help='how much better the candidate must be (WER, absolute)')
    ev.add_argument('--bf16', action='store_true')
    fr = sub.add_parser('freeze-test')
    fr.add_argument('--split', type=Path, required=True)
    lg = sub.add_parser('log')
    lg.add_argument('--wav', required=True)
    lg.add_argument('--asr', required=True)
    lg.add_argument('--accepted', required=True)
    lg.add_argument('--trust', default='harvested', choices=sorted(TRUST_RANK, key=lambda k: -TRUST_RANK[k]))
    args = parser.parse_args()
    if args.cmd == 'status':
        status(args.speaker)
    elif args.cmd == 'dataset':
        dest, n = build_training_manifest(args.speaker, args.out)
        print(f'{n} adaptation clip(s) -> {dest}')
        if n:
            frozen = ROOT / 'data' / args.speaker / 'frozen_test.json'
            print('\nRetrain with them (adaptation clips join TRAIN only):')
            print(f'  .venv\\Scripts\\python.exe src\\finetune.py --speaker {args.speaker} --model medium --lr 0.0003 \\\n      --split results\\{args.speaker}_split.json --extra-manifest {dest.relative_to(ROOT)} \\\n      --out models\\candidate-{args.speaker}')
            print('\nThen score the CANDIDATE and the CURRENT adapter on the frozen')
            print('set and compare with adapt.gate() before promoting anything.')
            if not frozen.exists():
                print('\n!! frozen_test.json does not exist. Create it FIRST or the')
                print('   gate cannot refuse a bad retrain.')
    elif args.cmd == 'learn':
        pairs = confusion_candidates(args.speaker, min_count=args.min_count)
        if not pairs:
            print(f'nothing seen {args.min_count}+ times yet.')
            return
        added = merge_into_vocab(args.speaker, pairs, dry_run=not args.apply)
        verb = 'added' if args.apply else 'would add'
        print(f'{len(pairs)} candidate pair(s); {verb} {len(added)} new:')
        for h, m in added.items():
            print(f'  {h} -> {m}')
        if not args.apply:
            print('\n(dry run -- pass --apply to write them to vocab.json)')
    elif args.cmd == 'evaluate':
        if not args.candidate.exists():
            raise SystemExit(f'No such adapter: {args.candidate}')
        r = evaluate(args.speaker, args.candidate, args.model, args.margin, args.bf16)
        print(f"\n  current   {r['current_wer']:.2%}   {r['current'] or '(base model)'}")
        print(f"  candidate {r['candidate_wer']:.2%}   {r['candidate']}")
        print(f"  margin    {r['margin']:.2%}")
        if r['deploy']:
            print('\n  PASS -- the candidate beats the current adapter on clips')
            print('  neither has ever trained on. Safe to promote.')
            print('\n  Promote by swapping the directory names; keep the old one')
            print('  as the rollback, the way whisper-*-prev-337 was kept.')
        else:
            print('\n  FAIL -- keep the current adapter. This is the gate doing')
            print('  its job: a retrain that does not beat what is already')
            print('  running does not ship, however good the training loss was.')
    elif args.cmd == 'freeze-test':
        freeze_test(args.speaker, args.split)
    elif args.cmd == 'log':
        log_correction(args.speaker, args.wav, args.asr, args.accepted, args.trust)
        print('logged.')

# RESTORED ENTRY POINT.
#
# Without this the file is a module that defines main() and never calls it: run
# as a script it imports, defines, and exits 0 having printed nothing. Kara
# starts four of these as child processes and reads their output, so a missing
# __main__ is not a crash anywhere -- it is a subprocess that "succeeds"
# instantly and produces nothing, which is the hardest possible shape of
# failure to see.
#
# setup.ps1 records that `package.py --strip` removed these blocks and that
# record.py's had to be restored for --list-devices to list anything. The same
# strip took the rest, and they were never put back.
if __name__ == '__main__':
    main()
