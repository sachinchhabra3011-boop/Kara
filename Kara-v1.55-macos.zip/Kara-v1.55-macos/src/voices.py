from __future__ import annotations
import json
import os
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
import osbridge
ROOT = Path(__file__).resolve().parent.parent
_NO_WINDOW = osbridge.NO_WINDOW
_CACHE: list['Voice'] | None = None
PIPER_DIR = ROOT / 'tools' / 'piper'
PIPER_EXE = PIPER_DIR / osbridge.PIPER_BINARY
PIPER_VOICES = ROOT / 'models' / 'piper-voices'

@dataclass(frozen=True)
class Voice:
    id: str
    name: str
    engine: str
    language: str = ''
    gender: str = ''
    natural: bool = False
    size: int = 0
    token: str = field(default='', repr=False)

    @property
    def region(self) -> str:
        if self.engine == 'piper' and '_' in self.token:
            tail = self.token.split('_', 1)[1].split('-', 1)[0]
            return tail.upper() if len(tail) <= 3 else ''
        return ''

    @property
    def legacy(self) -> bool:
        return not self.natural

    @property
    def size_label(self) -> str:
        if not self.size:
            return ''
        if self.size >= 1 << 30:
            return f'{self.size / (1 << 30):.1f} GB'
        return f'{self.size / (1 << 20):.0f} MB'

    @property
    def label(self) -> str:
        bits = [self.name]
        if self.region:
            bits.append(self.region)
        if self.size_label:
            bits.append(self.size_label)
        return '  ·  '.join(bits)

def _run(script: str, timeout: float=60) -> subprocess.CompletedProcess:
    """PowerShell. Windows-only by construction -- every caller is guarded."""
    return subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command', script], capture_output=True, encoding='utf-8', errors='replace', creationflags=_NO_WINDOW, timeout=timeout)
_ENUMERATE = '\n$ErrorActionPreference = "SilentlyContinue"\n$sizes = @{}\nforeach ($root in @("HKLM:\\SOFTWARE\\Microsoft\\Speech\\Voices\\Tokens",\n                    "HKLM:\\SOFTWARE\\Microsoft\\Speech_OneCore\\Voices\\Tokens")) {\n  Get-ChildItem $root | ForEach-Object {\n    $k = Get-ItemProperty $_.PSPath\n    $b = 0\n    if ($k.VoicePath) {\n      $dir = Split-Path $k.VoicePath -Parent\n      $leaf = Split-Path $k.VoicePath -Leaf\n      Get-ChildItem -Path $dir -Filter "$leaf*" -File | ForEach-Object { $b += $_.Length }\n    }\n    $sizes[$_.PSChildName] = $b\n  }\n}\n$out = New-Object System.Collections.ArrayList\n[Windows.Media.SpeechSynthesis.SpeechSynthesizer,Windows.Media,ContentType=WindowsRuntime] | Out-Null\nforeach ($v in [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices) {\n  $tok = Split-Path $v.Id -Leaf\n  [void]$out.Add([pscustomobject]@{\n    engine = "winrt"; name = $v.DisplayName; lang = [string]$v.Language\n    gender = [string]$v.Gender; token = $tok; bytes = [int]$sizes[$tok] })\n}\nAdd-Type -AssemblyName System.Speech\nforeach ($vi in (New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices()) {\n  $i = $vi.VoiceInfo\n  [void]$out.Add([pscustomobject]@{\n    engine = "sapi"; name = $i.Name; lang = [string]$i.Culture\n    gender = [string]$i.Gender; token = [string]$i.Id; bytes = [int]$sizes[$i.Id] })\n}\nConvertTo-Json -InputObject @($out) -Compress -Depth 3\n'
_WINRT_HEAD = '\n$ErrorActionPreference = "Stop"\nAdd-Type -AssemblyName System.Runtime.WindowsRuntime\n[Windows.Media.SpeechSynthesis.SpeechSynthesizer,Windows.Media,ContentType=WindowsRuntime] | Out-Null\n[Windows.Storage.Streams.DataReader,Windows.Storage.Streams,ContentType=WindowsRuntime] | Out-Null\n$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() |\n  Where-Object { $_.Name -eq \'AsTask\' -and $_.GetParameters().Count -eq 1 -and\n                 $_.GetParameters()[0].ParameterType.Name -eq \'IAsyncOperation`1\' })[0]\nfunction Await($op, $type) {\n  $t = $asTask.MakeGenericMethod($type).Invoke($null, @($op))\n  $t.Wait(30000) | Out-Null\n  $t.Result\n}\n'

def _is_natural(name: str) -> bool:
    low = (name or '').lower()
    return 'natural' in low and 'online' not in low

def _base_name(name: str) -> str:
    n = (name or '').strip()
    if ' - ' in n:
        n = n.split(' - ', 1)[0]
    for tail in (' Desktop',):
        if n.endswith(tail):
            n = n[:-len(tail)]
    return n.strip()

def _display(name: str) -> str:
    n = (name or '').strip()
    if ' - ' in n:
        n = n.split(' - ', 1)[0]
    return n.strip()

# APPLE SHIPS JOKE VOICES IN THE SAME LIST AS THE REAL ONES. `say -v '?'`
# returns Bahh, Boing, Bubbles, Jester, Zarvox and friends next to Samantha and
# Daniel, sorted alphabetically -- so the first English voice on a stock Mac is
# "Albert", a comedy voice. Kara reads a disabled user's own writing back to
# them. Picking a novelty voice by default is not a cosmetic bug, so these are
# excluded from the catalogue rather than merely ranked below the good ones.
_MAC_NOVELTY = {
    'albert', 'bad news', 'bahh', 'bells', 'boing', 'bubbles', 'cellos',
    'deranged', 'good news', 'grandma', 'grandpa', 'hysterical', 'jester',
    'junior', 'kathy', 'organ', 'ralph', 'superstar', 'trinoids', 'whisper',
    'wobble', 'zarvox', 'bruce', 'agnes', 'princess', 'fred', 'eddy', 'flo',
    'reed', 'rocko', 'sandy', 'shelley',
}

# The voices Apple actually intends for reading prose, best first.
_MAC_PREFERRED = ('samantha', 'alex', 'ava', 'allison', 'susan', 'tom',
                  'daniel', 'serena', 'kate', 'oliver', 'stephanie',
                  'karen', 'lee', 'moira', 'tessa', 'fiona', 'rishi', 'veena')


def _mac_base_name(name: str) -> str:
    """'Eddy (English (UK))' -> 'eddy'. The novelty list names the voice, not
    each of its fifteen per-language clones."""
    return (name or '').split('(', 1)[0].strip().lower()


def _mac_voices() -> list[Voice]:
    """The voices `say` can use. UNLIKE THE WINDOWS SAPI SET THESE ARE NOT A
    last resort: Apple's Premium and Enhanced voices are neural and read
    perfectly well, so catalogue() does not hide them the way it hides SAPI.
    A Mac with no Piper download is still fully usable."""
    found = []
    for v in osbridge.tts_voices():
        name = (v.get('name') or '').strip()
        if not name or _mac_base_name(name) in _MAC_NOVELTY:
            continue
        found.append(Voice(id=f'mac:{name}', name=name, engine='mac',
                           language=v.get('lang') or '',
                           natural=bool(v.get('natural')), token=name))
    return found


def _mac_rank(v: Voice) -> tuple:
    """Best English voice first, then anything else. Kara's spoken language is
    configurable, so the preferred language leads rather than 'en' always."""
    try:
        import config as _config
        want = (_config.load().get('language') or 'en').strip().lower()
    except Exception:
        want = 'en'
    lang = (v.language or '').lower()
    base = _mac_base_name(v.name)
    pref = _MAC_PREFERRED.index(base) if base in _MAC_PREFERRED else len(_MAC_PREFERRED)
    return (not lang.startswith(want), not v.natural, pref, v.name)


def _system_voices() -> list[Voice]:
    return _mac_voices() if osbridge.IS_MAC else _windows_voices()


def _windows_voices() -> list[Voice]:
    if not osbridge.IS_WINDOWS:
        return []
    try:
        out = _run(_ENUMERATE).stdout
        data = json.loads(out) if (out or '').strip() else []
    except Exception:
        return []
    if isinstance(data, dict):
        data = [data]
    found = []
    for d in data:
        name = str(d.get('name') or '').strip()
        if not name:
            continue
        engine = str(d.get('engine') or 'sapi')
        found.append(Voice(id=f'{engine}:{_display(name)}', name=_display(name), engine=engine, language=str(d.get('lang') or '').strip(), gender=str(d.get('gender') or '').strip(), natural=_is_natural(name), size=int(d.get('bytes') or 0), token=str(d.get('token') or '')))
    return found
PIPER_RELEASE = osbridge.PIPER_RELEASE

def piper_installed() -> bool:
    return PIPER_EXE.exists()

def install_piper(progress=None) -> tuple[bool, str]:
    if piper_installed():
        return (True, '')
    import io
    import shutil
    import tempfile
    import urllib.request
    import zipfile
    try:
        if progress:
            progress('Getting the speech engine (21 MB)…')
        with urllib.request.urlopen(PIPER_RELEASE, timeout=300) as r:
            blob = r.read()
        tmp = Path(tempfile.mkdtemp(prefix='kara_piper_'))
        if PIPER_RELEASE.endswith(('.tar.gz', '.tgz')):
            import tarfile
            with tarfile.open(fileobj=io.BytesIO(blob), mode='r:gz') as tf:
                tf.extractall(tmp)
        else:
            with zipfile.ZipFile(io.BytesIO(blob)) as z:
                z.extractall(tmp)
        found = next(tmp.rglob(osbridge.PIPER_BINARY), None)
        if found is None:
            return (False, f'the download did not contain {osbridge.PIPER_BINARY}')
        PIPER_DIR.mkdir(parents=True, exist_ok=True)
        for item in found.parent.iterdir():
            target = PIPER_DIR / item.name
            if item.is_dir():
                shutil.copytree(item, target, dirs_exist_ok=True)
            else:
                shutil.copy2(item, target)
        shutil.rmtree(tmp, ignore_errors=True)
        return (piper_installed(), '' if piper_installed() else 'unpack failed')
    except Exception as e:
        return (False, type(e).__name__)

def _piper_voices() -> list[Voice]:
    if not piper_installed() or not PIPER_VOICES.is_dir():
        return []
    found = []
    for model in sorted(PIPER_VOICES.glob('*.onnx')):
        meta = {}
        try:
            meta = json.loads(model.with_suffix('.onnx.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            pass
        lang = ''
        lg = meta.get('language') or {}
        if isinstance(lg, dict):
            lang = str(lg.get('name_english') or lg.get('code') or '')
        try:
            size = model.stat().st_size
        except OSError:
            size = 0
        stem = model.stem
        parts = stem.split('-')
        who = parts[1] if len(parts) > 1 else stem
        pretty = ' '.join((w.capitalize() for w in who.split('_')))
        found.append(Voice(id=f'piper:{stem}', name=pretty, engine='piper', language=lang, natural=True, size=size, token=stem))
    return found

def _piper_speak_to_wav(text: str, out_path: Path, model: Path, rate: int=0) -> bool:
    scale = max(0.5, min(2.0, 1.0 - int(rate) * 0.06))
    try:
        subprocess.run([str(PIPER_EXE), '-m', str(model), '-f', str(out_path), '--length-scale', f'{scale:.2f}'], input=(text or '').encode('utf-8'), capture_output=True, creationflags=_NO_WINDOW, timeout=120)
    except Exception:
        return False
    return out_path.exists() and out_path.stat().st_size > 0

def all_installed(refresh: bool=False) -> list[Voice]:
    global _CACHE
    if _CACHE is not None and (not refresh):
        return _CACHE
    found = _piper_voices() + _system_voices()
    rank = {'piper': 0, 'mac': 1, 'winrt': 2, 'sapi': 3}
    best: dict[str, Voice] = {}
    for v in found:
        key = _base_name(v.name).lower()
        cur = best.get(key)
        if cur is None or (not cur.natural, rank.get(cur.engine, 9)) > (not v.natural, rank.get(v.engine, 9)):
            best[key] = v
    out = sorted(best.values(), key=lambda v: (not v.natural, rank.get(v.engine, 9), v.name))
    if osbridge.IS_MAC:
        out = sorted(out, key=lambda v: (rank.get(v.engine, 9),) + _mac_rank(v))
    _CACHE = out
    return out

def catalogue(refresh: bool=False) -> list[Voice]:
    every = all_installed(refresh)
    if os.environ.get('KARA_ALLOW_LEGACY_VOICES') == '1':
        return every
    # 'legacy' MEANS SAPI, NOT 'NOT PIPER'. The Windows filter exists because
    # SAPI voices sound like 1998 and Kara would rather say nothing. macOS
    # system voices are a different thing entirely, so they stay.
    return [v for v in every if v.engine in ('piper', 'mac')]

def legacy_only() -> bool:
    every = all_installed()
    return bool(every) and (not any((v.engine in ('piper', 'mac') for v in every)))

def find(voice_id: str | None) -> Voice | None:
    if not voice_id:
        return None
    pool = all_installed()
    for v in pool:
        if v.id == voice_id:
            return v
    want = voice_id.split(':', 1)[-1].lower()
    for v in pool:
        if v.name.lower() == want:
            return v
    return None

def default() -> Voice | None:
    good = catalogue()
    return good[0] if good else None
PIPER_CATALOGUE = [('en_GB-alba-medium', 'Alba · Scottish English · female', 63500000), ('en_GB-cori-high', 'Cori · British English · female', 113000000), ('en_GB-northern_english_male-medium', 'Northern English · male', 63500000), ('en_GB-jenny_dioco-medium', 'Jenny · British English · female', 63500000), ('en_US-amy-medium', 'Amy · American English · female', 63500000), ('en_US-ryan-high', 'Ryan · American English · male', 113000000), ('en_US-lessac-high', 'Lessac · American English · female', 113000000), ('en_US-hfc_male-medium', 'HFC · American English · male', 63500000), ('en_US-libritts_r-medium', 'LibriTTS · many speakers', 76000000)]
PIPER_BASE = 'https://huggingface.co/rhasspy/piper-voices/resolve/main/en/{locale}/{speaker}/{quality}/{stem}.onnx'

def piper_download_url(stem: str) -> tuple[str, str]:
    locale, speaker, quality = stem.split('-', 2)
    url = PIPER_BASE.format(locale=locale, speaker=speaker, quality=quality, stem=stem)
    return (url, url + '.json')

def _text_file(text: str) -> Path:
    f = tempfile.NamedTemporaryFile('w', suffix='.txt', delete=False, encoding='utf-8')
    f.write(text or '')
    f.close()
    return Path(f.name)

def _ps_path(p: Path) -> str:
    return str(p).replace("'", "''")

def to_wav(text: str, out_path: Path | str, voice_id: str | None=None, rate: int=0) -> bool:
    if not (text or '').strip():
        return False
    out_path = Path(out_path)
    voice = find(voice_id) or default()
    if voice is not None and voice.engine == 'piper':
        return _piper_speak_to_wav(text, out_path, PIPER_VOICES / f'{voice.token}.onnx', rate)
    if voice is not None and voice.engine == 'mac':
        return osbridge.tts_to_wav(text, out_path, voice.token, rate)
    if osbridge.IS_MAC:
        # No voice resolved but this is a Mac: `say` with the system default
        # still beats returning False and leaving Kara mute.
        return osbridge.tts_to_wav(text, out_path, None, rate)
    src = _text_file(text)
    try:
        if voice is not None and voice.engine == 'winrt':
            delta = max(-90, min(200, int(rate) * 12))
            open_p = f"<prosody rate='{delta:+d}%'>" if delta else ''
            close_p = '</prosody>' if delta else ''
            script = _WINRT_HEAD + f"""\n$txt = [IO.File]::ReadAllText('{_ps_path(src)}', [Text.Encoding]::UTF8)\n$synth = New-Object Windows.Media.SpeechSynthesis.SpeechSynthesizer\n$v = [Windows.Media.SpeechSynthesis.SpeechSynthesizer]::AllVoices |\n     Where-Object {{ $_.DisplayName -like '{voice.name}*' }} | Select-Object -First 1\nif ($v) {{ $synth.Voice = $v }}\n$esc = [System.Security.SecurityElement]::Escape($txt)\n$ssml = "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>" +\n        "{open_p}" + $esc + "{close_p}</speak>"\n$stream = Await ($synth.SynthesizeSsmlToStreamAsync($ssml)) ([Windows.Media.SpeechSynthesis.SpeechSynthesisStream])\n$reader = New-Object Windows.Storage.Streams.DataReader($stream)\nAwait ($reader.LoadAsync($stream.Size)) ([uint32]) | Out-Null\n$bytes = New-Object byte[] $stream.Size\n$reader.ReadBytes($bytes)\n[IO.File]::WriteAllBytes('{_ps_path(out_path)}', $bytes)\n"""
        else:
            select = f"$s.SelectVoice('{voice.name}'); " if voice else ''
            script = f"Add-Type -AssemblyName System.Speech; $txt = [IO.File]::ReadAllText('{_ps_path(src)}', [Text.Encoding]::UTF8); $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; {select}$s.Rate = {max(-10, min(10, int(rate)))}; $s.SetOutputToWaveFile('{_ps_path(out_path)}'); $s.Speak($txt); $s.Dispose()"
        _run(script)
    except Exception:
        return False
    finally:
        try:
            src.unlink()
        except OSError:
            pass
    return out_path.exists() and out_path.stat().st_size > 0
def _for_device(data, sr: int, device):
    """Resample to whatever rate the output device actually runs at.

    PortAudio will happily accept a stream at a rate the device is not running
    at and then not convert it, so the pitch comes out wrong. Asking the device
    what it wants and meeting it there is the only reliable way through
    sounddevice. Returns the input untouched if anything about that fails --
    playing at a slightly wrong rate beats not playing at all.
    """
    # macOS ONLY. PortAudio's CoreAudio backend is the one that does not
    # resample; the Windows backends do, and Windows playback was working
    # before this function existed. Changing behaviour on a platform that has
    # no bug is how a fix becomes a regression.
    if not osbridge.IS_MAC:
        return (data, sr)
    try:
        import sounddevice as sd
        info = sd.query_devices(device if device is not None else sd.default.device[1],
                                'output')
        want = int(round(float(info['default_samplerate'])))
        if not want or want == int(sr):
            return (data, sr)
        import soxr
        return (soxr.resample(data, sr, want, quality='HQ').astype('float32'), want)
    except Exception:
        return (data, sr)

_stop_playing = threading.Event()

def stop_speaking() -> None:
    _stop_playing.set()
    try:
        import sounddevice as sd
        sd.stop()
    except Exception:
        pass

def speak_tracked(text: str, voice_id: str | None=None, device=None, rate: int=0) -> float:
    _stop_playing.clear()
    if not (text or '').strip():
        return 1.0
    wav = Path(tempfile.NamedTemporaryFile(suffix='.wav', delete=False).name)
    try:
        if not to_wav(text, wav, voice_id, rate):
            return 1.0
        import sounddevice as sd
        import soundfile as sf
        data, sr = sf.read(str(wav), dtype='float32')
        total = len(data) / float(sr) if sr else 0.0
        if total <= 0:
            return 1.0
        started = time.monotonic()
        # macOS, default output: hand the file to CoreAudio. PortAudio does not
        # resample on this platform, and Kara's voices are 22.05 kHz against
        # speakers running at 48 kHz -- which is what made the read-aloud
        # button sound like a bass rumble while `say` sounded fine.
        proc = osbridge.audio_player(wav) if device is None else None
        if proc is not None:
            while proc.poll() is None:
                if _stop_playing.is_set():
                    try:
                        proc.kill()
                    except Exception:
                        pass
                    return min(1.0, (time.monotonic() - started) / total)
                time.sleep(0.03)
            return 1.0
        data, sr = _for_device(data, sr, device)
        sd.play(data, sr, device=device)
        while time.monotonic() - started < total:
            if _stop_playing.is_set():
                sd.stop()
                return min(1.0, (time.monotonic() - started) / total)
            time.sleep(0.03)
        sd.wait()
        return 1.0
    except Exception:
        return 1.0
    finally:
        try:
            wav.unlink()
        except OSError:
            pass

def speak(text: str, voice_id: str | None=None, device=None, rate: int=0) -> None:
    if not (text or '').strip():
        return
    voice = find(voice_id) or default()
    if device is None and osbridge.IS_MAC:
        # Straight to the default output with no temp file, which is both
        # faster and what `say` is for.
        osbridge.tts_speak_direct(text, voice.token if voice and voice.engine == 'mac' else None, rate)
        return
    if device is None and voice is not None and (voice.engine == 'sapi'):
        src = _text_file(text)
        try:
            _run(f"Add-Type -AssemblyName System.Speech; $txt = [IO.File]::ReadAllText('{_ps_path(src)}', [Text.Encoding]::UTF8); $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.SelectVoice('{voice.name}'); $s.Rate = {max(-10, min(10, int(rate)))}; $s.Speak($txt)")
        except Exception:
            pass
        finally:
            try:
                src.unlink()
            except OSError:
                pass
        return
    wav = Path(tempfile.NamedTemporaryFile(suffix='.wav', delete=False).name)
    try:
        if not to_wav(text, wav, voice_id, rate):
            return
        import sounddevice as sd
        import soundfile as sf
        proc = osbridge.audio_player(wav) if device is None else None
        if proc is not None:
            proc.wait()
            return
        data, sr = sf.read(str(wav), dtype='float32')
        data, sr = _for_device(data, sr, device)
        sd.play(data, sr, device=device)
        sd.wait()
    except Exception:
        pass
    finally:
        try:
            wav.unlink()
        except OSError:
            pass
