"""Windows backend for the platform layer. See osbridge.py for the contract.

THE CODE HERE IS LIFTED, NOT REWRITTEN. Every function is the one that shipped
in v1.53, moved out of app.py and gui.py so that the macOS backend has
something to be symmetrical with. Behaviour on Windows is meant to be
unchanged, so the comments explaining *why* each Win32 dance is shaped the way
it is have come with it -- those were bought with real first-run failures.
"""
from __future__ import annotations

import os
import subprocess
import threading
import time
from pathlib import Path

PASTE_SETTLE = 0.16
CLIPBOARD_RESTORE_AFTER = 2.0

VK_CONTROL, VK_SHIFT, VK_BACK, VK_RETURN, VK_TAB, VK_SPACE = 17, 16, 8, 13, 9, 32
VK_LEFT, VK_Z, VK_Y, VK_A = 37, 90, 89, 65

KEYSTROKES = {
    'delete_word': (VK_BACK, [VK_CONTROL]),
    'backspace': (VK_BACK, []),
    'press_enter': (VK_RETURN, []),
    'new_line': (VK_RETURN, []),
    'tab': (VK_TAB, []),
    'space': (VK_SPACE, []),
    'select_last': (VK_LEFT, [VK_CONTROL, VK_SHIFT]),
    'undo': (VK_Z, [VK_CONTROL]),
    'redo': (VK_Y, [VK_CONTROL]),
    'clear': (VK_A, [VK_CONTROL]),
}

_TEXT_CLASSES = ('edit', 'richedit', 'textbox', 'scintilla', '_wwg', 'excel',
                 'opusapp', 'qwidget', 'qt5', 'qt6', 'consolewindowclass',
                 'pseudoconsolewindow')

NO_WINDOW = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
TRASH_NAME = 'Recycle Bin'

# Windows needs no permission to synthesise input into another window.
PERMISSION_HINT = ''


def accessibility_granted(prompt: bool = False) -> bool:
    return True


def open_accessibility_settings() -> bool:
    return False


def _user32():
    import ctypes
    from ctypes import wintypes
    u = ctypes.WinDLL('user32')
    u.GetForegroundWindow.restype = wintypes.HWND
    u.SetForegroundWindow.argtypes = [wintypes.HWND]
    u.SetForegroundWindow.restype = wintypes.BOOL
    u.IsWindow.argtypes = [wintypes.HWND]
    u.IsWindow.restype = wintypes.BOOL
    u.IsIconic.argtypes = [wintypes.HWND]
    u.IsIconic.restype = wintypes.BOOL
    u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    u.BringWindowToTop.argtypes = [wintypes.HWND]
    u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.c_void_p]
    u.GetWindowThreadProcessId.restype = wintypes.DWORD
    u.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    u.GetClassNameW.restype = ctypes.c_int
    return u


def _gui_thread_info_type(C, wintypes):
    class GUITHREADINFO(C.Structure):
        _fields_ = [('cbSize', wintypes.DWORD), ('flags', wintypes.DWORD),
                    ('hwndActive', wintypes.HWND), ('hwndFocus', wintypes.HWND),
                    ('hwndCapture', wintypes.HWND), ('hwndMenuOwner', wintypes.HWND),
                    ('hwndMoveSize', wintypes.HWND), ('hwndCaret', wintypes.HWND),
                    ('rcCaret', wintypes.RECT)]
    return GUITHREADINFO


def caret_info() -> dict:
    facts = {'hwnd': 0, 'focus_class': '', 'has_caret': False, 'looks_like_text': False}
    try:
        import ctypes as C
        from ctypes import wintypes
        u = _user32()
        hwnd = u.GetForegroundWindow()
        if not hwnd:
            return facts
        facts['hwnd'] = int(hwnd)
        tid = u.GetWindowThreadProcessId(hwnd, None)
        GUITHREADINFO = _gui_thread_info_type(C, wintypes)
        gti = GUITHREADINFO()
        gti.cbSize = C.sizeof(GUITHREADINFO)
        u.GetGUIThreadInfo.argtypes = [wintypes.DWORD, C.POINTER(GUITHREADINFO)]
        u.GetGUIThreadInfo.restype = wintypes.BOOL
        if not u.GetGUIThreadInfo(tid, C.byref(gti)):
            return facts
        facts['has_caret'] = bool(gti.hwndCaret)
        focus = gti.hwndFocus or hwnd
        buf = C.create_unicode_buffer(256)
        u.GetClassNameW(focus, buf, 256)
        cls = (buf.value or '').strip().lower()
        facts['focus_class'] = cls
        facts['looks_like_text'] = cls.startswith(_TEXT_CLASSES)
    except Exception:
        return facts
    return facts


def window_is_alive(handle: int) -> bool:
    return bool(handle) and bool(_user32().IsWindow(handle))


def focus_window(handle: int) -> tuple[bool, str]:
    import ctypes
    u = _user32()
    k = ctypes.WinDLL('kernel32')
    if not handle or not u.IsWindow(handle):
        return (False, 'gone')
    if u.GetForegroundWindow() == handle:
        return (True, '')
    for _ in range(3):
        fg = u.GetForegroundWindow()
        fg_tid = u.GetWindowThreadProcessId(fg, None) if fg else 0
        tgt_tid = u.GetWindowThreadProcessId(handle, None)
        cur_tid = k.GetCurrentThreadId()
        attached = []
        for tid in {fg_tid, tgt_tid}:
            if tid and tid != cur_tid and u.AttachThreadInput(tid, cur_tid, True):
                attached.append(tid)
        try:
            if u.IsIconic(handle):
                u.ShowWindow(handle, 9)
            u.BringWindowToTop(handle)
            u.SetForegroundWindow(handle)
        finally:
            for tid in attached:
                u.AttachThreadInput(tid, cur_tid, False)
        for _ in range(10):
            if u.GetForegroundWindow() == handle:
                return (True, '')
            time.sleep(0.02)
    return (False, 'refused')


def foreground_target() -> tuple[int, str, str]:
    """(hwnd, window title, process name). Third value is the process name so
    the caller can match it against its known-text-apps table -- macOS returns
    a bundle id in the same slot."""
    import ctypes
    try:
        u = ctypes.windll.user32
        hwnd = u.GetForegroundWindow()
        if not hwnd:
            return (0, '', '')
        length = u.GetWindowTextLengthW(hwnd)
        if not length:
            return (int(hwnd), '', process_name(int(hwnd)))
        buf = ctypes.create_unicode_buffer(length + 1)
        u.GetWindowTextW(hwnd, buf, length + 1)
        return (int(hwnd), (buf.value or '').strip(), process_name(int(hwnd)))
    except Exception:
        return (0, '', '')


def process_name(handle: int) -> str:
    import ctypes
    try:
        import psutil
        pid = ctypes.c_ulong()
        ctypes.windll.user32.GetWindowThreadProcessId(handle, ctypes.byref(pid))
        if not pid.value:
            return ''
        return psutil.Process(pid.value).name().lower()
    except Exception:
        return ''


def find_titled_window(title: str) -> int:
    if not title:
        return 0
    import ctypes
    from ctypes import wintypes
    u = ctypes.windll.user32
    found = []

    @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    def visit(h, _):
        if not u.IsWindowVisible(h):
            return True
        n = u.GetWindowTextLengthW(h)
        if not n:
            return True
        b = ctypes.create_unicode_buffer(n + 1)
        u.GetWindowTextW(h, b, n + 1)
        if b.value.strip() == title:
            found.append(h)
            return False
        return True
    u.EnumWindows(visit, 0)
    return found[0] if found else 0


def press_keys(handle: int | None, key: int, modifiers=()) -> dict:
    import ctypes
    if handle:
        focused, why = focus_window(handle)
        if not focused:
            return {'ok': False, 'focused': False, 'gone': why == 'gone', 'reason': why}
    time.sleep(0.05)
    u = ctypes.windll.user32
    KEYUP = 2
    for m in modifiers:
        u.keybd_event(m, 0, 0, 0)
    u.keybd_event(key, 0, 0, 0)
    u.keybd_event(key, 0, KEYUP, 0)
    for m in reversed(list(modifiers)):
        u.keybd_event(m, 0, KEYUP, 0)
    return {'ok': True, 'focused': True, 'gone': False, 'reason': ''}


def inject_text(text: str, handle: int | None = None, restore_clipboard: bool = True) -> dict:
    import ctypes
    import pyperclip
    previous = None
    if restore_clipboard:
        try:
            previous = pyperclip.paste()
        except Exception:
            previous = None
    try:
        pyperclip.copy(text)
    except Exception as e:
        return {'ok': False, 'focused': False, 'on_clipboard': False,
                'gone': False, 'reason': f'clipboard unavailable: {e}'}
    focused, gone = True, False
    if handle:
        focused, why = focus_window(handle)
        if not focused:
            gone = why == 'gone'
            return {'ok': False, 'focused': False, 'on_clipboard': True, 'gone': gone,
                    'reason': 'the target window no longer exists' if gone
                              else 'the target window would not come to the front'}
    time.sleep(PASTE_SETTLE)
    u = ctypes.windll.user32
    VK_CTRL, VK_V, KEYUP = 17, 86, 2
    u.keybd_event(VK_CTRL, 0, 0, 0)
    u.keybd_event(VK_V, 0, 0, 0)
    u.keybd_event(VK_V, 0, KEYUP, 0)
    u.keybd_event(VK_CTRL, 0, KEYUP, 0)
    if restore_clipboard and previous is not None and previous != text:
        def _restore_later(old=previous):
            time.sleep(CLIPBOARD_RESTORE_AFTER)
            try:
                import pyperclip as _pc
                _pc.copy(old)
            except Exception:
                pass
        threading.Thread(target=_restore_later, daemon=True, name='kara-clipboard').start()
    return {'ok': True, 'focused': focused, 'on_clipboard': True, 'gone': False, 'reason': ''}


def app_support_dir() -> Path:
    return Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'Kara'


def trash(path: Path) -> bool:
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [('hwnd', wintypes.HWND), ('wFunc', wintypes.UINT),
                    ('pFrom', wintypes.LPCWSTR), ('pTo', wintypes.LPCWSTR),
                    ('fFlags', ctypes.c_uint16),
                    ('fAnyOperationsAborted', wintypes.BOOL),
                    ('hNameMappings', wintypes.LPVOID),
                    ('lpszProgressTitle', wintypes.LPCWSTR)]
    FO_DELETE, FOF_ALLOWUNDO, FOF_NOCONFIRMATION, FOF_SILENT = 3, 0x0040, 0x0010, 0x0004
    op = SHFILEOPSTRUCTW()
    op.wFunc = FO_DELETE
    op.pFrom = str(path) + '\0\0'
    op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT
    try:
        rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
        return rc == 0 and not op.fAnyOperationsAborted
    except Exception:
        return False


def reveal(path: Path) -> bool:
    try:
        os.startfile(str(path if Path(path).is_dir() else Path(path).parent))
        return True
    except Exception:
        return False


def python_exe(current: Path) -> Path:
    """pythonw.exe cannot show a console, so a child that needs one gets the
    plain interpreter beside it."""
    if current.name.lower() == 'pythonw.exe':
        return current.with_name('python.exe')
    return current


_INSTANCE_MUTEX = None


def claim_single_instance(app_name: str = 'Kara') -> bool:
    global _INSTANCE_MUTEX
    import ctypes
    ERROR_ALREADY_EXISTS = 183
    try:
        k32 = ctypes.WinDLL('kernel32', use_last_error=True)
        k32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        k32.CreateMutexW.restype = ctypes.c_void_p
        k32.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = k32.CreateMutexW(None, False, 'Local\\Kara.VoiceToText.Desktop.1')
        if not handle:
            return True
        if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
            k32.CloseHandle(handle)
            return False
        _INSTANCE_MUTEX = handle
        return True
    except Exception:
        return True


def release_single_instance() -> None:
    global _INSTANCE_MUTEX
    if not _INSTANCE_MUTEX:
        return
    try:
        import ctypes
        k32 = ctypes.WinDLL('kernel32', use_last_error=True)
        k32.CloseHandle.argtypes = [ctypes.c_void_p]
        k32.CloseHandle(_INSTANCE_MUTEX)
    except Exception:
        pass
    finally:
        _INSTANCE_MUTEX = None


def wake_running_app(app_name: str = 'Kara') -> bool:
    import ctypes
    try:
        u = ctypes.windll.user32
        found = []

        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def visit(hwnd, _lparam):
            pid = ctypes.c_ulong()
            u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if pid.value == os.getpid():
                return True
            length = u.GetWindowTextLengthW(hwnd)
            if not length:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            u.GetWindowTextW(hwnd, buf, length + 1)
            if buf.value.strip() == app_name:
                found.append((bool(u.IsWindowVisible(hwnd)), hwnd))
            return True
        u.EnumWindows(visit, 0)
        if not found:
            return False
        found.sort(key=lambda x: not x[0])
        hwnd = found[0][1]
        u.ShowWindow(hwnd, 9)
        u.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False


def set_app_id(app_id: str) -> None:
    import ctypes
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass


def theme_titlebar(widget) -> None:
    import ctypes
    try:
        import contrast
        hwnd = int(widget.winId())
        dwm = ctypes.windll.dwmapi

        def colorref(hex_colour: str) -> int:
            h = hex_colour.lstrip('#')
            r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            return b << 16 | g << 8 | r

        DWMWA_USE_IMMERSIVE_DARK_MODE, DWMWA_BORDER_COLOR = 20, 34
        DWMWA_CAPTION_COLOR, DWMWA_TEXT_COLOR = 35, 36

        def attr(which: int, value: int) -> None:
            v = ctypes.c_int(value)
            dwm.DwmSetWindowAttribute(ctypes.c_void_p(hwnd), ctypes.c_int(which),
                                      ctypes.byref(v), ctypes.sizeof(v))
        import gui as _gui
        P = _gui.P
        dark_caption = contrast.luminance(P['canvas']) < 0.4
        attr(DWMWA_USE_IMMERSIVE_DARK_MODE, 1 if dark_caption else 0)
        attr(DWMWA_CAPTION_COLOR, colorref(P['canvas']))
        attr(DWMWA_BORDER_COLOR, colorref(P['line']))
        attr(DWMWA_TEXT_COLOR, colorref(P['canvas']))
    except Exception as e:
        try:
            import karalog
            karalog.get('gui').info('could not theme the title bar: %s', e)
        except Exception:
            pass


def tts_voices() -> list[dict]:
    """voices.py owns the PowerShell enumeration on Windows; it is left there
    because it also reads voice file sizes off the registry, which has no
    counterpart to abstract against."""
    return []


def _ps_speak(script: str) -> bool:
    try:
        r = subprocess.run(['powershell', '-NoProfile', '-NonInteractive', '-Command', script],
                           capture_output=True, creationflags=NO_WINDOW, timeout=180)
        return r.returncode == 0
    except Exception:
        return False


def _ps_quote(text: str) -> str:
    return (text or '').replace("'", "''")


def tts_to_wav(text: str, out_path: Path, voice_name: str | None = None, rate: int = 0) -> bool:
    """System.Speech to a wav file.

    THESE TWO WERE STUBS RETURNING FALSE when the platform layer was first
    split out, on the assumption that voices.py owned all Windows speech. It
    does not: editing.speak() falls back to the platform layer whenever
    voices.catalogue() is empty, which on Windows is any machine without Piper
    voices installed. Stubbing them made that fallback silent -- Kara would
    simply not speak, with no error. Restored to the PowerShell SAPI calls that
    lived in editing.py before the split.
    """
    safe, path = _ps_quote(text), str(out_path).replace("'", "''")
    select = f"$s.SelectVoice('{_ps_quote(voice_name)}'); " if voice_name else ''
    ok = _ps_speak(
        "Add-Type -AssemblyName System.Speech; "
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        f"{select}$s.Rate = {max(-10, min(10, int(rate)))}; "
        f"$s.SetOutputToWaveFile('{path}'); $s.Speak('{safe}'); $s.Dispose()")
    return ok and out_path.exists() and out_path.stat().st_size > 0


def tts_speak_direct(text: str, voice_name: str | None = None, rate: int = 0) -> bool:
    safe = _ps_quote(text)
    select = f"$s.SelectVoice('{_ps_quote(voice_name)}'); " if voice_name else ''
    return _ps_speak(
        "Add-Type -AssemblyName System.Speech; "
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
        f"{select}$s.Rate = {max(-10, min(10, int(rate)))}; $s.Speak('{safe}')")


def audio_player(path: Path):
    """Windows plays through sounddevice, which behaves there. Returning None
    tells the caller to use its own path, so nothing changes on Windows."""
    return None


PIPER_RELEASE = ('https://github.com/rhasspy/piper/releases/download/'
                 '2023.11.14-2/piper_windows_amd64.zip')
PIPER_BINARY = 'piper.exe'


def register_app(root: Path, version: str, log=None) -> bool:
    import appreg
    return appreg.ensure_registered(root, version, log)
