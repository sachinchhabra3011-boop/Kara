import argparse
import csv
import gc
import json
import platform
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
MODELS = {'tiny': {'params': '39M', 'min_ram_gb': 2, 'min_vram_gb': 1, 'typical_wer': 'not measured', 'needs_cuda': False}, 'base': {'params': '74M', 'min_ram_gb': 4, 'min_vram_gb': 2, 'typical_wer': 'not measured', 'needs_cuda': False}, 'small': {'params': '244M', 'min_ram_gb': 6, 'min_vram_gb': 3, 'typical_wer': '~7%', 'needs_cuda': False}, 'medium': {'params': '769M', 'min_ram_gb': 12, 'min_vram_gb': 6, 'typical_wer': '~4.5%', 'needs_cuda': False}, 'large-v3-turbo': {'params': '809M', 'min_ram_gb': 16, 'min_vram_gb': 6, 'typical_wer': 'not measured', 'needs_cuda': True}, 'large-v3': {'params': '1.55B', 'min_ram_gb': 32, 'min_vram_gb': 10, 'typical_wer': '~4.5%', 'needs_cuda': True}}
SEC_PER_STEP_3060 = {'tiny': 0.1, 'base': 0.18, 'small': 0.53, 'medium': 1.46, 'large-v3-turbo': 1.6, 'large-v3': 3.3}
MEASURED_SIZES = {'small', 'medium'}
BATCH = 2
EPOCHS = 10
WARMUP_STEPS = 1
EVAL_OVERHEAD = 1.25

def detect() -> dict:
    import torch
    hw = {'cpu': platform.processor() or platform.machine(), 'cuda': torch.cuda.is_available(), 'gpu': None, 'vram_gb': 0.0, 'ram_gb': 0.0, 'cores_physical': None, 'cores_logical': None}
    try:
        import psutil
        hw['ram_gb'] = round(psutil.virtual_memory().total / 1000000000.0, 1)
        hw['cores_physical'] = psutil.cpu_count(logical=False)
        hw['cores_logical'] = psutil.cpu_count()
    except Exception:
        pass
    if hw['cuda']:
        hw['gpu'] = torch.cuda.get_device_name(0)
        hw['vram_gb'] = round(torch.cuda.get_device_properties(0).total_memory / 1000000000.0, 1)
    else:
        try:
            import osbridge
            if osbridge.IS_MAC:
                # platform.processor() answers 'arm' on Apple Silicon, which is
                # shown to the user on the Measure-this-machine page and tells
                # them nothing. macOS knows the actual chip; ask it.
                import subprocess
                r = subprocess.run(['sysctl', '-n', 'machdep.cpu.brand_string'],
                                   capture_output=True, encoding='utf-8',
                                   errors='replace', timeout=10)
                name = (r.stdout or '').strip()
                if name:
                    hw['cpu'] = name
                # Apple Silicon has no separate VRAM: the GPU shares system
                # memory. Report it as the accelerator without inventing a
                # vram figure, so viable() keeps gating on cuda as before.
                if torch.backends.mps.is_available():
                    hw['mps'] = True
                    hw['gpu'] = f"{name or 'Apple Silicon'} (shared memory)"
        except Exception:
            pass
    return hw

def count_clips(speaker: str) -> int:
    manifest = ROOT / 'data' / speaker / 'manifest.csv'
    if not manifest.exists():
        return 0
    try:
        with manifest.open(encoding='utf-8-sig', newline='') as f:
            return sum((1 for _ in csv.DictReader(f)))
    except OSError:
        return 0

def viable(model: str, hw: dict) -> tuple[bool, str, str]:
    """Can this machine train this size, and on what.

    'needs_cuda' USED TO BE A FLAT REFUSAL, and on a Mac that told the user
    something untrue: the big models are not impossible here, they are slow.
    A machine with no NVIDIA card was shown "needs an NVIDIA GPU with 10 GB+"
    for a model its 25 GB of memory could in fact train, which reads as a
    hardware verdict rather than the speed trade-off it actually is.

    So CUDA is still the fast path, and where there is no CUDA the decision
    falls through to memory -- which is the real constraint. min_ram_gb was
    already in the table for exactly this. Kara shows the measured hours beside
    every size, so the user can see what "slow" costs and decide for
    themselves; that is more use than being told no.
    """
    spec = MODELS[model]
    if hw['cuda'] and hw['vram_gb'] >= spec['min_vram_gb']:
        return (True, 'cuda', '')
    if spec['needs_cuda'] and hw['cuda']:
        return (False, '', f"needs an NVIDIA GPU with {spec['min_vram_gb']} GB+ (only {hw['vram_gb']} GB)")
    if not hw['ram_gb']:
        return (True, 'cpu', '')
    if hw['ram_gb'] >= spec['min_ram_gb']:
        return (True, 'cpu', '')
    return (False, '', f"needs {spec['min_ram_gb']} GB of memory (this computer has {hw['ram_gb']} GB)")

def hours(per_step: float, clips: int, epochs: int=EPOCHS) -> float:
    steps = -(-max(clips, 1) // BATCH) * epochs
    return steps * per_step * EVAL_OVERHEAD / 3600

def human(h: float) -> str:
    if h <= 0:
        return '—'
    if h < 1:
        return f'{round(h * 60)} min'
    if h < 10:
        return f'{h:.1f} h'
    return f'{round(h)} h'

def estimate_report(speaker: str, clips: int | None=None, sec_per_step: dict | None=None) -> dict:
    hw = detect()
    clips = count_clips(speaker) if clips is None else clips
    sps = dict(SEC_PER_STEP_3060)
    if sec_per_step:
        sps.update(sec_per_step)
    options = []
    for name in MODELS:
        ok, device, why = viable(name, hw)
        row = {'model': name, 'params': MODELS[name]['params'], 'available': ok, 'device': device, 'reason': why, 'typical_wer': MODELS[name]['typical_wer'], 'sec_per_step': round(sps.get(name, 0.0), 2), 'measured': name in (sec_per_step or {}) or (name in MEASURED_SIZES and (not sec_per_step)), 'hours': round(hours(sps[name], clips), 2) if ok and name in sps else None}
        options.append(row)
    return {'hardware': hw, 'speaker': speaker, 'clips': clips, 'epochs': EPOCHS, 'options': options}

def measure(model: str, device: str, steps: int) -> tuple[float, float]:
    import psutil
    import torch
    from peft import LoraConfig, get_peft_model
    from transformers import WhisperForConditionalGeneration
    proc = psutil.Process()
    net = WhisperForConditionalGeneration.from_pretrained(f'openai/whisper-{model}', dtype=torch.float32)
    net.config.forced_decoder_ids = None
    net = get_peft_model(net, LoraConfig(r=32, lora_alpha=64, target_modules=['q_proj', 'v_proj'], lora_dropout=0.05, bias='none')).to(device)
    net.gradient_checkpointing_enable()
    net.enable_input_require_grads()
    net.config.use_cache = False
    net.train()
    opt = torch.optim.AdamW([p for p in net.parameters() if p.requires_grad], lr=0.0003)
    feats = torch.randn(BATCH, net.config.num_mel_bins, 3000, device=device)
    labels = torch.randint(0, 1000, (BATCH, 24), device=device)
    amp = torch.bfloat16 if model == 'large-v3' else torch.float16
    scaler = torch.amp.GradScaler('cuda') if device == 'cuda' and amp is torch.float16 else None

    def one():
        if device == 'cuda':
            with torch.autocast('cuda', dtype=amp):
                loss = net(input_features=feats, labels=labels).loss
            if scaler:
                scaler.scale(loss).backward()
                scaler.step(opt)
                scaler.update()
            else:
                loss.backward()
                opt.step()
        else:
            net(input_features=feats, labels=labels).loss.backward()
            opt.step()
        opt.zero_grad(set_to_none=True)
    try:
        for _ in range(WARMUP_STEPS):
            one()
        if device == 'cuda':
            torch.cuda.synchronize()
        t0 = time.time()
        for _ in range(steps):
            one()
        if device == 'cuda':
            torch.cuda.synchronize()
        per_step = (time.time() - t0) / steps
        peak = proc.memory_info().rss / 1000000000.0
    finally:
        del net, opt, feats, labels
        gc.collect()
        if device == 'cuda':
            torch.cuda.empty_cache()
    return (per_step, peak)

def _cached_sizes() -> set:
    """Which Whisper weights are already downloaded.

    Timing a size means loading its PyTorch weights, and those are a separate
    download from the CTranslate2 model the app runs on -- medium in fp32 is
    about 3 GB. Measuring every size therefore meant fetching several gigabytes
    before the button could answer, which on an ordinary connection is well
    past the ten-minute timeout the caller allows."""
    try:
        from huggingface_hub import scan_cache_dir
        have = set()
        for repo in scan_cache_dir().repos:
            rid = str(repo.repo_id)
            if rid.startswith('openai/whisper-'):
                have.add(rid.split('openai/whisper-', 1)[1])
        return have
    except Exception:
        return set()


ANCHOR = 'tiny'
# THE ANCHOR MUST BE CHEAP, NOT REPRESENTATIVE. This is a button someone
# presses and waits in front of, with a ten-minute ceiling on the caller. An
# earlier version picked the LARGEST cached size on the theory that it would
# predict best, chose medium, and spent longer than the timeout doing 5
# training steps on 769M parameters -- so the button that exists to estimate
# the wait became the wait. Nothing above 'small' is ever timed.
ANCHOR_CEILING = 'small'


def measured_report(speaker: str, steps: int, clips: int | None=None) -> dict:
    """Time this machine, then scale the rest from what was timed.

    ONE SIZE IS TIMED FOR REAL and the others are derived from it, rather than
    training all six. The anchor is whichever cached size is largest -- 'tiny'
    if none, because it is a small download and still exercises the same
    forward, backward and optimiser step on the same hardware.

    Scaling uses the ratios in SEC_PER_STEP_3060: those were measured on one
    GPU, so the RATIO between sizes is what carries over, not the absolute
    numbers. A derived row says so, and the app already draws the distinction
    between measured and estimated.
    """
    hw = detect()
    clips = count_clips(speaker) if clips is None else clips

    cached = _cached_sizes()
    order = list(MODELS)
    anchor = ANCHOR
    ceiling = SEC_PER_STEP_3060[ANCHOR_CEILING]
    for name in order:
        ok, _dev, _why = viable(name, hw)
        cost = SEC_PER_STEP_3060[name]
        if ok and name in cached and cost > SEC_PER_STEP_3060[anchor] and cost <= ceiling:
            anchor = name

    anchor_ok, anchor_dev, _ = viable(anchor, hw)
    ratio, anchor_note = None, ''
    if anchor_ok:
        try:
            per_step, peak = measure(anchor, anchor_dev, steps)
            ratio = per_step / SEC_PER_STEP_3060[anchor]
        except Exception as e:
            anchor_note = f"couldn't measure: {type(e).__name__}"

    options = []
    for name in MODELS:
        ok, device, why = viable(name, hw)
        row = {'model': name, 'params': MODELS[name]['params'], 'available': ok,
               'device': device, 'reason': why, 'typical_wer': MODELS[name]['typical_wer']}
        if not ok:
            row.update(sec_per_step=None, hours=None, measured=False)
            options.append(row)
            continue
        if ratio is None:
            sps = SEC_PER_STEP_3060[name]
            row.update(sec_per_step=round(sps, 2), measured=False,
                       hours=round(hours(sps, clips), 2),
                       note=anchor_note or 'estimated')
        else:
            sps = SEC_PER_STEP_3060[name] * ratio
            row.update(sec_per_step=round(sps, 2), measured=(name == anchor),
                       hours=round(hours(sps, clips), 2))
            # Both the timed row and the scaled ones describe THIS machine, so
            # both are worth keeping. Only the timed one claims to be measured.
            row['from_measurement'] = True
            if name == anchor:
                row['peak_gb'] = round(peak, 2)
            else:
                row['note'] = f'scaled from the measured {anchor}'
        options.append(row)
    return {'hardware': hw, 'speaker': speaker, 'clips': clips, 'epochs': EPOCHS,
            'options': options, 'anchor': anchor if ratio is not None else None}

def main() -> None:
    p = argparse.ArgumentParser(description='Estimate retrain time on this machine.')
    p.add_argument('--speaker', default=None)
    p.add_argument('--clips', type=int, default=None, help='override the manifest count')
    p.add_argument('--steps', type=int, default=5, help='timed LoRA steps per size')
    p.add_argument('--instant', action='store_true', help='skip measuring; use 3060 constants')
    p.add_argument('--json', action='store_true')
    args = p.parse_args()
    report = estimate_report(args.speaker, args.clips) if args.instant else measured_report(args.speaker, args.steps, args.clips)
    if args.json:
        print(json.dumps(report, indent=2))
        return
    hw = report['hardware']
    print('\nYour computer')
    print(f"  GPU  : {hw['gpu'] or 'none detected'}" + (f"  ({hw['vram_gb']} GB)" if hw['gpu'] else ''))
    print(f"  RAM  : {hw['ram_gb'] or '?'} GB")
    print(f"\nRetrain on {report['clips']} clips ({report['epochs']} epochs):\n")
    for r in report['options']:
        if r['available']:
            tag = '' if r.get('measured') else '  (estimated)'
            print(f"  {r['model']:<9} {human(r['hours']):>8}   on {r['device'].upper()}   accuracy {r['typical_wer']}{tag}")
        else:
            print(f"  {r['model']:<9} {'—':>8}   unavailable: {r['reason']}")
    print("\n  Accuracy was measured on one speaker's voice, not yours — treat it as indicative only.")

# RESTORED ENTRY POINT.
#
# Without this the file is a module that defines main() and never calls it: run
# as a script it imports, defines, and exits 0 having printed nothing. Kara
# starts four of these as child processes and reads their output, so a missing
# __main__ is not a crash anywhere -- it is a subprocess that "succeeds"
# instantly and produces nothing, which is the hardest possible shape of
# failure to see.
#
# setup.ps1 records that `package.py --strip` removed these blocks and that
# record.py's had to be restored for --list-devices to list anything. The same
# strip took the rest, and they were never put back.
if __name__ == '__main__':
    main()
