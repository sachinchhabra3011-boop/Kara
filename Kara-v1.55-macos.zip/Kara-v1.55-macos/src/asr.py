import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path
TARGET_RATE = 16000
MAX_NEW_TOKENS = 100
SAFEGUARD_KWARGS = {'temperature': (0.0, 0.2, 0.4, 0.6, 0.8, 1.0), 'compression_ratio_threshold': 2.4, 'logprob_threshold': -1.0, 'no_speech_threshold': 0.6}

def load_mono_16k(path: str):
    import numpy as np
    import soundfile as sf
    import soxr
    audio, sample_rate = sf.read(path, dtype='float32', always_2d=True)
    mono = audio.mean(axis=1)
    if sample_rate != TARGET_RATE:
        mono = soxr.resample(mono, sample_rate, TARGET_RATE, quality='VHQ')
    return np.ascontiguousarray(mono, dtype='float32')

def _build_pipeline(model_name: str, adapter: str | None, device: str, dtype, switchable: bool=False):
    from transformers import pipeline
    if not adapter:
        return pipeline('automatic-speech-recognition', model=f'openai/whisper-{model_name}', dtype=dtype, device=device)
    from transformers import WhisperForConditionalGeneration, WhisperProcessor
    from peft import PeftModel
    base = WhisperForConditionalGeneration.from_pretrained(f'openai/whisper-{model_name}', dtype=dtype)
    peft_model = PeftModel.from_pretrained(base, adapter)
    model = peft_model if switchable else peft_model.merge_and_unload()
    proc = WhisperProcessor.from_pretrained(adapter)
    asr = pipeline('automatic-speech-recognition', model=model, tokenizer=proc.tokenizer, feature_extractor=proc.feature_extractor, dtype=dtype, device=device)
    if switchable:
        asr.kara_peft = peft_model
    return asr

def transcribe_paths(model_name: str, paths: list[str], safeguards: bool=False, adapter: str | None=None, precision: str='fp16', bias: str | None=None) -> list[str]:
    import torch
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    if device != 'cuda':
        dtype = torch.float32
    elif precision == 'bf16':
        dtype = torch.bfloat16
    else:
        dtype = torch.float16
    asr = _build_pipeline(model_name, adapter, device, dtype)
    generate_kwargs = {'language': 'en', 'task': 'transcribe', 'max_new_tokens': MAX_NEW_TOKENS}
    if safeguards:
        generate_kwargs.update(SAFEGUARD_KWARGS)
    if bias:
        prompt_ids = asr.tokenizer.get_prompt_ids(bias[:600], return_tensors='pt').to(device)
        generate_kwargs['prompt_ids'] = prompt_ids
    hyps = []
    for i, path in enumerate(paths, start=1):
        audio = load_mono_16k(path)
        long_form = audio.shape[-1] > 30 * TARGET_RATE
        gk = dict(generate_kwargs)
        if long_form:
            gk.pop('max_new_tokens', None)
        result = asr({'raw': audio, 'sampling_rate': TARGET_RATE}, generate_kwargs=gk, return_timestamps=safeguards or long_form)
        hyps.append(result['text'].strip())
        print(f'  {i}/{len(paths)}', end='\r', flush=True)
    print(' ' * 24, end='\r')
    return hyps

def transcribe_isolated(model_name: str, paths: list[Path], safeguards: bool=False, adapter: str | None=None, precision: str='fp16', bias: str | None=None) -> list[str] | None:
    with tempfile.TemporaryDirectory() as tmp:
        in_path, out_path = (Path(tmp) / 'in.json', Path(tmp) / 'out.json')
        in_path.write_text(json.dumps({'paths': [str(p) for p in paths], 'bias': bias}), encoding='utf-8')
        cmd = [sys.executable, str(Path(__file__).resolve()), '--model', model_name, '--in', str(in_path), '--out', str(out_path)]
        if safeguards:
            cmd.append('--safeguards')
        if adapter:
            cmd += ['--adapter', str(adapter)]
        if precision != 'fp16':
            cmd += ['--precision', precision]
        for attempt in (1, 2):
            code = subprocess.run(cmd).returncode
            if code == 0:
                return json.loads(out_path.read_text(encoding='utf-8'))
            tail = 'retrying once' if attempt == 1 else 'skipping this model'
            print(f'  crashed (exit {code}), {tail}')
    return None

def main() -> None:
    parser = argparse.ArgumentParser(description='Worker: transcribe a list of files.')
    parser.add_argument('--model', required=True)
    parser.add_argument('--in', dest='in_path', type=Path, required=True)
    parser.add_argument('--out', dest='out_path', type=Path, required=True)
    parser.add_argument('--safeguards', action='store_true')
    parser.add_argument('--adapter', default=None)
    parser.add_argument('--precision', default='fp16')
    args = parser.parse_args()
    payload = json.loads(args.in_path.read_text(encoding='utf-8'))
    hyps = transcribe_paths(args.model, payload['paths'], safeguards=args.safeguards, adapter=args.adapter, precision=args.precision, bias=payload.get('bias'))
    args.out_path.write_text(json.dumps(hyps), encoding='utf-8')

# RESTORED ENTRY POINT.
#
# Without this the file is a module that defines main() and never calls it: run
# as a script it imports, defines, and exits 0 having printed nothing. Kara
# starts four of these as child processes and reads their output, so a missing
# __main__ is not a crash anywhere -- it is a subprocess that "succeeds"
# instantly and produces nothing, which is the hardest possible shape of
# failure to see.
#
# setup.ps1 records that `package.py --strip` removed these blocks and that
# record.py's had to be restored for --list-devices to list anything. The same
# strip took the rest, and they were never put back.
if __name__ == '__main__':
    main()
