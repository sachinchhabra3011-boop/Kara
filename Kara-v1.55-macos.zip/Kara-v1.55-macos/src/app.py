import argparse
import threading
import time
from pathlib import Path
PASTE_SETTLE = 0.16
CLIPBOARD_RESTORE_AFTER = 2.0
import editing
import spelling
ROOT = Path(__file__).resolve().parent.parent
DEFAULT_ADAPTER = None

# THE WIN32 CODE THAT USED TO LIVE HERE IS NOW IN oswin.py, beside its macOS
# counterpart in osmac.py. These names stay because gui.py calls them as
# appmod.inject_text / appmod.press_keys / appmod.window_is_alive /
# appmod.KEYSTROKES, and the point of the move was to change where the work
# happens, not what the app asks for.
import osbridge

KEYSTROKES = osbridge.KEYSTROKES


def caret_info() -> dict:
    return osbridge.caret_info()


def window_is_alive(hwnd: int) -> bool:
    return osbridge.window_is_alive(hwnd)


def focus_window(hwnd: int) -> bool:
    return osbridge.focus_window(hwnd)[0]


def _focus_with_reason(hwnd: int) -> tuple[bool, str]:
    return osbridge.focus_window(hwnd)


def press_keys(hwnd: int | None, vk: int, modifiers=()) -> dict:
    return osbridge.press_keys(hwnd, vk, modifiers)


def inject_text(text: str, hwnd: int | None = None, restore_clipboard: bool = True) -> dict:
    return osbridge.inject_text(text, hwnd, restore_clipboard)

class App:

    def __init__(self, speaker: str, adapter: str, speak: bool=True):
        from pipeline import Pipeline
        print('loading model (once)...', flush=True)
        self.pipe = Pipeline(speaker, adapter=adapter, bf16=True, correct=True)
        self.ed = editing.Editor()
        self.anchors = spelling.load_anchors(speaker)
        self.speaker = speaker
        self.speak = speak

    def _say(self, msg: str) -> None:
        print(f'  {msg}')
        if self.speak:
            editing.speak(msg)

    def handle_utterance(self, wav: str) -> None:
        raw = self.pipe.raw(wav)
        import punctuation
        punct = punctuation.parse_punctuation(raw)
        if punct:
            ok, msg = self.ed.punctuate(punct)
            self._say(msg)
            print(f'  buffer: {self.ed.text!r}')
            return
        cmd, args = editing.parse_command(raw)
        if cmd == 'unknown':
            import corrector
            clean = corrector.correct(raw, self.pipe.vocab, use_llm=False)
            self.ed.dictate(clean)
            self._say(f'added: "{clean}"')
        elif cmd == 'spell':
            self._say('spell the word, one anchor per letter')
            self._pending = 'spell'
        elif cmd == 'change_spell':
            target, spell_text = args
            word = spelling.parse_spelling(spell_text, self.anchors).capitalize()
            if word and self.ed.change(target, word):
                self._say(f'changed to "{word}"')
            else:
                self._say(f"couldn't change '{target}'")
        elif cmd == 'send':
            inject_text(self.ed.text)
            self._say('sent to the document')
        elif cmd == 'read':
            self._say(self.ed.text or 'empty')
        else:
            self._say(editing.apply_command(self.ed, raw))
        print(f'  buffer: {self.ed.text!r}')

    def handle_spelling(self, wav: str) -> str:
        word = spelling.parse_spelling(self.pipe.raw(wav), self.anchors).capitalize()
        self.ed.dictate(word)
        spelling.add_to_vocab(word, self.speaker)
        self._say(f'spelled and added: "{word}"')
        return word

    def mic_loop(self) -> None:
        import record
        idx, name, host = record.resolve_device(None)
        import sounddevice as sd
        sd.default.device = (idx, None)
        print(f'mic: [{idx}] {name}\n')
        print("ENTER to speak, ENTER to stop. Say 'send' to put text in the document.")
        print('Commands: delete last word, change X to Y, new line, undo, spell mode, read it back.\n')
        pending_spell = False
        while True:
            try:
                input('[ready] ')
            except (EOFError, KeyboardInterrupt):
                print('\nbye')
                return
            print('  listening — ENTER to stop')
            audio = record.record_until_enter()
            if audio.size < record.SAMPLE_RATE // 4:
                print('  (nothing captured)')
                continue
            import soundfile as sf
            import tempfile
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tf:
                sf.write(tf.name, audio, record.SAMPLE_RATE, subtype='PCM_16')
                wav = tf.name
            if pending_spell:
                self.handle_spelling(wav)
                pending_spell = False
            else:
                self.handle_utterance(wav)
                pending_spell = getattr(self, '_pending', None) == 'spell'
                self._pending = None
            Path(wav).unlink(missing_ok=True)

def main() -> None:
    parser = argparse.ArgumentParser(description='Project R app shell.')
    parser.add_argument('--speaker', default=None)
    parser.add_argument('--adapter', default=str(DEFAULT_ADAPTER))
    parser.add_argument('--no-speak', dest='speak', action='store_false')
    parser.add_argument('--mic', action='store_true', help='live push-to-talk loop')
    parser.add_argument('--wav', help='process one wav through the full app logic')
    args = parser.parse_args()
    app = App(args.speaker, args.adapter, speak=args.speak)
    if args.mic:
        app.mic_loop()
    elif args.wav:
        app.handle_utterance(args.wav)
    else:
        raise SystemExit('give --mic (live) or --wav <file> (test)')

# RESTORED ENTRY POINT.
#
# Without this the file is a module that defines main() and never calls it: run
# as a script it imports, defines, and exits 0 having printed nothing. Kara
# starts four of these as child processes and reads their output, so a missing
# __main__ is not a crash anywhere -- it is a subprocess that "succeeds"
# instantly and produces nothing, which is the hardest possible shape of
# failure to see.
#
# setup.ps1 records that `package.py --strip` removed these blocks and that
# record.py's had to be restored for --list-devices to list anything. The same
# strip took the rest, and they were never put back.
if __name__ == '__main__':
    main()
