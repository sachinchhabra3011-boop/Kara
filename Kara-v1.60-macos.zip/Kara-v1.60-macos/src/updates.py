from __future__ import annotations
import json
import re
import shutil
import tempfile
import urllib.request
import zipfile
from pathlib import Path
import atomicio
import config
import karalog
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'src'
PREVIOUS = ROOT / 'src.previous'
TIMEOUT = 30
REQUIRED = ('gui.py', 'asr.py', 'pipeline.py', 'editing.py', 'proofing.py', 'config.py', 'karalog.py')

def _log():
    return karalog.get('update')

def _version_tuple(text: str) -> tuple:
    nums = re.findall('\\d+', str(text or ''))
    return tuple((int(n) for n in nums)) if nums else (-1,)

def is_newer(candidate: str, current: str) -> bool:
    return _version_tuple(candidate) > _version_tuple(current)

def latest(source: str | None=None) -> dict:
    out = {'ok': False, 'version': '', 'url': '', 'notes': '', 'why': ''}
    source = source or (config.load().get('update_source') or '')
    if not source:
        out['why'] = 'no update source is configured'
        return out
    try:
        req = urllib.request.Request(source, headers={'Accept': 'application/vnd.github+json', 'User-Agent': 'Kara'})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            raw = r.read()
    except Exception as e:
        out['why'] = f'could not reach the update source ({type(e).__name__})'
        return out
    try:
        data = json.loads(raw.decode('utf-8-sig', 'replace'))
    except Exception as e:
        out['why'] = f'the update source is not readable JSON ({type(e).__name__})'
        return out
    if not isinstance(data, dict):
        out['why'] = 'the update source did not return a JSON object'
        return out
    version = str(data.get('tag_name') or data.get('version') or '').strip()

    # ONE update.json NOW DESCRIBES TWO BUILDS. Before the Mac port there was a
    # single "url", and a Mac reading it would have downloaded the Windows zip
    # and replaced its own src/ with code full of ctypes.windll -- an update
    # that reports success and leaves an app that cannot start. So the platform
    # key is read first, and a feed that offers only the other platform's build
    # is treated as "nothing for you", not as an update.
    import osbridge
    key = 'mac' if osbridge.IS_MAC else 'windows'
    platforms = data.get('platforms')
    url = ''
    if isinstance(platforms, dict):
        entry = platforms.get(key)
        if isinstance(entry, dict):
            url = str(entry.get('url') or '').strip()
            version = str(entry.get('version') or version).strip()
        elif isinstance(entry, str):
            url = entry.strip()
        if not url:
            out['why'] = f'this update has no build for {key}'
            return out
    else:
        # A FEED WITH ONE BARE "url" AND NO PLATFORMS BLOCK IS A WINDOWS FEED.
        # Every such feed in existence predates the Mac build -- the live
        # update.json for v1.53 is exactly this shape, and its url is the
        # Windows zip. Accepting it on a Mac would swap this install's src/ for
        # ctypes.windll code and call it an upgrade. Windows must keep reading
        # these, so the refusal is macOS-only and says what to do about it.
        url = str(data.get('zip') or data.get('url') or '').strip()
        if url and osbridge.IS_MAC:
            out['why'] = ('this update feed predates the Mac version and only '
                          'offers the Windows download')
            return out

    if not url:
        # A GitHub releases feed. Prefer an asset whose name says which
        # platform it is; fall back to any zip only when nothing is labelled.
        want = ('mac', 'macos', 'darwin', 'osx') if osbridge.IS_MAC else ('win', 'windows')
        avoid = ('win', 'windows') if osbridge.IS_MAC else ('mac', 'macos', 'darwin', 'osx')
        spare = ''
        for asset in data.get('assets') or []:
            name = str(asset.get('name') or '')
            low = name.lower()
            if not low.endswith('.zip'):
                continue
            link = str(asset.get('browser_download_url') or '')
            if any(w in low for w in want):
                url = link
                break
            if not any(a in low for a in avoid) and not spare:
                spare = link
        url = url or spare

    if not version or not url:
        out['why'] = f'the update source did not name a version and a zip for {key}'
        return out
    out.update(ok=True, version=version, url=url, notes=str(data.get('body') or data.get('notes') or '').strip())
    return out

def available(current_version: str, source: str | None=None) -> dict:
    info = latest(source)
    info['newer'] = bool(info['ok'] and is_newer(info['version'], current_version))
    return info

def _payload_src_dir(unpacked: Path) -> Path | None:
    if (unpacked / 'src').is_dir():
        return unpacked / 'src'
    for child in unpacked.iterdir():
        if child.is_dir() and (child / 'src').is_dir():
            return child / 'src'
    return None

def verify(src_dir: Path) -> tuple[bool, str]:
    if src_dir is None or not src_dir.is_dir():
        return (False, 'the download did not contain a src folder')
    missing = [f for f in REQUIRED if not (src_dir / f).is_file()]
    if missing:
        return (False, f"the download is incomplete ({', '.join(missing[:3])})")
    import ast
    for f in src_dir.glob('*.py'):
        try:
            ast.parse(f.read_text(encoding='utf-8-sig'), filename=f.name)
        except (OSError, SyntaxError) as e:
            return (False, f'{f.name} is damaged ({type(e).__name__})')
    return (True, '')

# WHAT AN UPDATE REPLACES BESIDES src/.
#
# install() used to copy src/ and nothing else, which was right when a release
# was only Python. It is not any more: v1.55 added jiwer to the requirements,
# six prompt sets under data/prompts/, and the Kara.app bundle. An in-app
# update therefore reported success, said 1.55 in the About box, and left the
# machine unable to train (no jiwer), short of setup sentences, and absent
# from Spotlight. Verified by running a real update against a realistic older
# install.
#
# AN ALLOW-LIST, NOT AN EXCLUDE-LIST. Everything here is content Kara ships and
# owns. A deny-list would eventually sweep up something of the user's, and the
# things at risk -- recordings, pages, the trained voice, the profile -- cannot
# be recreated.
PAYLOAD_FILES = ('requirements-app.txt', 'requirements-mac.txt', 'README.md',
                 'README-macOS.md', 'PRIVACY.md', 'TERMS.md', 'LICENSE',
                 'THIRD-PARTY-NOTICES.md')
PAYLOAD_DIRS = ('scripts', 'assets')


def _copy_payload(unpacked: Path, root: Path) -> tuple[list[str], bool]:
    """Bring across the non-src files a release owns. Returns what changed and
    whether the requirements moved (which means dependencies need installing)."""
    import filecmp
    src_root = unpacked
    if not (src_root / 'src').is_dir():
        for child in unpacked.iterdir():
            if child.is_dir() and (child / 'src').is_dir():
                src_root = child
                break
    changed, reqs_changed = [], False
    for name in PAYLOAD_FILES:
        new = src_root / name
        if not new.is_file():
            continue
        cur = root / name
        if cur.is_file() and filecmp.cmp(new, cur, shallow=False):
            continue
        shutil.copy2(new, cur)
        changed.append(name)
        if name.startswith('requirements'):
            reqs_changed = True
    for name in PAYLOAD_DIRS:
        new = src_root / name
        if new.is_dir():
            shutil.copytree(new, root / name, dirs_exist_ok=True)
            changed.append(name + '/')
    # The shipped prompt sets, by name. personal_setup.txt is generated from
    # the user's own form and holds the real names of their family and the
    # places they go -- it is never part of a release and must not be touched.
    new_prompts = src_root / 'data' / 'prompts'
    if new_prompts.is_dir():
        dest = root / 'data' / 'prompts'
        dest.mkdir(parents=True, exist_ok=True)
        for f in sorted(new_prompts.glob('setup_*.txt')):
            cur = dest / f.name
            if not (cur.is_file() and filecmp.cmp(f, cur, shallow=False)):
                shutil.copy2(f, cur)
                changed.append(f'data/prompts/{f.name}')
    # The .app bundle is a launcher, not the program; the running process has
    # already exec'd past it, so replacing it now is safe. Signed bundles must
    # be replaced whole rather than written into, or the seal breaks.
    new_app = src_root / 'Kara.app'
    if new_app.is_dir():
        cur_app = root / 'Kara.app'
        shutil.rmtree(cur_app, ignore_errors=True)
        shutil.copytree(new_app, cur_app, symlinks=True)
        changed.append('Kara.app')
    return changed, reqs_changed


def _install_requirements(root: Path) -> tuple[bool, str]:
    """Install dependencies a new release added. Without this, an update that
    needs a new package updates the code and leaves the feature broken."""
    import subprocess
    import osbridge
    py = Path(osbridge.venv_python(root))
    if not py.exists():
        return (False, 'no virtual environment found')
    req = root / ('requirements-mac.txt' if osbridge.IS_MAC else 'requirements-app.txt')
    if not req.is_file():
        return (False, f'{req.name} is missing')
    try:
        r = subprocess.run([str(py), '-m', 'pip', 'install', '-q', '-r', str(req)],
                           capture_output=True, encoding='utf-8', errors='replace',
                           timeout=1800, creationflags=osbridge.NO_WINDOW)
        return (r.returncode == 0, (r.stderr or '').strip()[-200:])
    except Exception as e:
        return (False, f'{type(e).__name__}')

def install(url: str, progress=None) -> tuple[bool, str]:
    tmp = Path(tempfile.mkdtemp(prefix='kara_update_'))
    try:
        if progress:
            progress('Downloading the update…')
        blob = tmp / 'payload.zip'
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Kara'}), timeout=300) as r, blob.open('wb') as f:
            shutil.copyfileobj(r, f)
        if progress:
            progress('Checking it is complete…')
        unpacked = tmp / 'unpacked'
        with zipfile.ZipFile(blob) as z:
            z.extractall(unpacked)
        new_src = _payload_src_dir(unpacked)
        ok, why = verify(new_src)
        if not ok:
            _log().warning('update refused: %s', why)
            return (False, why)
        if progress:
            progress('Installing…')
        if PREVIOUS.exists():
            shutil.rmtree(PREVIOUS, ignore_errors=True)
        SRC.rename(PREVIOUS)
        try:
            shutil.copytree(new_src, SRC)
        except Exception as e:
            PREVIOUS.rename(SRC)
            return (False, f'could not install ({type(e).__name__})')
        try:
            changed, reqs_changed = _copy_payload(unpacked, ROOT)
        except Exception as e:
            changed, reqs_changed = [], False
            _log().warning('could not update the files beside src/: %s', e)
        if changed:
            _log().info('update also replaced: %s', ', '.join(changed[:8]))
        if reqs_changed:
            if progress:
                progress('Getting the parts this version needs…')
            ok_req, why_req = _install_requirements(ROOT)
            _log().info('dependency install after update: ok=%s %s', ok_req, why_req)
            if not ok_req:
                _log().warning('update installed, but new dependencies did not: %s', why_req)
        _log().info('updated; previous kept at %s', PREVIOUS.name)
        return (True, '')
    except Exception as e:
        return (False, type(e).__name__)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def rollback() -> tuple[bool, str]:
    if not PREVIOUS.is_dir():
        return (False, 'there is no previous version to go back to')
    try:
        broken = ROOT / 'src.failed'
        if broken.exists():
            shutil.rmtree(broken, ignore_errors=True)
        if SRC.exists():
            SRC.rename(broken)
        PREVIOUS.rename(SRC)
        _log().warning('rolled back to the previous version')
        return (True, '')
    except Exception as e:
        return (False, type(e).__name__)

def settled() -> None:
    if PREVIOUS.is_dir():
        shutil.rmtree(PREVIOUS, ignore_errors=True)
