from __future__ import annotations
import csv
import difflib
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'data'
VERSION = 1
CUTOFF = 0.72
CEILING = 0.857
CEILING_FOR = {'latin': 0.857, 'devanagari': 0.606}
SENTENCE_END = '.!?।'
INSERT = 'insert'

def path_for(speaker: str) -> Path:
    return DATA / speaker / 'commands.json'

def load(speaker: str) -> list[dict]:
    p = path_for(speaker)
    if not p.is_file():
        return []
    try:
        blob = json.loads(p.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return []
    if not isinstance(blob, dict) or int(blob.get('version', 0)) > VERSION:
        return []
    out = []
    for row in blob.get('commands', []):
        if not isinstance(row, dict):
            continue
        phrases = [str(x).strip().lower() for x in row.get('phrases', []) if str(x).strip()]
        action = str(row.get('action', '')).strip()
        if not phrases or not action:
            continue
        item = {'phrases': phrases, 'action': action}
        if action == INSERT:
            item['text'] = str(row.get('text', ''))
            if not item['text']:
                continue
        out.append(item)
    return out

def save(speaker: str, commands: list[dict]) -> None:
    import atomicio
    p = path_for(speaker)
    p.parent.mkdir(parents=True, exist_ok=True)
    atomicio.write_json(p, {'version': VERSION, 'commands': commands}, backup=True)
_CORPUS: dict[str, list[str]] = {}
DEVANAGARI = 'devanagari'
LATIN = 'latin'

def script_of(text: str) -> str:
    return DEVANAGARI if any(('ऀ' <= ch <= 'ॿ' for ch in text or '')) else LATIN

def corpus(speaker: str, script: str=LATIN) -> list[str]:
    if script in _CORPUS:
        return _CORPUS[script]
    lines: list[str] = []
    prompts = DATA / 'prompts'
    if prompts.is_dir():
        import atomicio
        for f in sorted(atomicio.real_files(prompts.glob('*.txt'))):
            if 'command' in f.name.lower():
                continue
            try:
                lines += [ln.strip() for ln in f.read_text(encoding='utf-8').splitlines() if ln.strip() and (not ln.strip().startswith('#'))]
            except OSError:
                pass
    man = DATA / speaker / 'manifest.csv'
    if man.is_file():
        try:
            with man.open(encoding='utf-8-sig', newline='') as fh:
                for row in csv.DictReader(fh):
                    if 'command' in (row.get('prompt_set') or '').lower():
                        continue
                    text = (row.get('prompt_text') or '').strip()
                    if text:
                        lines.append(text)
        except OSError:
            pass
    cleaned = [ln.lower().rstrip(SENTENCE_END) for ln in lines]
    _CORPUS[DEVANAGARI] = [ln for ln in cleaned if script_of(ln) == DEVANAGARI]
    _CORPUS[LATIN] = [ln for ln in cleaned if script_of(ln) == LATIN]
    return _CORPUS.get(script, [])

def _score(a: str, b: str) -> float:
    return difflib.SequenceMatcher(None, a, b).ratio()
MIN_CORPUS = 60

def collision(phrase: str, speaker: str, limit: int=3) -> dict:
    p = (phrase or '').strip().lower().rstrip(SENTENCE_END)
    if not p:
        return {'verdict': 'refuse', 'score': 1.0, 'examples': [], 'reason': 'empty'}
    script = script_of(p)
    lines = corpus(speaker, script)
    if len(lines) < MIN_CORPUS:
        return {'verdict': 'unmeasured', 'score': 0.0, 'examples': [], 'reason': f'only {len(lines)} ordinary {script} sentences to compare against — not enough to judge this'}
    scored = sorted(((_score(p, line), line) for line in lines), reverse=True)
    best = scored[0][0] if scored else 0.0
    ceiling = CEILING_FOR.get(script, CEILING)
    verdict = 'safe' if best < CUTOFF else 'warn' if best < ceiling else 'refuse'
    return {'verdict': verdict, 'score': best, 'examples': [line for _s, line in scored[:limit]], 'script': script, 'ceiling': ceiling, 'reason': ''}

def check_against_builtins(phrase: str) -> dict:
    import editing
    p = (phrase or '').strip().lower().rstrip(SENTENCE_END)
    best_cmd, best = (None, 0.0)
    tables = [editing.COMMANDS] + list(editing.COMMAND_TABLES.values())
    for table in tables:
        for cmd, alts in table.items():
            for alt in alts:
                s = _score(p, alt)
                if s > best:
                    best_cmd, best = (cmd, s)
    ceiling = CEILING_FOR.get(script_of(p), CEILING)
    return {'command': best_cmd, 'score': best, 'clash': best >= ceiling}

def merge_into(commands_table: dict, speaker: str) -> dict:
    merged = {k: list(v) for k, v in commands_table.items()}
    for row in load(speaker):
        if row['action'] == INSERT:
            continue
        merged.setdefault(row['action'], [])
        for ph in row['phrases']:
            if ph not in merged[row['action']]:
                merged[row['action']].append(ph)
    return merged

def inserts(speaker: str) -> dict:
    out = {}
    for row in load(speaker):
        if row['action'] == INSERT:
            for ph in row['phrases']:
                out[ph] = row['text']
    return out

def match_insert(text: str, speaker: str) -> str | None:
    t = (text or '').strip().lower().rstrip(SENTENCE_END)
    if not t:
        return None
    best, best_text = (0.0, None)
    for phrase, snippet in inserts(speaker).items():
        s = _score(t, phrase)
        if s > best:
            best, best_text = (s, snippet)
    return best_text if best >= CUTOFF else None
