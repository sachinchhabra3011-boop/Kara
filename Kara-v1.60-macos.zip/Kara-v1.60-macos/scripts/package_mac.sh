#!/bin/bash
# Build the macOS release zip.
#
#   bash scripts/package_mac.sh 1.57
#
# WHAT MUST NOT GO IN: .venv (built for one machine's Python), models/ and
# data/<speaker>/ (downloaded or recorded per machine), logs, caches. The zip
# is the program plus the content Kara ships; setup.sh builds the rest on the
# target machine.
#
# THIS FILE IS NOT ITSELF SHIPPED -- it is a build tool, and the release does
# not need it. Keep a copy outside the tree, or restoring an install from its
# own zip loses it. (That has happened.)

set -eu
VERSION="${1:-}"
[ -z "$VERSION" ] && { echo "usage: package_mac.sh <version>   e.g. 1.57"; exit 1; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

# The version in the zip name and the version the app reports must agree, or
# the updater offers a build that then reports itself as still out of date.
INAPP="$(sed -n "s/^VERSION = '\(.*\)'$/\1/p" src/gui.py | head -1)"
if [ "$INAPP" != "$VERSION" ]; then
  echo "REFUSING: src/gui.py says VERSION = '$INAPP' but you asked to package '$VERSION'."
  exit 1
fi

# Rebuilt every time: Kara.app carries the version in its Info.plist, and an
# app whose plist says 1.56 inside a 1.57 zip reports the wrong version to
# macOS forever after. Rebuilding also means a release can never go out
# without the .app -- which is how the first macOS build shipped as a bare
# .command and never appeared in Spotlight.
if [ ! -f "$ROOT/assets/kara.icns" ]; then
  if [ -x "$ROOT/.venv/bin/python" ]; then
    "$ROOT/.venv/bin/python" "$ROOT/scripts/make_icon.py"
  else
    echo "REFUSING: assets/kara.icns is missing and there is no .venv to build it with."
    exit 1
  fi
fi
bash "$ROOT/scripts/make_app.sh" "$VERSION"

STAGE="$(mktemp -d)/Kara-v$VERSION-macos"
mkdir -p "$STAGE"

# Copied BY NAME rather than by exclusion: a deny-list silently ships whatever
# somebody adds next to it, and this archive is downloaded by people who cannot
# easily undo a mistake in it.
cp -R src "$STAGE/src"
cp -R assets "$STAGE/assets"
mkdir -p "$STAGE/scripts"
# THE BUILD TOOLS SHIP TOO. package_mac.sh used to be left out as "not needed
# at runtime" -- correct, until an install had to be restored from its own zip
# and the packaging script was simply gone. The zip is now a complete copy of
# the project, which costs a few kilobytes.
cp scripts/setup.sh scripts/make_app.sh scripts/make_icon.py \
   scripts/package_mac.sh scripts/NOTARIZING.md "$STAGE/scripts/"
cp Kara.command "$STAGE/Kara.command"
cp -R Kara.app "$STAGE/Kara.app"
cp requirements-app.txt requirements-mac.txt "$STAGE/"
for f in LICENSE PRIVACY.md TERMS.md THIRD-PARTY-NOTICES.md README.md README-macOS.md; do
  [ -f "$f" ] && cp "$f" "$STAGE/"
done

# The prompt sets ship: they are app content, the sentences the user reads
# during setup. personal_setup.txt is EXCLUDED BY NAME -- it is generated from
# the setup form and holds the user's real name and those of their family and
# the places they go. It must never leave the machine that made it.
mkdir -p "$STAGE/data/prompts"
for f in "$ROOT"/data/prompts/setup_*.txt; do
  [ -e "$f" ] || continue
  cp "$f" "$STAGE/data/prompts/"
done
rm -f "$STAGE/data/prompts/personal_setup.txt"
PROMPTS="$(ls "$STAGE/data/prompts" 2>/dev/null | wc -l | tr -d ' ')"
if [ "$PROMPTS" -lt 6 ]; then
  echo "REFUSING: only $PROMPTS prompt set(s) staged, expected 6."
  exit 1
fi

find "$STAGE" -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
find "$STAGE" -name '*.pyc' -delete 2>/dev/null || true
find "$STAGE" -name '.DS_Store' -delete 2>/dev/null || true

chmod +x "$STAGE/Kara.command" "$STAGE/scripts/setup.sh" \
         "$STAGE/scripts/make_app.sh" "$STAGE/Kara.app/Contents/MacOS/Kara"

# NO --sequesterRsrc: ditto writes an __MACOSX/ tree of ._ stubs beside every
# file, which is clutter on Windows and on GitHub. -X drops uid/gid and
# timestamps that differ per build machine while keeping the mode bits, which
# the executable check below depends on.
OUT="$ROOT/Kara-v$VERSION-macos.zip"
rm -f "$OUT"
( cd "$(dirname "$STAGE")" && zip -r -q -X "$OUT" "$(basename "$STAGE")" )
rm -rf "$(dirname "$STAGE")"

echo "built: $OUT"
ls -lh "$OUT" | awk '{print "  size:", $5}'

for f in "Kara.command" "Kara.app/Contents/MacOS/Kara"; do
  MODE="$(unzip -Z "$OUT" "Kara-v$VERSION-macos/$f" 2>/dev/null | head -1 | awk '{print $1}')"
  case "$MODE" in
    *x*) echo "  executable in the zip: $f" ;;
    *)   echo "  WARNING: $f is NOT executable inside the zip ($MODE)." ;;
  esac
done

# Read the KEY, not the Nth <string>: positional parsing returned
# CFBundleSignature's "????" and called it the version.
PLTMP="$(mktemp -t karaplist).plist"
unzip -p "$OUT" "Kara-v$VERSION-macos/Kara.app/Contents/Info.plist" > "$PLTMP" 2>/dev/null || true
PLV="$(plutil -extract CFBundleShortVersionString raw -o - "$PLTMP" 2>/dev/null || echo '?')"
PLID="$(plutil -extract CFBundleIdentifier raw -o - "$PLTMP" 2>/dev/null || echo '?')"
rm -f "$PLTMP"

# A signature that does not survive the zip means a bundle macOS calls damaged.
VTMP="$(mktemp -d)"
if ditto -x -k "$OUT" "$VTMP" 2>/dev/null && \
   codesign --verify --deep --strict "$VTMP/Kara-v$VERSION-macos/Kara.app" 2>/dev/null; then
  echo "  signature verifies inside the zip"
else
  echo "  WARNING: Kara.app's signature does not verify after unzipping."
fi
rm -rf "$VTMP"

# Nothing personal may be in a release. Checked, not assumed.
if unzip -l "$OUT" | grep -qE "personal_setup|data/[^/]*/(manifest|vocab|anchors|recordings)"; then
  echo "  REFUSING: the zip contains personal data. Do not ship this."
  exit 1
fi
echo "  prompt sets in the zip: $(unzip -l "$OUT" | grep -c 'data/prompts/setup_')"

if unzip -l "$OUT" | grep -q "Kara.app/Contents/Info.plist"; then
  echo "  Kara.app is in the zip (id ${PLID}, version ${PLV})"
  [ "$PLV" != "$VERSION" ] && echo "  WARNING: Info.plist says '$PLV' but this is the $VERSION zip."
  [ "$PLID" != "com.kara.voicetotext" ] && echo "  WARNING: bundle id is '$PLID'. Changing it revokes every permission users have granted."
else
  echo "  WARNING: Kara.app is MISSING from the zip."
fi
unzip -l "$OUT" | grep -q "Kara.app/Contents/Resources/kara.icns" && echo "  icon present" || echo "  WARNING: kara.icns missing."
