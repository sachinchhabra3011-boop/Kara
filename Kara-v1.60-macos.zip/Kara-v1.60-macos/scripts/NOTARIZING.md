# Signing and notarising Kara for macOS

All of Kara's signing happens at the end of `scripts/make_app.sh`.

## Where things stand

`make_app.sh` **ad-hoc signs** the bundle. That is free, needs no Apple
account, and is done for one reason: it gives Kara a stable code identity.

macOS records Microphone and Accessibility grants against a code identity. With
no signature it falls back to the path on disk, so moving the folder — or
replacing it on update — can silently drop permissions the user already gave.
Kara does not work without those two.

**Ad-hoc signing does not remove the Gatekeeper warning**, and is not trying
to. First launch still needs right-click ▸ Open, once.

Verified on macOS 26:

| | result |
|---|---|
| `spctl -a -t exec Kara.app` | rejected — ad-hoc is not a Developer ID |
| `codesign --verify --deep --strict` | valid |
| survives `zip` / `ditto` round-trip | yes |
| survives `chmod +x`, `xattr -dr` | yes |
| survives editing a file inside the bundle | **no** — seal breaks |

That last row is why signing is the last step of the build and why
`make_app.sh` fails if the seal does not verify. **A broken seal is refused
more firmly than no signature** — macOS calls it damaged. Never write into
`Kara.app` after it is signed.

## Removing the warning

Three steps, all requiring an **Apple Developer Program membership, $99/year**.
No fee beyond that; certificates and notarisation are included.

**1. A Developer ID Application certificate.** Once it is in the login
keychain, `make_app.sh` finds it and uses it instead of ad-hoc, with
`--options runtime` (the hardened runtime, which notarisation requires).

**2. Notarise the zip:**

```bash
xcrun notarytool submit Kara-v1.57-macos.zip \
  --apple-id you@example.com --team-id TEAMID \
  --password app-specific-password --wait
```

That password is an **app-specific password** from appleid.apple.com, not your
Apple ID password. `notarytool store-credentials` saves it once.

**3. Staple the ticket** so the app validates offline:

```bash
xcrun stapler staple Kara.app
```

Then rebuild the zip with the stapled app inside it.

## The part to think about first

Kara's `.app` is a **thin launcher**: a shell script, an icon and an
`Info.plist`. The Python, the virtual environment and the model live beside it
and are built on the user's machine.

That helps notarisation — almost nothing to scan, no bundled binaries — but the
notarised thing is the launcher, not the program. Gatekeeper checks the app the
user opens, so the warning does go. The interpreter it starts afterwards is an
ordinary child process the user installed themselves.

**Not tested end to end** — it needs a paid account. Treat the steps above as
documented, not proven. The likeliest thing to need work is the hardened
runtime on a script-based bundle.

## If you would rather not pay

The current arrangement works: right-click ▸ Open once, and `Kara.command`
clears the quarantine flag from the folder so it never asks again.
`README-macOS.md` covers it in the install steps.
