from __future__ import annotations
import re
from dataclasses import dataclass
__all__ = ['ErrorInfo', 'KaraError', 'CODES', 'look_up', 'classify', 'UNKNOWN']

@dataclass(frozen=True)
class ErrorInfo:
    code: str
    title: str
    say: str
    fix: str

    def message(self, detail: str='') -> str:
        out = f'{self.say}\n\n{self.fix}'
        if detail:
            out += f'\n\n({detail.strip()})'
        return f'{out}\n\n{self.code}'

def _e(code, title, say, fix):
    return ErrorInfo(code, title, say, fix)
CODES: dict[str, ErrorInfo] = {'KARA-1001': _e('KARA-1001', 'No microphone', 'Kara cannot find a microphone on this computer.', 'Plug your microphone in, then open Settings and choose it under Audio.'), 'KARA-1002': _e('KARA-1002', 'Microphone in use', 'Another program is using the microphone, so Kara cannot listen.', 'Close anything else that uses the microphone — a call, a recorder, a browser tab — and tap the microphone again.'), 'KARA-1003': _e('KARA-1003', 'Microphone stopped', 'The microphone stopped working part way through.', 'Check the cable is still in, then tap the microphone and say it again.'), 'KARA-1004': _e('KARA-1004', 'Microphone unplugged', 'The microphone Kara was set to use is not plugged in any more.', 'Plug it back in, or open Settings and pick a different one under Audio.'), 'KARA-1005': _e('KARA-1005', 'Microphone changes your voice', 'That microphone runs your voice through a voice changer before Kara hears it, so Kara would learn the wrong voice.', 'Open Settings and choose your real microphone under Audio.'), 'KARA-1006': _e('KARA-1006', 'Nothing recorded', 'Kara did not hear anything that time.', 'Tap the microphone, wait for the circle to move, then speak.'), 'KARA-1010': _e('KARA-1010', 'Cannot play sound', 'Kara could not read anything back through the speakers.', 'Open Settings and pick a different speaker under Audio, then press Test.'), 'KARA-2001': _e('KARA-2001', 'Voice model missing', 'The file that holds your trained voice is not where Kara expects it.', 'If you have a backup, restore it from Settings. Otherwise Kara can still write using the general model — it just will not know your voice as well.'), 'KARA-2002': _e('KARA-2002', 'Not enough graphics memory', 'There is not enough room on the graphics card to load the voice model.', 'Close other programs that use the graphics card — games, video editors, browsers with video — and start Kara again. You can also pick a smaller model in Settings under Processing.'), 'KARA-2003': _e('KARA-2003', 'Needs preparing for this computer', 'This computer has no NVIDIA graphics card, so Kara needs a version of the model built for the processor. It has not been made yet.', 'This one needs someone at a keyboard. The exact command is in the details below and in the diagnostics file.'), 'KARA-2004': _e('KARA-2004', 'Voice model would not load', 'Kara could not load the model it uses to understand speech.', 'Restart Kara. If it happens again, save the diagnostics file from Settings — About and send it on.'), 'KARA-2005': _e('KARA-2005', 'Could not make out the words', 'Kara heard the recording but could not turn it into words.', 'Try saying it again. If every attempt does this, restart Kara.'), 'KARA-3001': _e('KARA-3001', 'Could not save the page', 'Kara could not save what you have written.', 'Your words are still on the screen — do not close Kara. Copy them out with the Copy button, then check there is space on the disk.'), 'KARA-3002': _e('KARA-3002', 'Could not open the page', 'Kara could not read that page back.', 'The text file is still in your Kara folder and opens in Notepad. Settings — About — Open the folder will take you there.'), 'KARA-3003': _e('KARA-3003', 'Disk is full', 'There is no space left on the disk, so Kara cannot save anything.', 'Free some space, then try again. Nothing already saved has been lost.'), 'KARA-3004': _e('KARA-3004', 'Could not update the recording list', 'Kara could not update the list that says what each recording contains. Nothing was deleted, and your recordings are safe.', 'Check there is space on the disk and try again.'), 'KARA-3005': _e('KARA-3005', 'Not allowed to save there', 'Windows will not let Kara write to its own folder.', 'This usually means the folder is read-only or another program has a file open. Restarting the computer clears most cases.'), 'KARA-4001': _e('KARA-4001', 'That name will not work', 'A name cannot contain \\ / : * ? " < > or |.', 'Pick a name made of letters, numbers and spaces.'), 'KARA-4002': _e('KARA-4002', 'Not a Kara backup', 'That file is not a Kara backup, or it is damaged.', 'Look for the file ending in .karaprofile that Kara made for you.'), 'KARA-4003': _e('KARA-4003', 'Someone already has that name', 'There is already a profile with that name on this computer.', 'Import it under a different name, or replace the existing one — Kara will ask which.'), 'KARA-4004': _e('KARA-4004', 'Backup not finished', 'The backup could not be finished, so Kara did not leave a half-made one behind.', 'Check there is space where you are saving it, then try again.'), 'KARA-5001': _e('KARA-5001', 'Not enough recordings yet', 'There are not enough recordings yet to teach Kara your voice.', 'Open Settings — Voice and record some more. Fifty already makes a big difference.'), 'KARA-5002': _e('KARA-5002', 'Training stopped', 'Training stopped before it finished.', 'Nothing is lost — Kara saves as it goes. Open Settings — Training and press Resume.'), 'KARA-5003': _e('KARA-5003', 'Could not measure this computer', 'Kara could not time how fast this computer trains.', 'The estimate shown is still usable. You can try measuring again later.'), 'KARA-6001': _e('KARA-6001', 'Nowhere to send it', 'Kara does not know which program to send your writing to.', 'Click once on the document you want it in — Word, an email, anything you can type in — then come back and say send.'), 'KARA-6002': _e('KARA-6002', 'Could not reach that window', 'Kara could not bring that program to the front, so it has not sent anything.', 'Your writing is still here and is on the clipboard. Click the program you want and press Ctrl and V.'), 'KARA-6004': _e('KARA-6004', 'That document is not open', 'The document Kara was sending to has been closed.', 'Open the document you want, click once inside it, then come back and say send.'), 'KARA-6003': _e('KARA-6003', 'Clipboard is busy', 'Another program is holding the clipboard, so Kara could not use it.', 'Wait a moment and say send again.'), 'KARA-7002': _e('KARA-7002', 'Offline Mode is on', 'Kara is in Offline Mode, so it will not use the internet for anything.', 'Turn off Offline Mode in Settings if you want the online grammar check. Everything else, including backing up to a folder, keeps working either way.'), 'KARA-7101': _e('KARA-7101', 'No backup found', 'There is no backup in that folder yet.', 'Back up first, then a restore will have something to fetch.'), 'KARA-7102': _e('KARA-7102', 'No backup folder chosen', 'Kara does not know where to put the backup.', 'In Settings ▸ Backup, choose a folder. Putting it inside OneDrive or Google Drive sends it to the cloud on its own.'), 'KARA-7106': _e('KARA-7106', 'Backup was stopped', 'The backup was stopped before it finished.', 'Nothing has been damaged. Run it again when you are ready — it carries on from where it stopped.'), 'KARA-7103': _e('KARA-7103', 'Backup could not be read', 'Part of the backup could not be downloaded.', 'Check the connection and try again. Nothing on this computer has been changed.'), 'KARA-7104': _e('KARA-7104', 'Backup rejected a name', 'Kara refused an unexpected name inside the backup.', 'Report this. Nothing has been written.'), 'KARA-7105': _e('KARA-7105', 'Backup is from a newer Kara', 'This backup was made by a newer version of Kara than the one running.', 'Update Kara, then restore.'), 'KARA-9001': _e('KARA-9001', 'Something went wrong', 'Something went wrong that Kara does not have a name for.', 'Restart Kara. If it keeps happening, go to Settings — About and save the diagnostics file, then send it on.')}
UNKNOWN = CODES['KARA-9001']

class KaraError(Exception):

    def __init__(self, code: str, detail: str='', cause: BaseException | None=None):
        self.info = look_up(code)
        self.detail = detail or (str(cause) if cause else '')
        self.__cause__ = cause
        super().__init__(f'{self.info.code}: {self.info.say}' + (f' [{self.detail}]' if self.detail else ''))

    @property
    def code(self) -> str:
        return self.info.code

    def message(self) -> str:
        return self.info.message(self.detail)

def look_up(code: str) -> ErrorInfo:
    return CODES.get(code, UNKNOWN)
_PATTERNS: list[tuple[re.Pattern, str]] = [(re.compile('no input device|no default input|no microphone', re.I), 'KARA-1001'), (re.compile('device unavailable|being used by another|in use by another|exclusive mode|-9996|-9985', re.I), 'KARA-1002'), (re.compile('invalid device|device .*not (found|available)|no such device|-9996|error querying device', re.I), 'KARA-1004'), (re.compile('virtual|voice ?mod|voice ?changer|refusing to record', re.I), 'KARA-1005'), (re.compile('nothing recorded|no audio captured', re.I), 'KARA-1006'), (re.compile('out of memory|cuda out of memory|CUBLAS_STATUS_ALLOC', re.I), 'KARA-2002'), (re.compile('no NVIDIA GPU|cpu_engine\\.py --convert|has not been prepared', re.I), 'KARA-2003'), (re.compile('adapter|peft|safetensors|no such file.*model|checkpoint', re.I), 'KARA-2001'), (re.compile('no space left|disk full|not enough space|ENOSPC', re.I), 'KARA-3003'), (re.compile('permission denied|access is denied|read-only', re.I), 'KARA-3005'), (re.compile('not a (kara|valid) (backup|export)|bad zip|not a zip', re.I), 'KARA-4002'), (re.compile('already exists', re.I), 'KARA-4003'), (re.compile('clipboard', re.I), 'KARA-6003'), (re.compile('foreground|setforegroundwindow|no target window', re.I), 'KARA-6002')]

def classify(exc: BaseException | str, default: str='KARA-9001') -> ErrorInfo:
    if isinstance(exc, KaraError):
        return exc.info
    text = exc if isinstance(exc, str) else f'{type(exc).__name__}: {exc}'
    if not isinstance(exc, str):
        if isinstance(exc, MemoryError):
            return look_up('KARA-2002')
        if isinstance(exc, OSError) and getattr(exc, 'errno', None) == 28:
            return look_up('KARA-3003')
        if isinstance(exc, PermissionError):
            return look_up('KARA-3005')
    for pattern, code in _PATTERNS:
        if pattern.search(text):
            return look_up(code)
    return look_up(default)

def as_error(exc: BaseException, default: str='KARA-9001') -> KaraError:
    if isinstance(exc, KaraError):
        return exc
    info = classify(exc, default)
    return KaraError(info.code, f'{type(exc).__name__}: {exc}', cause=exc)
