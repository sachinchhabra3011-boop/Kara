# Kara -- one-shot setup for a fresh Windows machine.
#
#   powershell -ExecutionPolicy Bypass -File setup.ps1          # app only
#   powershell -ExecutionPolicy Bypass -File setup.ps1 -Full    # + training
#
# Checks rather than assumes: every step that can silently produce a broken-but-
# running install is verified here, because those are the failures that surface
# later as "it's just slow" or "it can't hear me" rather than as an error.

param(
    [switch]$Full,          # also install the training/eval stack
    [switch]$SkipModel      # don't pre-download the base Whisper weights
)

$ErrorActionPreference = "Stop"
$root = $PSScriptRoot
Set-Location $root

# THE APP ROOT, not this script's folder. In a release these scripts live in
# scripts\ so that the only double-clickable thing at the top level is Kara.cmd
# -- Windows hides known extensions, and a file called "setup" sitting beside
# "Kara" is the one a person clicks, which opens Notepad. That move broke
# $PSScriptRoot: it became ...\scripts, so every path below it went looking in
# the wrong folder. Resolve upward when src\ is not here.
if (-not (Test-Path (Join-Path $root "src"))) {
    $up = Split-Path $root -Parent
    if (Test-Path (Join-Path $up "src")) { $root = $up }
}


function Say($m)  { Write-Host "`n=== $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "  OK   $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  WARN $m" -ForegroundColor Yellow }
function Die($m)  { Write-Host "  FAIL $m" -ForegroundColor Red; exit 1 }

Say "Python"
$pyExe = $null
foreach ($c in @("py -3.12", "py -3", "python")) {
    try {
        $parts = $c.Split(" ")
        $v = & $parts[0] $parts[1..99] --version 2>&1
        # The Microsoft Store stub prints nothing useful and exits 9009. It is on
        # PATH by default on Windows and is NOT a usable interpreter.
        if ($v -match "Python 3\.(1[0-9])") { $pyExe = $c; Ok "$v  ($c)"; break }
    } catch { }
}
if (-not $pyExe) {
    Die "No Python 3.10+ found. Install from python.org (NOT the Microsoft Store
       build -- it is a stub that breaks venv creation). Tick 'Add to PATH'."
}

Say "Virtual environment"
if (Test-Path "$root\.venv") {
    Ok ".venv already exists (delete it to rebuild from scratch)"
} else {
    $p = $pyExe.Split(" ")
    & $p[0] $p[1..99] -m venv "$root\.venv"
    if (-not (Test-Path "$root\.venv\Scripts\python.exe")) { Die "venv creation failed" }
    Ok "created .venv"
}
$venvPy = "$root\.venv\Scripts\python.exe"

Say "GPU"
$hasNvidia = $false
try {
    $smi = & nvidia-smi --query-gpu=name,memory.total --format=csv,noheader 2>$null
    if ($LASTEXITCODE -eq 0 -and $smi) { $hasNvidia = $true; Ok "$smi" }
} catch { }
if (-not $hasNvidia) {
    Warn "No NVIDIA GPU detected. The app will still run, on CPU, but a single"
    Warn "utterance takes tens of seconds instead of under one -- too slow for"
    Warn "real use. A 6 GB+ NVIDIA card is the practical requirement."
}

Say "PyTorch"
# DO NOT REDIRECT A NATIVE COMMAND'S STDERR HERE. On a machine where torch is
# not installed -- which is every fresh machine, the case this line exists to
# detect -- `import torch` prints a traceback, and PowerShell 5.1 turns a
# REDIRECTED native stderr into a NativeCommandError record. With
# $ErrorActionPreference = "Stop" at the top of this file that is TERMINATING,
# so setup died at the exact step it was probing. The `2>$null` intended to
# hide the traceback was the thing that killed it. (HANDOFF PART 8.)
#
# Found by running this file on a clean extraction rather than reasoning about
# it: the failure cannot happen on a machine that already has torch.
$cudaOk = $false
try {
    $prevEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    & $venvPy -c "import torch,sys; sys.exit(0 if torch.cuda.is_available() else 1)" *> $null
    $cudaOk = ($LASTEXITCODE -eq 0)
} catch {
    $cudaOk = $false
} finally {
    $ErrorActionPreference = $prevEAP
}
if ($cudaOk) {
    Ok "torch already installed with working CUDA"
} else {
    Write-Host "  installing torch 2.5.1 + CUDA 12.1 (~2.5 GB, this is the slow part)"
    & $venvPy -m pip install --quiet --upgrade pip
    & $venvPy -m pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cu121
    if ($LASTEXITCODE -ne 0) { Die "torch install failed" }
}

Say "Dependencies"
$req = if ($Full) { "requirements.txt" } else { "requirements-app.txt" }
Write-Host "  installing $req"
& $venvPy -m pip install --quiet -r "$root\$req"
if ($LASTEXITCODE -ne 0) { Die "dependency install failed" }
Ok $req

Say "Verifying the install actually works"
# Not just "did pip exit 0". A CPU-only torch installs cleanly and then runs the
# app ~20x slower, which is exactly the failure this check exists to catch.
$check = & $venvPy -c @"
import torch, transformers, sys
print('torch       ', torch.__version__)
print('transformers', transformers.__version__)
print('cuda        ', torch.cuda.is_available())
if torch.cuda.is_available():
    print('device      ', torch.cuda.get_device_name(0))
    print('vram_gb     ', round(torch.cuda.get_device_properties(0).total_memory/1e9, 1))
if not transformers.__version__.startswith('5'):
    print('BADVERSION'); sys.exit(2)
"@ 2>&1
$check | ForEach-Object { Write-Host "  $_" }
if ($check -match "BADVERSION") { Die "transformers must be 5.x (see requirements.txt)" }
if ($check -match "cuda +False" -and $hasNvidia) {
    Warn "An NVIDIA GPU is present but torch cannot see CUDA. You most likely"
    Warn "have the CPU-only wheel. Fix:"
    Warn "  .venv\Scripts\python.exe -m pip uninstall -y torch"
    Warn "  .venv\Scripts\python.exe -m pip install torch==2.5.1 --index-url https://download.pytorch.org/whl/cu121"
}

Say "Microphone"
& $venvPy "$root\src\record.py" --list-devices 2>&1 | Select-Object -First 12 | ForEach-Object { Write-Host "  $_" }
Warn "Use a real USB mic. Virtual devices (Voicemod, Voice.ai, Stereo Mix) are"
Warn "refused outright -- they corrupt audio invisibly."

Say "Speaker profile"
$speaker = "$root\data\the user"
if ((Test-Path "$speaker\anchors.json") -and (Test-Path "$speaker\vocab.json")) {
    Ok "data\the user\ present (vocabulary + spelling anchors)"
} else {
    Warn "data\the user\{vocab,anchors}.json missing. These hold real names and are"
    Warn "gitignored, so they do not travel with the code -- copy them from the"
    Warn "original machine, or the app starts in a reduced mode (no name"
    Warn "correction, no spelling mode)."
}

Say "Adapter (the fine-tuned voice model)"
if (Test-Path "$root\models\whisper-large-v3-the user-lora\adapter_model.safetensors") {
    Ok "models\whisper-large-v3-the user-lora present"
} else {
    Warn "No trained voice model yet. One is not shipped -- it is personal data,"
    Warn "(~260 MB); copy the folder across. Without it you get generic Whisper,"
    Warn "which measured 34.7% WER on this speaker versus 4.5% fine-tuned."
}

Say "Ollama (optional -- the name/grammar corrector)"
$ollama = Get-Command ollama -ErrorAction SilentlyContinue
if ($ollama) {
    Ok "ollama installed"
    $models = & ollama list 2>$null | Out-String
    if ($models -match "qwen3:4b") { Ok "qwen3:4b pulled" }
    else { Warn "run:  ollama pull qwen3:4b" }
} else {
    Warn "Ollama not installed (https://ollama.com). Without it the corrector"
    Warn "fails open -- transcription still works, names are just not corrected."
}

if (-not $SkipModel) {
    Say "Pre-downloading base Whisper weights"
    # MEDIUM, not large-v3. Medium is what the app actually loads
    # (gui.DEFAULT_MODEL); pre-fetching large-v3 pulled ~3 GB the app then never
    # opened, and left the size it DOES open to download silently on first run --
    # the exact wait this step exists to remove.
    Write-Host "  medium is ~1.5 GB. Doing it now beats a silent wait the first"
    Write-Host "  time the app is opened. Skip with -SkipModel."
    # AND THE STDERR TRAP AGAIN. huggingface_hub prints an unauthenticated-request
    # WARNING to stderr; piping a native command's stderr in PowerShell 5.1 turns
    # each line into a NativeCommandError, which $ErrorActionPreference = "Stop"
    # makes terminating. So a warning about rate limits aborted the installer at
    # the last step, after torch and every dependency had installed correctly.
    # Same fault as the torch probe above, found the same way: by running it.
    #
    # This step is OPTIONAL by design -- the weights download on first launch if
    # they are missing -- so a failure here must never fail the install.
    try {
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        & $venvPy -c "from transformers import WhisperForConditionalGeneration as M; M.from_pretrained('openai/whisper-medium')" *> $null
        if ($LASTEXITCODE -eq 0) { Ok "base weights cached" }
        else { Warn "could not pre-download the weights; the app will fetch them on first run" }
    } catch {
        Warn "could not pre-download the weights; the app will fetch them on first run"
    } finally {
        $ErrorActionPreference = $prevEAP
    }
}

Say "Done"
Write-Host "  Make it a searchable Windows app:"
Write-Host "     powershell -ExecutionPolicy Bypass -File install_app.ps1"
Write-Host "     (then press Windows and type 'Kara')"
Write-Host "  Or just run it:  double-click Kara.cmd  /  .venv\Scripts\python.exe src\gui.py"
