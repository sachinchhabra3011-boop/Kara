# Register Harvard as a real Windows app for THIS user, so it shows up in
# Windows Search / the Start menu with its own icon. No admin, no packaging --
# a Start-menu shortcut is what Windows Search indexes.
#
#   powershell -ExecutionPolicy Bypass -File install_app.ps1
#   powershell -ExecutionPolicy Bypass -File install_app.ps1 -Uninstall

param([switch]$Uninstall, [switch]$NoDesktop, [switch]$DeleteData, [switch]$KeepData)

$ErrorActionPreference = "Stop"
$root   = $PSScriptRoot

# THE APP ROOT, not this script's folder. In a release these scripts live in
# scripts\ so that the only double-clickable thing at the top level is Kara.cmd
# -- Windows hides known extensions, and a file called "setup" sitting beside
# "Kara" is the one a person clicks, which opens Notepad. That move broke
# $PSScriptRoot: it became ...\scripts, so every path below it went looking in
# the wrong folder. Resolve upward when src\ is not here.
if (-not (Test-Path (Join-Path $root "src"))) {
    $up = Split-Path $root -Parent
    if (Test-Path (Join-Path $up "src")) { $root = $up }
}

$name   = "Kara"
$pyw    = Join-Path $root ".venv\Scripts\pythonw.exe"   # no console window
$script = Join-Path $root "src\gui.py"
$icon   = Join-Path $root "assets\kara.ico"

$startMenu = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs"
$lnkStart  = Join-Path $startMenu "$name.lnk"
$lnkDesk   = Join-Path ([Environment]::GetFolderPath("Desktop")) "$name.lnk"

# The app was called Reed until 2026-07-31. Its shortcuts still point at
# src\gui.py and would keep working, so nothing breaks -- but the user would be
# left with two entries under two names for one app, and searching the old name
# would launch it, which is worse than either alone. Clear them out.
$oldNames  = @("Reed", "Harvard")
$stale     = foreach ($n in $oldNames) {
    Join-Path $startMenu "$n.lnk"
    Join-Path ([Environment]::GetFolderPath("Desktop")) "$n.lnk"
}

function Remove-Stale {
    foreach ($l in $stale) {
        if (Test-Path $l) { Remove-Item $l -Force -EA SilentlyContinue; Write-Host "removed old shortcut $l" }
    }
}

if ($Uninstall) {
    Remove-Stale
    foreach ($l in @($lnkStart, $lnkDesk)) {
        if (Test-Path $l) { Remove-Item $l -Force; Write-Host "removed $l" }
    }
    Write-Host "$name shortcuts removed."

    # Your voice recordings and writing are YOURS, and they are hours of work
    # that cannot be recreated without redoing the whole setup. So uninstalling
    # never deletes them silently -- it asks, and defaults to keeping.
    $dataDir   = Join-Path $root "data"
    $modelsDir = Join-Path $root "models"
    $cfgFile   = Join-Path $root "kara_config.json"
    $present   = @($dataDir, $modelsDir) | Where-Object { Test-Path $_ }

    if (-not $present) { Write-Host "No personal data found."; return }

    $bytes = 0
    foreach ($d in $present) {
        $bytes += (Get-ChildItem $d -Recurse -File -EA SilentlyContinue |
                   Measure-Object Length -Sum).Sum
    }
    $mb = [math]::Round($bytes / 1MB)

    $doDelete = $false
    if ($DeleteData)   { $doDelete = $true }
    elseif ($KeepData) { $doDelete = $false }
    else {
        Write-Host ""
        Write-Host "You still have personal data here ($mb MB):" -ForegroundColor Yellow
        Write-Host "  - voice recordings and what each one said"
        Write-Host "  - the pages you have written"
        Write-Host "  - your trained voice model(s), names and settings"
        Write-Host ""
        Write-Host "Deleting is permanent. The recordings cannot be recreated"
        Write-Host "without doing the whole setup again."
        Write-Host ""
        $ans = Read-Host "Delete this personal data too? (type DELETE to confirm, anything else keeps it)"
        $doDelete = ($ans -ceq "DELETE")
    }

    if ($doDelete) {
        foreach ($d in $present) {
            Remove-Item $d -Recurse -Force -EA SilentlyContinue
            Write-Host "deleted $d"
        }
        foreach ($c in @($cfgFile, (Join-Path $root "reed_config.json"))) {
            if (Test-Path $c) { Remove-Item $c -Force -EA SilentlyContinue }
        }
        Write-Host "Personal data deleted." -ForegroundColor Yellow
    } else {
        Write-Host "Your data was KEPT at:"
        foreach ($d in $present) { Write-Host "  $d" }
        Write-Host "Delete those folders yourself if you want it gone."
    }
    return
}

# Fail loudly if the pieces are missing rather than making a dead shortcut.
foreach ($p in @($pyw, $script, $icon)) {
    if (-not (Test-Path $p)) { throw "missing: $p (run setup.ps1 / make_icon.py first)" }
}

# The AppUserModelID Kara declares at startup (gui.main). The SHORTCUT has to
# carry the same string or Windows cannot connect the running process to it --
# and with no shortcut to read a name and icon from, the taskbar falls back to
# describing the host executable, which is why right-clicking the taskbar
# button said "Python".
$appId = "Kara.VoiceToText.Desktop.1"

# WScript.Shell cannot write that property; it lives in the shortcut's
# IPropertyStore under PKEY_AppUserModel_ID. This is the smallest amount of
# interop that sets it.
if (-not ("Kara.Shortcut" -as [type])) {
@"
using System;
using System.Runtime.InteropServices;

namespace Kara {
  [StructLayout(LayoutKind.Sequential, Pack = 4)]
  public struct PropertyKey { public Guid fmtid; public uint pid;
    public PropertyKey(Guid g, uint p) { fmtid = g; pid = p; } }

  [ComImport, Guid("886d8eeb-8cf2-4446-8d02-cdba1dbdcf99"),
   InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  public interface IPropertyStore {
    void GetCount(out uint c);
    void GetAt(uint i, out PropertyKey k);
    void GetValue(ref PropertyKey k, IntPtr v);
    void SetValue(ref PropertyKey k, IntPtr v);
    void Commit();
  }

  [ComImport, Guid("00021401-0000-0000-C000-000000000046")]
  public class ShellLink { }

  [ComImport, Guid("0000010b-0000-0000-C000-000000000046"),
   InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  public interface IPersistFile {
    void GetClassID(out Guid id);
    [PreserveSig] int IsDirty();
    void Load([MarshalAs(UnmanagedType.LPWStr)] string f, uint mode);
    void Save([MarshalAs(UnmanagedType.LPWStr)] string f,
              [MarshalAs(UnmanagedType.Bool)] bool remember);
    void SaveCompleted([MarshalAs(UnmanagedType.LPWStr)] string f);
    void GetCurFile([MarshalAs(UnmanagedType.LPWStr)] out string f);
  }

  public static class Shortcut {
    // PROPVARIANT is built BY HAND. InitPropVariantFromString looks like the
    // obvious call and is not exported from propsys.dll -- it is an inline
    // helper in propvarutil.h, so P/Invoking it fails to bind and then
    // corrupts memory. The struct is simple enough to fill directly:
    //   offset 0  VARTYPE vt        (2 bytes)  VT_LPWSTR = 31
    //   offset 2  three reserved WORDs
    //   offset 8  the pointer union (8 bytes on x64)
    [DllImport("ole32.dll")] static extern int PropVariantClear(IntPtr pv);
    const int PROPVARIANT_SIZE = 24;      // x64
    const short VT_LPWSTR = 31;

    public static void SetAppId(string lnk, string appId) {
      var link = new ShellLink();
      ((IPersistFile)link).Load(lnk, 2 /* STGM_READWRITE */);
      var store = (IPropertyStore)link;
      var key = new PropertyKey(
        new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), 5);

      IntPtr pv = Marshal.AllocCoTaskMem(PROPVARIANT_SIZE);
      try {
        for (int i = 0; i < PROPVARIANT_SIZE; i++) Marshal.WriteByte(pv, i, 0);
        Marshal.WriteInt16(pv, 0, VT_LPWSTR);
        // PropVariantClear frees this string, so it must be CoTaskMem.
        Marshal.WriteIntPtr(pv, 8, Marshal.StringToCoTaskMemUni(appId));
        store.SetValue(ref key, pv);
        store.Commit();
        ((IPersistFile)link).Save(lnk, true);
      } finally { PropVariantClear(pv); Marshal.FreeCoTaskMem(pv); }
    }

    public static string GetAppId(string lnk) {
      var link = new ShellLink();
      ((IPersistFile)link).Load(lnk, 0 /* STGM_READ */);
      var store = (IPropertyStore)link;
      var key = new PropertyKey(
        new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"), 5);
      IntPtr pv = Marshal.AllocCoTaskMem(PROPVARIANT_SIZE);
      try {
        for (int i = 0; i < PROPVARIANT_SIZE; i++) Marshal.WriteByte(pv, i, 0);
        store.GetValue(ref key, pv);
        if (Marshal.ReadInt16(pv, 0) != VT_LPWSTR) return null;
        return Marshal.PtrToStringUni(Marshal.ReadIntPtr(pv, 8));
      } finally { PropVariantClear(pv); Marshal.FreeCoTaskMem(pv); }
    }
  }
}
"@ | ForEach-Object { Add-Type -TypeDefinition $_ -Language CSharp }
}

function New-Shortcut($path) {
    $sh = New-Object -ComObject WScript.Shell
    $s  = $sh.CreateShortcut($path)
    $s.TargetPath       = $pyw
    $s.Arguments        = "`"$script`""          # quoted: the path has a space
    $s.WorkingDirectory = $root
    $s.IconLocation     = "$icon,0"
    $s.Description      = "Kara - speech to text"
    $s.WindowStyle      = 1
    $s.Save()
    try {
        [Kara.Shortcut]::SetAppId($path, $appId)
    } catch {
        Write-Host "  (could not stamp the AppUserModelID: $($_.Exception.Message))"
        Write-Host "  the shortcut still works; the taskbar may name it 'Python'."
    }
}

Remove-Stale
New-Shortcut $lnkStart
Write-Host "Start-menu shortcut created: $lnkStart"
if (-not $NoDesktop) {
    New-Shortcut $lnkDesk
    Write-Host "Desktop shortcut created:    $lnkDesk"
}
Write-Host ""
Write-Host "Done. Press the Windows key and type 'Kara' to launch it."
Write-Host "(If it doesn't appear immediately, give the search index a minute.)"
