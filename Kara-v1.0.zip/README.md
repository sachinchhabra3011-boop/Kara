# Kara

Kara turns speech into writing, personalised to one speaker, and runs entirely
on your own computer.

## Installing

**Double-click Kara.cmd.**

That is the whole thing. The first time, it sets Kara up (about 2 GB, a few
minutes) and then starts it; every time after that it just starts it.

You need Windows 10 or 11 and Python 3.12. If Python is missing, Kara.cmd says
so and tells you where to get it.

Do not double-click the .ps1 files -- Windows opens those in Notepad instead of
running them. Kara.cmd runs them for you.

## Teaching it your voice

A fresh install uses the general speech model and is not personalised yet. Kara
offers to record a short setup on first launch. The recordings stay on your
machine and training runs there too. On the voice Kara was built for, this took
word error rate from 34.7% to 4.5%.

## Moving an existing setup to another computer

On the old machine: Settings > Backup, point it at a folder, switch on **Also
copy the trained voice model**, and back up. On the new machine, install as
above, point Settings > Backup at the same folder and press Restore. The profile
records which trained model belongs to it, so the restored one is found and used.

## Privacy

Everything runs locally. Recordings, documents and the trained voice model stay
on the machine; there is no account and no server. PRIVACY.md has the detail,
including the few optional features that can use the network.

Kara is free for personal use.
