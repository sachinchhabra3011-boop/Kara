# Kara

Kara turns speech into writing, personalised to one speaker, and runs entirely
on your own computer.

It exists for people whose speech general dictation software handles badly --
where off-the-shelf recognition is wrong often enough to be unusable, however
clearly the speaker is understood by the people around them. Kara is trained on
recordings of the person who will use it, and that is what makes the difference:
on the voice it was built for, word error rate went from 34.7% with a general
model to 4.5%.

Everything runs locally. Recordings, documents and the trained voice model stay
on the machine; there is no account and no server. See PRIVACY.md for the
detail, including the few optional features that can use the network and what
each of them sends.

## Running it

Unpack the folder anywhere, then:

    powershell -ExecutionPolicy Bypass -File setup.ps1
    powershell -ExecutionPolicy Bypass -File install_app.ps1

setup.ps1 installs the Python dependencies and fetches the base speech model on
first use. Windows 10 or 11 and Python 3.12 are required; an NVIDIA GPU is
optional, and without one Kara uses a quantised CPU model instead.
install_app.ps1 adds a Start-menu shortcut, so keep the folder where it is.

## Teaching it your voice

A fresh install runs the general model and is not personalised yet. Kara offers
to record a short setup on first launch. The recordings stay on your machine and
training runs there too.

## Moving an existing setup to another computer

On the old machine: Settings > Backup, point it at a folder, switch on **Also
copy the trained voice model**, and back up. On the new machine, install as
above, point Settings > Backup at the same folder and press Restore. The profile
records which adapter belongs to it, so the restored model is found and used.

Kara is free for personal use.
