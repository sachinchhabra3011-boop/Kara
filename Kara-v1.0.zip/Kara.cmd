@echo off
REM Harvard -- double-click this to start the app.
REM
REM A .cmd rather than a shortcut so it works after being copied to any folder
REM on any machine: %~dp0 is this file's own directory, so nothing is tied to
REM "C:\Claude Project R".
title Kara
cd /d "%~dp0"

if not exist ".venv\Scripts\pythonw.exe" (
    echo.
    echo   Kara is not set up on this computer yet.
    echo.
    echo   Right-click setup.ps1 and choose "Run with PowerShell", or run:
    echo       powershell -ExecutionPolicy Bypass -File setup.ps1
    echo.
    pause
    exit /b 1
)

REM pythonw, not python: no console window behind the app. the user should never
REM see a terminal. Errors still surface -- the GUI shows them itself, and
REM anything fatal lands in app_error.log below.
start "" ".venv\Scripts\pythonw.exe" "src\gui.py" %*
