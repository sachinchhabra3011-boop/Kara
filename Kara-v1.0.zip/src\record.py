import argparse
import csv
import datetime as dt
import io
import re
import sys
from pathlib import Path
import numpy as np
import sounddevice as sd
import soundfile as sf
import atomicio
import prompts
ROOT = Path(__file__).resolve().parent.parent
_NO_SPEAKER = ROOT / 'data' / '_no_speaker'
RECORDINGS = _NO_SPEAKER / 'recordings'
MANIFEST = _NO_SPEAKER / 'manifest.csv'

def _require_speaker() -> None:
    if MANIFEST.parent == _NO_SPEAKER:
        raise SystemExit('record: no speaker set, so there is nowhere safe to write. Call record.speaker_paths(<name>) and assign RECORDINGS/MANIFEST first, or pass --speaker on the command line.')

def speaker_paths(speaker: str) -> tuple[Path, Path]:
    base = ROOT / 'data' / speaker
    return (base / 'recordings', base / 'manifest.csv')
SAMPLE_RATE = 16000
FIELDS = ['prompt_id', 'prompt_set', 'prompt_text', 'wav_path', 'duration_s', 'peak', 'recorded_at']
VIRTUAL_MARKERS = ('voicemod', 'voice.ai', 'voiceai', 'virtual', 'cable', 'stereo mix', 'sound mapper', 'primary sound capture')
DEGRADED_MARKERS = ('hands-free', 'hands free')

def input_devices() -> list[tuple[int, str, str]]:
    host_apis = sd.query_hostapis()
    return [(i, d['name'], host_apis[d['hostapi']]['name']) for i, d in enumerate(sd.query_devices()) if d['max_input_channels'] > 0]

def output_devices() -> list[tuple[int, str, str]]:
    host_apis = sd.query_hostapis()
    return [(i, d['name'], host_apis[d['hostapi']]['name']) for i, d in enumerate(sd.query_devices()) if d['max_output_channels'] > 0]
_INF_TAIL = re.compile(';\\(([^()]+)\\)\\s*\\)?\\s*$')
_INF_ANY = re.compile('@[\\w\\\\/.:%#,-]+\\.sys[^;]*;?')

def pretty_name(name: str) -> str:
    raw = (name or '').strip()
    kind = raw.split('(', 1)[0].strip()
    m = _INF_TAIL.search(raw)
    if m:
        product = m.group(1).strip()
        return f'{product} ({kind})' if kind and kind.lower() not in product.lower() else product
    if '@' in raw and '.sys' in raw.lower():
        cleaned = _INF_ANY.sub('', raw).replace('%0', '').replace('%1', '')
        cleaned = re.sub('[()\\s;,]+$', '', cleaned).strip(' (')
        return cleaned or kind or raw
    return raw
_GENERIC = {'microphone', 'input', 'output', 'speakers', 'speaker', 'headset', 'headphones', 'headphone', 'line', 'line in', 'line out', 'mic', 'digital output', 'digital input'}

def is_junk_device(name: str) -> bool:
    raw = (name or '').strip()
    if not raw:
        return True
    stripped = re.sub('\\(\\s*\\)', '', raw).strip(' -')
    return not stripped or stripped.lower() in _GENERIC

def _host_key(name: str) -> str:
    raw = (name or '').strip()
    pretty = pretty_name(raw)
    if pretty.lower() != raw.lower():
        return pretty.lower()
    return raw.lower()[:31]

def _device_key(name: str) -> str:
    n = pretty_name(name).lower()
    n = re.sub('\\(\\s*\\d+\\s*-\\s*', '(', n)
    n = re.sub('(?<![a-z0-9])\\d+\\s*-\\s*', '', n)
    return re.sub('[^a-z0-9]+', ' ', n).strip()

def _connected_keys(want_input: bool) -> set[str]:
    try:
        host_apis = sd.query_hostapis()
        return {_device_key(d['name']) for d in sd.query_devices() if 'wasapi' in host_apis[d['hostapi']]['name'].lower() and (d['max_input_channels'] > 0 if want_input else d['max_output_channels'] > 0)}
    except Exception:
        return set()

def unique_devices(devices: list[tuple[int, str, str]], connected_only: bool=True) -> list[tuple[int, str, str]]:

    def _merge(items, keyfn):
        out: dict[str, tuple[int, str, str]] = {}
        for dev in items:
            _i, name, api = dev
            key = keyfn(name)
            cur = out.get(key)
            better = cur is None
            if not better:
                ds_new = 'directsound' in api.lower()
                ds_old = 'directsound' in cur[2].lower()
                better = ds_new and (not ds_old) or (ds_new == ds_old and len(name) > len(cur[1]))
            if better:
                out[key] = dev
        return list(out.values())
    real = [d for d in devices if not is_junk_device(d[1])]
    merged = _merge(_merge(real, _host_key), _device_key)
    if not connected_only or not merged:
        return merged
    try:
        table = sd.query_devices()
        want_input = table[merged[0][0]]['max_input_channels'] > 0
    except Exception:
        return merged
    live = _connected_keys(want_input)
    if not live:
        return merged
    return [d for d in merged if _device_key(d[1]) in live]

def output_device_index(name: str | None) -> int | None:
    if not name:
        return None
    for i, dname, _api in unique_devices(output_devices()):
        if dname.strip() == name.strip():
            return i
    return None

def has_marker(name: str, markers: tuple[str, ...]) -> bool:
    lowered = name.lower()
    return any((m in lowered for m in markers))

def resolve_device(spec: str | None, allow_virtual: bool=False) -> tuple[int, str, str]:
    devices = input_devices()
    if not devices:
        raise SystemExit('No input devices found.')
    if spec is None:
        real = [d for d in devices if not has_marker(d[1], VIRTUAL_MARKERS + DEGRADED_MARKERS)]
        usb = [d for d in real if 'usb' in d[1].lower()]
        candidates = usb or real
        if not candidates:
            raise SystemExit('Every input device looks virtual or degraded. Pass --device explicitly\nafter checking --list-devices.')
        preferred = [d for d in candidates if 'directsound' in d[2].lower()]
        chosen = (preferred or candidates)[0]
    elif spec.isdigit():
        index = int(spec)
        chosen = next((d for d in devices if d[0] == index), None)
        if chosen is None:
            raise SystemExit(f'Device {index} is not an input device. Try --list-devices.')
    else:
        matches = [d for d in devices if spec.lower() in d[1].lower()]
        if not matches:
            raise SystemExit(f'No input device matching {spec!r}. Try --list-devices.')
        preferred = [d for d in matches if 'directsound' in d[2].lower()]
        chosen = (preferred or matches)[0]
    if has_marker(chosen[1], VIRTUAL_MARKERS) and (not allow_virtual):
        raise SystemExit(f"Refusing to record through '{chosen[1]}'.\nThat is a virtual or voice-changing device. Anything captured through it\nis silently altered and cannot be used to train or benchmark. Plug in a\nreal microphone and pass --device.")
    if has_marker(chosen[1], DEGRADED_MARKERS):
        print(f"! '{chosen[1]}' is a Bluetooth hands-free device. Narrowband audio.")
        print('! Use a wired or USB microphone if you have one.\n')
    return chosen

def read_manifest() -> list[dict]:
    atomicio.restore_from_backup(MANIFEST)
    if not MANIFEST.exists():
        return []
    with MANIFEST.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def already_recorded() -> set[str]:
    return {row['prompt_id'] for row in read_manifest() if row.get('prompt_id')}

def write_manifest(rows: list[dict]) -> None:
    _require_speaker()
    atomicio.write_csv(MANIFEST, FIELDS, rows, backup=True)

def drop_from_manifest(prompt_ids: list[str]) -> None:
    rows = read_manifest()
    if not rows:
        raise SystemExit('Nothing recorded yet.')
    targets = set(prompt_ids)
    missing = targets - {r['prompt_id'] for r in rows}
    if missing:
        raise SystemExit(f"Not in the manifest: {', '.join(sorted(missing))}")
    keep = [r for r in rows if r['prompt_id'] not in targets]
    try:
        write_manifest(keep)
    except OSError as e:
        raise SystemExit(f'Could not update {MANIFEST.name}, so nothing was deleted: {e}')
    for row in rows:
        if row['prompt_id'] in targets:
            wav = ROOT / row['wav_path']
            wav.unlink(missing_ok=True)
            print(f"dropped {row['prompt_id']}")

def append_manifest(row: dict) -> None:
    _require_speaker()
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    if not MANIFEST.exists():
        write_manifest([row])
        return
    buf = io.StringIO(newline='')
    csv.DictWriter(buf, fieldnames=FIELDS, extrasaction='ignore').writerow(row)
    atomicio.append_line(MANIFEST, buf.getvalue())

def record_until_enter() -> np.ndarray:
    frames = []
    with sd.InputStream(samplerate=SAMPLE_RATE, channels=1, dtype='float32', callback=lambda data, *_: frames.append(data.copy())):
        input()
    if not frames:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate(frames, axis=0).squeeze(axis=-1)

def level_advice(peak: float) -> str | None:
    if peak < 0.15:
        return 'quiet - raise the mic gain, aim for peak 0.25-0.50'
    if peak > 0.8:
        return 'hot - lower the mic gain, aim for peak 0.25-0.50'
    return None
CLIP_LEVEL = 0.99

def clipped_fraction(audio: np.ndarray) -> float:
    if audio.size == 0:
        return 0.0
    return float(np.count_nonzero(np.abs(audio) >= CLIP_LEVEL) / audio.size)

def quality_check(audio: np.ndarray) -> tuple[str | None, str | None]:
    if audio.size == 0:
        return ('fatal', 'nothing recorded')
    duration = audio.size / SAMPLE_RATE
    rms = float(np.sqrt(np.mean(audio ** 2)))
    if duration < 0.4:
        return ('fatal', f'very short ({duration:.1f}s)')
    if rms < 0.005:
        return ('fatal', 'very quiet — move closer to the mic or raise input gain')
    clipped = clipped_fraction(audio)
    if clipped >= 0.02:
        return ('warn', f'much of that was too loud ({clipped:.0%} clipped) — move back from the mic or lower the input gain')
    if clipped > 0:
        return ('warn', 'part of that was too loud — try moving back a little')
    if float(np.max(np.abs(audio))) < 0.15:
        return ('warn', 'that was quiet — move closer to the mic')
    return (None, None)

def quality_warning(audio: np.ndarray) -> str | None:
    _severity, message = quality_check(audio)
    return message

def require_interactive_stdin() -> None:
    if not sys.stdin.isatty():
        raise SystemExit("record.py needs an interactive terminal, and this one has no keyboard\nattached to it. VS Code's Run button and the Code Runner extension both\ndo this.\n\nOpen a terminal and type the command yourself:\n    .\\.venv\\Scripts\\Activate.ps1\n    python src\\record.py --set harvard\n")

def main() -> None:
    parser = argparse.ArgumentParser(description='Record prompts for Project R.')
    parser.add_argument('--speaker', help="whose voice this is — a short name of your choosing. Each speaker's recordings, manifest and model are kept under data/<name>/.")
    parser.add_argument('--set', default='harvard', help='prompt set name (harvard, personal)')
    parser.add_argument('--device', default=None, help='input device index or name fragment')
    parser.add_argument('--list-devices', action='store_true')
    parser.add_argument('--redo', nargs='+', metavar='PROMPT_ID', help='delete these clips so they get recorded again')
    args = parser.parse_args()
    if args.list_devices:
        for index, name, host_api in input_devices():
            flag = ''
            if has_marker(name, VIRTUAL_MARKERS):
                flag = '  [VIRTUAL - refused]'
            elif has_marker(name, DEGRADED_MARKERS):
                flag = '  [narrowband]'
            print(f'  [{index:>2}] {name}  ({host_api}){flag}')
        return
    if not args.speaker:
        raise SystemExit("--speaker is required (for example: --speaker dad). It keeps each person's recordings in their own folder so they never collide.")
    global RECORDINGS, MANIFEST
    RECORDINGS, MANIFEST = speaker_paths(args.speaker)
    print(f'speaker: {args.speaker}  ->  {MANIFEST.relative_to(ROOT)}')
    if args.redo:
        drop_from_manifest(args.redo)
    require_interactive_stdin()
    index, name, host_api = resolve_device(args.device)
    sd.default.device = (index, None)
    print(f'\nmic: [{index}] {name}  ({host_api})')
    all_prompts = prompts.load(args.set)
    recorded = already_recorded()
    total = len(all_prompts)

    def next_todo(start: int) -> int:
        for j in range(start, total):
            if all_prompts[j][0] not in recorded:
                return j
        return total
    if next_todo(0) == total:
        print(f"'{args.set}' is fully recorded. Nothing to do.")
        return
    _require_speaker()
    RECORDINGS.mkdir(parents=True, exist_ok=True)
    print(f"\n{total - len(recorded)} of {total} prompts left in '{args.set}'.")
    print('ENTER start/stop/keep.  r = redo this one   b = back one   s = skip   q = quit\n')
    cursor = next_todo(0)
    while cursor < total:
        prompt_id, text = all_prompts[cursor]
        done = prompt_id in recorded
        print(f'[{cursor + 1}/{total}]  {text}' + ('   (redo)' if done else ''))
        action = input('           ready > ').strip().lower()
        if action == 'q':
            print('\nSaved. Run again to pick up here.')
            return
        if action == 'b':
            cursor = max(0, cursor - 1)
            continue
        if action == 's':
            cursor = next_todo(cursor + 1)
            continue
        print('           recording — ENTER to stop')
        audio = record_until_enter()
        warning = quality_warning(audio)
        if warning:
            print(f'           ! {warning}\n')
            continue
        duration = audio.size / SAMPLE_RATE
        peak = float(np.max(np.abs(audio)))
        advice = level_advice(peak)
        print(f'           {duration:.1f}s   peak {peak:.2f}' + (f'   ! {advice}' if advice else ''))
        if input('           ENTER to keep, r to redo > ').strip().lower() == 'r':
            print()
            continue
        if prompt_id in recorded:
            drop_from_manifest([prompt_id])
            recorded.discard(prompt_id)
        wav_path = RECORDINGS / f'{prompt_id}.wav'
        sf.write(wav_path, audio, SAMPLE_RATE, subtype='PCM_16')
        append_manifest({'prompt_id': prompt_id, 'prompt_set': args.set, 'prompt_text': text, 'wav_path': str(wav_path.relative_to(ROOT)), 'duration_s': f'{duration:.2f}', 'peak': f'{peak:.3f}', 'recorded_at': dt.datetime.now().isoformat(timespec='seconds')})
        recorded.add(prompt_id)
        print()
        cursor = next_todo(cursor + 1)
    print(f"Done with '{args.set}'.")
