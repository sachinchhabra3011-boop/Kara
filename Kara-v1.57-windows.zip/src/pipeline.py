import argparse
import json
from pathlib import Path
import asr
import corrector
ROOT = Path(__file__).resolve().parent.parent
ALTERNATIVES = 3

class Pipeline:

    def __init__(self, speaker: str, model: str='large-v3', adapter: str | None=None, bf16: bool=True, correct: bool=True, safeguards: bool=False, switchable: bool=False):
        import torch
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        if device != 'cuda':
            dtype = torch.float32
        else:
            dtype = torch.bfloat16 if bf16 else torch.float16
        self.asr = asr._build_pipeline(model, adapter, device, dtype, switchable=switchable)
        try:
            import config as _config
            lang = (_config.load().get('language') or 'en').strip() or 'en'
        except Exception:
            lang = 'en'
        self.gen = {'language': lang, 'task': 'transcribe', 'max_new_tokens': asr.MAX_NEW_TOKENS}
        if safeguards:
            self.gen.update(asr.SAFEGUARD_KWARGS)
        self._ts = safeguards
        self.correct = correct
        self.vocab = corrector.load_vocab(speaker) if correct else None

    def unload(self) -> None:
        import gc
        import torch
        self.asr = None
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def raw(self, wav: str) -> str:
        audio = asr.load_mono_16k(wav)
        long_form = audio.shape[-1] > 30 * asr.TARGET_RATE
        gen = dict(self.gen)
        if long_form:
            gen.pop('max_new_tokens', None)
        out = self.asr({'raw': audio, 'sampling_rate': asr.TARGET_RATE}, generate_kwargs=gen, return_timestamps=self._ts or long_form)
        return out['text'].strip()

    def word_probs(self, wav: str) -> list[tuple[str, float]]:
        return [(w['word'], w['prob']) for w in self.word_choices(wav)]

    def word_choices(self, wav: str) -> list[dict]:
        import torch
        audio = asr.load_mono_16k(wav)
        if audio.shape[-1] > 30 * asr.TARGET_RATE:
            return []
        try:
            model = self.asr.model
            tok = self.asr.tokenizer
            feats = self.asr.feature_extractor(audio, sampling_rate=asr.TARGET_RATE, return_tensors='pt')
            inputs = feats.input_features.to(model.device, dtype=model.dtype)
            gen = {k: v for k, v in self.gen.items() if k != 'return_timestamps'}
            with torch.no_grad():
                out = model.generate(inputs, **gen, return_dict_in_generate=True, output_scores=True)
        except Exception as e:
            try:
                import karalog
                karalog.get('asr').warning('word_choices failed: %s: %s', type(e).__name__, e)
            except Exception:
                pass
            return []
        seq = out.sequences[0]
        scores = out.scores or []
        generated = seq[-len(scores):] if scores else []
        pairs = []
        for step, token_id in enumerate(generated):
            logits = scores[step][0]
            dist = torch.softmax(logits.float(), dim=-1)
            prob = float(dist[int(token_id)])
            top = torch.topk(dist, ALTERNATIVES + 1)
            alts = [(int(i), float(p)) for p, i in zip(top.values.tolist(), top.indices.tolist()) if int(i) != int(token_id)][:ALTERNATIVES]
            pairs.append((int(token_id), prob, alts))
        words: list[dict] = []
        piece, probs, first_alts = ('', [], [])
        specials = set(getattr(tok, 'all_special_ids', []) or [])

        def flush():
            if piece.strip() and probs:
                words.append({'word': piece.strip(), 'prob': sum(probs) / len(probs), 'alts': first_alts})
        for token_id, prob, alts in pairs:
            if token_id in specials:
                continue
            text = tok.decode([token_id])
            if not text:
                continue
            if text.startswith(' ') and piece.strip():
                flush()
                piece, probs, first_alts = ('', [], [])
            if not piece:
                first_alts = [(tok.decode([i]).strip(), p) for i, p in alts if tok.decode([i]).strip()]
            piece += text
            probs.append(prob)
        flush()
        return words

    def process(self, wav: str, use_llm: bool=True) -> dict:
        raw = self.raw(wav)
        clean = corrector.correct(raw, self.vocab, use_llm=use_llm) if self.correct else raw
        return {'raw': raw, 'clean': clean}

    def process_live(self, wav: str) -> dict:
        return self.process(wav, use_llm=False)

    def can_switch(self) -> bool:
        return getattr(self.asr, 'kara_peft', None) is not None

    def process_base(self, wav: str) -> dict:
        peft = getattr(self.asr, 'kara_peft', None)
        if peft is None:
            raw = self.raw(wav)
            return {'raw': raw, 'clean': raw, 'base_model': False}
        with peft.disable_adapter():
            raw = self.raw(wav)
        return {'raw': raw, 'clean': raw, 'base_model': True}

def _eval(pipe: Pipeline, split_path: Path, speaker: str) -> None:
    import csv
    import jiwer
    from transformers.models.whisper.english_normalizer import EnglishTextNormalizer
    normalize = EnglishTextNormalizer({})
    test_ids = set(json.loads(split_path.read_text())['test_ids'])
    manifest = ROOT / 'data' / speaker / 'manifest.csv'
    rows = [r for r in csv.DictReader(manifest.open(encoding='utf-8-sig', newline='')) if r['prompt_id'] in test_ids]
    refs, raws, cleans = ([], [], [])
    for i, r in enumerate(rows, start=1):
        out = pipe.process(str(ROOT / r['wav_path']))
        refs.append(normalize(r['prompt_text']))
        raws.append(normalize(out['raw']))
        cleans.append(normalize(out['clean']))
        print(f'  {i}/{len(rows)}', end='\r', flush=True)
    print(' ' * 24, end='\r')
    print(f'full-stack eval on {len(rows)} held-out clips:')
    print(f'  fine-tuned only : {jiwer.wer(refs, raws):.1%}')
    print(f'  + corrector     : {jiwer.wer(refs, cleans):.1%}')

def main() -> None:
    parser = argparse.ArgumentParser(description='Unified transcribe+correct pipeline.')
    parser.add_argument('--speaker', required=True)
    parser.add_argument('--model', default='large-v3')
    parser.add_argument('--adapter', default=None)
    parser.add_argument('--bf16', action='store_true')
    parser.add_argument('--no-correct', dest='correct', action='store_false')
    parser.add_argument('--safeguards', action='store_true', help='re-enable anti-loop safeguards (off-the-shelf models need them)')
    parser.add_argument('--wav', help='transcribe+correct a single file')
    parser.add_argument('--eval', type=Path, help='split json: full-stack WER on held-out')
    args = parser.parse_args()
    pipe = Pipeline(args.speaker, model=args.model, adapter=args.adapter, bf16=args.bf16, correct=args.correct, safeguards=args.safeguards)
    if args.eval:
        _eval(pipe, args.eval, args.speaker)
    elif args.wav:
        out = pipe.process(args.wav)
        print(f"raw  : {out['raw']}")
        print(f"clean: {out['clean']}")
    else:
        raise SystemExit('give --wav <file> or --eval <split.json>')
