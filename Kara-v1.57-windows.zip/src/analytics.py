from __future__ import annotations
import csv
import json
import re
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / 'results'
DATA = ROOT / 'data'
SWEEP = [(50, 'bench_sweep_50.csv'), (100, 'bench_sweep_100.csv'), (200, 'bench_sweep_200.csv'), (300, 'bench_sweep_300.csv'), (402, 'bench_small_473.csv')]
_WORD = re.compile("[a-z0-9']+")

def _words(s: str) -> list[str]:
    return _WORD.findall((s or '').lower())

def edit_distance(ref: list[str], hyp: list[str]) -> int:
    if not ref:
        return len(hyp)
    prev = list(range(len(hyp) + 1))
    for i, r in enumerate(ref, 1):
        cur = [i]
        for j, h in enumerate(hyp, 1):
            cur.append(min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (r != h)))
        prev = cur
    return prev[-1]

def corpus_wer(rows) -> dict:
    errors = words = clips = 0
    for row in rows:
        ref = _words(row.get('reference'))
        hyp = _words(row.get('hypothesis'))
        if not ref:
            continue
        errors += edit_distance(ref, hyp)
        words += len(ref)
        clips += 1
    return {'wer': errors / words if words else 0.0, 'errors': errors, 'words': words, 'clips': clips}

def _read_csv(path: Path) -> list[dict]:
    with path.open(newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))

def learning_curve() -> list[dict]:
    out = []
    for n, name in SWEEP:
        path = RESULTS / name
        if not path.is_file():
            continue
        try:
            stats = corpus_wer(_read_csv(path))
        except (OSError, ValueError):
            continue
        if not stats['words']:
            continue
        stats.update(clips_trained=n, source=name)
        out.append(stats)
    return out

def history_path(speaker: str) -> Path:
    return DATA / speaker / 'wer_history.jsonl'

def record(speaker: str, entry: dict) -> None:
    try:
        import atomicio
        row = dict(entry)
        row.setdefault('at', time.time())
        atomicio.append_line(history_path(speaker), json.dumps(row, ensure_ascii=False) + '\n')
    except Exception:
        pass

def history(speaker: str) -> list[dict]:
    path = history_path(speaker)
    if not path.is_file():
        return []
    out = []
    try:
        for line in path.read_text(encoding='utf-8').splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if isinstance(row, dict) and 'candidate_wer' in row:
                out.append(row)
    except OSError:
        return []
    out.sort(key=lambda r: r.get('at', 0.0))
    return out

def summary(speaker: str) -> dict:
    hist = history(speaker)
    curve = learning_curve()
    best = min((h['candidate_wer'] for h in hist if h.get('candidate_wer') is not None), default=None)
    deployed = [h for h in hist if h.get('deploy')]
    return {'curve': curve, 'history': hist, 'evaluations': len(hist), 'deployed': len(deployed), 'best_wer': best, 'latest': hist[-1] if hist else None, 'curve_best': min((c['wer'] for c in curve), default=None)}
