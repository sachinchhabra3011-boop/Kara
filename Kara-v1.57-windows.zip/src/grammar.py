from __future__ import annotations
import re
from dataclasses import dataclass
__all__ = ['Issue', 'check', 'fix_all', 'apply_one']

@dataclass(frozen=True)
class Issue:
    start: int
    end: int
    replacement: str
    label: str
    kind: str

    @property
    def length(self) -> int:
        return self.end - self.start
_ABBREV = {'mr', 'mrs', 'ms', 'dr', 'prof', 'sr', 'jr', 'st', 'vs', 'etc', 'e.g', 'i.e', 'no', 'fig', 'approx', 'dept', 'est'}
_JOINED = re.compile('(?<=[a-z])(?=[A-Z])')
_CAMEL_OK = {'iphone', 'ipad', 'macbook', 'youtube', 'javascript', 'powerpoint', 'wifi', 'paypal', 'ebay', 'openai', 'github', 'linkedin', 'whatsapp'}
_SENT_END = re.compile('([.!?])(\\s*)([a-z])')
_SPACE_BEFORE_PUNCT = re.compile('\\s+([,.;:!?])')
_NO_SPACE_AFTER_PUNCT = re.compile('([,;:])(?=[^\\s\\d])')
_DOUBLE_SPACE = re.compile('(?<=\\S)([ \\t]{2,})(?=\\S)')
_REPEAT_PUNCT = re.compile('([,.;:!?])\\1+')
_SPACE_BEFORE_CLOSE = re.compile('\\s+([)\\]])')
_LONE_I = re.compile("(?<![\\w'])i(?![\\w'])")

def _tokens(text: str):
    return list(re.finditer('\\S+', text))

def check(text: str, vocab: dict | None=None) -> list[Issue]:
    issues: list[Issue] = []
    allowed = set(_CAMEL_OK)
    if vocab:
        for key in ('people', 'names', 'places', 'brands_apps', 'foods', 'spelled'):
            for w in vocab.get(key) or []:
                allowed.add(str(w).lower())
    for tok in _tokens(text):
        word = tok.group()
        bare = word.strip('.,;:!?"\'()[]')
        if bare.lower() in allowed or len(bare) < 4:
            continue
        for m in _JOINED.finditer(word):
            at = tok.start() + m.start()
            left = word[:m.start()].strip('.,;:!?"\'()[]')
            right = word[m.start():].strip('.,;:!?"\'()[]')
            if not left or not right:
                continue
            issues.append(Issue(at, at, ' ', f'“{left}{right}” looks like two words', 'joined_words'))
    for m in _SPACE_BEFORE_PUNCT.finditer(text):
        issues.append(Issue(m.start(), m.end(), m.group(1), f'space before “{m.group(1)}”', 'space_before_punct'))
    for m in _NO_SPACE_AFTER_PUNCT.finditer(text):
        issues.append(Issue(m.end(), m.end(), ' ', f'missing space after “{m.group(1)}”', 'no_space_after_punct'))
    for m in _SENT_END.finditer(text):
        before = text[:m.start()].split()
        last = before[-1].rstrip('.').lower() if before else ''
        if last in _ABBREV:
            continue
        letter_at = m.start(3)
        issues.append(Issue(letter_at, letter_at + 1, m.group(3).upper(), f'“{m.group(3)}” should start a new sentence', 'sentence_case'))
    for m in _DOUBLE_SPACE.finditer(text):
        issues.append(Issue(m.start(1), m.end(1), ' ', 'extra spaces', 'double_space'))
    for m in _REPEAT_PUNCT.finditer(text):
        issues.append(Issue(m.start(), m.end(), m.group(1), f'repeated “{m.group(1)}”', 'repeat_punct'))
    for m in _SPACE_BEFORE_CLOSE.finditer(text):
        issues.append(Issue(m.start(), m.end(), m.group(1), 'space before a bracket', 'space_before_close'))
    for m in _LONE_I.finditer(text):
        issues.append(Issue(m.start(), m.end(), 'I', '“i” should be capital', 'lone_i'))
    issues.sort(key=lambda i: (i.start, -i.length))
    out: list[Issue] = []
    last_end = -1
    for i in issues:
        if i.start < last_end:
            continue
        out.append(i)
        last_end = max(last_end, i.end)
    return out

def apply_one(text: str, issue: Issue) -> str:
    return text[:issue.start] + issue.replacement + text[issue.end:]

def fix_all(text: str, vocab: dict | None=None) -> tuple[str, int]:
    issues = check(text, vocab)
    for issue in reversed(issues):
        text = apply_one(text, issue)
    return (text, len(issues))

def describe(issues: list[Issue]) -> str:
    if not issues:
        return 'nothing to fix'
    if len(issues) == 1:
        return f'1 thing to fix: {issues[0].label}'
    return f'{len(issues)} things to fix'
