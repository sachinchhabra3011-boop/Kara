from __future__ import annotations
import json
import time
from pathlib import Path
import atomicio
ROOT = Path(__file__).resolve().parent.parent
KEEP = 40
DIRNAME = 'utterances'

def dir_for(speaker: str) -> Path:
    return ROOT / 'data' / speaker / DIRNAME

def index_path(speaker: str) -> Path:
    return dir_for(speaker) / 'index.json'

def load_index(speaker: str) -> list[dict]:
    p = index_path(speaker)
    if not p.exists():
        return []
    try:
        rows = json.loads(p.read_text(encoding='utf-8'))
        return rows if isinstance(rows, list) else []
    except (OSError, ValueError):
        return []

def save_index(speaker: str, rows: list[dict]) -> None:
    try:
        atomicio.write_json(index_path(speaker), rows)
    except OSError:
        pass

def _new_id() -> str:
    return f'{int(time.time() * 1000):013d}'

def save(speaker: str, audio, sample_rate: int, asr_text: str='', mode: str='dictation') -> dict | None:
    import soundfile as sf
    d = dir_for(speaker)
    try:
        d.mkdir(parents=True, exist_ok=True)
        utt_id = _new_id()
        wav = d / f'{utt_id}.wav'
        sf.write(wav, audio, sample_rate, subtype='PCM_16')
    except (OSError, RuntimeError):
        return None
    row = {'id': utt_id, 'wav': str(wav.relative_to(ROOT)).replace('\\', '/'), 'asr': asr_text, 'mode': mode, 'at': time.time(), 'duration_s': round(len(audio) / float(sample_rate), 2), 'corrected': None}
    rows = load_index(speaker)
    rows.append(row)
    rows = prune(speaker, rows)
    save_index(speaker, rows)
    return row

def prune(speaker: str, rows: list[dict] | None=None, keep: int=KEEP) -> list[dict]:
    rows = load_index(speaker) if rows is None else rows
    rows = sorted(rows, key=lambda r: r.get('at', 0))
    keep_rows = rows[-keep:] if keep > 0 else []
    kept_names = {Path(r.get('wav', '')).name for r in keep_rows}
    d = dir_for(speaker)
    if d.is_dir():
        for wav in d.glob('*.wav'):
            if wav.name not in kept_names:
                try:
                    wav.unlink()
                except OSError:
                    pass
    return keep_rows

def latest(speaker: str, n: int=1) -> list[dict]:
    rows = sorted(load_index(speaker), key=lambda r: r.get('at', 0), reverse=True)
    return rows[:n]

def get(speaker: str, utt_id: str) -> dict | None:
    return next((r for r in load_index(speaker) if r.get('id') == utt_id), None)

def _update(speaker: str, utt_id: str, **fields) -> None:
    rows = load_index(speaker)
    for r in rows:
        if r.get('id') == utt_id:
            r.update(fields)
            save_index(speaker, rows)
            return

def note_asr(speaker: str, utt_id: str, asr_text: str) -> None:
    _update(speaker, utt_id, asr=asr_text)

def note_correction(speaker: str, utt_id: str, corrected: str) -> None:
    _update(speaker, utt_id, corrected=corrected)

def mark_harvested(speaker: str, utt_id: str) -> None:
    _update(speaker, utt_id, harvested=True)

def wav_for(speaker: str, utt_id: str) -> Path | None:
    row = get(speaker, utt_id)
    if not row:
        return None
    p = ROOT / row['wav']
    return p if p.exists() else None

def forget_all(speaker: str) -> int:
    d = dir_for(speaker)
    n = 0
    if d.is_dir():
        for wav in d.glob('*.wav'):
            try:
                wav.unlink()
                n += 1
            except OSError:
                pass
    save_index(speaker, [])
    return n

def inventory(speaker: str) -> dict:
    d = dir_for(speaker)
    wavs = list(d.glob('*.wav')) if d.is_dir() else []
    rows = load_index(speaker)
    total = 0
    for w in wavs:
        try:
            total += w.stat().st_size
        except OSError:
            pass
    idx = index_path(speaker)
    if idx.exists():
        total += idx.stat().st_size
    return {'count': len(wavs), 'bytes': total, 'seconds': round(sum((float(r.get('duration_s') or 0) for r in rows)), 1), 'where': str(d), 'keep': KEEP}
