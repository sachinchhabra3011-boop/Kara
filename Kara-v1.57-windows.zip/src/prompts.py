from pathlib import Path
PROMPTS_DIR = Path(__file__).resolve().parent.parent / 'data' / 'prompts'

def load(set_name: str) -> list[tuple[str, str]]:
    path = PROMPTS_DIR / f'{set_name}.txt'
    if not path.exists():
        available = sorted((p.stem for p in PROMPTS_DIR.glob('*.txt')))
        raise SystemExit(f"No prompt set '{set_name}'. Available: {', '.join(available)}")
    lines = [line.strip() for line in path.read_text(encoding='utf-8').splitlines() if line.strip() and (not line.lstrip().startswith('#'))]
    return [(f'{set_name}-{i:03d}', text) for i, text in enumerate(lines)]
