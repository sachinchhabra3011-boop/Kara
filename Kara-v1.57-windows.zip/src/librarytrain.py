from __future__ import annotations
import re
from pathlib import Path
import config
import library
ROOT = Path(__file__).resolve().parent.parent
MIN_LENGTH = 4
_WORD = re.compile("[A-Za-z][A-Za-z'’-]{2,}")

def included(speaker: str) -> list[str]:
    cfg = config.load()
    return [str(d) for d in cfg.get('train_on_documents') or []]

def _set(ids: list[str]) -> None:
    cfg = config.load()
    cfg['train_on_documents'] = sorted(set(ids))
    config.save(cfg)

def include(speaker: str, doc_id: str) -> None:
    _set(included(speaker) + [doc_id])

def forget(speaker: str, doc_id: str) -> None:
    _set([d for d in included(speaker) if d != doc_id])

def words_in(speaker: str, doc_id: str) -> set[str]:
    try:
        text = library.read(speaker, doc_id)
    except Exception:
        return set()
    found = {m.group().strip("'’-").lower() for m in _WORD.finditer(text or '')}
    return {w for w in found if len(w) >= MIN_LENGTH}

def vocabulary(speaker: str, known=None) -> set[str]:
    out: set[str] = set()
    for doc_id in included(speaker):
        out |= words_in(speaker, doc_id)
    if known is not None:
        out = {w for w in out if not known(w)}
    return out

def summary(speaker: str, known=None) -> dict:
    docs = included(speaker)
    words = vocabulary(speaker, known)
    return {'documents': len(docs), 'words': len(words), 'sample': sorted(words)[:40]}

def choices(speaker: str) -> list[dict]:
    on = set(included(speaker))
    rows = []
    for d in library.list_docs(speaker):
        rows.append({'id': d.get('id'), 'title': d.get('title') or '(untitled)', 'included': d.get('id') in on})
    return rows
