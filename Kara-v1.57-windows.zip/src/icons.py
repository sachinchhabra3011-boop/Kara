from __future__ import annotations
import math
from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QAbstractButton, QWidget
from i18n import t

def _copy(p: QPainter):
    p.drawRoundedRect(QRectF(9.0, 7.0, 11.5, 13.5), 2.4, 2.4)
    r = 2.4
    back = QPainterPath()
    back.moveTo(15.0, 3.5)
    back.lineTo(3.5 + r, 3.5)
    back.quadTo(3.5, 3.5, 3.5, 3.5 + r)
    back.lineTo(3.5, 17.0 - r)
    back.quadTo(3.5, 17.0, 3.5 + r, 17.0)
    back.lineTo(9.0, 17.0)
    p.drawPath(back)

def _speaker(p: QPainter, muted: bool=False):
    body = QPainterPath()
    body.moveTo(3.0, 9.0)
    body.lineTo(7.0, 9.0)
    body.lineTo(11.5, 4.5)
    body.lineTo(11.5, 19.5)
    body.lineTo(7.0, 15.0)
    body.lineTo(3.0, 15.0)
    body.closeSubpath()
    p.drawPath(body)
    if muted:
        p.drawLine(QPointF(15.0, 9.0), QPointF(20.5, 15.0))
        p.drawLine(QPointF(20.5, 9.0), QPointF(15.0, 15.0))
    else:
        p.drawArc(QRectF(11.0, 7.5, 7.0, 9.0), -60 * 16, 120 * 16)
        p.drawArc(QRectF(11.0, 4.5, 11.0, 15.0), -60 * 16, 120 * 16)

def _undo(p: QPainter):
    path = QPainterPath()
    path.moveTo(4.0, 11.0)
    path.arcTo(QRectF(4.0, 7.0, 16.0, 13.0), 180.0, -230.0)
    p.drawPath(path)
    head = QPainterPath()
    head.moveTo(4.0, 5.5)
    head.lineTo(4.0, 12.0)
    head.lineTo(10.0, 12.0)
    p.drawPath(head)

def _redo(p: QPainter):
    p.save()
    p.translate(24.0, 0.0)
    p.scale(-1.0, 1.0)
    _undo(p)
    p.restore()

def _more(p: QPainter):
    p.save()
    brush = p.pen().color()
    p.setBrush(brush)
    p.setPen(Qt.NoPen)
    for x in (6.0, 12.0, 18.0):
        p.drawEllipse(QPointF(x, 12.0), 1.7, 1.7)
    p.restore()

def _trash(p: QPainter):
    p.drawLine(QPointF(3.5, 6.5), QPointF(20.5, 6.5))
    p.drawLine(QPointF(9.5, 6.5), QPointF(9.5, 3.5))
    p.drawLine(QPointF(9.5, 3.5), QPointF(14.5, 3.5))
    p.drawLine(QPointF(14.5, 3.5), QPointF(14.5, 6.5))
    body = QPainterPath()
    body.moveTo(5.5, 6.5)
    body.lineTo(6.8, 20.5)
    body.lineTo(17.2, 20.5)
    body.lineTo(18.5, 6.5)
    p.drawPath(body)
    p.drawLine(QPointF(10.0, 10.0), QPointF(10.4, 17.0))
    p.drawLine(QPointF(14.0, 10.0), QPointF(13.6, 17.0))

def _cog(p: QPainter):
    cx = cy = 12.0
    teeth, r_out, r_in = (7, 10.2, 7.4)
    step = math.tau / teeth
    half = step * 0.24
    path = QPainterPath()
    started = False
    for i in range(teeth):
        a = step * i
        for ang, rad in ((a - half, r_out), (a + half, r_out), (a + half + step * 0.14, r_in), (a + step - half - step * 0.14, r_in)):
            pt = QPointF(cx + math.cos(ang) * rad, cy + math.sin(ang) * rad)
            if started:
                path.lineTo(pt)
            else:
                path.moveTo(pt)
                started = True
    path.closeSubpath()
    p.drawPath(path)
    p.drawEllipse(QPointF(cx, cy), 3.4, 3.4)

def _cycle(p: QPainter):
    import math
    cx = cy = 12.0
    r = 7.6
    for base in (0.0, 180.0):
        a0 = math.radians(base + 20)
        a1 = math.radians(base + 160)
        rect = QRectF(cx - r, cy - r, 2 * r, 2 * r)
        p.drawArc(rect, int((base + 20) * 16), int(140 * 16))
        ex, ey = (cx + math.cos(a1) * r, cy + math.sin(a1) * r)
        tang = a1 + math.pi / 2
        for da in (math.radians(150), -math.radians(150)):
            hx = ex + math.cos(tang + da) * 4.2
            hy = ey + math.sin(tang + da) * 4.2
            p.drawLine(QPointF(ex, ey), QPointF(hx, hy))

def _menu(p: QPainter):
    for y in (6.5, 12.0, 17.5):
        p.drawLine(QPointF(4.0, y), QPointF(20.0, y))

def _mini(p: QPainter):
    p.drawRoundedRect(QRectF(3.0, 5.0, 18.0, 14.0), 2.4, 2.4)
    p.save()
    p.setBrush(p.pen().color())
    p.drawRoundedRect(QRectF(11.5, 11.0, 8.0, 6.5), 1.4, 1.4)
    p.restore()

def _expand(p: QPainter):
    p.drawLine(QPointF(4.0, 10.0), QPointF(4.0, 4.0))
    p.drawLine(QPointF(4.0, 4.0), QPointF(10.0, 4.0))
    p.drawLine(QPointF(4.0, 4.0), QPointF(10.5, 10.5))
    p.drawLine(QPointF(20.0, 14.0), QPointF(20.0, 20.0))
    p.drawLine(QPointF(20.0, 20.0), QPointF(14.0, 20.0))
    p.drawLine(QPointF(20.0, 20.0), QPointF(13.5, 13.5))

def _warn(p: QPainter):
    p.drawPolygon([QPointF(12.0, 3.5), QPointF(22.0, 20.5), QPointF(2.0, 20.5)])
    p.drawLine(QPointF(12.0, 9.5), QPointF(12.0, 14.5))
    p.drawLine(QPointF(12.0, 17.6), QPointF(12.0, 17.7))
GLYPHS = {'menu': _menu, 'mini': _mini, 'expand': _expand, 'warn': _warn, 'copy': _copy, 'speaker': _speaker, 'undo': _undo, 'redo': _redo, 'more': _more, 'trash': _trash, 'cog': _cog, 'cycle': _cycle}

def paint_glyph(p: QPainter, name: str, box: float, colour: QColor, width: float=1.9, muted: bool=False):
    p.save()
    p.setRenderHint(QPainter.Antialiasing)
    p.scale(box / 24.0, box / 24.0)
    pen = QPen(colour)
    pen.setWidthF(width * 24.0 / box)
    pen.setCapStyle(Qt.RoundCap)
    pen.setJoinStyle(Qt.RoundJoin)
    p.setPen(pen)
    p.setBrush(Qt.NoBrush)
    fn = GLYPHS[name]
    if name == 'speaker':
        fn(p, muted)
    else:
        fn(p)
    p.restore()

def paint_mark(p: QPainter, size: float, colour: QColor, void: QColor | None=None, cut: str | None=None) -> None:
    p.save()
    p.setRenderHint(QPainter.Antialiasing)
    p.scale(size / 64.0, size / 64.0)
    ring = cut == 'ring' or (cut is None and size >= 34)
    if ring:
        pen = QPen(colour)
        pen.setWidthF(5.0)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        p.setPen(pen)
        p.setBrush(Qt.NoBrush)
        p.drawEllipse(QRectF(9.5, 9.5, 45.0, 45.0))
        wave = QPainterPath()
        wave.moveTo(17, 32)
        wave.quadTo(20, 23, 23, 32)
        wave.quadTo(26, 41, 29, 32)
        wave.quadTo(31.5, 26, 34, 32)
        wave.lineTo(47, 32)
        pen.setWidthF(4.0)
        p.setPen(pen)
        p.drawPath(wave)
    else:
        p.setPen(Qt.NoPen)
        p.setBrush(colour)
        p.drawEllipse(QRectF(5, 5, 54, 54))
        wave = QPainterPath()
        if size >= 22:
            wave.moveTo(15, 32)
            wave.quadTo(19, 21, 23, 32)
            wave.quadTo(27, 43, 31, 32)
            wave.lineTo(49, 32)
            stroke = 7.0
        else:
            wave.moveTo(14, 34)
            wave.quadTo(21, 16, 28, 34)
            wave.lineTo(50, 34)
            stroke = 8.5
        pen = QPen(void if void is not None else QColor('#34190e'))
        pen.setWidthF(stroke)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        p.setPen(pen)
        p.setBrush(Qt.NoBrush)
        p.drawPath(wave)
    p.restore()

class ToggleSwitch(QAbstractButton):

    def __init__(self, text: str='', parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setCursor(Qt.PointingHandCursor)
        self._text = t(text)
        self.setAccessibleName(self._text)
        self._pos = 0.0
        self._on = '#9fc98a'
        self._off = '#5a3527'
        self._knob = '#f4ece4'
        self._ink = '#f4ece4'
        self.setMinimumHeight(30)
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._step)
        self.toggled.connect(self._begin)

    def _begin(self, on: bool):
        if not self.isVisible():
            self._pos = 1.0 if on else 0.0
            self._timer.stop()
            self.update()
            return
        self._timer.start(12)
    W, H = (46, 26)

    def set_colours(self, on=None, off=None, knob=None, ink=None):
        self._on = on or self._on
        self._off = off or self._off
        self._knob = knob or self._knob
        self._ink = ink or self._ink
        self.update()

    def setText(self, text: str):
        self._text = text
        self.updateGeometry()
        self.update()

    def text(self) -> str:
        return self._text

    def sizeHint(self):
        from PySide6.QtCore import QSize
        from PySide6.QtGui import QFontMetrics
        w = self.W + 10 + QFontMetrics(self.font()).horizontalAdvance(self._text)
        return QSize(int(w), max(self.H + 4, 30))

    def _step(self):
        target = 1.0 if self.isChecked() else 0.0
        if abs(self._pos - target) < 0.03:
            self._pos = target
            self._timer.stop()
        else:
            self._pos += (target - self._pos) * 0.35
        self.update()

    def paintEvent(self, _e):
        if not self._timer.isActive():
            self._pos = 1.0 if self.isChecked() else 0.0
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        y = (self.height() - self.H) / 2
        track = QRectF(0, y, self.W, self.H)
        c_off, c_on = (QColor(self._off), QColor(self._on))
        t = self._pos
        track_col = QColor(int(c_off.red() + (c_on.red() - c_off.red()) * t), int(c_off.green() + (c_on.green() - c_off.green()) * t), int(c_off.blue() + (c_on.blue() - c_off.blue()) * t))
        p.setPen(Qt.NoPen)
        p.setBrush(track_col)
        p.drawRoundedRect(track, self.H / 2, self.H / 2)
        r = self.H - 8
        x = 4 + t * (self.W - r - 8)
        p.setBrush(QColor(self._knob))
        p.drawEllipse(QRectF(x, y + 4, r, r))
        if self._text:
            p.setPen(QColor(self._ink))
            p.drawText(QRectF(self.W + 10, 0, self.width() - self.W - 10, self.height()), Qt.AlignLeft | Qt.AlignVCenter, self._text)
        p.end()

class Mark(QWidget):

    def __init__(self, size: int=28, colour: str='#a58970', void: str='#34190e', parent=None):
        super().__init__(parent)
        self._size, self._colour, self._void = (size, colour, void)
        self.setFixedSize(size, size)

    def set_colour(self, colour: str, void: str | None=None):
        self._colour = colour
        if void:
            self._void = void
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        paint_mark(p, self._size, QColor(self._colour), QColor(self._void), cut='ring')
        p.end()

class Wordmark(QWidget):

    def __init__(self, size: int=28, colour: str='#a58970', ink: str='#f4ece4', void: str='#34190e', families: list[str] | None=None, parent=None):
        super().__init__(parent)
        self._size, self._colour, self._ink, self._void = (size, colour, ink, void)
        self._families = families or ['Source Sans 3', 'Segoe UI Variable Display', 'Segoe UI', 'Roboto']
        self._gap = max(6.0, size * 0.34)
        self.setFixedHeight(size)
        self.setMinimumWidth(int(size + self._gap + size * 2.2))

    def _font(self) -> QFont:
        f = QFont()
        f.setFamilies(self._families)
        f.setPixelSize(int(self._size * 0.86))
        f.setWeight(QFont.DemiBold)
        return f

    def sizeHint(self):
        from PySide6.QtCore import QSize
        from PySide6.QtGui import QFontMetrics
        w = self._size + self._gap + QFontMetrics(self._font()).horizontalAdvance('Kara')
        return QSize(int(w), self._size)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.TextAntialiasing)
        paint_mark(p, self._size, QColor(self._colour), QColor(self._void), cut='ring')
        p.setFont(self._font())
        p.setPen(QColor(self._ink))
        p.drawText(QRectF(self._size + self._gap, 0, self.width() - self._size - self._gap, self._size), Qt.AlignLeft | Qt.AlignVCenter, 'Kara')
        p.end()

def mark_icon(sizes=(16, 24, 32, 48, 64, 128, 256), colour: str='#a58970', void: str='#34190e'):
    from PySide6.QtGui import QIcon, QPixmap
    icon = QIcon()
    for s in sizes:
        pix = QPixmap(s, s)
        pix.fill(Qt.transparent)
        p = QPainter(pix)
        paint_mark(p, float(s), QColor(colour), QColor(void))
        p.end()
        icon.addPixmap(pix)
    return icon
AVATAR_COLOURS = ['#3f7d6e', '#4a6fa5', '#7a5a9e', '#a85670', '#8c6231', '#4c7139']

def avatar_colour(name: str) -> str:
    return AVATAR_COLOURS[sum((ord(c) for c in (name or '?').lower())) % len(AVATAR_COLOURS)]

def paint_avatar(p: QPainter, name: str, size: float, ink: str='#ffffff', photo: str | None=None):
    p.save()
    p.setRenderHint(QPainter.Antialiasing)
    p.setRenderHint(QPainter.SmoothPixmapTransform)
    if photo:
        from PySide6.QtGui import QPainterPath as _PP, QPixmap
        pix = QPixmap(photo)
        if not pix.isNull():
            clip = _PP()
            clip.addEllipse(QRectF(0, 0, size, size))
            p.setClipPath(clip)
            scaled = pix.scaled(int(size), int(size), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
            p.drawPixmap(int((size - scaled.width()) / 2), int((size - scaled.height()) / 2), scaled)
            p.restore()
            return
    p.setPen(Qt.NoPen)
    p.setBrush(QColor(avatar_colour(name)))
    p.drawEllipse(QRectF(0, 0, size, size))
    f = p.font()
    f.setPixelSize(int(size * 0.46))
    f.setWeight(QFont.DemiBold)
    p.setFont(f)
    p.setPen(QColor(ink))
    letter = (name or '?').strip()[:1].upper() or '?'
    p.drawText(QRectF(0, 0, size, size), Qt.AlignCenter, letter)
    p.restore()

class Avatar(QWidget):

    def __init__(self, name: str, size: int=40, parent=None, photo: str | None=None):
        super().__init__(parent)
        self.name = name
        self.photo = photo
        self.setFixedSize(size, size)

    def set_name(self, name: str, photo: str | None=None):
        self.name = name
        self.photo = photo
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        paint_avatar(p, self.name, float(self.width()), photo=self.photo)
        p.end()

class AvatarButton(QAbstractButton):

    def __init__(self, name: str, size: int=34, parent=None, photo: str | None=None):
        super().__init__(parent)
        self.name = name
        self.photo = photo
        self.setFixedSize(size, size)
        self.setCursor(Qt.PointingHandCursor)
        self._hover = False
        self.setToolTip(t('Profiles'))
        self.setAccessibleName(t('Profiles'))

    def set_name(self, name: str, photo: str | None=None):
        self.name = name
        self.photo = photo
        self.setToolTip(t('Profile: %s') % name)
        self.setAccessibleName(t('Profile: %s') % name)
        self.update()

    def enterEvent(self, e):
        self._hover = True
        self.update()

    def leaveEvent(self, e):
        self._hover = False
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        d = float(self.width())
        if self._hover:
            ring = QColor(avatar_colour(self.name))
            ring.setAlphaF(0.35)
            p.setPen(Qt.NoPen)
            p.setBrush(ring)
            p.drawEllipse(QRectF(0, 0, d, d))
            p.translate(2, 2)
            paint_avatar(p, self.name, d - 4, photo=self.photo)
        else:
            paint_avatar(p, self.name, d, photo=self.photo)
        p.end()

class GlyphIcon(QWidget):

    def __init__(self, glyph: str, box: float=32.0, colour='#f28b84', parent=None):
        super().__init__(parent)
        self.glyph, self.box = (glyph, float(box))
        self.colour = QColor(colour)
        self.setFixedSize(int(self.box) + 8, int(self.box) + 8)

    def set_colour(self, colour):
        self.colour = QColor(colour)
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        off = (self.width() - self.box) / 2.0
        p.translate(off, off)
        paint_glyph(p, self.glyph, self.box, self.colour)
        p.end()

class IconButton(QAbstractButton):

    def __init__(self, glyph: str, tooltip: str='', checkable: bool=False, size: int=34, box: float=19.0, parent=None):
        super().__init__(parent)
        self.glyph = glyph
        self.box = box
        self.setCheckable(checkable)
        self.setFixedSize(size, size)
        self.setCursor(Qt.PointingHandCursor)
        if tooltip:
            said = t(tooltip)
            self.setToolTip(said)
            self.setAccessibleName(said)
        self._hover = False
        self.col_idle = QColor('#b09a88')
        self.col_on = QColor('#7aa5d6')
        self.col_hover = QColor('#f2e8df')
        self.col_disabled = QColor('#6b584c')
        self.col_hover_bg = QColor(255, 255, 255, 18)

    def set_palette(self, idle, on, hover, disabled, hover_bg):
        self.col_idle = QColor(idle)
        self.col_on = QColor(on)
        self.col_hover = QColor(hover)
        self.col_disabled = QColor(disabled)
        self.col_hover_bg = QColor(hover_bg)
        self.update()

    def enterEvent(self, e):
        self._hover = True
        self.update()

    def leaveEvent(self, e):
        self._hover = False
        self.update()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        if self._hover and self.isEnabled():
            p.setPen(Qt.NoPen)
            p.setBrush(self.col_hover_bg)
            p.drawRoundedRect(QRectF(0, 0, self.width(), self.height()), 8, 8)
        if not self.isEnabled():
            col = self.col_disabled
        elif self.isCheckable() and self.isChecked():
            col = self.col_on
        elif self._hover:
            col = self.col_hover
        else:
            col = self.col_idle
        off = (self.width() - self.box) / 2.0
        p.translate(off, off)
        if self.isDown():
            p.translate(self.box / 2, self.box / 2)
            p.scale(0.92, 0.92)
            p.translate(-self.box / 2, -self.box / 2)
        muted = self.isCheckable() and (not self.isChecked())
        paint_glyph(p, self.glyph, self.box, col, muted=muted)
        p.end()

class Spinner(QWidget):

    def __init__(self, size: int=18, parent=None):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self._angle = 0.0
        self._colour = QColor('#a58970')
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._spin)
        self.hide()

    def set_colour(self, colour):
        self._colour = QColor(colour)
        self.update()

    def _spin(self):
        self._angle = (self._angle + 6.0) % 360.0
        self.update()

    def start(self):
        self.show()
        if not self._timer.isActive():
            self._timer.start(16)

    def stop(self):
        self._timer.stop()
        self.hide()

    def paintEvent(self, _e):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        m = 2.0
        rect = QRectF(m, m, self.width() - 2 * m, self.height() - 2 * m)
        faint = QColor(self._colour)
        faint.setAlphaF(0.22)
        p.setPen(QPen(faint, 2.0, Qt.SolidLine, Qt.RoundCap))
        p.drawEllipse(rect)
        p.setPen(QPen(self._colour, 2.0, Qt.SolidLine, Qt.RoundCap))
        p.drawArc(rect, int(-self._angle * 16), 100 * 16)
        p.end()

def _sheet(path: str):
    import sys
    from PySide6.QtWidgets import QApplication, QHBoxLayout
    app = QApplication(sys.argv)
    holder = QWidget()
    holder.setStyleSheet('background:#34190e;')
    lay = QHBoxLayout(holder)
    lay.setContentsMargins(12, 12, 12, 12)
    for name in GLYPHS:
        b = IconButton(name, size=40, box=23.0)
        lay.addWidget(b)
    off = IconButton('speaker', checkable=True, size=40, box=23.0)
    on = IconButton('speaker', checkable=True, size=40, box=23.0)
    on.setChecked(True)
    lay.addWidget(off)
    lay.addWidget(on)
    holder.resize(holder.sizeHint())
    holder.grab().save(path)
    print('wrote', path)
    sys.exit(0)
