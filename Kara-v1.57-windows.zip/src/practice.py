from __future__ import annotations
import json
import re
import unicodedata
from datetime import date, timedelta
from pathlib import Path
import atomicio
ROOT = Path(__file__).resolve().parent.parent

def _words(text: str) -> list[str]:
    out = []
    for chunk in (text or '').split():
        w = ''.join((c for c in chunk if not unicodedata.category(c).startswith('P')))
        if w:
            out.append(w.lower())
    return out
LEVELS = [(1, '/r/ at the start', ['Read the red book on the roof.', 'The rain is ready to run.', 'Right now the road is wet.']), (2, '/r/ at the end', ['The water is better in winter.', 'My father wrote a letter.', 'Put the paper under the door.']), (3, 'Long vowels', ['Take a seat and meet me here.', 'The road home is a long drive.', 'He phoned me on a green phone.']), (4, '/s/ at the start', ['My sister sat in the sun.', 'Seven seconds is not long.', 'She said so on Sunday.']), (5, 'Word endings', ['He asked and then walked away.', 'My hands held the books.', 'The lights stayed on all night.']), (6, 'Plosives — p, k, f', ['Put four cups on the table.', 'The key fits the front door.', 'A pen and a piece of paper.']), (7, '/r/ after a consonant', ['The strong wind broke the branch.', 'She brought bread on the train.', 'A bright green dress.']), (8, 'Weak first sounds', ['He hit the ball very high.', 'I hope the heat holds.', 'Hold on and help me here.']), (9, 'Two syllables', ['Open the window in the morning.', 'The table is under the ladder.', 'Follow me into the garden.']), (10, 'Three syllables', ['Tomorrow is important to my family.', 'The hospital is a long way away.', 'Remember to telephone your brother.']), (11, 'Names', []), (12, 'Places', []), (13, 'Numbers', ['Thirteen is not thirty.', 'Fifteen people, not fifty.', 'It costs forty-four rupees.']), (14, '/r/ inside a cluster', ['The scrambled letters were extraordinary.', 'I borrowed a library card.', 'Three trains crossed the bridge.'])]
LEVEL_NAMES = {n: name for n, name, _s in LEVELS}
PHRASES_PER_ROUND = 8
CUSTOM_LEVEL = 0
QUEUE_REPEATS = 2

def path(speaker: str) -> Path:
    return ROOT / 'data' / speaker / 'practice.json'

def clips_manifest(speaker: str) -> Path:
    return ROOT / 'data' / speaker / 'practice_manifest.csv'
CLIP_FIELDS_EXTRA = ['practice_score']

def keep_clip(speaker: str, target: str, audio, score: int) -> str | None:
    import csv
    import soundfile as sf
    import record
    target = (target or '').strip()
    if not target or audio is None or (not getattr(audio, 'size', 0)):
        return None
    rec_dir = ROOT / 'data' / speaker / 'recordings'
    rec_dir.mkdir(parents=True, exist_ok=True)
    dest = clips_manifest(speaker)
    rows = []
    if dest.exists():
        with dest.open(encoding='utf-8-sig', newline='') as f:
            rows = list(csv.DictReader(f))
    clip_id = f'practice-{len(rows):05d}'
    n = len(rows)
    while (rec_dir / f'{clip_id}.wav').exists():
        n += 1
        clip_id = f'practice-{n:05d}'
    wav = rec_dir / f'{clip_id}.wav'
    sf.write(str(wav), audio, record.SAMPLE_RATE, subtype='PCM_16')
    rows.append({'prompt_id': clip_id, 'prompt_set': 'practice', 'prompt_text': target, 'wav_path': str(wav.relative_to(ROOT)).replace('\\', '/'), 'duration_s': f'{audio.size / record.SAMPLE_RATE:.2f}', 'peak': f'{float(abs(audio).max()):.3f}', 'recorded_at': _now(), 'practice_score': str(int(score))})
    atomicio.write_csv(dest, record.FIELDS + CLIP_FIELDS_EXTRA, rows, backup=True)
    return clip_id

def clip_count(speaker: str) -> int:
    import csv
    dest = clips_manifest(speaker)
    if not dest.exists():
        return 0
    try:
        with dest.open(encoding='utf-8-sig', newline='') as f:
            return sum((1 for r in csv.DictReader(f) if (r.get('prompt_text') or '').strip()))
    except OSError:
        return 0

def _now() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

def load(speaker: str) -> dict:
    try:
        d = json.loads(path(speaker).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        d = {}
    return {'levels': {str(k): v for k, v in (d.get('levels') or {}).items()}, 'streak': int(d.get('streak') or 0), 'last_day': str(d.get('last_day') or ''), 'said': int(d.get('said') or 0), 'blocked': [str(x) for x in d.get('blocked') or []], 'custom': [str(x) for x in d.get('custom') or []]}

def save(speaker: str, state: dict) -> None:
    atomicio.write_json(path(speaker), {'_comment': 'Practice progress. Yours -- delete it and only the numbers go.', **state}, backup=True)

def _vocab_words(speaker: str, keys) -> list[str]:
    try:
        import corrector
        v = corrector.load_vocab(speaker) or {}
    except Exception:
        return []
    out = []
    for key in keys:
        for item in v.get(key) or []:
            w = str(item).strip()
            if w:
                out.append(w)
    return out

def corrections(speaker: str) -> list[dict]:
    seen, out = (set(), [])
    try:
        import wordfix
        for row in wordfix.candidates(speaker, repeats=QUEUE_REPEATS):
            key = str(row['meant']).lower()
            if key not in seen:
                seen.add(key)
                out.append({'heard': row['heard'], 'meant': row['meant'], 'count': row['count']})
    except Exception:
        pass
    try:
        import corrector
        table = (corrector.load_vocab(speaker) or {}).get('confusions') or {}
        for heard, meant in table.items():
            key = str(meant).lower()
            if key not in seen:
                seen.add(key)
                out.append({'heard': str(heard), 'meant': str(meant), 'count': 1})
    except Exception:
        pass
    return out

def has_evidence(speaker: str) -> bool:
    return bool(corrections(speaker))
_VOWELS = set('aeiou')

def level_of(meant: str, people: set[str], places: set[str]) -> int | None:
    w = (meant or '').strip().lower()
    if not w:
        return None
    if w in people:
        return 11
    if w in places:
        return 12
    head = w.split()[0]
    if 'r' in head:
        i = head.index('r')
        if i == 0:
            return 1
        before, after = (head[i - 1], head[i + 1] if i + 1 < len(head) else '')
        if before not in _VOWELS:
            return 14 if i >= 2 and head[i - 2] not in _VOWELS else 7
        if not after or i == len(head) - 1:
            return 2
        return 2
    if head.startswith('s') and len(head) > 1 and (head[1] not in _VOWELS):
        return 4
    if head.startswith('s'):
        return 4
    if head[0] in 'pkf':
        return 6
    return None

def assignments(speaker: str) -> dict[int, list[str]]:
    people = {w.lower() for w in _vocab_words(speaker, ('names', 'people'))}
    places = {w.lower() for w in _vocab_words(speaker, ('places',))}
    out: dict[int, list[str]] = {}
    for row in corrections(speaker):
        n = level_of(row['meant'], people, places)
        if n is None:
            continue
        if n == 11:
            phrase = f"This is {row['meant']}."
        elif n == 12:
            phrase = f"We are going to {row['meant']}."
        else:
            phrase = f"I said {row['meant']}, not {row['heard']}."
        out.setdefault(n, [])
        if phrase not in out[n]:
            out[n].append(phrase)
    return out

def phrases_for(speaker: str, level: int) -> list[str]:
    mine = assignments(speaker).get(level, [])
    seeds = dict(((n, s) for n, _l, s in LEVELS)).get(level, [])
    picked = list(dict.fromkeys(list(mine) + list(seeds)))
    blocked = {b.strip().lower() for b in load(speaker)['blocked']}
    picked = [p for p in picked if p.strip().lower() not in blocked]
    return picked[:PHRASES_PER_ROUND]

def block(speaker: str, phrase: str) -> None:
    state = load(speaker)
    if phrase and phrase not in state['blocked']:
        state['blocked'].append(phrase)
        save(speaker, state)

def unblock(speaker: str, phrase: str) -> None:
    state = load(speaker)
    state['blocked'] = [b for b in state['blocked'] if b != phrase]
    save(speaker, state)

def add_custom(speaker: str, text: str) -> str:
    text = ' '.join((text or '').split())
    if not text:
        return ''
    phrase = text if len(text.split()) > 1 else f'I want to say {text}.'
    if not phrase.endswith(('.', '?', '!')):
        phrase += '.'
    state = load(speaker)
    if phrase not in state['custom']:
        state['custom'].append(phrase)
        save(speaker, state)
    return phrase

def remove_custom(speaker: str, phrase: str) -> None:
    state = load(speaker)
    state['custom'] = [c for c in state['custom'] if c != phrase]
    save(speaker, state)

def custom_phrases(speaker: str) -> list[str]:
    blocked = {b.strip().lower() for b in load(speaker)['blocked']}
    return [c for c in load(speaker)['custom'] if c.strip().lower() not in blocked]

def score(said: str, target: str) -> int:
    want = _words(target)
    got = _words(said)
    if not want:
        return 0
    import difflib
    sm = difflib.SequenceMatcher(a=got, b=want, autojunk=False)
    hit = sum((n for _i, _j, n in sm.get_matching_blocks()))
    return int(round(100 * min(1.0, hit / len(want))))

def record_round(speaker: str, level: int, scores: list[int]) -> dict:
    state = load(speaker)
    acc = int(round(sum(scores) / len(scores))) if scores else 0
    before = int(state['levels'].get(str(level), 0))
    state['levels'][str(level)] = max(before, acc)
    state['said'] = state['said'] + len(scores)
    today = date.today().isoformat()
    if state['last_day'] != today:
        yesterday = (date.today() - timedelta(days=1)).isoformat()
        state['streak'] = state['streak'] + 1 if state['last_day'] == yesterday else 1
        state['last_day'] = today
    save(speaker, state)
    return {'accuracy': acc, 'before': before, 'streak': state['streak']}

def ladder(speaker: str) -> list[dict]:
    state = load(speaker)
    levels = state['levels']
    out, found_current = ([], False)
    for n, name, _seeds in LEVELS:
        acc = int(levels.get(str(n), 0))
        if acc >= 90:
            st = 'done'
        elif acc:
            st = 'part'
        elif not found_current:
            st, found_current = ('now', True)
        else:
            st = 'todo'
        out.append({'n': n, 'name': name, 'accuracy': acc, 'state': st})
    if not any((r['state'] == 'now' for r in out)):
        weakest = min(out, key=lambda r: r['accuracy'])
        weakest['state'] = 'now'
    return out

def current_level(speaker: str) -> dict:
    return next((r for r in ladder(speaker) if r['state'] == 'now'))

def summary(speaker: str) -> dict:
    state = load(speaker)
    done = [v for v in state['levels'].values() if v]
    return {'streak': state['streak'], 'said': state['said'], 'accuracy': int(round(sum(done) / len(done))) if done else 0}
