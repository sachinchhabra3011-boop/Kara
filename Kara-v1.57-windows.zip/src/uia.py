from __future__ import annotations
import ctypes
import threading
from ctypes import POINTER, byref, c_int, c_void_p, c_wchar_p
_CLSID_UIA = '{FF48DBA4-60EF-4201-AA87-54103EEF594E}'
_IID_IUIA = '{30CBE57D-D9D0-452A-AB13-7AC5AC4825EE}'
S_OK = 0
COINIT_MULTITHREADED = 0
RPC_E_CHANGED_MODE = -2147417850
UIA_E_ELEMENTNOTAVAILABLE = -2147220991
POLL_SECONDS = 0.15
RECONCILE_SECONDS = 0.3
STALE_AFTER = 4.0
AGREE_TIMES = 2
UIA_ValuePatternId = 10002
UIA_TextPatternId = 10014
UIA_TextEditPatternId = 10032
UIA_ValueIsReadOnlyPropertyId = 30046
UIA_IsEnabledPropertyId = 30010
UIA_IsKeyboardFocusablePropertyId = 30009
UIA_IsPasswordPropertyId = 30019
UIA_ProcessIdPropertyId = 30002
VT_BOOL = 11
VT_I4 = 3
UIA_EditControlTypeId = 50004
UIA_DocumentControlTypeId = 50030
UIA_ComboBoxControlTypeId = 50003
_TEXT_CONTROLS = {UIA_EditControlTypeId, UIA_DocumentControlTypeId, UIA_ComboBoxControlTypeId}
_local = threading.local()
_broken = False

class _GUID(ctypes.Structure):
    _fields_ = [('Data1', ctypes.c_ulong), ('Data2', ctypes.c_ushort), ('Data3', ctypes.c_ushort), ('Data4', ctypes.c_ubyte * 8)]

def _guid(text: str) -> _GUID:
    g = _GUID()
    if ctypes.oledll.ole32.CLSIDFromString(c_wchar_p(text), byref(g)) != S_OK:
        raise OSError(f'bad guid {text}')
    return g

def _call(ptr: c_void_p, index: int, argtypes, *args) -> int:
    vtable = ctypes.cast(ptr, POINTER(POINTER(c_void_p)))[0]
    proto = ctypes.WINFUNCTYPE(ctypes.HRESULT, c_void_p, *argtypes)
    return proto(vtable[index])(ptr, *args)

def _release(ptr) -> None:
    if ptr:
        try:
            vt = ctypes.cast(ptr, POINTER(POINTER(c_void_p)))[0]
            ctypes.WINFUNCTYPE(ctypes.c_ulong, c_void_p)(vt[2])(ptr)
        except Exception:
            pass

def _automation():
    global _broken
    if _broken:
        return None
    got = getattr(_local, 'uia', None)
    if got is not None:
        return got
    try:
        try:
            ctypes.oledll.ole32.CoInitializeEx(None, COINIT_MULTITHREADED)
        except OSError as e:
            if getattr(e, 'winerror', 0) != RPC_E_CHANGED_MODE:
                raise
        uia = c_void_p()
        ctypes.oledll.ole32.CoCreateInstance(byref(_guid(_CLSID_UIA)), None, 1, byref(_guid(_IID_IUIA)), byref(uia))
        if not uia:
            raise OSError('no IUIAutomation')
        _local.uia = uia
        return uia
    except Exception:
        _broken = True
        return None

def available() -> bool:
    return _automation() is not None

class _VARIANT(ctypes.Structure):
    _fields_ = [('vt', ctypes.c_ushort), ('r1', ctypes.c_ushort), ('r2', ctypes.c_ushort), ('r3', ctypes.c_ushort), ('val', ctypes.c_longlong)]

def _read_bool_property(element, prop_id: int):
    v = _VARIANT()
    try:
        if _call(element, 10, (c_int, POINTER(_VARIANT)), prop_id, byref(v)) != S_OK:
            return None
    except Exception:
        return None
    try:
        if v.vt != VT_BOOL:
            return None
        return bool(v.val & 65535)
    finally:
        try:
            ctypes.oledll.oleaut32.VariantClear(byref(v))
        except Exception:
            pass

def _read_int_property(element, prop_id: int):
    v = _VARIANT()
    try:
        if _call(element, 10, (c_int, POINTER(_VARIANT)), prop_id, byref(v)) != S_OK:
            return None
    except Exception:
        return None
    try:
        return int(v.val & 4294967295) if v.vt == VT_I4 else None
    finally:
        try:
            ctypes.oledll.oleaut32.VariantClear(byref(v))
        except Exception:
            pass

def _foreground_pid():
    try:
        from ctypes import wintypes
        u = ctypes.WinDLL('user32')
        u.GetForegroundWindow.restype = wintypes.HWND
        u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.c_void_p]
        hwnd = u.GetForegroundWindow()
        if not hwnd:
            return None
        pid = wintypes.DWORD()
        u.GetWindowThreadProcessId(hwnd, byref(pid))
        return int(pid.value) or None
    except Exception:
        return None

def is_editable(control_type: int, value_pattern: bool, text_pattern: bool, textedit_pattern: bool, read_only=None, enabled=None, focusable=None, password=None) -> bool:
    if enabled is False or password is True or focusable is False:
        return False
    if textedit_pattern:
        return True
    if value_pattern and read_only is False and text_pattern:
        return True
    if control_type == UIA_EditControlTypeId and read_only is not True:
        return True
    return False

def focus_info() -> dict:
    out = {'ok': False, 'control_type': 0, 'value_pattern': False, 'text_pattern': False, 'textedit_pattern': False, 'editable': False, 'read_only': None, 'enabled': None, 'focusable': None, 'password': None, 'pid': None, 'foreground_pid': None, 'stale': False}
    uia = _automation()
    if uia is None:
        return out
    element = c_void_p()
    for attempt in (0, 1):
        try:
            hr = _call(uia, 8, (POINTER(c_void_p),), byref(element))
        except Exception:
            global _broken
            _broken = True
            return out
        if hr == S_OK and element:
            break
        if hr != UIA_E_ELEMENTNOTAVAILABLE or attempt:
            return out
        import time
        time.sleep(0.03)
    if not element:
        return out
    try:
        out['ok'] = True
        ctype = c_int(0)
        try:
            _call(element, 21, (POINTER(c_int),), byref(ctype))
            out['control_type'] = ctype.value
        except Exception:
            pass
        for pid, key in ((UIA_ValuePatternId, 'value_pattern'), (UIA_TextPatternId, 'text_pattern'), (UIA_TextEditPatternId, 'textedit_pattern')):
            pat = c_void_p()
            try:
                if _call(element, 16, (c_int, POINTER(c_void_p)), pid, byref(pat)) == S_OK and pat:
                    out[key] = True
                    _release(pat)
            except Exception:
                pass
        for prop, key in ((UIA_ValueIsReadOnlyPropertyId, 'read_only'), (UIA_IsEnabledPropertyId, 'enabled'), (UIA_IsKeyboardFocusablePropertyId, 'focusable'), (UIA_IsPasswordPropertyId, 'password')):
            out[key] = _read_bool_property(element, prop)
        out['pid'] = _read_int_property(element, UIA_ProcessIdPropertyId)
        out['editable'] = is_editable(out['control_type'], out['value_pattern'], out['text_pattern'], out['textedit_pattern'], out['read_only'], out['enabled'], out['focusable'], out['password'])
        fg = _foreground_pid()
        out['foreground_pid'], out['stale'] = (fg, False)
        if out['editable'] and fg and out['pid'] and (out['pid'] != fg):
            out['stale'] = True
            out['editable'] = False
    finally:
        _release(element)
    return out
_latest: tuple[float, dict] | None = None
_latest_lock = threading.Lock()
_worker_started = False
_pending = None
_pending_n = 0

def _record(f: dict, immediate: bool=False) -> None:
    import time
    global _latest, _pending, _pending_n
    if not f.get('ok'):
        return
    if immediate:
        _pending, _pending_n = (f['editable'], AGREE_TIMES)
        with _latest_lock:
            _latest = (time.monotonic(), f)
        return
    if _pending is not None and f['editable'] == _pending:
        _pending_n += 1
    else:
        _pending, _pending_n = (f['editable'], 1)
    with _latest_lock:
        settled = _latest[1]['editable'] if _latest else None
        if _pending_n >= AGREE_TIMES or settled is None:
            _latest = (time.monotonic(), f)
        else:
            _latest = (time.monotonic(), dict(_latest[1]))

def _worker() -> None:
    _start_focus_hook()
    while True:
        woken = _wake.wait(RECONCILE_SECONDS if _events_on else POLL_SECONDS)
        _wake.clear()
        f = focus_info()
        if not f['ok'] and _broken:
            return
        _record(f, immediate=woken)
_IID_FOCUS_HANDLER = '{C270F6B5-5C69-4290-9745-7A7F97169468}'
_IID_IUNKNOWN = '{00000000-0000-0000-C000-000000000046}'
E_NOINTERFACE = -2147467262
_handler_refs = []
_events_on = False
_hook_started = False
_wake = threading.Event()

def _start_focus_hook() -> bool:
    global _hook_started
    if _hook_started:
        return True
    _hook_started = True

    def _pump():
        try:
            import ctypes as C
            from ctypes import wintypes
            EVENT_OBJECT_FOCUS = 32773
            WINEVENT_OUTOFCONTEXT = 0
            PROC = C.WINFUNCTYPE(None, wintypes.HANDLE, wintypes.DWORD, wintypes.HWND, wintypes.LONG, wintypes.LONG, wintypes.DWORD, wintypes.DWORD)

            def _on_focus(*_a):
                _wake.set()
            cb = PROC(_on_focus)
            _handler_refs.append(cb)
            u = C.WinDLL('user32')
            u.SetWinEventHook.restype = wintypes.HANDLE
            h = u.SetWinEventHook(EVENT_OBJECT_FOCUS, EVENT_OBJECT_FOCUS, None, cb, 0, 0, WINEVENT_OUTOFCONTEXT)
            if not h:
                return
            global _events_on
            _events_on = True
            msg = wintypes.MSG()
            while u.GetMessageW(C.byref(msg), None, 0, 0) > 0:
                u.TranslateMessage(C.byref(msg))
                u.DispatchMessageW(C.byref(msg))
        except Exception:
            pass
    threading.Thread(target=_pump, name='kara-focus-hook', daemon=True).start()
    return True

def _install_focus_handler(uia) -> bool:
    global _events_on
    try:
        QI = ctypes.WINFUNCTYPE(ctypes.HRESULT, c_void_p, c_void_p, c_void_p)
        ADDREF = ctypes.WINFUNCTYPE(ctypes.c_ulong, c_void_p)
        HANDLE = ctypes.WINFUNCTYPE(ctypes.HRESULT, c_void_p, c_void_p)

        class _Vtbl(ctypes.Structure):
            _fields_ = [('QueryInterface', QI), ('AddRef', ADDREF), ('Release', ADDREF), ('HandleFocusChangedEvent', HANDLE)]

        class _Obj(ctypes.Structure):
            _fields_ = [('lpVtbl', POINTER(_Vtbl))]
        want = {_IID_FOCUS_HANDLER.lower(), _IID_IUNKNOWN.lower()}

        def _qi(this, riid, ppv):
            try:
                s = ctypes.create_unicode_buffer(64)
                ctypes.oledll.ole32.StringFromGUID2(riid, s, 64)
                if s.value.lower() in want:
                    ctypes.cast(ppv, POINTER(c_void_p))[0] = this
                    return S_OK
                ctypes.cast(ppv, POINTER(c_void_p))[0] = None
            except Exception:
                pass
            return E_NOINTERFACE

        def _addref(_this):
            return 2

        def _handle(_this, sender):
            try:
                _record(focus_info(), immediate=True)
            except Exception:
                pass
            return S_OK
        qi, ar, rl, hd = (QI(_qi), ADDREF(_addref), ADDREF(_addref), HANDLE(_handle))
        vt = _Vtbl(qi, ar, rl, hd)
        obj = _Obj(ctypes.pointer(vt))
        _handler_refs.extend([qi, ar, rl, hd, vt, obj])
        hr = _call(uia, 39, (c_void_p, c_void_p), None, ctypes.byref(obj))
        _events_on = hr == S_OK
        return _events_on
    except Exception:
        _events_on = False
        return False

def events_active() -> bool:
    return _events_on

def start() -> None:
    global _worker_started
    if _worker_started or _broken:
        return
    _worker_started = True
    t = threading.Thread(target=_worker, name='kara-uia', daemon=True)
    t.start()
_CONTROL_NAMES = {50000: 'Button', 50003: 'ComboBox', 50004: 'Edit', 50005: 'Hyperlink', 50008: 'List', 50011: 'MenuItem', 50020: 'Text', 50025: 'Custom', 50026: 'Group', 50030: 'Document', 50032: 'Pane', 50033: 'Window'}

def describe(f: dict | None=None) -> str:
    if f is None:
        f = latest()
    if not f or not f.get('ok'):
        return 'uia: no reading'
    ct = f.get('control_type', 0)
    pats = '+'.join((k for k, v in (('Value', f.get('value_pattern')), ('Text', f.get('text_pattern')), ('TextEdit', f.get('textedit_pattern'))) if v)) or 'none'
    extra = ''
    if f.get('stale'):
        extra = ' STALE(other process)'
    elif f.get('read_only') is True:
        extra = ' read-only'
    return f"uia: {_CONTROL_NAMES.get(ct, ct)} patterns={pats}{extra} -> {('text field' if f.get('editable') else 'not a field')}"

def latest() -> dict | None:
    import time
    with _latest_lock:
        got = _latest
    if got is None:
        return None
    when, f = got
    return None if time.monotonic() - when > STALE_AFTER else f

def focused_is_text_field() -> tuple[bool, bool]:
    start()
    f = latest()
    if f is None:
        return (False, False)
    return (f['ok'], f['editable'])

def watch(seconds: int=60, out_path=None) -> str:
    import ctypes as C
    import time
    from ctypes import wintypes
    from pathlib import Path
    out_path = Path(out_path or Path(__file__).resolve().parent.parent / 'logs' / 'uia-probe.txt')
    out_path.parent.mkdir(parents=True, exist_ok=True)
    u = C.WinDLL('user32')
    u.GetForegroundWindow.restype = wintypes.HWND
    u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, C.c_void_p]

    def app_of(hwnd):
        try:
            import psutil
            pid = wintypes.DWORD()
            u.GetWindowThreadProcessId(hwnd, C.byref(pid))
            return psutil.Process(pid.value).name()
        except Exception:
            return '?'
    seen, rows = (set(), [])
    end = time.time() + seconds
    print(f'Recording for {seconds}s.\nClick INTO a text box, then OUT of it (onto blank space), in at least two apps -- a browser and a chat app are the useful ones.\n')
    while time.time() < end:
        hwnd = int(u.GetForegroundWindow() or 0)
        f = focus_info()
        key = (app_of(hwnd), f['ok'], f['control_type'], f['value_pattern'], f['text_pattern'], f['textedit_pattern'])
        if key not in seen:
            seen.add(key)
            pats = '+'.join((p for p, on in (('Value', f['value_pattern']), ('Text', f['text_pattern']), ('TextEdit', f['textedit_pattern'])) if on)) or 'none'
            line = f"{key[0]:<18}{_CONTROL_NAMES.get(f['control_type'], f['control_type']):<12}{pats:<24}{('FIELD' if f['editable'] else 'not a field')}"
            rows.append(line)
            print('  ' + line)
        time.sleep(0.15)
    header = f"{'app':<18}{'control type':<12}{'patterns':<24}Kara's current verdict\n" + '-' * 74
    out_path.write_text(header + '\n' + '\n'.join(rows) + '\n', encoding='utf-8')
    print(f'\n{len(rows)} distinct states written to {out_path}')
    return str(out_path)
