from __future__ import annotations
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
import atomicio
import lexicon
try:
    import winspell
except Exception:
    winspell = None
ROOT = Path(__file__).resolve().parent.parent
WINDOWS_DIALECT = {'en': 'en-CA', 'en-gb': 'en-CA', 'en-us': 'en-US'}
SPELLING = 'spelling'
GRAMMAR = 'grammar'
UNSURE = 'unsure'
DEFAULT_SERVICE = 'https://api.languagetool.org/v2/check'
SERVICE_TIMEOUT = 6.0
MAX_ONLINE_CHARS = 20000

@dataclass(frozen=True)
class Mark:
    start: int
    end: int
    kind: str
    word: str
    message: str
    suggestions: tuple = ()
    fix: str | None = None
    rule: str = ''
_CONTRACTIONS = ["i'm", "i've", "i'll", "i'd", "you're", "you've", "you'll", "you'd", "he's", "he'll", "he'd", "she's", "she'll", "she'd", "it's", "we're", "we've", "we'll", "we'd", "they're", "they've", "they'll", "they'd", "that's", "there's", "here's", "what's", "who's", "where's", "when's", "how's", "let's", "don't", "doesn't", "didn't", "isn't", "aren't", "wasn't", "weren't", "hasn't", "haven't", "hadn't", "won't", "wouldn't", "can't", "couldn't", "shouldn't", "mustn't", "needn't", "shan't", "ain't", "y'all", "o'clock"]
_DEAPOSTROPHISED = {c.replace("'", ''): c for c in _CONTRACTIONS}
_WORD = re.compile("[A-Za-z][A-Za-z'’]*")

class _Span:
    __slots__ = ('_s', '_e')

    def __init__(self, s: int, e: int):
        self._s, self._e = (s, e)

    def start(self) -> int:
        return self._s

    def end(self) -> int:
        return self._e

def dict_path(speaker: str) -> Path:
    return ROOT / 'data' / speaker / 'dictionary.json'

def load_dictionary(speaker: str) -> dict:
    p = dict_path(speaker)
    try:
        d = json.loads(p.read_text(encoding='utf-8'))
        return {'added': list(d.get('added') or []), 'ignored': list(d.get('ignored') or [])}
    except (OSError, ValueError):
        return {'added': [], 'ignored': []}

def save_dictionary(speaker: str, d: dict) -> None:
    atomicio.write_json(dict_path(speaker), {'_comment': 'Words you told Kara are correct, and words you told it to ignore. Yours: edit or delete freely.', 'added': sorted(set(d.get('added') or []), key=str.lower), 'ignored': sorted(set(d.get('ignored') or []), key=str.lower)}, backup=True)

def add_word(speaker: str, word: str) -> None:
    d = load_dictionary(speaker)
    if word and word.lower() not in {w.lower() for w in d['added']}:
        d['added'].append(word)
        save_dictionary(speaker, d)

def ignore_word(speaker: str, word: str) -> None:
    d = load_dictionary(speaker)
    if word and word.lower() not in {w.lower() for w in d['ignored']}:
        d['ignored'].append(word)
        save_dictionary(speaker, d)

def forget_word(speaker: str, word: str) -> None:
    d = load_dictionary(speaker)
    low = word.lower()
    d['added'] = [w for w in d['added'] if w.lower() != low]
    d['ignored'] = [w for w in d['ignored'] if w.lower() != low]
    save_dictionary(speaker, d)
EXTRA_WORDS = lexicon.EXTRA_WORDS

@dataclass
class Proofreader:
    speaker: str
    language: str = 'en'
    _spell: object | None = field(default=None, repr=False)
    _known: set = field(default_factory=set, repr=False)
    _ignored: set = field(default_factory=set, repr=False)
    _available: bool = True
    _win_tag: str = ''
    _sugg_cache: dict = field(default_factory=dict, repr=False)
    _derived_cache: dict = field(default_factory=dict, repr=False)

    def __post_init__(self):
        self._win_tag = ''
        if winspell is not None:
            try:
                tag = WINDOWS_DIALECT.get((self.language or 'en').lower(), '')
                if tag and winspell.available(tag):
                    self._win_tag = tag
            except Exception:
                self._win_tag = ''
        try:
            from spellchecker import SpellChecker
            self._spell = SpellChecker(language=self.language or 'en', distance=1)
            if (self.language or 'en') == 'en':
                wf = self._spell.word_frequency
                wf.load_json(lexicon.british_forms(dict(wf.dictionary)))
                wf.load_json({w: 50 for w in EXTRA_WORDS if w not in wf.dictionary})
        except Exception:
            self._spell = None
            self._available = False
        self.reload()

    def reload(self) -> None:
        d = load_dictionary(self.speaker)
        self._known = {w.lower() for w in d['added']}
        self._ignored = {w.lower() for w in d['ignored']}
        for key in ('people', 'names', 'places', 'brands_apps', 'foods', 'spelled'):
            for w in self._vocab().get(key) or []:
                for part in str(w).split():
                    self._known.add(part.strip(".,'").lower())

    def _vocab(self) -> dict:
        try:
            return json.loads((ROOT / 'data' / self.speaker / 'vocab.json').read_text(encoding='utf-8'))
        except (OSError, ValueError):
            return {}

    def _in_dict(self, w: str) -> bool:
        if self._spell is None:
            return False
        return w in self._spell.word_frequency.dictionary

    def _is_derived(self, w: str) -> bool:
        if self._spell is None or (self.language or 'en') != 'en':
            return False
        hit = self._derived_cache.get(w)
        if hit is None:
            hit = lexicon.derived(w, self._in_dict, prefixes_only=bool(self._win_tag)) or ''
            self._derived_cache[w] = hit
        return bool(hit)

    def explain(self, word: str) -> str:
        w = word.lower().strip("'’")
        if self._in_dict(w):
            return 'in the dictionary'
        if w in self._known:
            return 'your dictionary or vocabulary'
        d = lexicon.derived(w, self._in_dict) if self._spell is not None else None
        return f'built from known words: {d}' if d else 'not a word'

    def is_known(self, word: str) -> bool:
        w = word.lower().strip("'’")
        if not w or w in self._known or w in self._ignored:
            return True
        if w in _DEAPOSTROPHISED:
            return False
        if self._win_tag:
            try:
                if winspell.is_known(word.strip("'’"), self._win_tag):
                    return True
            except Exception:
                self._win_tag = ''
        if self._spell is None:
            return not self._win_tag
        if not self._spell.unknown([w]):
            return True
        return self._is_derived(w)

    def suggestions_for(self, word: str, limit: int=5) -> list[str]:
        w = word.lower()
        cached = self._sugg_cache.get(w)
        if cached is not None:
            return [_match_case(word, s) for s in cached]
        out: list[str] = []
        if w in _DEAPOSTROPHISED:
            out.append(_DEAPOSTROPHISED[w])
        if self._win_tag:
            try:
                out += winspell.suggest(word, limit, self._win_tag)
            except Exception:
                self._win_tag = ''
        if self._spell is not None:
            try:
                cands = self._spell.candidates(w) or set()
            except Exception:
                cands = set()
            ranked = sorted(cands, key=lambda c: -self._spell.word_frequency[c])
            out += [c for c in ranked if c != w]
        seen, final = (set(), [])
        for s in out:
            if s.lower() in seen:
                continue
            seen.add(s.lower())
            final.append(s)
            if len(final) >= limit:
                break
        self._sugg_cache[w] = tuple(final)
        return [_match_case(word, s) for s in final]

    def check(self, text: str, vocab: dict | None=None, online: bool=False, service: str=DEFAULT_SERVICE) -> tuple[list[Mark], str | None]:
        marks = self._local(text, vocab)
        if not online:
            return (marks, None)
        found, err = check_online(text, service)
        if err:
            return (marks, err)
        merged = list(marks)
        taken = [(m.start, m.end) for m in marks]
        for m in found:
            if any((m.start < b and a < m.end or (m.start == a and m.end == b) for a, b in taken)):
                continue
            merged.append(m)
        merged.sort(key=lambda m: (m.start, m.end))
        return (merged, None)

    def _local(self, text: str, vocab: dict | None=None) -> list[Mark]:
        marks: list[Mark] = []
        if (self.language or 'en') == 'hi':
            import hindispell
            for start, end, why in hindispell.check(text or ''):
                word = text[start:end]
                if word.lower() in self._known or word.lower() in self._ignored:
                    continue
                marks.append(Mark(start, end, SPELLING, word, why, rule='hindi_structure'))
            return sorted(marks, key=lambda m: m.start)
        tokens = [(m.start(), m.end(), m.group()) for m in _WORD.finditer(text or '') if len(m.group()) >= 2 and (not m.group().isupper())]
        candidates = {w.lower().strip("'’") for _s, _e, w in tokens}
        candidates -= self._known
        candidates -= self._ignored
        original = {}
        for _s, _e, w in tokens:
            original.setdefault(w.lower().strip("'’"), w.strip("'’"))
        unknown: set = set()
        forced = {c for c in candidates if c in _DEAPOSTROPHISED}
        if candidates and self._win_tag:
            try:
                ask = {original.get(c, c): c for c in candidates - forced}
                bad = winspell.unknown(ask.keys(), self._win_tag)
                unknown = {ask[w] for w in bad if w in ask} | forced
            except Exception:
                self._win_tag = ''
        if candidates and (not self._win_tag) and (self._spell is not None):
            unknown = set(self._spell.unknown(candidates - forced)) | forced
            unknown -= {w for w in unknown - forced if self._is_derived(w)}
        for start, end, word in tokens:
            low = word.lower().strip("'’")
            if low not in unknown:
                continue
            m = _Span(start, end)
            sugg = self.suggestions_for(word)
            low = word.lower()
            if low in _DEAPOSTROPHISED:
                msg = f'“{word}” is missing an apostrophe'
                rule = 'contraction'
            else:
                msg = f'“{word}” is not in the dictionary'
                rule = 'unknown_word'
            marks.append(Mark(m.start(), m.end(), SPELLING, word, msg, tuple(sugg), sugg[0] if sugg else None, rule))
        try:
            import grammar
            for issue in grammar.check(text, vocab or self._vocab()):
                marks.append(Mark(issue.start, issue.end, GRAMMAR, text[issue.start:issue.end], issue.label, (issue.replacement,), issue.replacement, issue.kind))
        except Exception:
            pass
        marks.sort(key=lambda m: (m.start, m.end))
        return marks

def check_online(text: str, url: str=DEFAULT_SERVICE, language: str='en-US', timeout: float=SERVICE_TIMEOUT) -> tuple[list[Mark], str | None]:
    text = (text or '').strip()
    if not text:
        return ([], None)
    if len(text) > MAX_ONLINE_CHARS:
        text = text[:MAX_ONLINE_CHARS]
    try:
        import requests
        r = requests.post(url, timeout=timeout, data={'text': text, 'language': language, 'enabledOnly': 'false'})
        if r.status_code == 429:
            return ([], 'the free grammar service is busy — try again in a minute')
        if r.status_code >= 400:
            return ([], f'the grammar service said {r.status_code}')
        payload = r.json()
    except Exception as e:
        return ([], f'could not reach the grammar service ({type(e).__name__})')
    marks: list[Mark] = []
    for m in payload.get('matches', []):
        start = int(m.get('offset', 0))
        length = int(m.get('length', 0))
        repls = tuple((r.get('value', '') for r in (m.get('replacements') or [])[:5] if r.get('value')))
        rule = m.get('rule') or {}
        if rule.get('issueType') == 'misspelling' or (rule.get('category') or {}).get('id') == 'TYPOS':
            continue
        marks.append(Mark(start, start + length, GRAMMAR, text[start:start + length], m.get('shortMessage') or m.get('message') or 'grammar', repls, repls[0] if repls else None, f"lt:{rule.get('id', '?')}"))
    return (marks, None)

def _match_case(original: str, suggestion: str) -> str:
    if original.isupper():
        return suggestion.upper()
    if original[:1].isupper():
        return suggestion[:1].upper() + suggestion[1:]
    return suggestion

def counts(marks: list[Mark]) -> tuple[int, int]:
    return (sum((1 for m in marks if m.kind == SPELLING)), sum((1 for m in marks if m.kind == GRAMMAR)))
