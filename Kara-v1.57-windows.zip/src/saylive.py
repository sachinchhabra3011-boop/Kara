from __future__ import annotations
import re
TIER_TABLE = 1
TIER_NAME = {TIER_TABLE: 'YOURS'}
UNSURE_BELOW = 0.6
_READER = None

def _is_word(w: str) -> bool:
    global _READER
    if _READER is None:
        try:
            import proofing
            _READER = proofing.Proofreader(speaker='')
        except Exception:
            _READER = False
    if _READER is False:
        return False
    try:
        return bool(_READER.is_known(w))
    except Exception:
        return False

def _table(speaker: str) -> dict:
    try:
        import corrector
        return {str(k): str(v) for k, v in ((corrector.load_vocab(speaker) or {}).get('confusions') or {}).items()}
    except Exception:
        return {}

def suspicions(text: str, speaker: str, limit: int=8) -> list[dict]:
    text = text or ''
    out: list[dict] = []
    claimed: set[tuple[int, int]] = set()
    for heard, meant in _table(speaker).items():
        if not heard.strip() or heard.strip().lower() == meant.strip().lower():
            continue
        for m in re.finditer(f'\\b{re.escape(heard)}\\b', text, re.IGNORECASE):
            span = (m.start(), m.end())
            if span in claimed:
                continue
            claimed.add(span)
            out.append({'said': m.group(0), 'meant': _match_case(m.group(0), meant), 'tier': TIER_TABLE, 'why': 'Kara has got this wrong for you before', 'start': span[0], 'end': span[1], 'prob': None})
    out.sort(key=lambda s: s['start'])
    return out[:limit]

def _match_case(said: str, meant: str) -> str:
    if said[:1].isupper():
        return meant[:1].upper() + meant[1:]
    return meant

def apply(text: str, s: dict) -> str:
    start, end = (int(s['start']), int(s['end']))
    if not 0 <= start < end <= len(text):
        return text
    if text[start:end] != s['said']:
        return text
    return text[:start] + str(s['meant']) + text[end:]
