from __future__ import annotations
import re
from dataclasses import dataclass
LOW = 0.6
_WORDISH = re.compile("[A-Za-z0-9']+")

@dataclass(frozen=True)
class Span:
    start: int
    end: int
    prob: float

def clean_token(word: str) -> str:
    found = _WORDISH.findall((word or '').lower())
    return found[0] if found else ''

def _find_from(text_lower: str, token: str, pos: int) -> int:
    if not token:
        return -1
    at = pos
    n = len(text_lower)
    while True:
        i = text_lower.find(token, at)
        if i < 0:
            return -1
        before_ok = i == 0 or not (text_lower[i - 1].isalnum() or text_lower[i - 1] == "'")
        j = i + len(token)
        after_ok = j >= n or not (text_lower[j].isalnum() or text_lower[j] == "'")
        if before_ok and after_ok:
            return i
        at = i + 1

def spans_for(text: str, words, *, start: int=0, threshold: float=LOW) -> list[Span]:
    if not text or not words:
        return []
    low = text.lower()
    out: list[Span] = []
    pos = max(0, start)
    for word, prob in words:
        token = clean_token(word)
        if not token:
            continue
        at = _find_from(low, token, pos)
        if at < 0:
            continue
        end = at + len(token)
        if prob < threshold:
            out.append(Span(at, end, float(prob)))
        pos = end
    return out

def did_you_mean(word: str, speaker: str='', limit: int=3) -> list[str]:
    w = clean_token(word)
    if not w:
        return []
    out: list[str] = []
    vocab = {}
    if speaker:
        try:
            import corrector
            vocab = corrector.load_vocab(speaker) or {}
        except Exception:
            vocab = {}
    for heard, meant in (vocab.get('confusions') or {}).items():
        if clean_token(str(heard)) == w and meant and (str(meant).lower() != w):
            out.append(str(meant))
    if vocab:
        try:
            import corrector
            for cand in corrector.vocab_words(vocab):
                c = clean_token(str(cand))
                if c and c != w and _one_edit(w, c):
                    out.append(str(cand))
        except Exception:
            pass
    try:
        import proofing
        pr = proofing.Proofreader(speaker or '')
        for cand in pr.suggestions_for(w, limit=limit + 2):
            if clean_token(cand) != w:
                out.append(cand)
    except Exception:
        pass
    seen, final = (set(), [])
    for c in out:
        k = c.lower()
        if k in seen:
            continue
        seen.add(k)
        final.append(c)
        if len(final) >= limit:
            break
    return final

def _one_edit(a: str, b: str) -> bool:
    if abs(len(a) - len(b)) > 1:
        return False
    if a == b:
        return False
    if len(a) == len(b):
        return sum((1 for x, y in zip(a, b) if x != y)) == 1
    short, long_ = (a, b) if len(a) < len(b) else (b, a)
    i = j = diff = 0
    while i < len(short) and j < len(long_):
        if short[i] != long_[j]:
            diff += 1
            if diff > 1:
                return False
            j += 1
            continue
        i += 1
        j += 1
    return True

def to_marks(spans, kind: str, message: str="Kara wasn't sure it heard this", text: str='', speaker: str=''):
    import proofing
    marks = []
    for s in spans:
        word = text[s.start:s.end] if text else ''
        alts = tuple(did_you_mean(word, speaker)) if word else ()
        msg = message
        if alts:
            msg = f"Did you mean {' or '.join(alts[:2])}?"
        marks.append(proofing.Mark(start=s.start, end=s.end, kind=kind, word=word, message=msg, suggestions=alts, fix=None, rule='low_confidence'))
    return marks

def summarise(words, *, threshold: float=LOW) -> dict:
    n = len(words)
    low = sum((1 for _w, p in words if p < threshold))
    return {'words': n, 'unsure': low, 'mean': sum((p for _w, p in words)) / n if n else 0.0}
