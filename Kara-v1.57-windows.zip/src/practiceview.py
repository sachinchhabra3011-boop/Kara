from __future__ import annotations
import tempfile
import time
from pathlib import Path
import soundfile as sf
from PySide6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QDialog, QFrame, QGraphicsDropShadowEffect, QHBoxLayout, QLabel, QLineEdit, QPushButton, QStackedWidget, QVBoxLayout, QWidget
import karalog
import practice
import record
from i18n import t

class PracticeListener(QThread):
    heard = Signal(str)
    failed = Signal(str)

    def __init__(self, pipe, audio):
        super().__init__()
        self.pipe, self.audio = (pipe, audio)

    def run(self):
        wav = ''
        try:
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tf:
                wav = tf.name
            sf.write(wav, self.audio, record.SAMPLE_RATE, subtype='PCM_16')
            self.heard.emit(self.pipe.raw(wav))
        except Exception as e:
            self.failed.emit(str(e))
        finally:
            if wav:
                Path(wav).unlink(missing_ok=True)

class Waveform(QWidget):
    picked = Signal(int)
    BAR = 11
    GAP = 12
    TOP = 118

    def __init__(self, rows, palette):
        super().__init__()
        self.rows, self.P = (rows, palette)
        self.setFixedHeight(self.TOP + 26)
        self.setMouseTracking(True)
        self._hover = -1
        self.setCursor(Qt.PointingHandCursor)
        self.setAccessibleName(t('Practice levels — pick one to practise'))

    def _index_at(self, x: int) -> int:
        step = self.BAR + self.GAP
        i = int(x // step)
        return i if 0 <= i < len(self.rows) else -1

    def mouseMoveEvent(self, e):
        i = self._index_at(e.position().x())
        if i != self._hover:
            self._hover = i
            self.setToolTip(t('Level %s · %s') % (self.rows[i]['n'], self.rows[i]['name']) + (t(' · %s%%') % (self.rows[i]['accuracy'],) if self.rows[i]['accuracy'] else t(' · not started')) if i >= 0 else '')
            self.update()

    def leaveEvent(self, _e):
        self._hover = -1
        self.update()

    def mousePressEvent(self, e):
        i = self._index_at(e.position().x())
        if i >= 0:
            self.picked.emit(self.rows[i]['n'])

    def paintEvent(self, _e):
        P = self.P
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        colour = {'done': P['green'], 'part': P['amber'], 'now': P['beige'], 'todo': P['line']}
        step = self.BAR + self.GAP
        for i, r in enumerate(self.rows):
            acc = r['accuracy']
            if acc:
                h = int(26 + acc / 100 * (self.TOP - 26))
            elif r['state'] == 'now':
                h = 62
            else:
                h = 18
            x = i * step
            y = self.TOP - h
            if i == self._hover:
                h = int(h * 1.06)
                y = self.TOP - h
            if r['state'] == 'now':
                p.setPen(Qt.NoPen)
                p.setBrush(QColor(P['beige']))
                p.setOpacity(0.22)
                p.drawRoundedRect(x - 3, y - 3, self.BAR + 6, h + 6, 9, 9)
                p.setOpacity(1.0)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(colour[r['state']]))
            p.drawRoundedRect(x, y, self.BAR, h, 6, 6)
            p.setPen(QPen(QColor(P['beige_text'] if r['state'] == 'now' else P['ink_soft'] if r['state'] != 'todo' else P['line'])))
            f = p.font()
            f.setPointSize(8)
            p.setFont(f)
            p.drawText(x - 5, self.TOP + 6, self.BAR + 10, 16, Qt.AlignHCenter, str(r['n']))
        p.end()

class Ring(QWidget):

    def __init__(self, value: int, label: str, palette, size: int=132, colour_key: str='beige'):
        super().__init__()
        self.value, self.label, self.P = (value, label, palette)
        self.key = colour_key
        self.setFixedSize(size, size)

    def paintEvent(self, _e):
        P = self.P
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w = self.width()
        pad = 8
        rect = self.rect().adjusted(pad, pad, -pad, -pad)
        pen = QPen(QColor(P['line']), 11)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        p.drawArc(rect, 0, 360 * 16)
        if self.value:
            pen.setColor(QColor(P[self.key]))
            p.setPen(pen)
            p.drawArc(rect, 90 * 16, -int(360 * 16 * self.value / 100))
        p.setPen(QPen(QColor(P['ink'])))
        f = p.font()
        f.setPointSize(int(w / 6))
        f.setBold(True)
        p.setFont(f)
        p.drawText(self.rect().adjusted(0, -10, 0, -10), Qt.AlignCenter, f'{self.value}%')
        p.setPen(QPen(QColor(P['ink_soft'])))
        f.setPointSize(9)
        f.setBold(False)
        p.setFont(f)
        p.drawText(self.rect().adjusted(0, 34, 0, 34), Qt.AlignCenter, self.label)
        p.end()

class GlowCard(QFrame):
    clicked = Signal()
    REST, HOVER = (18, 46)

    def __init__(self, palette, live: bool=True):
        super().__init__()
        self.P, self._live = (palette, live)
        self.setObjectName('Card')
        self.setCursor(Qt.PointingHandCursor if live else Qt.ForbiddenCursor)
        glow = QGraphicsDropShadowEffect(self)
        glow.setOffset(0, 0)
        glow.setColor(QColor(palette['beige']))
        glow.setBlurRadius(self.REST if live else 0)
        self.setGraphicsEffect(glow)
        self._glow = glow
        self._anim = QPropertyAnimation(glow, b'blurRadius', self)
        self._anim.setDuration(170)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)

    def _glow_to(self, value: int):
        self._anim.stop()
        self._anim.setStartValue(self._glow.blurRadius())
        self._anim.setEndValue(value)
        self._anim.start()

    def enterEvent(self, _e):
        if self._live:
            self._glow_to(self.HOVER)

    def leaveEvent(self, _e):
        if self._live:
            self._glow_to(self.REST)

    def mouseReleaseEvent(self, e):
        if self._live and e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()

class PracticeDialog(QDialog):

    def __init__(self, window):
        super().__init__(window)
        from gui import P, DISPLAY_STACK, SANS_STACK, PAPER_STACK, SILENCE_TIMEOUT
        self.win, self.P = (window, P)
        self.speaker = window.speaker
        self.QUIET_STOP = SILENCE_TIMEOUT
        self._listener = None
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._watch)
        self._clear_attempt()
        self.setWindowTitle(t('Practice'))
        self.resize(880, 700)
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        self.setSizeGripEnabled(True)
        self.setMinimumSize(560, 480)
        self.setStyleSheet(f"""\n            QDialog {{ background: {P['canvas']}; }}\n            QLabel {{ color: {P['ink']}; font-family: {SANS_STACK};\n                      font-size: 14px; }}\n            QLabel#Eyebrow {{ color: {P['beige']}; font-family: {DISPLAY_STACK};\n                      font-size: 11px; font-weight: 700; letter-spacing: 2px; }}\n            QLabel#H {{ font-family: {DISPLAY_STACK}; font-size: 20px;\n                      font-weight: 700; }}\n            QLabel#Note {{ color: {P['ink_soft']}; font-size: 13px; }}\n            QLabel#Say {{ font-family: {PAPER_STACK}; font-size: 34px; }}\n            QLabel#Phrase {{ font-family: {PAPER_STACK}; font-size: 20px; }}\n            QLabel#Axis {{ color: {P['ink_soft']}; font-size: 12px; }}\n            QLabel#Stat {{ font-family: {DISPLAY_STACK}; font-size: 28px;\n                      font-weight: 700; }}\n            QFrame#Card {{ background: {P['surface']};\n                      border: 1px solid {P['line']}; border-radius: 13px; }}\n            QFrame#Sep {{ background: {P['line']}; max-height: 1px;\n                      border: none; }}\n            QPushButton {{ font-family: {DISPLAY_STACK}; font-size: 14px;\n                      font-weight: 700; background: {P['beige']};\n                      color: {P['on_accent']}; border: none;\n                      border-radius: 11px; padding: 11px 22px; }}\n            QPushButton:hover {{ background: {P['beige_text']}; }}\n            QPushButton#Ghost {{ background: transparent; color: {P['ink']};\n                      border: 1px solid {P['line']}; }}\n            QPushButton#Ghost:hover {{ border-color: {P['beige']}; }}\n            /* A REFUSED BUTTON MUST NOT WEAR THE PRIMARY COLOUR. Without this\n               the disabled "Not yet" kept the accent fill and read as the main\n               action on the screen while doing nothing when pressed. */\n            QPushButton:disabled {{ background: transparent;\n                      color: {P['ink_soft']}; border: 1px dashed {P['line']}; }}\n            QLineEdit {{ background: {P['surface']}; color: {P['ink']};\n                      border: 1px solid {P['line']}; border-radius: 10px;\n                      padding: 10px 13px; font-family: {SANS_STACK};\n                      font-size: 14px; }}\n            QLineEdit:focus {{ border-color: {P['beige']}; }}\n        """)
        self.stack = QStackedWidget()
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(self.stack)
        self.level = practice.current_level(self.speaker)['n']
        self.custom_round = False
        self.stack.addWidget(self._page_choose())
        self.stack.addWidget(self._page_ladder())
        self.stack.addWidget(self._page_custom())
        self.stack.addWidget(QWidget())
        self.stack.addWidget(QWidget())

    def _page_choose(self) -> QWidget:
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(40, 34, 40, 40)
        lay.setSpacing(0)
        eb = QLabel(t('PRACTICE'))
        eb.setObjectName('Eyebrow')
        eb.setAlignment(Qt.AlignHCenter)
        h = QLabel(t('What would you like to practise?'))
        h.setObjectName('H')
        h.setAlignment(Qt.AlignHCenter)
        ready = practice.has_evidence(self.speaker)
        found = len(practice.corrections(self.speaker))
        auto = self._door('Automatic', f'The words Kara has got wrong for you, in levels. {found} on file.' if ready else 'Nothing here yet. Correct a word Kara gets wrong — two and too, say — and it appears here.', 'Start' if ready else 'Nothing to practise yet', live=ready)
        if ready:
            auto.clicked.connect(lambda: self.stack.setCurrentIndex(1))
        cust = self._door('Your own words', 'Anything you want to work on, whether or not Kara has noticed it.', 'Choose')
        cust.clicked.connect(self._open_custom)
        row = QHBoxLayout()
        row.setSpacing(26)
        row.addStretch()
        row.addWidget(auto)
        row.addWidget(cust)
        row.addStretch()
        lay.addStretch(3)
        lay.addWidget(eb)
        lay.addSpacing(4)
        lay.addWidget(h)
        lay.addSpacing(30)
        lay.addLayout(row)
        lay.addStretch(4)
        return page

    def _door(self, title: str, note: str, action: str, live: bool=True) -> GlowCard:
        P = self.P
        card = GlowCard(P, live=live)
        card.setFixedSize(310, 200)
        cl = QVBoxLayout(card)
        cl.setContentsMargins(24, 22, 24, 20)
        cl.setSpacing(8)
        head = QLabel(t(title))
        head.setObjectName('H')
        head.setWordWrap(True)
        cl.addWidget(head)
        n = QLabel(t(note))
        n.setObjectName('Note')
        n.setWordWrap(True)
        cl.addWidget(n)
        cl.addStretch()
        a = QLabel(f'{action} →' if live else action)
        a.setObjectName('Eyebrow')
        if not live:
            a.setStyleSheet(f"color:{P['ink_soft']};")
        cl.addWidget(a)
        return card

    def _open_custom(self):
        fresh = self._page_custom()
        old = self.stack.widget(2)
        self.stack.insertWidget(2, fresh)
        self.stack.removeWidget(old)
        old.deleteLater()
        self.stack.setCurrentWidget(fresh)

    def _page_custom(self) -> QWidget:
        P = self.P
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(36, 32, 36, 34)
        lay.setSpacing(12)
        eb = QLabel(t('YOUR OWN WORDS'))
        eb.setObjectName('Eyebrow')
        lay.addWidget(eb)
        h = QLabel(t('Add a word or a sentence to practise'))
        h.setObjectName('H')
        h.setWordWrap(True)
        lay.addWidget(h)
        note = QLabel(t('A single word is put into a short sentence before you say it. Said alone, the sounds that give you trouble behave differently from the way they behave in a sentence — so a bare word would be practice for a case that does not come up.'))
        note.setObjectName('Note')
        note.setWordWrap(True)
        lay.addWidget(note)
        row = QHBoxLayout()
        row.setSpacing(10)
        self.custom_edit = QLineEdit()
        self.custom_edit.setPlaceholderText(t('a word, or a whole sentence'))
        self.custom_edit.returnPressed.connect(self._add_custom)
        add = QPushButton(t('Add'))
        add.setCursor(Qt.PointingHandCursor)
        add.clicked.connect(self._add_custom)
        row.addWidget(self.custom_edit, 1)
        row.addWidget(add)
        lay.addLayout(row)
        mine = practice.custom_phrases(self.speaker)
        box = QFrame()
        box.setObjectName('Card')
        bl = QVBoxLayout(box)
        bl.setContentsMargins(20, 16, 20, 16)
        bl.setSpacing(6)
        if not mine:
            empty = QLabel(t('Nothing here yet.'))
            empty.setObjectName('Note')
            bl.addWidget(empty)
        for phrase in mine:
            r = QHBoxLayout()
            lbl = QLabel(phrase)
            lbl.setObjectName('Phrase')
            lbl.setWordWrap(True)
            rm = QPushButton(t('Remove'))
            rm.setObjectName('Ghost')
            rm.setCursor(Qt.PointingHandCursor)
            rm.setStyleSheet('padding:4px 12px;font-size:12px;')
            rm.clicked.connect(lambda _=False, p=phrase: self._remove_custom(p))
            r.addWidget(lbl, 1)
            r.addWidget(rm)
            bl.addLayout(r)
        bl.addStretch()
        lay.addWidget(box, 1)
        foot = QHBoxLayout()
        foot.setSpacing(10)
        back = QPushButton(t('Back'))
        back.setObjectName('Ghost')
        back.setCursor(Qt.PointingHandCursor)
        back.clicked.connect(lambda: self.stack.setCurrentIndex(0))
        start = QPushButton('Practice' if mine else 'Add one first')
        start.setEnabled(bool(mine))
        start.setCursor(Qt.PointingHandCursor if mine else Qt.ForbiddenCursor)
        start.clicked.connect(self._start_custom)
        foot.addWidget(back)
        foot.addStretch()
        foot.addWidget(start)
        lay.addLayout(foot)
        return page

    def _add_custom(self):
        text = self.custom_edit.text()
        if text.strip():
            practice.add_custom(self.speaker, text)
            self._open_custom()

    def _remove_custom(self, phrase: str):
        practice.remove_custom(self.speaker, phrase)
        self._open_custom()

    def _start_custom(self):
        phrases = practice.custom_phrases(self.speaker)
        if phrases:
            self._start_round(practice.CUSTOM_LEVEL, phrases)

    def _page_ladder(self) -> QWidget:
        P = self.P
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(32, 28, 32, 30)
        lay.setSpacing(14)
        eb = QLabel(t('PRACTICE'))
        eb.setObjectName('Eyebrow')
        lay.addWidget(eb)
        rows = practice.ladder(self.speaker)
        cur = next((r for r in rows if r['state'] == 'now'))
        h = QLabel(t('The sounds worth practising, in the order your recordings put them'))
        h.setObjectName('H')
        h.setWordWrap(True)
        lay.addWidget(h)
        wave = Waveform(rows, P)
        wave.picked.connect(self._choose_level)
        lay.addWidget(wave)
        axis = QHBoxLayout()
        a = QLabel(t('Level %s · %s') % (rows[0]['n'], rows[0]['name']))
        b = QLabel(t('Level %s · %s') % (rows[-1]['n'], rows[-1]['name']))
        for w in (a, b):
            w.setObjectName('Axis')
        axis.addWidget(a)
        axis.addStretch()
        axis.addWidget(b)
        lay.addLayout(axis)
        sep = QFrame()
        sep.setObjectName('Sep')
        sep.setFixedHeight(1)
        lay.addWidget(sep)
        cards = QHBoxLayout()
        cards.setSpacing(16)
        left = QFrame()
        left.setObjectName('Card')
        ll = QVBoxLayout(left)
        ll.setContentsMargins(20, 18, 20, 20)
        ll.setSpacing(6)
        head = QLabel(t('Level %s — %s') % (cur['n'], cur['name']))
        head.setObjectName('H')
        ll.addWidget(head)
        why = QLabel(t('Words Kara has actually got wrong for you. Saying them is worth more than recording new ones.'))
        why.setObjectName('Note')
        why.setWordWrap(True)
        ll.addWidget(why)
        ll.addSpacing(6)
        for phrase in practice.phrases_for(self.speaker, cur['n'])[:3]:
            p = QLabel(phrase)
            p.setObjectName('Phrase')
            ll.addWidget(p)
        ll.addStretch()
        row = QHBoxLayout()
        row.setSpacing(10)
        go = QPushButton(t('Start level %s') % (cur['n'],))
        go.setCursor(Qt.PointingHandCursor)
        go.clicked.connect(lambda: self._start_round(cur['n']))
        row.addWidget(go)
        row.addStretch()
        ll.addLayout(row)
        cards.addWidget(left, 3)
        s = practice.summary(self.speaker)
        right = QFrame()
        right.setObjectName('Card')
        rl = QHBoxLayout(right)
        rl.setContentsMargins(22, 18, 22, 18)
        rl.setSpacing(22)
        rl.addStretch()
        rl.addWidget(Ring(s['accuracy'], 'this week', P), 0, Qt.AlignVCenter)
        stats = QVBoxLayout()
        stats.setSpacing(16)
        stats.addStretch()
        for n, label in ((s['streak'], 'day streak'), (s['said'], 'phrases said')):
            box = QVBoxLayout()
            box.setSpacing(0)
            v = QLabel(str(n))
            v.setObjectName('Stat')
            l = QLabel(label)
            l.setObjectName('Note')
            box.addWidget(v)
            box.addWidget(l)
            stats.addLayout(box)
        stats.addStretch()
        rl.addLayout(stats)
        rl.addStretch()
        cards.addWidget(right, 2)
        lay.addLayout(cards)
        return page

    def _choose_level(self, n: int):
        self.level = n
        self._start_round(n)

    def _start_round(self, level: int, phrases: list[str] | None=None):
        self.level = level
        self.custom_round = phrases is not None
        self.phrases = list(phrases) if phrases is not None else practice.phrases_for(self.speaker, level)
        self.scores: list[int] = []
        self.idx = 0
        self._clear_attempt()
        self._build_round()

    def _clear_attempt(self):
        self.listening = False
        self.thinking = False
        self.heard_text = None
        self.attempt = None
        self._audio = None

    def _build_round(self):
        P = self.P
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(32, 28, 32, 30)
        lay.setSpacing(12)
        head = QHBoxLayout()
        eb = QLabel(t('CUSTOM · %s OF %s') % (self.idx + 1, len(self.phrases)) if self.custom_round else t('LEVEL %s OF %s') % (self.level, len(self.phrases)))
        eb.setObjectName('Eyebrow')
        flag = QPushButton(t('⚠  Not this one'))
        flag.setObjectName('Ghost')
        flag.setCursor(Qt.PointingHandCursor)
        flag.setFocusPolicy(Qt.NoFocus)
        flag.setStyleSheet('padding:6px 14px;font-size:12px;')
        flag.setToolTip(t('Never show this phrase in practice again.'))
        flag.clicked.connect(self._block_this)
        head.addWidget(eb)
        head.addStretch()
        head.addWidget(flag)
        lay.addLayout(head)
        pips = QHBoxLayout()
        pips.setSpacing(5)
        for i in range(len(self.phrases)):
            bar = QFrame()
            bar.setFixedHeight(5)
            done = i < len(self.scores)
            col = P['green'] if done and self.scores[i] >= 85 else P['amber'] if done else P['beige'] if i == self.idx else P['line']
            bar.setStyleSheet(f'background:{col};border-radius:3px;')
            pips.addWidget(bar)
        lay.addLayout(pips)
        lay.addSpacing(10)
        body = QHBoxLayout()
        body.setSpacing(26)
        left = QVBoxLayout()
        left.setSpacing(8)
        target = self.phrases[self.idx] if self.phrases else ''
        say = QLabel(target)
        say.setObjectName('Say')
        say.setWordWrap(True)
        say.setAlignment(Qt.AlignHCenter)
        left.addWidget(say)
        self.hint = QLabel(self._opening_hint())
        self.hint.setObjectName('Note')
        self.hint.setWordWrap(True)
        self.hint.setAlignment(Qt.AlignHCenter)
        left.addWidget(self.hint)
        left.addSpacing(14)
        from gui import MicOrb
        self.orb = MicOrb(source=self._mic_peak, accent=P['beige'], canvas=P['canvas'], size=118)
        self.orb.set_state('listening' if self.listening else 'thinking' if self.thinking else 'idle' if self._can_listen() else 'disabled')
        self.orb.clicked.connect(self._toggle_listen)
        holder = QHBoxLayout()
        holder.addStretch()
        holder.addWidget(self.orb)
        holder.addStretch()
        left.addLayout(holder)
        tap = QLabel(t('Hold space, or tap once'))
        tap.setObjectName('Note')
        tap.setAlignment(Qt.AlignHCenter)
        left.addWidget(tap)
        if self.heard_text is not None:
            left.addSpacing(12)
            card = QFrame()
            card.setObjectName('Card')
            card.setMaximumWidth(560)
            cl = QVBoxLayout(card)
            cl.setContentsMargins(18, 14, 18, 16)
            cl.setSpacing(4)
            cap = QLabel(t('KARA HEARD'))
            cap.setObjectName('Eyebrow')
            cap.setAlignment(Qt.AlignHCenter)
            cl.addWidget(cap)
            got = QLabel(self.heard_text or '— nothing —')
            got.setObjectName('Phrase')
            got.setWordWrap(True)
            got.setAlignment(Qt.AlignHCenter)
            cl.addWidget(got)
            sc = self.attempt or 0
            col = P['green'] if sc >= 85 else P['amber'] if sc >= 60 else P['red']
            verdict = QLabel(t('%s%% of that phrase came through') % (sc,))
            verdict.setObjectName('Note')
            verdict.setAlignment(Qt.AlignHCenter)
            verdict.setStyleSheet(f'color:{col};font-weight:700;')
            cl.addWidget(verdict)
            left.addWidget(card, 0, Qt.AlignHCenter)
        left.insertStretch(0, 1)
        left.addStretch(2)
        column = QWidget()
        column.setLayout(left)
        column.setMaximumWidth(820)
        body.addStretch(1)
        body.addWidget(column, 100)
        body.addStretch(1)
        lay.addLayout(body, 1)
        row = QHBoxLayout()
        row.setSpacing(10)
        stop = QPushButton(t('Save and exit'))
        stop.setObjectName('Ghost')
        stop.clicked.connect(self._save_and_exit)
        row.addStretch()
        if self.attempt is None:
            buttons = (stop,)
        else:
            again = QPushButton(t('Say it again'))
            again.setObjectName('Ghost')
            again.clicked.connect(self._retry)
            nxt = QPushButton('Keep it — next' if self.idx + 1 < len(self.phrases) else 'Keep it — finish')
            nxt.clicked.connect(self._commit)
            row.addWidget(again)
            row.addWidget(nxt)
            buttons = (stop, again, nxt)
        row.addWidget(stop)
        for b in buttons:
            b.setCursor(Qt.PointingHandCursor)
            b.setFocusPolicy(Qt.NoFocus)
        lay.addLayout(row)
        page.setFocusPolicy(Qt.StrongFocus)
        old = self.stack.widget(3)
        self.stack.insertWidget(3, page)
        self.stack.removeWidget(old)
        old.deleteLater()
        self._round_page = page
        self.stack.setCurrentWidget(page)
        page.setFocus()

    def _mic_peak(self) -> float:
        mic = getattr(self.win, 'mic', None)
        return float(mic.peak) if mic and self.listening else 0.0

    def _can_listen(self) -> bool:
        return bool(self.win.pipe and self.win.mic and (not self.win.recording))

    def _opening_hint(self) -> str:
        if not self.win.mic:
            return 'No microphone — Kara could not open one. Check Settings ▸ Sound.'
        if not self.win.pipe:
            return 'Kara is still starting up — the voice model is loading.'
        if self.win.recording:
            return "Finish what you're saying on the page first."
        return 'Take your time — the microphone waits.'

    def _say(self, text: str):
        try:
            self.hint.setText(t(text))
        except (AttributeError, RuntimeError):
            pass

    def _toggle_listen(self):
        if self.thinking:
            return
        if self.listening:
            self._stop_listen()
            return
        if not self._can_listen():
            self._say(self._opening_hint())
            return
        showing = self.attempt is not None
        self._clear_attempt()
        self.listening = True
        if showing:
            self._build_round()
        self.orb.set_state('listening')
        self._say('Listening — tap again when you finish.')
        self.win.mic.start()
        self._timer.start(400)

    def _stop_listen(self, auto: bool=False):
        if not self.listening:
            return
        self.listening = False
        self._timer.stop()
        audio = self.win.mic.stop()
        if audio.size < record.SAMPLE_RATE // 4:
            self.orb.set_state('idle')
            self._say("I didn't hear anything. Try again.")
            return
        severity, message = record.quality_check(audio)
        if severity == 'fatal':
            self.orb.set_state('idle')
            self._say(t('%s — try that again.') % (message,))
            karalog.get('practice').info('attempt refused: %s', message)
            return
        if severity == 'warn':
            karalog.get('practice').warning('degraded audio, scoring it anyway: %s', message)
        self._audio = audio
        self.thinking = True
        self.orb.set_state('thinking')
        self._say('Stopped after a quiet moment — working out what I heard.' if auto else 'Working out what I heard…')
        self._listener = PracticeListener(self.win.pipe, audio)
        self._listener.heard.connect(self._heard_ok)
        self._listener.failed.connect(self._heard_failed)
        self._listener.start()

    def _watch(self):
        if not (self.listening and self.win.mic):
            self._timer.stop()
            return
        if self.win.mic.silent_for() >= self.QUIET_STOP:
            self._stop_listen(auto=True)

    def _heard_ok(self, text: str):
        self.thinking = False
        self.heard_text = (text or '').strip()
        target = self.phrases[self.idx] if self.phrases else ''
        self.attempt = practice.score(self.heard_text, target)
        karalog.get('practice').info('level %s phrase %s/%s scored %s%%', self.level, self.idx + 1, len(self.phrases), self.attempt)
        self._build_round()
        self._say('Keep it, or say it again — nothing is recorded until you choose.')

    def _heard_failed(self, message: str):
        self.thinking = False
        self.orb.set_state('idle')
        self._say('Kara could not work that one out. Try it again.')
        karalog.get('practice').warning('attempt failed: %s', message)

    def _commit(self):
        score = self.attempt or 0
        target = self.phrases[self.idx] if self.phrases else ''
        try:
            clip = practice.keep_clip(self.win.speaker, target, self._audio, score)
            if clip:
                karalog.get('practice').info('kept clip %s (scored %s%%)', clip, score)
        except Exception as e:
            karalog.get('practice').warning('practice clip not kept: %s', e)
        self._clear_attempt()
        self._answer(score)

    def _retry(self):
        self._drop_listener()
        self._clear_attempt()
        self._build_round()

    def _skip(self):
        self._drop_listener()
        self._clear_attempt()
        self._answer(0)

    def _block_this(self):
        if not self.phrases:
            return
        phrase = self.phrases[self.idx]
        practice.block(self.speaker, phrase)
        if self.custom_round:
            practice.remove_custom(self.speaker, phrase)
        karalog.get('practice').info('phrase blocked in level %s', self.level)
        self._drop_listener()
        self._clear_attempt()
        self.phrases = [p for i, p in enumerate(self.phrases) if i != self.idx]
        if self.idx >= len(self.phrases):
            self._finish() if self.scores else self._save_and_exit()
            return
        self._build_round()

    def _save_and_exit(self):
        self._abandon()
        if self.scores:
            practice.record_round(self.speaker, self.level, self.scores)
            karalog.get('practice').info('round saved early: %s of %s phrases', len(self.scores), len(self.phrases))
        self.accept()

    def _drop_listener(self):
        t = getattr(self, '_listener', None)
        if t is None:
            return
        try:
            t.heard.disconnect()
            t.failed.disconnect()
        except (RuntimeError, TypeError):
            pass
        if t.isRunning():
            t.wait(15000)
        self._listener = None
        self.thinking = False

    def _abandon(self):
        timer = getattr(self, '_timer', None)
        if timer is not None:
            timer.stop()
        if self.listening and self.win.mic:
            self.win.mic.stop()
        self._drop_listener()
        self._clear_attempt()

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Space and (not e.isAutoRepeat()) and (self.stack.currentWidget() is getattr(self, '_round_page', None)):
            self._space_down = time.monotonic()
            self._space_started = not self.listening
            if self.listening:
                self._stop_listen()
            else:
                self._toggle_listen()
            return
        super().keyPressEvent(e)

    def keyReleaseEvent(self, e):
        if e.key() == Qt.Key_Space and (not e.isAutoRepeat()) and (self.stack.currentWidget() is getattr(self, '_round_page', None)):
            down = getattr(self, '_space_down', None)
            self._space_down = None
            if down is not None and self.listening and getattr(self, '_space_started', False) and (time.monotonic() - down >= self.win.HOLD_MS):
                self._stop_listen()
            return
        super().keyReleaseEvent(e)

    def done(self, result: int):
        self._abandon()
        super().done(result)

    def _answer(self, score: int):
        self.scores.append(int(score))
        self.idx += 1
        if self.idx >= len(self.phrases):
            self._finish()
            return
        self._build_round()

    def _finish(self):
        P = self.P
        self._timer.stop()
        result = practice.record_round(self.speaker, self.level, self.scores)
        page = QWidget()
        lay = QVBoxLayout(page)
        lay.setContentsMargins(32, 28, 32, 30)
        lay.setSpacing(14)
        eb = QLabel(t('YOUR OWN WORDS — DONE') if self.custom_round else t('LEVEL %s COMPLETE') % (self.level,))
        eb.setObjectName('Eyebrow')
        lay.addWidget(eb)
        top = QHBoxLayout()
        top.setSpacing(30)
        good = result['accuracy'] >= result['before']
        top.addWidget(Ring(result['accuracy'], 'this round', P, 158, 'green' if good else 'amber'))
        deltas = QVBoxLayout()
        deltas.setSpacing(9)
        for phrase, sc in zip(self.phrases, self.scores):
            r = QHBoxLayout()
            r.setSpacing(12)
            short = ' '.join(phrase.split()[:3]).rstrip(',.')
            if len(phrase.split()) > 3:
                short += '…'
            n = QLabel(short)
            n.setObjectName('Note')
            n.setFixedWidth(150)
            track = QFrame()
            track.setFixedHeight(8)
            col = P['green'] if sc >= 85 else P['amber'] if sc >= 60 else P['red']
            track.setStyleSheet(f"border-radius:4px;background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 {col}, stop:{max(0.01, sc / 100):.2f} {col},stop:{min(0.99, sc / 100 + 0.001):.3f} {P['line']},stop:1 {P['line']});")
            v = QLabel(f'{sc}%')
            v.setObjectName('Note')
            v.setStyleSheet(f'color:{col};font-weight:700;')
            r.addWidget(n)
            r.addWidget(track, 1)
            r.addWidget(v)
            deltas.addLayout(r)
        deltas.addStretch()
        top.addLayout(deltas, 1)
        lay.addLayout(top)
        worst = min(zip(self.phrases, self.scores), key=lambda row: row[1], default=('', 100))
        note = QLabel(t("“%s” was the hardest one at %s%%. One round is not enough to tell whether that is a real change — it stays in tomorrow's set.") % (worst[0], worst[1]) if worst[1] < 85 else t('Every phrase came through above 85%%. Level %s is done unless you want it again.') % (self.level,))
        note.setObjectName('Note')
        note.setWordWrap(True)
        note.setStyleSheet(f"border-left:3px solid {P['beige']};padding:12px 16px;background:{P['surface']};")
        lay.addWidget(note)
        lay.addStretch()
        row = QHBoxLayout()
        row.setSpacing(10)
        if self.custom_round:
            nxt = QPushButton(t('Do these again'))
            nxt.clicked.connect(self._start_custom)
            back = QPushButton(t('Back to your words'))
            back.setObjectName('Ghost')
            back.clicked.connect(self._open_custom)
            row.addWidget(nxt)
            row.addStretch()
            row.addWidget(back)
            buttons = (nxt, back)
        else:
            nxt = QPushButton(t('Practise level %s') % (min(self.level + 1, 14),))
            nxt.clicked.connect(lambda: self._start_round(min(self.level + 1, 14)))
            again = QPushButton(t('Do this one again'))
            again.setObjectName('Ghost')
            again.clicked.connect(lambda: self._start_round(self.level))
            back = QPushButton(t('Back to the levels'))
            back.setObjectName('Ghost')
            back.clicked.connect(self._reload_ladder)
            row.addWidget(nxt)
            row.addWidget(again)
            row.addStretch()
            row.addWidget(back)
            buttons = (nxt, again, back)
        for b in buttons:
            b.setCursor(Qt.PointingHandCursor)
        lay.addLayout(row)
        old = self.stack.widget(4)
        self.stack.insertWidget(4, page)
        self.stack.removeWidget(old)
        old.deleteLater()
        self.stack.setCurrentWidget(page)

    def _reload_ladder(self):
        fresh = self._page_ladder()
        old = self.stack.widget(1)
        self.stack.insertWidget(1, fresh)
        self.stack.removeWidget(old)
        old.deleteLater()
        self.stack.setCurrentWidget(fresh)
