from __future__ import annotations
from PySide6.QtCore import QPoint, Qt, Signal
from PySide6.QtWidgets import QHBoxLayout, QLabel, QStackedWidget, QVBoxLayout, QWidget
from i18n import t

class MiniPlayer(QWidget):
    closed = Signal()
    SIZE = 168
    MARGIN = 6
    ICON = 28
    ORB = 84
    GAP = 6

    def __init__(self, window):
        super().__init__(None)
        self.win = window
        self._drag: QPoint | None = None
        self.setWindowTitle('Kara')
        self.setWindowFlags(Qt.Window | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setFixedSize(self.SIZE, self.SIZE)
        from gui import IconButton, MicOrb, P, SANS_STACK
        self._P = P
        self.setStyleSheet(f"\n            QWidget {{ background: transparent; color: {P['ink']};\n                       font-family: {SANS_STACK}; }}\n            QLabel#Mode {{ color: {P['beige_text']}; font-size: 11px;\n                           font-weight: 700; letter-spacing: 0.6px;\n                           background: {P['beige_bg']};\n                           border: 1px solid {P['line']};\n                           border-radius: 11px; padding: 3px 12px; }}\n            QLabel#Warn {{ color: {P['red']}; font-size: 14px;\n                           font-weight: 600; }}\n        ")
        self.stack = QStackedWidget(self)
        self.stack.setGeometry(0, 0, self.SIZE, self.SIZE)
        self.stack.addWidget(self._build_face(IconButton, MicOrb, P))
        self.stack.addWidget(self._build_warning(P))
        self.stack.setCurrentIndex(0)
        self.sync()

    def _build_face(self, IconButton, MicOrb, P) -> QWidget:
        face = QWidget()
        lay = QVBoxLayout(face)
        lay.setContentsMargins(self.MARGIN, self.MARGIN, self.MARGIN, self.MARGIN)
        lay.setSpacing(8)
        lay.addStretch()
        row = QHBoxLayout()
        row.setSpacing(self.GAP)
        row.addStretch()
        self.mode_btn = IconButton('cycle', 'Change mode', size=self.ICON, box=16.0)
        self.mode_btn.clicked.connect(self._cycle)
        row.addWidget(self.mode_btn, 0, Qt.AlignVCenter)
        self.orb = MicOrb(source=self.win._mic_level, accent=P['beige'], canvas=P['canvas'], size=self.ORB)
        self.orb.clicked.connect(self.win.toggle_record)
        row.addWidget(self.orb, 0, Qt.AlignVCenter)
        self.back_btn = IconButton('expand', 'Back to the full window', size=self.ICON, box=16.0)
        self.back_btn.clicked.connect(self._restore)
        row.addWidget(self.back_btn, 0, Qt.AlignVCenter)
        row.addStretch()
        lay.addLayout(row)
        chip = QHBoxLayout()
        chip.addStretch()
        self.mode_lab = QLabel('')
        self.mode_lab.setObjectName('Mode')
        self.mode_lab.setAlignment(Qt.AlignCenter)
        chip.addWidget(self.mode_lab)
        chip.addStretch()
        lay.addLayout(chip)
        lay.addStretch()
        return face

    def _build_warning(self, P) -> QWidget:
        from gui import GlyphIcon
        face = QWidget()
        lay = QVBoxLayout(face)
        lay.setContentsMargins(14, 14, 14, 14)
        lay.setSpacing(8)
        lay.addStretch()
        self.warn_icon = GlyphIcon('warn', 40, P['red'])
        lay.addWidget(self.warn_icon, 0, Qt.AlignHCenter)
        self.warn_text = QLabel('')
        self.warn_text.setObjectName('Warn')
        self.warn_text.setAlignment(Qt.AlignCenter)
        self.warn_text.setWordWrap(True)
        lay.addWidget(self.warn_text)
        lay.addStretch()
        return face

    def show_warning(self, text: str) -> None:
        self.warn_text.setText(text)
        self.stack.setCurrentIndex(1)
        self.update()
        from PySide6.QtCore import QTimer
        QTimer.singleShot(4000, self.clear_warning)

    def clear_warning(self) -> None:
        self.stack.setCurrentIndex(0)
        self.update()

    def _cycle(self) -> None:
        self.win.cycle_mode()
        self.sync()

    def sync(self) -> None:
        try:
            label = next((m[1] for m in self.win.modes if m[0] == self.win.current_mode()))
        except StopIteration:
            label = ''
        self.mode_lab.setText(label.upper())
        self.mode_btn.setToolTip(t('Mode: %s — tap to change') % label)
        try:
            self.orb.set_state(self.win.mic_btn.state())
        except Exception:
            pass
        if self._glow_wanted():
            self.update()

    def _restore(self):
        self.win.showNormal()
        self.win.raise_()
        self.win.activateWindow()
        self.close()

    def closeEvent(self, e):
        self._save_position()
        self.closed.emit()
        super().closeEvent(e)

    def _save_position(self):
        try:
            import config
            cfg = config.load()
            cfg['mini_position'] = [self.x(), self.y()]
            config.save(cfg)
        except Exception:
            pass

    def restore_position(self):
        try:
            import config
            pos = config.load().get('mini_position')
            if not (isinstance(pos, list) and len(pos) == 2):
                return self._centre_on_parent()
            from PySide6.QtCore import QRect
            from PySide6.QtGui import QGuiApplication
            want = QRect(int(pos[0]), int(pos[1]), self.SIZE, self.SIZE)
            for screen in QGuiApplication.screens():
                if screen.availableGeometry().intersects(want):
                    self.move(want.topLeft())
                    return
        except Exception:
            pass
        self._centre_on_parent()

    def _centre_on_parent(self):
        try:
            g = self.win.frameGeometry()
            self.move(g.center().x() - self.SIZE // 2, g.bottom() - self.SIZE - 40)
        except Exception:
            pass

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._drag = e.globalPosition().toPoint() - self.frameGeometry().topLeft()

    def mouseMoveEvent(self, e):
        if self._drag is not None and e.buttons() & Qt.LeftButton:
            self.move(e.globalPosition().toPoint() - self._drag)

    def mouseReleaseEvent(self, e):
        self._drag = None

    def _glow_wanted(self) -> bool:
        try:
            import gui
            return bool(self.win.recording and self.win.config.get('listening_glow', True) and gui.motion_ms(1))
        except Exception:
            return False

    def paintEvent(self, _e):
        import math
        import time as _time
        from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QRadialGradient
        warning = self.stack.currentIndex() == 1
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setBrush(QColor(self._P['red_bg'] if warning else self._P['surface']))
        p.setPen(QPen(QColor(self._P['red'] if warning else self._P['line']), 2 if warning else 1))
        card = self.rect().adjusted(1, 1, -2, -2)
        p.drawRoundedRect(card, 16, 16)
        if warning or not self._glow_wanted():
            return
        breathe = 0.5 + 0.5 * math.sin(_time.monotonic() * math.tau / 3.2)
        glow = QColor(self._P['beige'])
        glow.setAlphaF(0.22 * (0.45 + 0.55 * breathe))
        edge = QColor(self._P['beige'])
        edge.setAlphaF(0.0)
        path = QPainterPath()
        path.addRoundedRect(card, 16, 16)
        p.setClipPath(path)
        centre = self.orb.geometry().center() if hasattr(self, 'orb') else card.center()
        g = QRadialGradient(centre.x(), centre.y(), card.height() * (0.62 + 0.06 * breathe))
        g.setColorAt(0.0, glow)
        mid = QColor(glow)
        mid.setAlphaF(glow.alphaF() * 0.35)
        g.setColorAt(0.55, mid)
        g.setColorAt(1.0, edge)
        p.fillRect(card, g)
