import json
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / 'kara_config.json'
LEGACY_CONFIG_PATH = ROOT / 'reed_config.json'
DEFAULTS = {'input_device': None, 'output_device': None, 'sec_per_step': {}, 'listening_glow': True, 'train_reminder_days': 7, 'train_reminded_at': 0.0, 'model': None, 'include_spelling': True, 'theme': 'dusk', 'tts_voice': None, 'tts_rate': 0, 'mini_position': None, 'language': 'en', 'ui_language': 'en', 'active_profile': None, 'profiles': {}, 'terms_accepted': None, 'speak_responses': False, 'keep_utterances': True, 'offline_mode': True, 'grammar_service': 'https://api.languagetool.org/v2/check', 'extra_text_apps': [], 'retrain_offered_at': 0, 'train_on_documents': [], 'update_source': '', 'update_check': True, 'update_offered': '', 'beta_warned': False, 'unsure_threshold': 0.6, 'cloud_backup': False, 'cloud_backup_model': True, 'cloud_provider': 'local', 'cloud_local_path': None, 'auto_backup': True, 'last_backup': None, 'last_backup_fingerprint': None}
DEFAULT_UPDATE_SOURCE = ''

def effective_update_source(cfg) -> str:
    return (cfg.get('update_source') or '').strip() or DEFAULT_UPDATE_SOURCE

def _migrate_legacy() -> None:
    try:
        if CONFIG_PATH.exists() or not LEGACY_CONFIG_PATH.exists():
            return
        LEGACY_CONFIG_PATH.rename(CONFIG_PATH)
    except OSError:
        pass

def _ui_language_codes() -> set:
    try:
        import i18n
        return {'en', *i18n.TRANSLATIONS}
    except Exception:
        return {'en'}

def _inherit_ui_language(cfg: dict, stored: dict) -> None:
    if 'ui_language' in stored:
        return
    spoken = (stored.get('language') or '').strip().lower()
    if spoken and spoken != 'en' and (spoken in _ui_language_codes()):
        cfg['ui_language'] = spoken

def load() -> dict:
    cfg = dict(DEFAULTS)
    _migrate_legacy()
    try:
        stored = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
        if isinstance(stored, dict):
            cfg.update({k: stored[k] for k in DEFAULTS if k in stored})
            _inherit_ui_language(cfg, stored)
    except (OSError, ValueError):
        pass
    return cfg

def save(cfg: dict) -> None:
    keep = {k: cfg.get(k, DEFAULTS[k]) for k in DEFAULTS}
    try:
        import atomicio
        atomicio.write_json(CONFIG_PATH, keep)
    except OSError:
        pass
