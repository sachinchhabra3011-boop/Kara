from __future__ import annotations
FLOOR = {'ink_on_paper': 7.0, 'ink_on_canvas': 7.0, 'ink_on_surface': 7.0, 'ink_soft_on_surface': 4.5, 'accent_on_canvas': 4.5, 'on_accent_on_accent': 4.5, 'red_on_paper': 4.5, 'blue_on_paper': 4.5, 'line_on_surface': 1.2}
MARK_DISTANCE_FLOOR = 40.0

def _srgb(c: float) -> float:
    c /= 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

def luminance(hex_colour: str) -> float:
    h = hex_colour.lstrip('#')
    if len(h) == 3:
        h = ''.join((ch * 2 for ch in h))
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * _srgb(r) + 0.7152 * _srgb(g) + 0.0722 * _srgb(b)

def ratio(a: str, b: str) -> float:
    la, lb = (luminance(a), luminance(b))
    hi, lo = (max(la, lb), min(la, lb))
    return (hi + 0.05) / (lo + 0.05)

def _lab(hex_colour: str) -> tuple[float, float, float]:
    h = hex_colour.lstrip('#')
    if len(h) == 3:
        h = ''.join((ch * 2 for ch in h))
    r, g, b = (_srgb(int(h[i:i + 2], 16)) for i in (0, 2, 4))
    x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    y = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 1.0
    z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883

    def f(t):
        return t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116
    fx, fy, fz = (f(x), f(y), f(z))
    return (116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz))

def distance(a: str, b: str) -> float:
    la, aa, ba = _lab(a)
    lb, ab, bb = _lab(b)
    return ((la - lb) ** 2 + (aa - ab) ** 2 + (ba - bb) ** 2) ** 0.5
PAIRS = {'ink_on_paper': ('paper_ink', 'paper'), 'ink_on_canvas': ('ink', 'canvas'), 'ink_on_surface': ('ink', 'surface'), 'ink_soft_on_surface': ('ink_soft', 'surface'), 'accent_on_canvas': ('beige_text', 'canvas'), 'on_accent_on_accent': ('on_accent', 'beige'), 'red_on_paper': ('red', 'paper'), 'blue_on_paper': ('blue', 'paper'), 'line_on_surface': ('line', 'surface')}

def check(palette: dict) -> list[dict]:
    out = []
    for name, (a, b) in PAIRS.items():
        if a not in palette or b not in palette:
            continue
        r = ratio(palette[a], palette[b])
        floor = FLOOR[name]
        out.append({'name': name, 'a': a, 'b': b, 'ratio': r, 'floor': floor, 'ok': r >= floor, 'kind': 'contrast'})
    if 'red' in palette and 'blue' in palette:
        d = distance(palette['red'], palette['blue'])
        out.append({'name': 'red_vs_blue (dE)', 'a': 'red', 'b': 'blue', 'ratio': d, 'floor': MARK_DISTANCE_FLOOR, 'ok': d >= MARK_DISTANCE_FLOOR, 'kind': 'distance'})
    return out

def report(name: str, palette: dict) -> int:
    rows = check(palette)
    bad = [r for r in rows if not r['ok']]
    print(f'\n{name}')
    print('-' * 58)
    for r in rows:
        mark = 'ok  ' if r['ok'] else 'FAIL'
        unit = 'dE' if r['kind'] == 'distance' else ':1'
        print(f"  {mark} {r['name']:<22} {r['ratio']:6.2f}{unit}  (needs {r['floor']:.1f})")
    print(f'  {len(rows) - len(bad)}/{len(rows)} pass')
    return len(bad)
