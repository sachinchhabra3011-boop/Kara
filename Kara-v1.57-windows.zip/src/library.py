from __future__ import annotations
import json
import re
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
TITLE_WORDS = 6
UNTITLED = 'New page'

def _dir(speaker: str) -> Path:
    return ROOT / 'data' / speaker / 'library'

def _index_path(speaker: str) -> Path:
    return _dir(speaker) / 'index.json'

def doc_path(speaker: str, doc_id: str) -> Path:
    return _dir(speaker) / f'{doc_id}.txt'

def _now() -> float:
    return time.time()

def _new_id() -> str:
    return f'{int(_now() * 1000):013d}'

def auto_title(text: str) -> str:
    words = text.split()
    if not words:
        return UNTITLED
    title = ' '.join(words[:TITLE_WORDS]).strip(' ,.;:!?-—')
    title = re.sub('\\s+', ' ', title)
    if len(words) > TITLE_WORDS:
        title += '…'
    return title[:60] or UNTITLED

def load_index(speaker: str) -> list[dict]:
    p = _index_path(speaker)
    if not p.exists():
        return []
    try:
        data = json.loads(p.read_text(encoding='utf-8'))
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []

def save_index(speaker: str, rows: list[dict]) -> None:
    p = _index_path(speaker)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix('.json.tmp')
    try:
        tmp.write_text(json.dumps(rows, indent=1, ensure_ascii=False), encoding='utf-8')
        tmp.replace(p)
    except OSError:
        pass

def list_docs(speaker: str) -> list[dict]:
    rows = load_index(speaker)
    rows.sort(key=lambda r: r.get('modified', 0), reverse=True)
    return rows

def create(speaker: str, text: str='') -> dict:
    doc_id = _new_id()
    row = {'id': doc_id, 'title': auto_title(text), 'created': _now(), 'modified': _now(), 'words': len(text.split())}
    _dir(speaker).mkdir(parents=True, exist_ok=True)
    doc_path(speaker, doc_id).write_text(text, encoding='utf-8')
    rows = load_index(speaker)
    rows.append(row)
    save_index(speaker, rows)
    return row

def read(speaker: str, doc_id: str) -> str:
    p = doc_path(speaker, doc_id)
    try:
        return p.read_text(encoding='utf-8')
    except OSError:
        return ''

def save(speaker: str, doc_id: str, text: str, title: str | None=None) -> dict | None:
    rows = load_index(speaker)
    row = next((r for r in rows if r.get('id') == doc_id), None)
    if row is None:
        return None
    p = doc_path(speaker, doc_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix('.txt.tmp')
    try:
        tmp.write_text(text, encoding='utf-8')
        tmp.replace(p)
    except OSError:
        return row
    if title is not None:
        row['title'] = title.strip()[:60] or UNTITLED
        row['renamed'] = True
    elif not row.get('renamed'):
        row['title'] = auto_title(text)
    row['modified'] = _now()
    row['words'] = len(text.split())
    save_index(speaker, rows)
    return row

def rename(speaker: str, doc_id: str, title: str) -> None:
    rows = load_index(speaker)
    for r in rows:
        if r.get('id') == doc_id:
            r['title'] = title.strip()[:60] or UNTITLED
            r['renamed'] = True
            r['modified'] = _now()
    save_index(speaker, rows)

def recycle(path: Path) -> bool:
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [('hwnd', wintypes.HWND), ('wFunc', wintypes.UINT), ('pFrom', wintypes.LPCWSTR), ('pTo', wintypes.LPCWSTR), ('fFlags', ctypes.c_uint16), ('fAnyOperationsAborted', wintypes.BOOL), ('hNameMappings', wintypes.LPVOID), ('lpszProgressTitle', wintypes.LPCWSTR)]
    FO_DELETE = 3
    FOF_ALLOWUNDO = 64
    FOF_NOCONFIRMATION = 16
    FOF_SILENT = 4
    FOF_NOERRORUI = 1024
    try:
        op = SHFILEOPSTRUCTW()
        op.wFunc = FO_DELETE
        op.pFrom = str(path) + '\x00\x00'
        op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_SILENT | FOF_NOERRORUI
        rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
        return rc == 0 and (not op.fAnyOperationsAborted)
    except Exception:
        return False

def delete(speaker: str, doc_id: str) -> None:
    rows = [r for r in load_index(speaker) if r.get('id') != doc_id]
    save_index(speaker, rows)
    p = doc_path(speaker, doc_id)
    if p.exists() and (not recycle(p)):
        try:
            p.unlink()
        except OSError:
            pass

def rebuild_index(speaker: str) -> list[dict]:
    d = _dir(speaker)
    if not d.is_dir():
        return []
    known = {r.get('id'): r for r in load_index(speaker)}
    rows = []
    for p in sorted(d.glob('*.txt')):
        doc_id = p.stem
        try:
            text = p.read_text(encoding='utf-8')
            stat = p.stat()
        except OSError:
            continue
        old = known.get(doc_id, {})
        rows.append({'id': doc_id, 'title': old.get('title') or auto_title(text), 'renamed': old.get('renamed', False), 'created': old.get('created', stat.st_ctime), 'modified': stat.st_mtime, 'words': len(text.split())})
    save_index(speaker, rows)
    return rows

def when(ts: float) -> str:
    now = _now()
    day = 86400.0
    delta = now - ts
    if delta < 60:
        return 'just now'
    if delta < 3600:
        return f'{int(delta // 60)} min ago'
    lt, ln = (time.localtime(ts), time.localtime(now))
    if lt.tm_yday == ln.tm_yday and lt.tm_year == ln.tm_year:
        return time.strftime('%H:%M', lt)
    if delta < 2 * day:
        return 'yesterday'
    if delta < 7 * day:
        return time.strftime('%A', lt)
    if lt.tm_year == ln.tm_year:
        return time.strftime('%-d %b', lt) if hasattr(time, 'tzset') else time.strftime('%d %b', lt)
    return time.strftime('%d %b %Y', lt)
