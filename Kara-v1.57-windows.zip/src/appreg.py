from __future__ import annotations
import os
import shutil
from pathlib import Path
KEY = 'Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Kara'
STABLE_DIR = Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'Kara'
STABLE_UNINSTALLER = STABLE_DIR / 'uninstall.ps1'

def _installer_source(root: Path) -> Path | None:
    for rel in ('scripts/install_app.ps1', 'install_app.ps1'):
        p = root / rel
        if p.is_file():
            return p
    return None

def _uninstall_command(root: Path) -> str:
    return f'powershell -ExecutionPolicy Bypass -NoProfile -File "{STABLE_UNINSTALLER}" -Uninstall -InstallRoot "{root}"'

def ensure_registered(root: Path, version: str, log=None) -> bool:

    def say(msg, *a):
        if log is not None:
            try:
                log.info(msg, *a)
            except Exception:
                pass
    try:
        import winreg
    except ImportError:
        return False
    try:
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, KEY) as k:
                have, _ = winreg.QueryValueEx(k, 'DisplayVersion')
                cmd, _ = winreg.QueryValueEx(k, 'UninstallString')
            if have == version and STABLE_UNINSTALLER.is_file() and (str(root) in cmd):
                return False
        except FileNotFoundError:
            pass
        src = _installer_source(root)
        if src is None:
            say('not registering with Windows: no installer in this build')
            return False
        STABLE_DIR.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, STABLE_UNINSTALLER)
        if not STABLE_UNINSTALLER.is_file():
            say('not registering with Windows: could not place the uninstaller')
            return False
        icon = root / 'assets' / 'kara.ico'
        values = {'DisplayName': 'Kara', 'DisplayVersion': version, 'Publisher': 'Kara', 'InstallLocation': str(root), 'UninstallString': _uninstall_command(root)}
        if icon.is_file():
            values['DisplayIcon'] = str(icon)
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, KEY) as k:
            for name, val in values.items():
                winreg.SetValueEx(k, name, 0, winreg.REG_SZ, val)
            for name in ('NoModify', 'NoRepair'):
                winreg.SetValueEx(k, name, 0, winreg.REG_DWORD, 1)
        say('registered with Windows as Kara %s', version)
        return True
    except OSError as e:
        say('could not register with Windows: %s', e)
        return False
