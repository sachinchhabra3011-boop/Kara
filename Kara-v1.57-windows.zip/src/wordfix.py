from __future__ import annotations
import re
from collections import Counter
import adapt
REPEATS = adapt.PROMOTE_AFTER
_WORD = re.compile("[A-Za-z']+")

def _words(text: str) -> list[str]:
    return _WORD.findall((text or '').lower())

def candidates(speaker: str, repeats: int=REPEATS) -> list[dict]:
    try:
        import corrector
    except Exception:
        return []
    pairs = Counter()
    for row in adapt.read_queue(speaker):
        if row.get('trust') not in adapt.PROMOTING_TRUST:
            continue
        heard, meant = (_words(row.get('asr_output')), _words(row.get('accepted')))
        if not heard or not meant or len(heard) != len(meant):
            continue
        for a, b in zip(heard, meant):
            if a != b:
                pairs[a, b] += 1
    try:
        table = {str(k).lower(): str(v) for k, v in (corrector.load_vocab(speaker).get('confusions') or {}).items()}
    except Exception:
        table = {}
    out = []
    for (heard, meant), n in pairs.most_common():
        if n < repeats:
            continue
        out.append({'heard': heard, 'meant': meant, 'count': n, 'known': table.get(heard, '').lower() == meant})
    return out

def teach(speaker: str, heard: str, meant: str) -> bool:
    try:
        import corrector
        import profiles as profile
        import atomicio
        import json
        path = profile.paths(speaker)['vocab']
        vocab = corrector.load_vocab(speaker) or {}
        table = dict(vocab.get('confusions') or {})
        table[heard] = meant
        vocab['confusions'] = table
        atomicio.write_json(path, vocab, backup=True)
        return True
    except Exception:
        return False

def forget(speaker: str, heard: str) -> bool:
    try:
        import corrector
        import profiles as profile
        import atomicio
        path = profile.paths(speaker)['vocab']
        vocab = corrector.load_vocab(speaker) or {}
        table = {k: v for k, v in (vocab.get('confusions') or {}).items() if str(k).lower() != heard.lower()}
        vocab['confusions'] = table
        atomicio.write_json(path, vocab, backup=True)
        return True
    except Exception:
        return False

def taught(speaker: str) -> list[tuple[str, str]]:
    try:
        import corrector
        return sorted(((str(k), str(v)) for k, v in (corrector.load_vocab(speaker).get('confusions') or {}).items()))
    except Exception:
        return []
