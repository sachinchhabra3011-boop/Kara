import difflib
import re
import spelling
from editing import SENTENCE_END
MARKS = {'comma': ',', 'full stop': '.', 'period': '.', 'full-stop': '.', 'dot': '.', 'question mark': '?', 'question': '?', 'exclamation mark': '!', 'exclamation point': '!', 'exclamation': '!', 'colon': ':', 'semicolon': ';', 'semi colon': ';', 'dash': ' -', 'hyphen': '-', 'single quotation mark': "'", 'single quotation': "'", 'single quote': "'", 'apostrophe': "'", 'double quotation mark': '"', 'double quotation': '"', 'double quote': '"', 'quotation mark': '"', 'speech mark': '"', 'quote': '"', 'कॉमा': ',', 'अल्पविराम': ',', 'पूर्ण विराम': '।', 'पूर्णविराम': '।', 'डंडा': '।', 'खड़ी पाई': '।', 'फुल स्टॉप': '.', 'प्रश्न चिह्न': '?', 'सवालिया निशान': '?', 'क्वेश्चन मार्क': '?', 'विस्मयादिबोधक चिह्न': '!', 'एक्सक्लेमेशन मार्क': '!', 'कोलन': ':', 'अपूर्ण विराम': ':', 'सेमीकोलन': ';', 'अर्धविराम': ';', 'डैश': ' -', 'हाइफ़न': '-', 'योजक चिह्न': '-', 'एपोस्ट्रोफ़ी': "'", 'उद्धरण चिह्न': '"', 'कोट': '"', 'डबल कोट': '"'}
_MARK_ALT = '|'.join((re.escape(k) for k in sorted(MARKS, key=len, reverse=True)))
ORDINALS = {'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5, 'sixth': 6, 'seventh': 7, 'eighth': 8, 'ninth': 9, 'tenth': 10, 'last': -1, '1st': 1, '2nd': 2, '3rd': 3, '4th': 4, '5th': 5, '6th': 6, '7th': 7, '8th': 8, '9th': 9, '10th': 10}
_ORD_ALT = '|'.join((re.escape(k) for k in sorted(ORDINALS, key=len, reverse=True)))
NUMBERS = {'a': 1, 'an': 1, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10}
_NUM_ALT = '|'.join(sorted(NUMBERS, key=len, reverse=True)) + '|\\d+'

def _count(tok) -> int:
    if not tok:
        return 1
    tok = tok.strip().lower()
    return int(tok) if tok.isdigit() else NUMBERS.get(tok, 1)
_INDEX = dict(ORDINALS)
_INDEX.update({k: v for k, v in NUMBERS.items() if k not in ('a', 'an')})
_IDX_ALT = '|'.join((re.escape(k) for k in sorted(_INDEX, key=len, reverse=True))) + '|\\d+'

def _index(tok):
    if not tok:
        return None
    tok = tok.strip().lower()
    return int(tok) if tok.isdigit() else _INDEX.get(tok)
_CHUNK = '(?:paragraph|bullet|block|point|para|line)'
_DEL_VERB = '(?:get\\s+rid\\s+of|take\\s+out|delete|remove|erase|scratch|clear|cut|drop)'
_PREP = '(?:in|on|of|from|at|inside|within)'

def _para_ref(a: str, b: str) -> str:
    return f'(?:(?:the\\s+)?(?P<{a}>{_IDX_ALT})\\s+{_CHUNK}|{_CHUNK}\\s+(?P<{b}>{_IDX_ALT}))'
_ADD = re.compile(f'\\b(?:add|put|insert|place|stick)\\s+(?:(?P<count>{_NUM_ALT})\\s+)?(?:the\\s+)?(?P<mark>{_MARK_ALT})s?\\b\\s*(?P<where>.*)', re.IGNORECASE)
_ADD_REVERSED = re.compile(f'^\\s*(?P<where>(?:after|before)\\s+.+?)\\s*,?\\s*\\b(?:add|put|insert|place|stick)\\s+(?:(?P<count>{_NUM_ALT})\\s+)?(?:the\\s+)?(?P<mark>{_MARK_ALT})s?\\b\\s*$', re.IGNORECASE)
_ADD_BARE = re.compile(f'^\\s*(?:an?\\s+|the\\s+)?(?P<mark>{_MARK_ALT})s?\\s+(?P<where>(?:after|before|at)\\s+.+)$', re.IGNORECASE)
_ADD_ALONE = re.compile(f'^\\s*(?:an?\\s+|the\\s+)?(?:(?P<count>{_NUM_ALT})\\s+)?(?P<mark>{_MARK_ALT})s?\\s*$', re.IGNORECASE)
_DELETE = re.compile(f'\\b{_DEL_VERB}\\s+(?:the\\s+)?(?:(?P<which>{_ORD_ALT})\\s+)?(?P<mark>{_MARK_ALT})s?\\b\\s*(?P<where>.*)', re.IGNORECASE)
_UPPER = 'capitalis\\w*|capitaliz\\w*|upper\\s*case|uppercase|capital'
_LOWER = 'uncapitalis\\w*|uncapitaliz\\w*|lower\\s*case|lowercase|small|uncapital'
_CASE_VERB_FIRST = re.compile(f'\\b(?:{_UPPER}|{_LOWER})\\b\\s*(.*)', re.IGNORECASE)
_CASE_TARGET_FIRST = re.compile(f'\\b(?:chang\\w*|mak\\w*|set)\\s+(.+?)\\s+(?:to\\s+be\\s+|to\\s+|into\\s+|be\\s+)?(?:{_UPPER}|{_LOWER})\\b', re.IGNORECASE)

def _ordinal(tok: str):
    return ORDINALS.get(tok.strip().lower())
_LOC_PARA = re.compile(f'\\b{_PREP}\\s+' + _para_ref('p1', 'p2') + '\\b', re.IGNORECASE)

def _prepare(text: str, spelled=None):
    if spelled is not None:
        return (text, spelled)
    return spelling.expand_spelled(text)

def parse_punctuation(text: str, spelled=None):
    t = text.strip().rstrip(SENTENCE_END).lower()
    if not t:
        return None
    t, spelled = _prepare(t, spelled)
    md = _DELETE.search(t)
    if md:
        return {'op': 'delete', 'mark': MARKS[md.group('mark').lower()], 'which': _ordinal(md.group('which')) if md.group('which') else None, 'loc': _parse_locator(md.group('where'), spelled), '_raw': t}
    mr = _ADD_REVERSED.match(t)
    if mr:
        return {'op': 'add', 'mark': MARKS[mr.group('mark').lower()], 'count': _count(mr.group('count')), 'loc': _parse_locator(mr.group('where'), spelled), '_raw': t}
    m = _ADD.search(t)
    if not m:
        m = _ADD_BARE.match(t)
    if not m:
        ma = _ADD_ALONE.match(t)
        if ma:
            return {'op': 'add', 'mark': MARKS[ma.group('mark').lower()], 'count': _count(ma.group('count')), 'loc': {'type': 'end'}, '_raw': t}
    if not m:
        return None
    return {'op': 'add', 'mark': MARKS[m.group('mark').lower()], 'count': _count(m.groupdict().get('count')), 'loc': _parse_locator(m.group('where'), spelled), '_raw': t}

def _parse_locator(where: str, spelled=()) -> dict:
    original = where.strip().lower()
    where = where.strip().lower()
    where = re.sub('^(?:after|before|at|to|of|in)\\s+', '', where).strip()
    where = re.sub('^the\\s+', '', where).strip()
    if not re.match(f'^(?:{_ORD_ALT})\\s', where):
        where = re.sub('^words?\\s+', '', where).strip()
    directional = bool(re.match('^(?:after|before)\\b', original))
    if directional and where in ('', 'after', 'before', 'the', 'a', 'an', 'word', 'words', 'it'):
        return {'type': 'missing'}
    if where in ('', 'end', 'the end', 'very end'):
        return {'type': 'end'}
    line_no = None
    ml = _LOC_PARA.search(where)
    if ml:
        line_no = _index(ml.group('p1') or ml.group('p2'))
    if line_no is not None:
        where = (where[:ml.start()] + ' ' + where[ml.end():]).strip()
        if where in ('end', 'the end', 'very end'):
            return {'type': 'line', 'line': line_no}
    m = re.search('(\\w+)\\s+letters?(?:\\s+(?:of|in)\\s+(?:the\\s+)?(.+))?', where)
    if m and _ordinal(m.group(1)) is not None:
        loc = {'type': 'letter', 'letter': _ordinal(m.group(1)), 'of': None, 'line': line_no}
        rest = (m.group(2) or '').strip()
        if rest:
            mw = re.search('(\\w+)\\s+word', rest)
            if mw and _ordinal(mw.group(1)) is not None:
                loc['of'] = {'type': 'word', 'word': _ordinal(mw.group(1)), 'sentence': None}
            else:
                loc['of'] = {'type': 'phrase', 'phrase': rest, 'exact': rest in spelled}
        return loc
    ml2 = re.search(f'(\\w+)\\s+{_CHUNK}\\b', where)
    if line_no is None and ml2 and (_ordinal(ml2.group(1)) is not None):
        return {'type': 'line', 'line': _ordinal(ml2.group(1))}
    if line_no is not None and (not where):
        return {'type': 'line', 'line': line_no}
    m = re.search('(\\w+)\\s+word(?:\\s+(?:of|in)\\s+(?:the\\s+)?(\\w+)\\s+sentence)?', where)
    if m and _ordinal(m.group(1)) is not None:
        loc = {'type': 'word', 'word': _ordinal(m.group(1)), 'sentence': None}
        if m.group(2) and _ordinal(m.group(2)) is not None:
            loc['sentence'] = _ordinal(m.group(2))
        return loc
    m = re.search('(\\w+)\\s+sentence', where)
    if m and _ordinal(m.group(1)) is not None:
        return {'type': 'sentence', 'sentence': _ordinal(m.group(1))}
    if where in ('that', 'that word', 'there'):
        return {'type': 'word', 'word': -1, 'sentence': None}
    return {'type': 'phrase', 'phrase': where, 'exact': where in spelled}

def parse_case(text: str, spelled=None):
    t = text.strip().rstrip(SENTENCE_END).lower()
    if not t:
        return None
    t, spelled = _prepare(t, spelled)

    def _is_upper(s: str) -> bool:
        return bool(re.search(_UPPER, s, re.IGNORECASE)) and (not re.search('uncapital|lower\\s*case|lowercase|small', s, re.IGNORECASE))
    m = _CASE_TARGET_FIRST.search(t)
    if m:
        return {'op': 'case', 'upper': _is_upper(t), 'loc': _parse_locator(m.group(1), spelled)}
    m = _CASE_VERB_FIRST.search(t)
    if m:
        return {'op': 'case', 'upper': _is_upper(t), 'loc': _parse_locator(m.group(1), spelled)}
    return None
_TRIM = re.compile(f'\\b{_DEL_VERB}\\s+(?:everything|all|the rest)\\s*(?:(?:in|on)\\s+(?:the\\s+)?(?P<line>\\w+)\\s+{_CHUNK}\\s*)?(?:(?:that\\s+is|which\\s+is)\\s+)?(?P<dir>after|before|from)\\s+(?P<phrase>.+)', re.IGNORECASE)
_TRAIL_LINE = re.compile(f'\\s*\\b(?:in|on)\\s+(?:the\\s+)?(\\w+)\\s+{_CHUNK}\\s*$', re.IGNORECASE)
_DEL_LINE_NO = re.compile(f'\\b{_DEL_VERB}\\s+' + _para_ref('o1', 'o2') + '\\b', re.IGNORECASE)
_DEL_LINE_TEXT = re.compile(f"""\\b{_DEL_VERB}\\s+(?:the\\s+)?{_CHUNK}\\s+(?:that\\s+says\\s+|saying\\s+|reading\\s+)?[\\"']?(.+?)[\\"']?\\s*$""", re.IGNORECASE)
_DEL_WORD = re.compile(f"""\\b{_DEL_VERB}\\s+(?:the\\s+)?(?:(?P<pre>{_IDX_ALT})\\s+)?(?:word\\s+)?[\\"']?(?P<word>.+?)[\\"']?(?:\\s+(?:number\\s+|no\\.?\\s+)?(?P<post>{_IDX_ALT}))?\\s*$""", re.IGNORECASE)
_IDX_TAIL = re.compile(f'^(?P<word>.+?)\\s+(?:number\\s+|no\\.?\\s+)?(?P<idx>{_IDX_ALT})$', re.IGNORECASE)
_IDX_HEAD = re.compile(f'^(?P<idx>{_IDX_ALT})\\s+(?P<word>.+?)$', re.IGNORECASE)

def _split_index(phrase: str):
    for pat in (_IDX_TAIL, _IDX_HEAD):
        m = pat.match(phrase.strip())
        if m:
            n = _index(m.group('idx'))
            if n is not None:
                return (m.group('word').strip(), n)
    return (phrase, None)
_NOT_A_WORD_DELETE = {'everything', 'all', 'that', 'this', 'it', 'the rest', 'last word', 'word', 'line', 'last line', 'last sentence', 'sentence', 'last comma', 'last period'}
_DEL_WORD_AT = re.compile(f'^\\s*{_DEL_VERB}\\s+(?:the\\s+)?(?P<idx>{_IDX_ALT})\\s+word\\b\\s*$', re.IGNORECASE)

def parse_delete(text: str, spelled=None):
    t = text.strip().rstrip(SENTENCE_END).lower()
    if not t:
        return None
    t, spelled = _prepare(t, spelled)
    m = _TRIM.search(t)
    if m:
        direction = 'before' if m.group('dir') == 'before' else 'after'
        phrase = m.group('phrase').strip()
        scope_line = None
        if m.group('line'):
            scope_line = _ordinal(m.group('line')) or -1
        trail = _TRAIL_LINE.search(phrase)
        if trail:
            scope_line = _ordinal(trail.group(1)) or -1
            phrase = phrase[:trail.start()].strip()
        return {'op': 'trim', 'dir': direction, 'phrase': phrase, 'line': scope_line, 'exact': phrase in spelled}
    m = _DEL_LINE_NO.search(t)
    if m:
        line = _index(m.group('o1') or m.group('o2'))
        if line is not None:
            return {'op': 'delline', 'line': line, 'text': None}
    m = _DEL_LINE_TEXT.search(t)
    if m:
        return {'op': 'delline', 'line': None, 'text': m.group(1).strip()}
    m = _DEL_WORD_AT.match(t)
    if m:
        n = _index(m.group('idx'))
        if n is not None:
            return {'op': 'delwordat', 'index': n, '_raw': t}
    m = _DEL_WORD.search(t)
    if m:
        word = m.group('word').strip()
        if word and word not in _NOT_A_WORD_DELETE and (not word.startswith('last ')):
            n = _index(m.group('post'))
            if n is None:
                n = _index(m.group('pre'))
            return {'op': 'delword', 'word': word, 'index': n, '_raw': t}
    return None

def _phrase_end(text: str, phrase: str, exact: bool=False):
    if exact:
        hits = find_matches(text, phrase)
        return hits[0][1] if hits else None
    return _find_phrase_end(text, phrase)
BLOCK_WORDS = 75

def _line_spans(text: str):
    if not text.strip():
        return [(0, len(text))]
    sents = _sentence_spans(text)
    if not sents:
        sents = [(0, len(text))]
    spans, start, words = ([], sents[0][0], 0)
    for a, b in sents:
        n = len(text[a:b].split())
        if words and words + n > BLOCK_WORDS:
            spans.append((start, a))
            start, words = (a, 0)
        words += n
    spans.append((start, len(text)))
    out = []
    for a, b in spans:
        toks = list(re.finditer('\\S+', text[a:b]))
        if len(toks) <= BLOCK_WORDS * 1.5:
            out.append((a, b))
            continue
        for i in range(0, len(toks), BLOCK_WORDS):
            chunk = toks[i:i + BLOCK_WORDS]
            s = a if i == 0 else a + chunk[0].start()
            e = b if i + BLOCK_WORDS >= len(toks) else a + chunk[-1].end()
            out.append((s, e))
    return out

def find_matches(text: str, phrase: str, span=None):
    a, b = span or (0, len(text))
    seg = text[a:b]
    pat = f"\\b{re.escape(phrase)}(?:['â€™]s|s)?\\b"
    return [(a + m.start(), a + m.end()) for m in re.finditer(pat, seg, re.IGNORECASE)]

def word_occurrences(text: str, word: str) -> list[tuple[int, int]]:
    pat = f"\\b{re.escape(word)}(?:['â€™]s|s)?\\b[,.;:!?]*"
    return [(m.start(), m.end()) for m in re.finditer(pat, text, re.IGNORECASE)]

def apply_delete(text: str, cmd: dict):
    op = cmd['op']
    if op == 'trim':
        scope_start, scope_end = (0, len(text))
        if cmd.get('line') is not None:
            spans = _line_spans(text)
            i = cmd['line']
            if i == -1:
                i = len(spans)
            if not 1 <= i <= len(spans):
                return (text, False, f"there is no paragraph {cmd['line']}")
            scope_start, scope_end = spans[i - 1]
        seg = text[scope_start:scope_end]
        end = _phrase_end(seg, cmd['phrase'], cmd.get('exact', False))
        if end is None:
            return (text, False, f"couldn't find {cmd['phrase']!r}")
        if cmd['dir'] == 'after':
            kept = text[:scope_start + end] + text[scope_end:]
        else:
            start = end
            while start > 0 and (not seg[start - 1].isspace()):
                start -= 1
            kept = text[:scope_start] + seg[start:] + text[scope_end:]
        return (kept, True, f"deleted everything {cmd['dir']} {cmd['phrase']!r}")
    if op == 'delline':
        spans = _line_spans(text)
        if cmd['line'] is not None:
            i = cmd['line']
            if i == -1:
                i = len(spans)
            if not 1 <= i <= len(spans):
                return (text, False, f"there is no paragraph {cmd['line']}")
        else:
            want = cmd['text'].lower()
            hits = [k for k, (a, b) in enumerate(spans, start=1) if want in text[a:b].lower()]
            if not hits:
                hits = [k for k, (a, b) in enumerate(spans, start=1) if difflib.SequenceMatcher(None, text[a:b].lower(), want).ratio() > 0.7]
            if not hits:
                return (text, False, f"no line says {cmd['text']!r}")
            i = hits[0]
        a, b = spans[i - 1]
        cut_to = min(len(text), b + 1)
        return (text[:a] + text[cut_to:], True, f'deleted paragraph {i}')
    if op == 'delwordat':
        words = list(re.finditer('\\S+', text))
        if not words:
            return (text, False, 'there is nothing to delete')
        n = cmd['index']
        if n == -1:
            n = len(words)
        if not 1 <= n <= len(words):
            return (text, False, f'there are only {len(words)} words' if len(words) != 1 else 'there is only one word')
        m = words[n - 1]
        a, b = (m.start(), m.end())
        while b < len(text) and text[b] == ' ':
            b += 1
            break
        if b >= len(text) and a > 0 and (text[a - 1] == ' '):
            a -= 1
        gone = m.group()
        return (text[:a] + text[b:], True, f'deleted word {n}: {gone!r}')
    if op == 'delword':
        hits = word_occurrences(text, cmd['word'])
        if not hits:
            return (text, False, f"couldn't find {cmd['word']!r}")
        n = cmd['index']
        if n is None:
            if len(hits) > 1:
                return (text, False, {'choices': hits, 'phrase': cmd['word'], 'command': cmd.get('_raw', f"delete {cmd['word']}"), 'block': 1})
            n = 1
        if n == -1:
            n = len(hits)
        if not 1 <= n <= len(hits):
            return (text, False, f"there are only {len(hits)} of {cmd['word']!r}")
        a, b = hits[n - 1]
        if b < len(text) and text[b] == ' ':
            b += 1
        elif a > 0 and text[a - 1] == ' ':
            a -= 1
        return (text[:a] + text[b:], True, f"deleted {cmd['word']!r}")
    return (text, False, "didn't understand that deletion")
_SCOPE = re.compile(f'^\\s*(?:{_PREP}\\s+)?' + _para_ref('o1', 'o2') + f'\\s*[,.]?\\s*(?:(?:the\\s+)?(?P<word>{_IDX_ALT})\\s+word\\s*[,.]?\\s*)?(?P<rest>.*)$', re.IGNORECASE)
_VERB = 'chang\\w*|replac\\w*|swap\\w*|turn\\w*|mak\\w*|correct\\w*|fix\\w*|set'
_SWAP = re.compile(f'\\b(?:{_VERB})\\s+(?:the\\s+)?(?:({_ORD_ALT})\\s+)?({_MARK_ALT})\\b\\s*(?:(?:to|into|with|for)\\s+)?(?:an?\\s+|the\\s+)?({_MARK_ALT})\\b', re.IGNORECASE)

def parse_swap(text: str):
    m = _SWAP.search(text.strip().rstrip('!?').lower())
    if not m:
        return None
    return {'op': 'swap', 'which': _ordinal(m.group(1)) if m.group(1) else None, 'from': MARKS[m.group(2).lower()], 'to': MARKS[m.group(3).lower()], '_raw': text.strip()}

def mark_occurrences(text: str, mark: str, span=None):
    a, b = span or (0, len(text))
    seg = text[a:b]
    return [(a + i, a + i + len(mark)) for i in range(len(seg)) if seg.startswith(mark, i)]

def apply_swap(text: str, cmd: dict, span=None, command: str='', block=None):
    hits = mark_occurrences(text, cmd['from'], span)
    if not hits:
        return (text, False, f"there is no {cmd['from']!r} there")
    n = cmd['which']
    if n is None:
        if len(hits) > 1:
            return (text, False, {'choices': hits, 'phrase': cmd['from'], 'command': command or text, 'block': block or 1})
        n = 1
    if n == -1:
        n = len(hits)
    if not 1 <= n <= len(hits):
        return (text, False, f'there are only {len(hits)}')
    a, b = hits[n - 1]
    return (text[:a] + cmd['to'] + text[b:], True, f"changed {cmd['from']!r} to {cmd['to']!r}")

def parse_choice(text: str):
    t = text.strip().rstrip(SENTENCE_END).lower()
    t = re.sub('^(?:the\\s+)?', '', t)
    t = re.sub('\\s+one$', '', t).strip()
    if t.isdigit():
        return int(t)
    n = _INDEX.get(t)
    return n if n and n > 0 else None
_SCOPE_SUFFIX = re.compile(f'^(?P<cmd>.+?)[,\\s]+(?:{_PREP}\\s+)?' + _para_ref('o1', 'o2') + '\\s*$', re.IGNORECASE)

def parse_scope(text: str):
    t = text.strip().rstrip(SENTENCE_END)
    m = _SCOPE.match(t)
    if m:
        line = _index(m.group('o1') or m.group('o2'))
        word = _index(m.group('word')) if m.group('word') else None
        if line is not None and (not (m.group('word') and word is None)):
            return ({'line': line, 'word': word}, m.group('rest').strip())
    ms = _SCOPE_SUFFIX.match(t)
    if ms:
        line = _index(ms.group('o1') or ms.group('o2'))
        inner = ms.group('cmd').strip()
        probe = parse_edit(inner) if line is not None else None
        if probe and probe.get('loc', {}).get('type') != 'missing':
            return ({'line': line, 'word': None}, inner)
    return (None, text)

def _para_hint(text: str, li: int) -> str:
    spans = _line_spans(text)
    if not 1 <= li <= len(spans):
        return f'paragraph {li}'
    a, b = spans[li - 1]
    opening = ' '.join(text[a:b].split()[:4])
    return f'paragraph {li} (starts "{opening}")' if opening else f'paragraph {li}'

def _scoped_punct(text: str, a: int, b: int, cmd: dict, command: str, li: int):
    seg = text[a:b]
    if cmd['op'] == 'delete':
        hits = mark_occurrences(text, cmd['mark'], (a, b))
        if not hits:
            return (text, False, f"there is no {cmd['mark']!r} in {_para_hint(text, li)}")
        loc = cmd.get('loc') or {'type': 'end'}
        if loc['type'] == 'missing':
            return (text, False, "I didn't catch what to delete it after")
        if loc['type'] != 'end':
            if loc['type'] == 'phrase':
                anchors = find_matches(text, loc['phrase'], (a, b))
                if not anchors:
                    return (text, False, f"no {loc['phrase']!r} in {_para_hint(text, li)}")
                if len(anchors) > 1:
                    return (text, False, {'choices': anchors, 'phrase': loc['phrase'], 'command': command, 'block': li})
                anchor = anchors[0][1]
            else:
                rel, err = _locate(seg, loc, cmd)
                if err:
                    return (text, False, err)
                anchor = a + rel
            after = [h for h in hits if h[0] >= anchor]
            if not after:
                return (text, False, f"no {cmd['mark']!r} after that")
            x, y = after[0]
        else:
            n = cmd.get('which') or -1
            if n == -1:
                n = len(hits)
            if not 1 <= n <= len(hits):
                return (text, False, f'there are only {len(hits)}')
            x, y = hits[n - 1]
        return (text[:x] + text[y:], True, f"deleted {cmd['mark']!r}")
    loc = cmd['loc']
    if loc['type'] == 'phrase':
        hits = find_matches(text, loc['phrase'], (a, b))
        if len(hits) > 1:
            return (text, False, {'choices': hits, 'phrase': loc['phrase'], 'command': command, 'block': li})
        if not hits:
            return (text, False, f"no {loc['phrase']!r} in {_para_hint(text, li)}")
        pos = hits[0][1]
    else:
        rel, err = _locate(seg, loc, cmd)
        if err:
            return (text, False, err)
        pos = a + rel
    mk = cmd['mark'] * cmd.get('count', 1)
    return (text[:pos] + mk + text[pos:], True, f'added {mk!r}')

def apply_scoped(text: str, scope: dict, command: str):
    command, spelled = _prepare(command)
    spans = _line_spans(text)
    li = scope['line']
    if li == -1:
        li = len(spans)
    if not 1 <= li <= len(spans):
        return (text, False, f"there is no paragraph {scope['line']}")
    a, b = spans[li - 1]
    seg = text[a:b]
    if scope.get('word'):
        wspans = _word_spans(seg)
        wi = scope['word']
        if wi == -1:
            wi = len(wspans)
        if not 1 <= wi <= len(wspans):
            return (text, False, f"there is no word {scope['word']} in paragraph {li}")
        wa, wb = wspans[wi - 1]
        old = seg[wa:wb]
        mc = re.match('(?:change|replace|make|set|correct|fix)\\b(.*)$', command, re.IGNORECASE)
        if mc:
            tail = mc.group(1)
            parts = re.split('\\s+(?:to|with|into)\\s+', tail, flags=re.IGNORECASE)
            new = parts[-1].strip() if len(parts) > 1 else tail.strip()
            named = parts[0].strip() if len(parts) > 1 else ''
            if not new:
                return (text, False, 'what should it change to?')
            keep = re.match("^[\\w'â€™-]+", old)
            trail = old[len(keep.group(0)):] if keep else ''
            note = ''
            if named and difflib.SequenceMatcher(None, named.lower(), (keep.group(0) if keep else old).lower()).ratio() < 0.6:
                note = f' (you said {named!r})'
            return (text[:a] + seg[:wa] + new + trail + seg[wb:] + text[b:], True, f'changed {old!r} to {new!r}{note}')
        if re.match(f'\\s*{_DEL_VERB}\\b', command, re.IGNORECASE):
            ea = wa
            eb = wb + 1 if wb < len(seg) and seg[wb] == ' ' else wb
            if eb == wb and ea > 0 and (seg[ea - 1] == ' '):
                ea -= 1
            return (text[:a] + seg[:ea] + seg[eb:] + text[b:], True, f'deleted {old!r}')
        cased = parse_case(command)
        if cased:
            up = cased['upper']
            new = old[:1].upper() + old[1:] if up else old[:1].lower() + old[1:]
            return (text[:a] + seg[:wa] + new + seg[wb:] + text[b:], True, 'capitalised' if up else 'lowercased')
        return (text, False, f'not something I can do to a word: "{command}"')
    punct = parse_punctuation(command, spelled)
    if punct:
        return _scoped_punct(text, a, b, punct, command, li)
    swap = parse_swap(command)
    if swap:
        return apply_swap(text, swap, (a, b), command=command, block=li)
    named = _named_target(command)
    if named:
        hits = find_matches(text, named, (a, b))
        idx = None
        if not hits:
            stem, n = _split_index(named)
            if n is not None:
                stem_hits = find_matches(text, stem, (a, b))
                if stem_hits:
                    named, hits, idx = (stem, stem_hits, n)
        if not hits:
            return (text, False, f'no {named!r} in {_para_hint(text, li)}')
        if idx is not None:
            if idx == -1:
                idx = len(hits)
            if not 1 <= idx <= len(hits):
                n = len(hits)
                return (text, False, f"there {('is' if n == 1 else 'are')} only {n} of {named!r} in {_para_hint(text, li)}")
            return _apply_at(text, hits[idx - 1], command)
        if len(hits) > 1:
            return (text, False, {'choices': hits, 'phrase': named, 'command': command, 'block': li})
        return _apply_at(text, hits[0], command)
    inner = parse_edit(command, spelled)
    if not inner:
        return (text, False, f'not a command: "{command}"')
    if inner.get('op') == 'add' and inner.get('loc', {}).get('type') == 'phrase':
        hits = find_matches(text, inner['loc']['phrase'], (a, b))
        if len(hits) > 1:
            return (text, False, {'choices': hits, 'phrase': inner['loc']['phrase'], 'command': command, 'block': li})
        if hits:
            pos = hits[0][1]
            mk = inner['mark'] * inner.get('count', 1)
            return (text[:pos] + mk + text[pos:], True, f'added {mk!r}')
        return (text, False, f"no {inner['loc']['phrase']!r} in {_para_hint(text, li)}")
    new_seg, ok, msg = apply_edit(seg, inner)
    if not ok:
        return (text, False, msg)
    return (text[:a] + new_seg + text[b:], True, msg)

def apply_spelled(text: str, command: str):
    expanded, spelled = spelling.expand_spelled(command)
    if not spelled:
        return None
    named = _named_target(expanded)
    if not named or named.lower() not in spelled:
        return None
    word = named.lower()
    hits = find_matches(text, word)
    if not hits:
        return (text, False, f"couldn't find {word!r} spelled that way")
    if len(hits) > 1:
        return (text, False, {'choices': hits, 'phrase': word, 'command': expanded, 'block': 1})
    return _apply_at(text, hits[0], expanded)

def _named_target(command: str):
    m = re.match(f'\\s*(?:{_VERB})\\s+(.+?)\\s+(?:to|with|into)\\s+.+$', command, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    m = re.match(f'\\s*{_DEL_VERB}\\s+(?:the\\s+)?(?:word\\s+)?(.+?)\\s*$', command, re.IGNORECASE)
    if m:
        target = m.group(1).strip()
        if target in _NOT_A_WORD_DELETE or re.match(f'^(?:{_MARK_ALT})\\b', target, re.I):
            return None
        return target
    m = re.match(f'\\s*(?:{_UPPER}|{_LOWER})\\s+(.+?)\\s*$', command, re.IGNORECASE)
    if m:
        return m.group(1).strip()
    return None

def _apply_at(text: str, span: tuple, command: str):
    a, b = span
    old = text[a:b]
    swap = parse_swap(command)
    if swap:
        return (text[:a] + swap['to'] + text[b:], True, f"changed {swap['from']!r} to {swap['to']!r}")
    punct = parse_punctuation(command)
    if punct and punct['op'] == 'add':
        mk = punct['mark'] * punct.get('count', 1)
        return (text[:b] + mk + text[b:], True, f'added {mk!r}')
    m = re.match(f'\\s*(?:{_VERB})\\s+.+?\\s+(?:to|with|into)\\s+(.+)$', command, re.IGNORECASE)
    if m:
        new = m.group(1).strip()
        return (text[:a] + new + text[b:], True, f'changed {old!r} to {new!r}')
    if re.match(f'\\s*{_DEL_VERB}\\b', command, re.IGNORECASE):
        ea, eb = (a, b)
        if eb < len(text) and text[eb] == ' ':
            eb += 1
        elif ea > 0 and text[ea - 1] == ' ':
            ea -= 1
        return (text[:ea] + text[eb:], True, f'deleted {old!r}')
    cased = parse_case(command)
    if cased:
        up = cased['upper']
        new = old[:1].upper() + old[1:] if up else old[:1].lower() + old[1:]
        return (text[:a] + new + text[b:], True, 'capitalised' if up else 'lowercased')
    return (text, False, f'not something I can do: "{command}"')

def parse_edit(text: str, spelled=None):
    text, spelled = _prepare(text, spelled)
    return parse_space(text) or parse_punctuation(text, spelled) or parse_delete(text, spelled) or parse_swap(text) or parse_case(text, spelled)

def apply_edit(text: str, cmd: dict):
    op = cmd.get('op')
    if op == 'swap':
        return apply_swap(text, cmd, command=cmd.get('_raw', ''))
    if op == 'case':
        return apply_case(text, cmd)
    if op == 'addspace':
        return apply_space(text, cmd)
    if op in ('trim', 'delline', 'delword', 'delwordat'):
        return apply_delete(text, cmd)
    return apply_punctuation(text, cmd)
_ADD_SPACE_BETWEEN = re.compile('^\\s*(?:put|add|insert|leave)\\s+(?:a\\s+|the\\s+)?spaces?\\s+(?:in\\s+)?between\\s+(?P<left>.+?)\\s+and\\s+(?P<right>.+?)\\s*$', re.IGNORECASE)
_SPLIT = re.compile('^\\s*(?:split|separate|break)\\s+(?:up\\s+)?(?:the\\s+word\\s+)?(?P<left>.+?)(?:\\s+and\\s+(?P<right>.+?))?\\s*$', re.IGNORECASE)
_ADD_SPACE_AFTER = re.compile('^\\s*(?:put|add|insert)\\s+(?:a\\s+|the\\s+)?spaces?\\s+(?P<dir>after|before)\\s+(?P<word>.+?)\\s*$', re.IGNORECASE)

def parse_space(text: str):
    t = text.strip().rstrip(SENTENCE_END)
    if not t:
        return None
    m = _ADD_SPACE_BETWEEN.match(t) or _SPLIT.match(t)
    if m:
        left = (m.group('left') or '').strip()
        right = (m.groupdict().get('right') or '').strip()
        if left:
            return {'op': 'addspace', 'left': left, 'right': right or None, 'dir': None, '_raw': t}
    m = _ADD_SPACE_AFTER.match(t)
    if m:
        return {'op': 'addspace', 'left': m.group('word').strip(), 'right': None, 'dir': m.group('dir').lower(), '_raw': t}
    return None

def apply_space(text: str, cmd: dict):
    left = (cmd.get('left') or '').strip()
    right = (cmd.get('right') or '').strip()
    if not left:
        return (text, False, 'say which words to separate')
    if right:
        joined = re.escape(left) + re.escape(right)
        hits = list(re.finditer(f'(?<!\\w){joined}(?!\\w)', text, re.IGNORECASE))
        if not hits:
            if re.search(f'(?<!\\w){re.escape(left)}\\s+{re.escape(right)}(?!\\w)', text, re.IGNORECASE):
                return (text, False, f'{left!r} and {right!r} already have a space')
            return (text, False, f"couldn't find {left + right!r} joined together")
        if len(hits) > 1:
            return (text, False, {'choices': [(h.start(), h.end()) for h in hits], 'phrase': left + right, 'command': cmd.get('_raw', ''), 'block': 1})
        h = hits[0]
        cut = h.start() + len(left)
        return (text[:cut] + ' ' + text[cut:], True, f'split {left!r} and {right!r}')
    pat = f'(?<!\\w)({re.escape(left)})(\\w+)' if cmd.get('dir') != 'before' else f'(?<!\\w)(\\w+?)({re.escape(left)})(?!\\w)'
    hits = list(re.finditer(pat, text, re.IGNORECASE))
    if not hits:
        return (text, False, f"couldn't find a word joined onto {left!r}")
    if len(hits) > 1:
        return (text, False, {'choices': [(h.start(), h.end()) for h in hits], 'phrase': hits[0].group(0), 'command': cmd.get('_raw', ''), 'block': 1})
    h = hits[0]
    cut = h.start() + len(h.group(1))
    return (text[:cut] + ' ' + text[cut:], True, f'put a space after {left!r}')

def _letter_positions(text: str, loc: dict) -> list[int]:
    scope_start, scope_end = (0, len(text))
    if loc.get('line') is not None:
        spans = _line_spans(text)
        i = loc['line']
        if i == -1:
            i = len(spans)
        if not 1 <= i <= len(spans):
            return []
        scope_start, scope_end = spans[i - 1]
    of = loc.get('of')
    if of:
        seg, base = (text[scope_start:scope_end], scope_start)
        if of['type'] == 'word':
            spans = _word_spans(seg)
            i = of['word']
            if i == -1:
                i = len(spans)
            if not 1 <= i <= len(spans):
                return []
            a, b = spans[i - 1]
            scope_start, scope_end = (base + a, base + b)
        else:
            end = _phrase_end(seg, of['phrase'], of.get('exact', False))
            if end is None:
                return []
            start = end
            while start > 0 and (not seg[start - 1].isspace()):
                start -= 1
            scope_start, scope_end = (base + start, base + end)
    letters = [i for i in range(scope_start, scope_end) if text[i].isalpha()]
    n = loc['letter']
    if n == -1:
        n = len(letters)
    if not 1 <= n <= len(letters):
        return []
    return [letters[n - 1]]

def apply_case(text: str, cmd: dict):
    loc = cmd['loc']
    up = cmd['upper']
    if loc['type'] == 'letter':
        idx = _letter_positions(text, loc)
        if not idx:
            return (text, False, 'that letter is not there')
        i = idx[0]
        ch = text[i].upper() if up else text[i].lower()
        return (text[:i] + ch + text[i + 1:], True, 'capitalised' if up else 'lowercased')
    if loc['type'] == 'word':
        spans = _word_spans(text)
        if loc.get('sentence'):
            ss = _sentence_spans(text)
            si = loc['sentence'] - 1
            if not 0 <= si < len(ss):
                return (text, False, f"there is no sentence {loc['sentence']}")
            s0, s1 = ss[si]
            spans = [(a, b) for a, b in spans if a >= s0 and b <= s1]
        i = loc['word']
        if i == -1:
            i = len(spans)
        if not 1 <= i <= len(spans):
            return (text, False, 'that word is not there')
        a, b = spans[i - 1]
    elif loc['type'] == 'phrase':
        end = _phrase_end(text, loc['phrase'], loc.get('exact', False))
        if end is None:
            return (text, False, f"couldn't find {loc['phrase']!r}")
        a = end
        while a > 0 and (not text[a - 1].isspace()):
            a -= 1
        b = end
    else:
        return (text, False, "didn't understand what to change")
    seg = text[a:b]
    new = seg[:1].upper() + seg[1:] if up else seg[:1].lower() + seg[1:]
    return (text[:a] + new + text[b:], True, 'capitalised' if up else 'lowercased')

def _word_spans(text: str):
    return [(mo.start(), mo.end()) for mo in re.finditer('\\S+', text)]

def _sentence_spans(text: str):
    spans, start = ([], 0)
    for mo in re.finditer('[.!?]+(?:\\s+|$)', text):
        spans.append((start, mo.end()))
        start = mo.end()
    if start < len(text.rstrip()) + 1 and text[start:].strip():
        spans.append((start, len(text)))
    return spans

def _insert_at(text: str, pos: int, mark: str) -> str:
    return text[:pos] + mark + text[pos:]

def _find_phrase_end(text: str, phrase: str):
    idx = text.lower().find(phrase.lower())
    if idx >= 0:
        return idx + len(phrase)
    words = _word_spans(text)
    n = max(1, len(phrase.split()))
    best = (0.0, None)
    for size in {max(1, n - 1), n, n + 1}:
        for i in range(len(words) - size + 1):
            a, b = (words[i][0], words[i + size - 1][1])
            r = difflib.SequenceMatcher(None, text[a:b].lower(), phrase.lower()).ratio()
            if r > best[0]:
                best = (r, b)
    return best[1] if best[0] >= 0.6 else None

def _locate(text: str, loc: dict, cmd: dict):
    t = loc['type']
    if t == 'missing':
        return (None, "I didn't catch what to put it after")
    if t == 'end':
        return (len(text.rstrip()), None)
    if t == 'phrase':
        hits = find_matches(text, loc['phrase'])
        if len(hits) > 1:
            return (None, {'choices': hits, 'phrase': loc['phrase'], 'command': cmd.get('_raw', ''), 'block': 1})
        if hits:
            return (hits[0][1], None)
        if loc.get('exact'):
            return (None, f"couldn't find {loc['phrase']!r} spelled that way")
        if len(loc['phrase']) <= 3:
            return (None, f"couldn't find {loc['phrase']!r}")
        pos = _find_phrase_end(text, loc['phrase'])
        if pos is None:
            return (None, f"couldn't find {loc['phrase']!r}")
        return (pos, None)
    if t == 'word':
        spans = _word_spans(text)
        if loc.get('sentence'):
            ss = _sentence_spans(text)
            si = loc['sentence'] - 1
            if not 0 <= si < len(ss):
                return (None, f"there is no sentence {loc['sentence']}")
            s0, s1 = ss[si]
            spans = [(a, b) for a, b in spans if a >= s0 and b <= s1]
        wi = loc['word']
        if wi == -1:
            wi = len(spans)
        if not 1 <= wi <= len(spans):
            return (None, 'that word is not there')
        return (spans[wi - 1][1], None)
    if t == 'letter':
        idx = _letter_positions(text, loc)
        if not idx:
            return (None, 'that letter is not there')
        return (idx[0] + 1, None)
    if t == 'line':
        spans = _line_spans(text)
        i = loc['line']
        if i == -1:
            i = len(spans)
        if not 1 <= i <= len(spans):
            return (None, f"there is no paragraph {loc['line']}")
        a, b = spans[i - 1]
        return (a + len(text[a:b].rstrip()), None)
    if t == 'sentence':
        ss = _sentence_spans(text)
        si = loc['sentence']
        if si == -1:
            si = len(ss)
        if not 1 <= si <= len(ss):
            return (None, f"there is no sentence {loc['sentence']}")
        s0, s1 = ss[si - 1]
        return (s0 + len(text[s0:s1].rstrip()), None)
    return (None, "didn't understand where")

def apply_punctuation(text: str, cmd: dict):
    if cmd['op'] == 'delete':
        mark = cmd['mark']
        loc = cmd.get('loc') or {'type': 'end'}
        hits = mark_occurrences(text, mark)
        if not hits:
            return (text, False, f'there is no {mark!r} to delete')
        if loc['type'] == 'missing':
            return (text, False, "I didn't catch what to delete it after")
        if loc['type'] != 'end':
            anchor, err = _locate(text, loc, cmd)
            if err:
                return (text, False, err)
            after = [h for h in hits if h[0] >= anchor]
            if not after:
                return (text, False, f'no {mark!r} after that')
            a, b = after[0]
        else:
            n = cmd.get('which') or -1
            if n == -1:
                n = len(hits)
            if not 1 <= n <= len(hits):
                return (text, False, f'there are only {len(hits)}')
            a, b = hits[n - 1]
        return (text[:a] + text[b:], True, f'deleted {mark!r}')
    mark = cmd['mark'] * cmd.get('count', 1)
    pos, err = _locate(text, cmd['loc'], cmd)
    if err:
        return (text, False, err)
    return (_insert_at(text, pos, mark), True, f'added {mark!r}')
