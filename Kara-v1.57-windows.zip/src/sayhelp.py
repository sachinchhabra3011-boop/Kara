from __future__ import annotations
_SHOW = {'delete_word': ('Take back the last word', 'delete that'), 'delete_sentence': ('Take back the last sentence', 'delete last sentence'), 'delete_line': ('Take back the last line', 'delete last line'), 'clear': ('Start the page again', 'start over'), 'new_line': ('Start a new line', 'new line'), 'press_enter': ('Press Enter', 'press enter'), 'backspace': ('Rub out one letter', 'press backspace'), 'tab': ('Press Tab', 'press tab'), 'space': ('Add a space', 'press space'), 'select_last': ('Select the last word', 'select last word'), 'undo': ('Undo', 'undo'), 'redo': ('Do it again', 'redo'), 'capitalize': ('Make it a capital', 'capitalize that'), 'read': ('Read it back to me', 'read it back'), 'word_count': ('How long is it?', 'how many words'), 'spell': ('Spell a word out', 'spell mode'), 'send': ('Send it where it goes', 'send it'), 'exit': ('Stop listening', 'stop')}
_PATTERNS = [('Change a word', 'change hope to faith'), ('Change one of several', 'change the second hope to faith'), ('Say it the other way round', 'instead of hope say faith'), ('Spell out what you mean', 'change hope to spelling f a i t h'), ('Work on one paragraph', 'in the last paragraph change hope to faith'), ('Add a word next to another', 'add high after school'), ('…or before it', 'put big before school'), ('Say which one, if there are several', 'add high after school line 4')]

def _one_line(phrases) -> str:
    usable = [p for p in phrases if len(p.split()) >= 2] or list(phrases)
    return min(usable, key=len)

def _example_for(key: str, language: str | None, fallback: str) -> str:
    import editing
    code = (language or 'en').strip().lower().split('-')[0]
    table = editing.COMMAND_TABLES.get(code)
    if not table or key not in table or (not table[key]):
        return fallback
    return _one_line(table[key])

def sections(speaker: str | None=None, language: str | None=None) -> list[tuple[str, list[tuple[str, str]]]]:
    import editing
    out: list[tuple[str, list[tuple[str, str]]]] = []
    rows = []
    for key, (what, say) in _SHOW.items():
        if key in editing.COMMANDS:
            rows.append((what, _example_for(key, language, say)))
    out.append(('Editing what you wrote', rows))
    out.append(('Changing a word', list(_PATTERNS)))
    try:
        import punctuation
        import usercommands
        want = usercommands.DEVANAGARI if (language or 'en').lower().startswith('hi') else usercommands.LATIN
        by_mark: dict[str, list[str]] = {}
        for name, mark in punctuation.MARKS.items():
            by_mark.setdefault(mark, []).append(name)
        marks = []
        for mark, names in by_mark.items():
            if want == usercommands.LATIN and usercommands.script_of(mark) == usercommands.DEVANAGARI:
                continue
            preferred = [n for n in names if usercommands.script_of(n) == want] or names
            marks.append((f'Type  {mark}', preferred[0]))
        out.append(('Punctuation', marks))
    except Exception:
        pass
    if speaker:
        try:
            import usercommands
            mine = usercommands.load(speaker)
            rows = []
            for entry in mine.get('commands') or []:
                phrase = str(entry.get('phrase') or '').strip()
                if not phrase:
                    continue
                action = entry.get('action') or {}
                if action.get('kind') == 'insert':
                    what = f"Type “{str(action.get('text', ''))[:28]}”"
                else:
                    what = f"Same as “{action.get('command', '')}”"
                rows.append((what, phrase))
            if rows:
                out.append(('Phrases you added', rows))
        except Exception:
            pass
    return out

def flat(speaker: str | None=None) -> list[tuple[str, str, str]]:
    return [(title, what, say) for title, rows in sections(speaker) for what, say in rows]

def search(term: str, speaker: str | None=None) -> list[tuple[str, str, str]]:
    t = (term or '').strip().lower()
    if not t:
        return flat(speaker)
    return [r for r in flat(speaker) if t in r[1].lower() or t in r[2].lower()]
