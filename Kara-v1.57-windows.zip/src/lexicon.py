from __future__ import annotations
_PRODUCTIVE = [('ization', 'isation'), ('izations', 'isations'), ('ize', 'ise'), ('izes', 'ises'), ('ized', 'ised'), ('izing', 'ising'), ('izer', 'iser'), ('izers', 'isers'), ('yze', 'yse'), ('yzes', 'yses'), ('yzed', 'ysed'), ('yzing', 'ysing')]
_INFLECT = ('', 's', 'ed', 'ing', 'er', 'ers', 'ful', 'fully', 'less', 'ist', 'ists', 'ism', 'ly', 'able')
_EXACT = ('', 's')
_CLOSED: tuple[tuple[str, str, tuple], ...] = (('color', 'colour', _INFLECT), ('honor', 'honour', _INFLECT), ('favor', 'favour', _INFLECT), ('flavor', 'flavour', _INFLECT), ('humor', 'humour', _INFLECT), ('rumor', 'rumour', _INFLECT), ('labor', 'labour', _INFLECT), ('harbor', 'harbour', _INFLECT), ('neighbor', 'neighbour', _INFLECT), ('behavior', 'behaviour', _INFLECT), ('endeavor', 'endeavour', _INFLECT), ('armor', 'armour', _INFLECT), ('vapor', 'vapour', _INFLECT), ('odor', 'odour', _INFLECT), ('vigor', 'vigour', _EXACT), ('splendor', 'splendour', _EXACT), ('savior', 'saviour', _EXACT), ('parlor', 'parlour', _EXACT), ('valor', 'valour', _EXACT), ('candor', 'candour', _EXACT), ('clamor', 'clamour', _INFLECT), ('rigor', 'rigour', _EXACT), ('ardor', 'ardour', _EXACT), ('fervor', 'fervour', _EXACT), ('demeanor', 'demeanour', _EXACT), ('misdemeanor', 'misdemeanour', _EXACT), ('favorite', 'favourite', _EXACT), ('favoritism', 'favouritism', _EXACT), ('colorful', 'colourful', _EXACT), ('colorless', 'colourless', _EXACT), ('watercolor', 'watercolour', _EXACT), ('discolor', 'discolour', _INFLECT), ('honorable', 'honourable', _EXACT), ('honorary', 'honourary', _EXACT), ('center', 'centre', _INFLECT), ('theater', 'theatre', _EXACT), ('liter', 'litre', _EXACT), ('meter', 'metre', _EXACT), ('kilometer', 'kilometre', _EXACT), ('centimeter', 'centimetre', _EXACT), ('millimeter', 'millimetre', _EXACT), ('micrometer', 'micrometre', _EXACT), ('fiber', 'fibre', _EXACT), ('somber', 'sombre', _EXACT), ('caliber', 'calibre', _EXACT), ('luster', 'lustre', _EXACT), ('specter', 'spectre', _EXACT), ('scepter', 'sceptre', _EXACT), ('maneuver', 'manoeuvre', _INFLECT), ('saltpeter', 'saltpetre', _EXACT), ('epicenter', 'epicentre', _EXACT), ('reconnoiter', 'reconnoitre', _EXACT), ('defense', 'defence', _EXACT), ('offense', 'offence', _EXACT), ('pretense', 'pretence', _EXACT), ('license', 'licence', _EXACT), ('practice', 'practise', _INFLECT), ('defenseless', 'defenceless', _EXACT), ('catalog', 'catalogue', _INFLECT), ('dialog', 'dialogue', _INFLECT), ('analog', 'analogue', _EXACT), ('monolog', 'monologue', _EXACT), ('epilog', 'epilogue', _EXACT), ('prolog', 'prologue', _EXACT), ('travelog', 'travelogue', _EXACT), ('demagog', 'demagogue', _EXACT), ('esthetic', 'aesthetic', _INFLECT), ('anesthetic', 'anaesthetic', _INFLECT), ('anesthesia', 'anaesthesia', _EXACT), ('anemia', 'anaemia', _EXACT), ('anemic', 'anaemic', _EXACT), ('archeology', 'archaeology', _EXACT), ('archeological', 'archaeological', _EXACT), ('diarrhea', 'diarrhoea', _EXACT), ('encyclopedia', 'encyclopaedia', _EXACT), ('fetal', 'foetal', _EXACT), ('fetus', 'foetus', _EXACT), ('gynecology', 'gynaecology', _EXACT), ('hemoglobin', 'haemoglobin', _EXACT), ('hemorrhage', 'haemorrhage', _INFLECT), ('leukemia', 'leukaemia', _EXACT), ('esophagus', 'oesophagus', _EXACT), ('estrogen', 'oestrogen', _EXACT), ('pediatric', 'paediatric', _EXACT), ('pediatrics', 'paediatrics', _EXACT), ('pediatrician', 'paediatrician', _EXACT), ('paleontology', 'palaeontology', _EXACT), ('orthopedic', 'orthopaedic', _EXACT), ('celiac', 'coeliac', _EXACT), ('edema', 'oedema', _EXACT), ('hemorrhoid', 'haemorrhoid', _EXACT), ('septicemia', 'septicaemia', _EXACT), ('traveler', 'traveller', _EXACT), ('canceled', 'cancelled', _EXACT), ('canceling', 'cancelling', _EXACT), ('cancelation', 'cancellation', _EXACT), ('counselor', 'counsellor', _EXACT), ('counseled', 'counselled', _EXACT), ('counseling', 'counselling', _EXACT), ('labeled', 'labelled', _EXACT), ('labeling', 'labelling', _EXACT), ('modeled', 'modelled', _EXACT), ('modeling', 'modelling', _EXACT), ('signaled', 'signalled', _EXACT), ('signaling', 'signalling', _EXACT), ('totaled', 'totalled', _EXACT), ('fueled', 'fuelled', _EXACT), ('fueling', 'fuelling', _EXACT), ('marvelous', 'marvellous', _EXACT), ('jewelry', 'jewellery', _EXACT), ('jeweler', 'jeweller', _EXACT), ('woolen', 'woollen', _EXACT), ('enroll', 'enrol', _EXACT), ('enrollment', 'enrolment', _EXACT), ('fulfill', 'fulfil', _EXACT), ('fulfillment', 'fulfilment', _EXACT), ('installment', 'instalment', _EXACT), ('skillful', 'skilful', _EXACT), ('willful', 'wilful', _EXACT), ('appall', 'appal', _EXACT), ('distill', 'distil', _EXACT), ('instill', 'instil', _EXACT), ('enthrall', 'enthral', _EXACT), ('program', 'programme', _EXACT), ('gray', 'grey', _INFLECT), ('check', 'cheque', _EXACT), ('curb', 'kerb', _EXACT), ('tire', 'tyre', _EXACT), ('plow', 'plough', _INFLECT), ('draft', 'draught', _EXACT), ('mold', 'mould', _INFLECT), ('smolder', 'smoulder', _INFLECT), ('story', 'storey', _EXACT), ('cozy', 'cosy', _EXACT), ('pajamas', 'pyjamas', _EXACT), ('whiskey', 'whisky', _EXACT), ('annex', 'annexe', _EXACT), ('ax', 'axe', _EXACT), ('donut', 'doughnut', _EXACT), ('aluminum', 'aluminium', _EXACT), ('sulfur', 'sulphur', _EXACT), ('mustache', 'moustache', _EXACT), ('aging', 'ageing', _EXACT), ('judgment', 'judgement', _EXACT), ('acknowledgment', 'acknowledgement', _EXACT), ('tidbit', 'titbit', _EXACT), ('airplane', 'aeroplane', _EXACT), ('mom', 'mum', _EXACT), ('math', 'maths', _EXACT), ('licorice', 'liquorice', _EXACT), ('gonna', 'gonna', _EXACT))
EXTRA_WORDS = {'app', 'apps', 'bot', 'bots', 'wifi', 'usb', 'logout', 'login', 'screenshot', 'screenshots', 'smartphone', 'smartphones', 'selfie', 'selfies', 'emoji', 'emojis', 'hashtag', 'hashtags', 'playlist', 'playlists', 'podcast', 'podcasts', 'texting', 'texted', 'googling', 'googled', 'clickbait', 'influencer', 'influencers', 'powerbank', 'voicemail', 'autocorrect', 'touchscreen', 'webcam', 'webcams', 'smartwatch', 'livestream', 'unfollow', 'unsubscribe', 'reboot', 'wearable', 'wearables', 'chatbot', 'chatbots', 'dataset', 'datasets', 'username', 'usernames', 'offline', 'online', 'covid', 'lockdown', 'lockdowns', 'telehealth', 'upcycle', 'upcycled', 'whatsapp', 'spotify', 'uber', 'youtube', 'instagram', 'podcasting', 'biryani', 'paneer', 'roti', 'rotis', 'dosa', 'dosas', 'chapati', 'chapatis', 'samosa', 'samosas', 'idli', 'dal', 'chai', 'masala', 'namaste', 'rangoli', 'kurta', 'auto', 'tiffin', 'lakh', 'lakhs', 'crore', 'crores', 'rupee', 'rupees', 'jugaad', 'wallah', 'dysarthria', 'dysarthric', 'carer', 'carers', 'caregiver', 'caregivers', 'wheelchairs', 'physio', 'neurodiverse', 'neurodiversity', 'nonverbal', 'assistive', 'accessibility'}
_AE_OE: tuple[tuple[str, str, str], ...] = (('emia', 'aemia', '$'), ('hemo', 'haemo', '^'), ('hema', 'haema', '^'), ('estro', 'oestro', '^'), ('esoph', 'oesoph', '^'), ('paleo', 'palaeo', '^'), ('archeo', 'archaeo', '^'), ('gynec', 'gynaec', '^'), ('esthet', 'aesthet', '^'), ('anesthe', 'anaesthe', ''), ('orthoped', 'orthopaed', ''), ('diarrhe', 'diarrhoe', ''), ('pedia', 'paedia', '$'), ('pedic', 'paedic', '$'), ('edema', 'oedema', '$'))
_AE_OE_STOP = {'academia', 'bohemia', 'premia'}

def _rewrite(word: str, am: str, br: str, where: str) -> str | None:
    if word in _AE_OE_STOP:
        return None
    if where == '^':
        return br + word[len(am):] if word.startswith(am) else None
    if where == '$':
        return word[:-len(am)] + br if word.endswith(am) else None
    return word.replace(am, br) if am in word else None

def _affix(base: str, suffix: str) -> str:
    if suffix and base.endswith('e') and (suffix[0] in 'aeiouy'):
        return base[:-1] + suffix
    return base + suffix

def british_forms(dictionary) -> dict:
    out: dict[str, int] = {}
    for am_suffix, br_suffix in _PRODUCTIVE:
        n = len(am_suffix)
        for word, freq in dictionary.items():
            if len(word) > n + 2 and word.endswith(am_suffix):
                british = word[:-n] + br_suffix
                if british not in dictionary:
                    out[british] = max(out.get(british, 0), freq)
    for am, br, suffixes in _CLOSED:
        for suf in suffixes:
            am_form, br_form = (_affix(am, suf), _affix(br, suf))
            freq = dictionary.get(am_form)
            if freq is None or br_form in dictionary:
                continue
            out[br_form] = max(out.get(br_form, 0), freq)
    starts = [(a, b, len(a)) for a, b, w in _AE_OE if w == '^']
    ends = [(a, b, len(a)) for a, b, w in _AE_OE if w == '$']
    anys = [(a, b) for a, b, w in _AE_OE if w == '']
    for word, freq in dictionary.items():
        if len(word) < 6 or word in _AE_OE_STOP:
            continue
        for am, br, n in starts:
            if word.startswith(am):
                british = br + word[n:]
                if british not in dictionary:
                    out[british] = max(out.get(british, 0), freq)
        for am, br, n in ends:
            if word.endswith(am):
                british = word[:-n] + br
                if british not in dictionary:
                    out[british] = max(out.get(british, 0), freq)
        for am, br in anys:
            if am in word:
                british = word.replace(am, br)
                if british not in dictionary:
                    out[british] = max(out.get(british, 0), freq)
    return out
_PREFIXES = ('neuro', 'psycho', 'socio', 'bio', 'eco', 'geo', 'thermo', 'electro', 'hydro', 'aero', 'agro', 'astro', 'cardio', 'chemo', 'cyber', 'ethno', 'photo', 'physio', 'techno', 'telecom', 'tele', 'video', 'audio', 'micro', 'macro', 'mega', 'nano', 'mini', 'multi', 'mono', 'poly', 'semi', 'hyper', 'hypo', 'super', 'supra', 'sub', 'infra', 'ultra', 'over', 'under', 'counter', 'anti', 'pre', 'post', 're', 'un', 'non', 'de', 'dis', 'mis', 'mal', 'co', 'ex', 'self', 'inter', 'intra', 'trans', 'cross', 'meta', 'neo', 'proto', 'pseudo', 'quasi', 'retro', 'auto', 'homo', 'hetero', 'omni', 'uni', 'tri', 'quad', 'peri', 'para', 'epi', 'endo', 'exo', 'fore', 'kilo', 'milli', 'centi', 'archaeo', 'archeo', 'palaeo', 'paleo', 'biblio', 'phyto', 'deoxy', 'anthropo', 'bacterio', 'cerebro', 'chrono', 'cosmo', 'cyto', 'dendro', 'dermato', 'embryo', 'entomo', 'epidemio', 'gastro', 'glyco', 'gluco', 'gyno', 'haemo', 'hemo', 'helio', 'hepato', 'histo', 'hypno', 'immuno', 'lipo', 'litho', 'magneto', 'meteoro', 'morpho', 'myco', 'myo', 'necro', 'nephro', 'oceano', 'oligo', 'onco', 'onto', 'ophthalmo', 'organo', 'ortho', 'osteo', 'ornitho', 'patho', 'petro', 'phago', 'pheno', 'philo', 'phono', 'phospho', 'pneumo', 'pulmo', 'pyro', 'radio', 'reno', 'rhino', 'ribo', 'sarco', 'schizo', 'sclero', 'seismo', 'sero', 'somato', 'sono', 'spectro', 'stereo', 'strato', 'thrombo', 'topo', 'toxico', 'tracheo', 'tricho', 'tropo', 'turbo', 'uro', 'vaso', 'vermi', 'viro', 'visco', 'xeno', 'xero', 'xylo', 'zoo', 'zygo')
_SUFFIXES = ('lessness', 'fulness', 'fully', 'ness', 'less', 'ful', 'able', 'ably', 'ability', 'ible', 'ment', 'ments', 'ship', 'hood', 'wise', 'like', 'wards', 'ward', 'ish', 'ism', 'ist', 'ists', 'ity', 'ly', 'proof', 'worthy', 'maker', 'makers', 'ization', 'isation', 'izations', 'isations', 'izability', 'isability', 'aemia', 'emia')
_STEM_REPAIR = {'ability': ('', 'e'), 'ibility': ('', 'e'), 'ization': ('', 'e'), 'isation': ('', 'e'), 'izations': ('', 'e'), 'isations': ('', 'e'), 'ity': ('', 'y', 'e'), 'ist': ('', 'y'), 'ists': ('', 'y'), 'ism': ('', 'y'), 'able': ('', 'e'), 'ably': ('', 'e')}
MIN_WORD = 7
MIN_STEM = 4
MIN_PLURAL_STEM = 6
MAX_DEPTH = 2

def _bad_plural(stem: str) -> bool:
    if stem.endswith(('s', 'x', 'z', 'ch', 'sh')):
        return True
    if len(stem) >= 2 and stem[-1] == 'o' and (stem[-2] not in 'aeiou'):
        return True
    return False

def _misspelling_shape(stem: str, suffix: str, known) -> bool:
    if suffix == 'ly' and stem.endswith('ic'):
        return True
    if suffix == 'ity' and stem.endswith('ous'):
        return True
    if suffix == 'ment' and stem.endswith('ue'):
        return True
    if suffix in ('able', 'ably', 'ability') and known(stem + 'e'):
        return True
    return False

def derived(word: str, known, depth: int=MAX_DEPTH, prefixes_only: bool=False) -> str | None:
    w = (word or '').lower().strip("'’")
    if depth <= 0 or len(w) < MIN_WORD:
        return None
    if '-' in w:
        parts = [p for p in w.split('-') if p]
        if len(parts) >= 2 and all((known(p) or derived(p, known, depth - 1) for p in parts)):
            return ' - '.join(parts)
        return None
    for pre in _PREFIXES:
        if not w.startswith(pre):
            continue
        rest = w[len(pre):]
        if len(rest) < MIN_STEM:
            continue
        if known(rest):
            return f'{pre} + {rest}'
        deeper = derived(rest, known, depth - 1, prefixes_only)
        if deeper:
            return f'{pre} + ({deeper})'
    if prefixes_only:
        return None
    if w.endswith('s') and (not w.endswith('ss')):
        stem = w[:-1]
        if len(stem) >= MIN_PLURAL_STEM and known(stem) and (not _bad_plural(stem)):
            return f'{stem} + s'
    for suf in _SUFFIXES:
        if not w.endswith(suf):
            continue
        stem = w[:-len(suf)]
        if len(stem) < MIN_STEM or _misspelling_shape(stem, suf, known):
            continue
        for repair in _STEM_REPAIR.get(suf, ('',)):
            fixed = stem + repair
            if known(fixed):
                return f'{fixed} + {suf}'
        deeper = derived(stem, known, depth - 1)
        if deeper:
            return f'({deeper}) + {suf}'
    return None
