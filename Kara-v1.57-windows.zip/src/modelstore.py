from __future__ import annotations
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path
import atomicio
ROOT = Path(__file__).resolve().parent.parent
MODELS = ROOT / 'models'
KEEP = 20

def history_dir(speaker: str) -> Path:
    return MODELS / speaker / 'history'

def index_path(speaker: str) -> Path:
    return history_dir(speaker) / 'history.json'

def live_path(speaker: str, size: str) -> Path:
    import profiles
    found = profiles.adapter_for(speaker, size)
    if found is not None:
        return found
    return MODELS / speaker / f'whisper-{size}-lora'

def _stamp() -> str:
    return datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')

def read_index(speaker: str) -> list[dict]:
    try:
        data = json.loads(index_path(speaker).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return []
    rows = data.get('versions') if isinstance(data, dict) else data
    if not isinstance(rows, list):
        return []
    return [r for r in rows if isinstance(r, dict) and (history_dir(speaker) / str(r.get('dir', ''))).is_dir()]

def _write_index(speaker: str, rows: list[dict]) -> None:
    history_dir(speaker).mkdir(parents=True, exist_ok=True)
    atomicio.write_json(index_path(speaker), {'_comment': 'Voice model versions, newest first. Delete a folder here and its row disappears with it.', 'versions': rows}, backup=True)

def snapshot(speaker: str, size: str, note: str='', wer: float | None=None) -> dict | None:
    src = live_path(speaker, size)
    if not src.is_dir() or not any(src.iterdir()):
        return None
    stamp = _stamp()
    name = f'{stamp}-{size}'
    n = 2
    while (history_dir(speaker) / name).exists():
        name = f'{stamp}-{size}-{n}'
        n += 1
    dest = history_dir(speaker) / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(src, dest, dirs_exist_ok=True)
    row = {'dir': name, 'size': size, 'at': stamp, 'note': note, 'wer': wer, 'bytes': sum((f.stat().st_size for f in dest.rglob('*') if f.is_file()))}
    rows = [row] + read_index(speaker)
    _write_index(speaker, rows)
    prune(speaker)
    return row

def prune(speaker: str, keep: int=KEEP) -> int:
    rows = read_index(speaker)
    if len(rows) <= max(1, keep):
        return 0
    doomed = rows[keep:]
    for r in doomed:
        shutil.rmtree(history_dir(speaker) / str(r['dir']), ignore_errors=True)
    _write_index(speaker, rows[:keep])
    return len(doomed)

def promote(speaker: str, size: str, candidate: Path, note: str='', wer: float | None=None) -> bool:
    candidate = Path(candidate)
    if not candidate.is_dir() or not any(candidate.iterdir()):
        return False
    snapshot(speaker, size, note=note or 'replaced by a new training', wer=wer)
    dest = live_path(speaker, size)
    dest.parent.mkdir(parents=True, exist_ok=True)
    staging = dest.with_name(dest.name + '.incoming')
    shutil.rmtree(staging, ignore_errors=True)
    shutil.copytree(candidate, staging)
    old = dest.with_name(dest.name + '.replacing')
    shutil.rmtree(old, ignore_errors=True)
    if dest.exists():
        dest.rename(old)
    staging.rename(dest)
    shutil.rmtree(old, ignore_errors=True)
    try:
        import profiles
        profiles.set_adapter(speaker, size, dest)
    except Exception as e:
        print(f'could not record the adapter for {size}: {e}')
    return True

def restore(speaker: str, version_dir: str) -> bool:
    rows = read_index(speaker)
    row = next((r for r in rows if str(r.get('dir')) == version_dir), None)
    if row is None:
        return False
    src = history_dir(speaker) / version_dir
    if not src.is_dir():
        return False
    size = str(row.get('size') or 'medium')
    return promote(speaker, size, src, note='replaced by restoring an earlier version', wer=row.get('wer'))

def describe(row: dict) -> str:
    when = str(row.get('at', ''))
    try:
        shown = datetime.strptime(when, '%Y%m%d-%H%M%S').strftime('%d %b %Y, %H:%M')
    except ValueError:
        shown = when or 'unknown'
    bits = [shown, str(row.get('size', ''))]
    wer = row.get('wer')
    if isinstance(wer, (int, float)):
        bits.append(f'{wer * 100:.1f}% error')
    size_b = row.get('bytes') or 0
    if size_b:
        bits.append(f'{size_b / 1000000.0:.0f} MB')
    return '  ·  '.join((b for b in bits if b))

def total_bytes(speaker: str) -> int:
    return sum((int(r.get('bytes') or 0) for r in read_index(speaker)))

def main() -> None:
    import argparse
    p = argparse.ArgumentParser(description='Voice model version history.')
    p.add_argument('--speaker', required=True)
    sub = p.add_subparsers(dest='cmd', required=True)
    sub.add_parser('list')
    sn = sub.add_parser('snapshot')
    sn.add_argument('--size', default='medium')
    rs = sub.add_parser('restore')
    rs.add_argument('--version', required=True)
    args = p.parse_args()
    if args.cmd == 'list':
        rows = read_index(args.speaker)
        print(f'{len(rows)} kept version(s), {total_bytes(args.speaker) / 1000000.0:.0f} MB')
        for r in rows:
            print(f"  {r['dir']:<28} {describe(r)}")
        if not rows:
            print('  (nothing kept yet — a version is filed before each training)')
    elif args.cmd == 'snapshot':
        row = snapshot(args.speaker, args.size, note='asked for on the command line')
        print(f"kept {row['dir']}" if row else 'nothing to keep (no adapter yet)')
    elif args.cmd == 'restore':
        ok = restore(args.speaker, args.version)
        print('restored' if ok else 'no such version')
