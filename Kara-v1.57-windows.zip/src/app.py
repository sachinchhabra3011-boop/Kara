import argparse
import threading
import time
from pathlib import Path
PASTE_SETTLE = 0.16
CLIPBOARD_RESTORE_AFTER = 2.0
import editing
import spelling
ROOT = Path(__file__).resolve().parent.parent
DEFAULT_ADAPTER = None

def _user32():
    import ctypes
    from ctypes import wintypes
    u = ctypes.WinDLL('user32')
    u.GetForegroundWindow.restype = wintypes.HWND
    u.SetForegroundWindow.argtypes = [wintypes.HWND]
    u.SetForegroundWindow.restype = wintypes.BOOL
    u.IsWindow.argtypes = [wintypes.HWND]
    u.IsWindow.restype = wintypes.BOOL
    u.IsIconic.argtypes = [wintypes.HWND]
    u.IsIconic.restype = wintypes.BOOL
    u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    u.BringWindowToTop.argtypes = [wintypes.HWND]
    u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.c_void_p]
    u.GetWindowThreadProcessId.restype = wintypes.DWORD
    u.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    u.GetClassNameW.restype = ctypes.c_int
    return u
_TEXT_CLASSES = ('edit', 'richedit', 'textbox', 'scintilla', '_wwg', 'excel', 'opusapp', 'qwidget', 'qt5', 'qt6', 'consolewindowclass', 'pseudoconsolewindow')

def _gui_thread_info_type(C, wintypes):

    class GUITHREADINFO(C.Structure):
        _fields_ = [('cbSize', wintypes.DWORD), ('flags', wintypes.DWORD), ('hwndActive', wintypes.HWND), ('hwndFocus', wintypes.HWND), ('hwndCapture', wintypes.HWND), ('hwndMenuOwner', wintypes.HWND), ('hwndMoveSize', wintypes.HWND), ('hwndCaret', wintypes.HWND), ('rcCaret', wintypes.RECT)]
    return GUITHREADINFO

def caret_info() -> dict:
    facts = {'hwnd': 0, 'focus_class': '', 'has_caret': False, 'looks_like_text': False}
    try:
        import ctypes as C
        from ctypes import wintypes
        u = _user32()
        hwnd = u.GetForegroundWindow()
        if not hwnd:
            return facts
        facts['hwnd'] = int(hwnd)
        tid = u.GetWindowThreadProcessId(hwnd, None)
        GUITHREADINFO = _gui_thread_info_type(C, wintypes)
        gti = GUITHREADINFO()
        gti.cbSize = C.sizeof(GUITHREADINFO)
        u.GetGUIThreadInfo.argtypes = [wintypes.DWORD, C.POINTER(GUITHREADINFO)]
        u.GetGUIThreadInfo.restype = wintypes.BOOL
        if not u.GetGUIThreadInfo(tid, C.byref(gti)):
            return facts
        facts['has_caret'] = bool(gti.hwndCaret)
        focus = gti.hwndFocus or hwnd
        buf = C.create_unicode_buffer(256)
        u.GetClassNameW(focus, buf, 256)
        cls = (buf.value or '').strip().lower()
        facts['focus_class'] = cls
        facts['looks_like_text'] = cls.startswith(_TEXT_CLASSES)
    except Exception:
        return facts
    return facts

def window_is_alive(hwnd: int) -> bool:
    return bool(hwnd) and bool(_user32().IsWindow(hwnd))

def focus_window(hwnd: int) -> bool:
    return _focus_with_reason(hwnd)[0]

def _focus_with_reason(hwnd: int) -> tuple[bool, str]:
    import ctypes
    u = _user32()
    k = ctypes.WinDLL('kernel32')
    if not hwnd or not u.IsWindow(hwnd):
        return (False, 'gone')
    if u.GetForegroundWindow() == hwnd:
        return (True, '')
    for _ in range(3):
        fg = u.GetForegroundWindow()
        fg_tid = u.GetWindowThreadProcessId(fg, None) if fg else 0
        tgt_tid = u.GetWindowThreadProcessId(hwnd, None)
        cur_tid = k.GetCurrentThreadId()
        attached = []
        for tid in {fg_tid, tgt_tid}:
            if tid and tid != cur_tid and u.AttachThreadInput(tid, cur_tid, True):
                attached.append(tid)
        try:
            if u.IsIconic(hwnd):
                u.ShowWindow(hwnd, 9)
            u.BringWindowToTop(hwnd)
            u.SetForegroundWindow(hwnd)
        finally:
            for tid in attached:
                u.AttachThreadInput(tid, cur_tid, False)
        for _ in range(10):
            if u.GetForegroundWindow() == hwnd:
                return (True, '')
            time.sleep(0.02)
    return (False, 'refused')
VK_CONTROL, VK_SHIFT, VK_BACK, VK_RETURN, VK_TAB, VK_SPACE = (17, 16, 8, 13, 9, 32)
VK_LEFT, VK_Z, VK_Y, VK_A = (37, 90, 89, 65)
KEYSTROKES = {'delete_word': (VK_BACK, [VK_CONTROL]), 'backspace': (VK_BACK, []), 'press_enter': (VK_RETURN, []), 'new_line': (VK_RETURN, []), 'tab': (VK_TAB, []), 'space': (VK_SPACE, []), 'select_last': (VK_LEFT, [VK_CONTROL, VK_SHIFT]), 'undo': (VK_Z, [VK_CONTROL]), 'redo': (VK_Y, [VK_CONTROL]), 'clear': (VK_A, [VK_CONTROL])}

def press_keys(hwnd: int | None, vk: int, modifiers=()) -> dict:
    import ctypes
    if hwnd:
        focused, why = _focus_with_reason(hwnd)
        if not focused:
            return {'ok': False, 'focused': False, 'gone': why == 'gone', 'reason': why}
    time.sleep(0.05)
    u = ctypes.windll.user32
    KEYUP = 2
    for m in modifiers:
        u.keybd_event(m, 0, 0, 0)
    u.keybd_event(vk, 0, 0, 0)
    u.keybd_event(vk, 0, KEYUP, 0)
    for m in reversed(list(modifiers)):
        u.keybd_event(m, 0, KEYUP, 0)
    return {'ok': True, 'focused': True, 'gone': False, 'reason': ''}

def inject_text(text: str, hwnd: int | None=None, restore_clipboard: bool=True) -> dict:
    import ctypes
    import pyperclip
    previous = None
    if restore_clipboard:
        try:
            previous = pyperclip.paste()
        except Exception:
            previous = None
    try:
        pyperclip.copy(text)
    except Exception as e:
        return {'ok': False, 'focused': False, 'on_clipboard': False, 'reason': f'clipboard unavailable: {e}'}
    focused, gone = (True, False)
    if hwnd:
        focused, why = _focus_with_reason(hwnd)
        if not focused:
            gone = why == 'gone'
            return {'ok': False, 'focused': False, 'on_clipboard': True, 'gone': gone, 'reason': 'the target window no longer exists' if gone else 'the target window would not come to the front'}
    time.sleep(PASTE_SETTLE)
    u = ctypes.windll.user32
    VK_CTRL, VK_V, KEYUP = (17, 86, 2)
    u.keybd_event(VK_CTRL, 0, 0, 0)
    u.keybd_event(VK_V, 0, 0, 0)
    u.keybd_event(VK_V, 0, KEYUP, 0)
    u.keybd_event(VK_CTRL, 0, KEYUP, 0)
    if restore_clipboard and previous is not None and (previous != text):

        def _restore_later(old=previous):
            time.sleep(CLIPBOARD_RESTORE_AFTER)
            try:
                import pyperclip as _pc
                _pc.copy(old)
            except Exception:
                pass
        threading.Thread(target=_restore_later, daemon=True, name='kara-clipboard').start()
    return {'ok': True, 'focused': focused, 'on_clipboard': True, 'gone': False, 'reason': ''}

class App:

    def __init__(self, speaker: str, adapter: str, speak: bool=True):
        from pipeline import Pipeline
        print('loading model (once)...', flush=True)
        self.pipe = Pipeline(speaker, adapter=adapter, bf16=True, correct=True)
        self.ed = editing.Editor()
        self.anchors = spelling.load_anchors(speaker)
        self.speaker = speaker
        self.speak = speak

    def _say(self, msg: str) -> None:
        print(f'  {msg}')
        if self.speak:
            editing.speak(msg)

    def handle_utterance(self, wav: str) -> None:
        raw = self.pipe.raw(wav)
        import punctuation
        punct = punctuation.parse_punctuation(raw)
        if punct:
            ok, msg = self.ed.punctuate(punct)
            self._say(msg)
            print(f'  buffer: {self.ed.text!r}')
            return
        cmd, args = editing.parse_command(raw)
        if cmd == 'unknown':
            import corrector
            clean = corrector.correct(raw, self.pipe.vocab, use_llm=False)
            self.ed.dictate(clean)
            self._say(f'added: "{clean}"')
        elif cmd == 'spell':
            self._say('spell the word, one anchor per letter')
            self._pending = 'spell'
        elif cmd == 'change_spell':
            target, spell_text = args
            word = spelling.parse_spelling(spell_text, self.anchors).capitalize()
            if word and self.ed.change(target, word):
                self._say(f'changed to "{word}"')
            else:
                self._say(f"couldn't change '{target}'")
        elif cmd == 'send':
            inject_text(self.ed.text)
            self._say('sent to the document')
        elif cmd == 'read':
            self._say(self.ed.text or 'empty')
        else:
            self._say(editing.apply_command(self.ed, raw))
        print(f'  buffer: {self.ed.text!r}')

    def handle_spelling(self, wav: str) -> str:
        word = spelling.parse_spelling(self.pipe.raw(wav), self.anchors).capitalize()
        self.ed.dictate(word)
        spelling.add_to_vocab(word, self.speaker)
        self._say(f'spelled and added: "{word}"')
        return word

    def mic_loop(self) -> None:
        import record
        idx, name, host = record.resolve_device(None)
        import sounddevice as sd
        sd.default.device = (idx, None)
        print(f'mic: [{idx}] {name}\n')
        print("ENTER to speak, ENTER to stop. Say 'send' to put text in the document.")
        print('Commands: delete last word, change X to Y, new line, undo, spell mode, read it back.\n')
        pending_spell = False
        while True:
            try:
                input('[ready] ')
            except (EOFError, KeyboardInterrupt):
                print('\nbye')
                return
            print('  listening — ENTER to stop')
            audio = record.record_until_enter()
            if audio.size < record.SAMPLE_RATE // 4:
                print('  (nothing captured)')
                continue
            import soundfile as sf
            import tempfile
            with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tf:
                sf.write(tf.name, audio, record.SAMPLE_RATE, subtype='PCM_16')
                wav = tf.name
            if pending_spell:
                self.handle_spelling(wav)
                pending_spell = False
            else:
                self.handle_utterance(wav)
                pending_spell = getattr(self, '_pending', None) == 'spell'
                self._pending = None
            Path(wav).unlink(missing_ok=True)

def main() -> None:
    parser = argparse.ArgumentParser(description='Project R app shell.')
    parser.add_argument('--speaker', default=None)
    parser.add_argument('--adapter', default=str(DEFAULT_ADAPTER))
    parser.add_argument('--no-speak', dest='speak', action='store_false')
    parser.add_argument('--mic', action='store_true', help='live push-to-talk loop')
    parser.add_argument('--wav', help='process one wav through the full app logic')
    args = parser.parse_args()
    app = App(args.speaker, args.adapter, speak=args.speak)
    if args.mic:
        app.mic_loop()
    elif args.wav:
        app.handle_utterance(args.wav)
    else:
        raise SystemExit('give --mic (live) or --wav <file> (test)')
