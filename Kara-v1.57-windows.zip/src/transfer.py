from __future__ import annotations
import json
import shutil
import time
import zipfile
from pathlib import Path
import profiles
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'data'
MODELS = ROOT / 'models'
SUFFIX = '.karaprofile'
FORMAT_VERSION = 1
META_NAME = 'kara-export.json'
LEGACY_SUFFIX = '.reedprofile'
LEGACY_META_NAME = 'reed-export.json'
READABLE_SUFFIXES = (SUFFIX, LEGACY_SUFFIX)
_SKIP = {'.tmp', '.deleted', '.pyc'}
_SKIP_NAMES = {'desktop.ini', 'Thumbs.db', '.DS_Store'}
_SKIP_DIRS = {'utterances'}
DOCUMENTS_DIR = 'library'

def _wanted(p: Path, include_documents: bool=True) -> bool:
    if not p.is_file() or p.suffix in _SKIP or p.name in _SKIP_NAMES:
        return False
    if any((part in _SKIP_DIRS for part in p.parts)):
        return False
    if not include_documents and DOCUMENTS_DIR in p.parts:
        return False
    return True

def _model_dirs(name: str) -> list[tuple[str, Path]]:
    out: list[tuple[str, Path]] = []
    own = MODELS / name
    if own.is_dir():
        for d in own.iterdir():
            if d.is_dir():
                out.append((d.name, d))
    seen = {n for n, _ in out}
    for size in ('small', 'medium', 'large-v3'):
        adapter = profiles.adapter_for(name, size)
        std = f'whisper-{size}-lora'
        if adapter and std not in seen and Path(adapter).is_dir():
            out.append((std, Path(adapter)))
            seen.add(std)
    return out

def estimate_size(name: str, include_models: bool=True, include_documents: bool=True) -> int:
    total = 0
    base = profiles.paths(name)['base']
    if base.is_dir():
        total += sum((f.stat().st_size for f in base.rglob('*') if _wanted(f, include_documents)))
    if include_models:
        for _n, d in _model_dirs(name):
            total += sum((f.stat().st_size for f in d.rglob('*') if _wanted(f, include_documents)))
    return total

def documents_size(name: str) -> int:
    base = profiles.paths(name)['base'] / DOCUMENTS_DIR
    if not base.is_dir():
        return 0
    return sum((f.stat().st_size for f in base.rglob('*') if _wanted(f)))

def export_profile(name: str, dest: Path, include_models: bool=True, progress=None, should_stop=None, include_documents: bool=True) -> Path:
    dest = Path(dest)
    if dest.suffix != SUFFIX:
        dest = dest.with_suffix(SUFFIX)
    base = profiles.paths(name)['base']
    if not base.is_dir():
        raise FileNotFoundError(f'no profile named {name!r}')
    jobs: list[tuple[Path, str]] = []
    for f in sorted(base.rglob('*')):
        if _wanted(f, include_documents):
            jobs.append((f, f'data/{f.relative_to(base).as_posix()}'))
    if include_models:
        for arc_name, d in _model_dirs(name):
            for f in sorted(d.rglob('*')):
                if _wanted(f, include_documents):
                    jobs.append((f, f'models/{arc_name}/{f.relative_to(d).as_posix()}'))
    inv = profiles.data_inventory(name)
    meta = {'format': FORMAT_VERSION, 'profile': name, 'display_name': profiles.display_name(name), 'created': time.time(), 'created_readable': time.strftime('%Y-%m-%d %H:%M'), 'includes_models': bool(include_models), 'includes_documents': bool(include_documents), 'model_names': [n for n, _ in _model_dirs(name)] if include_models else [], 'counts': {r['what']: r['detail'] for r in inv}, 'files': len(jobs), 'bytes': sum((f.stat().st_size for f, _ in jobs))}
    part = dest.with_suffix(dest.suffix + '.part')
    part.parent.mkdir(parents=True, exist_ok=True)
    total = len(jobs) + 1
    try:
        with zipfile.ZipFile(part, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            z.writestr(META_NAME, json.dumps(meta, indent=2))
            for i, (src, arc) in enumerate(jobs, start=1):
                if should_stop and should_stop():
                    raise InterruptedError('export cancelled')
                z.write(src, arc)
                if progress:
                    progress(i, total, src.name)
        part.replace(dest)
    except BaseException:
        part.unlink(missing_ok=True)
        raise
    if progress:
        progress(total, total, 'done')
    return dest

def inspect_export(path: Path) -> dict:
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        found = next((n for n in (META_NAME, LEGACY_META_NAME) if n in names), None)
        if found is None:
            raise ValueError('this does not look like a Kara profile backup')
        meta = json.loads(z.read(found))
    if int(meta.get('format', 0)) > FORMAT_VERSION:
        raise ValueError(f"this backup was made by a newer version of Kara (format {meta.get('format')}, this one understands {FORMAT_VERSION})")
    return meta

def import_profile(path: Path, new_name: str | None=None, overwrite: bool=False, progress=None) -> str:
    path = Path(path)
    meta = inspect_export(path)
    name = (new_name or meta.get('profile') or 'imported').strip()
    if not name or any((c in name for c in '\\/:*?"<>|')):
        raise ValueError(f'invalid profile name: {name!r}')
    base = DATA / name
    if base.exists() and any(base.iterdir()) and (not overwrite):
        raise FileExistsError(name)
    staging = DATA / f'_import_{name}'
    shutil.rmtree(staging, ignore_errors=True)
    staging.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n not in (META_NAME, LEGACY_META_NAME)]
            for i, member in enumerate(names, start=1):
                target = (staging / member).resolve()
                if not str(target).startswith(str(staging.resolve())):
                    raise ValueError(f'unsafe path in backup: {member}')
                z.extract(member, staging)
                if progress:
                    progress(i, len(names), Path(member).name)
        if base.exists():
            shutil.rmtree(base, ignore_errors=True)
        src_data = staging / 'data'
        base.parent.mkdir(parents=True, exist_ok=True)
        if src_data.is_dir():
            shutil.move(str(src_data), str(base))
        else:
            base.mkdir(parents=True, exist_ok=True)
        src_models = staging / 'models'
        if src_models.is_dir():
            dest_models = MODELS / name
            dest_models.mkdir(parents=True, exist_ok=True)
            for d in src_models.iterdir():
                if d.is_dir():
                    target = dest_models / d.name
                    shutil.rmtree(target, ignore_errors=True)
                    shutil.move(str(d), str(target))
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    shown = meta.get('display_name')
    if shown and shown != name:
        profiles.set_display_name(name, shown)
    return name

def default_filename(name: str) -> str:
    return f"{name}-kara-{time.strftime('%Y-%m-%d')}{SUFFIX}"
