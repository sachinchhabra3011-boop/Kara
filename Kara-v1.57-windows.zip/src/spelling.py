import argparse
import difflib
import json
import re
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
FILLERS = {'for', 'as', 'in', 'is', 'like', 'of', 'the', 'a', 'an'}
LETTER_NAMES = {'ay': 'A', 'ai': 'A', 'bee': 'B', 'be': 'B', 'cee': 'C', 'see': 'C', 'sea': 'C', 'dee': 'D', 'de': 'D', 'ee': 'E', 'eff': 'F', 'ef': 'F', 'gee': 'G', 'ge': 'G', 'aitch': 'H', 'haitch': 'H', 'jay': 'J', 'jai': 'J', 'kay': 'K', 'ka': 'K', 'el': 'L', 'ell': 'L', 'em': 'M', 'en': 'N', 'oh': 'O', 'ohh': 'O', 'pee': 'P', 'pea': 'P', 'cue': 'Q', 'queue': 'Q', 'kew': 'Q', 'ar': 'R', 'are': 'R', 'ess': 'S', 'es': 'S', 'tee': 'T', 'tea': 'T', 'yoo': 'U', 'you': 'U', 'yu': 'U', 'vee': 'V', 've': 'V', 'ex': 'X', 'eks': 'X', 'why': 'Y', 'wai': 'Y', 'zed': 'Z', 'zee': 'Z', 'dabro': 'W', 'double': 'W', 'doubleyou': 'W'}
INLINE_MARKERS = {'spelled', 'spell', 'spelt', 'spelling', 'spells'}

def _letters_from(token: str) -> list[str] | None:
    low = token.lower().strip('.,!?;:"\'')
    if re.fullmatch('[a-z](?:[-.][a-z])+', low):
        return [c.upper() for c in re.findall('[a-z]', low)]
    clean = re.sub('[^a-z]', '', low)
    if len(clean) == 1:
        return [clean.upper()]
    if clean in LETTER_NAMES:
        return [LETTER_NAMES[clean]]
    return None

def _expand(text: str, upper: bool=True):
    tokens = text.split()
    out: list[str] = []
    spelled: set[str] = set()
    i = 0
    while i < len(tokens):
        bare = re.sub('[^a-z]', '', tokens[i].lower())
        if bare in INLINE_MARKERS:
            letters: list[str] = []
            j = i + 1
            while j < len(tokens):
                got = _letters_from(tokens[j])
                if got is None:
                    break
                letters += got
                j += 1
            if letters:
                word = ''.join(letters)
                out.append(word if upper else word.lower())
                spelled.add(word.lower())
                i = j
                continue
        out.append(tokens[i])
        i += 1
    return (' '.join(out), spelled)

def expand_inline(text: str) -> str:
    return _expand(text)[0]

def expand_spelled(text: str):
    return _expand(text, upper=False)

def load_anchors(speaker: str) -> dict:
    path = ROOT / 'data' / speaker / 'anchors.json'
    if not path.exists():
        raise SystemExit(f"""No anchor alphabet for '{speaker}'. Create {path} — one entry per letter, e.g. {{"anchors": {{"a": "apple", "b": "boy"}}}}.""")
    return json.loads(path.read_text(encoding='utf-8'))['anchors']

def parse_spelling(text: str, anchors: dict) -> str:
    first_word = {w.split()[0].lower(): L for L, w in anchors.items()}
    anchor_keys = list(first_word)
    tokens = re.findall('[a-z]+', text.lower())
    letters = []
    for tok in tokens:
        if tok in FILLERS:
            continue
        if tok in first_word:
            letters.append(first_word[tok])
            continue
        match = difflib.get_close_matches(tok, anchor_keys, n=1, cutoff=0.75)
        if match:
            letters.append(first_word[match[0]])
    if letters:
        return ''.join(letters)
    out = []
    for tok in tokens:
        if len(tok) == 1 and tok.isalpha():
            out.append(tok.upper())
        elif tok in FILLERS:
            continue
        elif tok in LETTER_NAMES:
            out.append(LETTER_NAMES[tok])
    return ''.join(out)

def add_to_vocab(word: str, speaker: str, category: str='spelled') -> None:
    path = ROOT / 'data' / speaker / 'vocab.json'
    vocab = json.loads(path.read_text(encoding='utf-8'))
    bucket = vocab.setdefault(category, [])
    if not any((word.lower() == w.lower() for w in bucket)):
        bucket.append(word)
        import atomicio
        atomicio.write_json(path, vocab, backup=True)
        print(f'added {word!r} to vocab.json[{category}]')
    else:
        print(f'{word!r} already in vocab.json[{category}]')

def spell_from_audio(wav: str, speaker: str, adapter: str | None, bf16: bool) -> str:
    import asr
    hyp = asr.transcribe_paths('large-v3', [wav], adapter=adapter, precision='bf16' if bf16 else 'fp16')[0]
    print(f'heard: {hyp!r}')
    return parse_spelling(hyp, load_anchors(speaker))

def main() -> None:
    parser = argparse.ArgumentParser(description='Reconstruct a word from anchor spelling.')
    parser.add_argument('--speaker', required=True)
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument('--spell', help='the spelling transcription as text')
    src.add_argument('--audio', help='a wav of him spelling (transcribed first)')
    parser.add_argument('--adapter', default=None)
    parser.add_argument('--bf16', action='store_true')
    parser.add_argument('--add', action='store_true', help='write the result to vocab.json')
    parser.add_argument('--category', default='spelled')
    args = parser.parse_args()
    if args.spell is not None:
        word = parse_spelling(args.spell, load_anchors(args.speaker))
    else:
        word = spell_from_audio(args.audio, args.speaker, args.adapter, args.bf16)
    word = word.capitalize()
    print(f'spelled -> {word!r}')
    if args.add and word:
        add_to_vocab(word, args.speaker, args.category)
