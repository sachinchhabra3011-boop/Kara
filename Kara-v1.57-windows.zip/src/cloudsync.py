from __future__ import annotations
import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable, Protocol
import atomicio
import config
import karalog
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'data'
MODELS = ROOT / 'models'
MANIFEST_KEY = 'manifest.json'
MANIFEST_VERSION = 1
INCLUDE_DIRS = ('recordings', 'library')
INCLUDE_FILES = ('manifest.csv', 'vocab.json', 'anchors.json', 'frozen_test.json', 'adapt_queue.jsonl', 'profile.json')
NEVER = ('utterances', 'quarantine', 'account.bin')
CHUNK = 1 << 20

class SyncError(Exception):

    def __init__(self, code: str, detail: str=''):
        self.code = code
        self.detail = detail
        super().__init__(f'{code}: {detail}' if detail else code)

class Backend(Protocol):

    def has(self, key: str) -> bool:
        ...

    def put(self, key: str, data: bytes) -> None:
        ...

    def get(self, key: str) -> bytes:
        ...

    def delete(self, key: str) -> None:
        ...

class LocalBackend:

    def __init__(self, root: Path | str):
        self.root = Path(root)

    def _p(self, key: str) -> Path:
        if '/' in key.strip('/') and (not key.startswith('blobs/')):
            raise SyncError('KARA-7104', f'bad key {key!r}')
        if '..' in key:
            raise SyncError('KARA-7104', f'bad key {key!r}')
        return self.root / key

    def has(self, key: str) -> bool:
        return self._p(key).exists()

    def put(self, key: str, data: bytes) -> None:
        p = self._p(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        atomicio.write_bytes(p, data)

    def get(self, key: str) -> bytes:
        try:
            return self._p(key).read_bytes()
        except OSError as e:
            raise SyncError('KARA-7103', str(e))

    def delete(self, key: str) -> None:
        try:
            self._p(key).unlink()
        except OSError:
            pass

@dataclass
class Item:
    path: str
    sha: str
    size: int

@dataclass
class Manifest:
    speaker: str
    items: dict[str, Item] = field(default_factory=dict)
    updated: float = 0.0
    version: int = MANIFEST_VERSION

    def to_json(self) -> bytes:
        return json.dumps({'version': self.version, 'speaker': self.speaker, 'updated': self.updated, 'items': {k: {'sha': v.sha, 'size': v.size} for k, v in sorted(self.items.items())}}, indent=2).encode('utf-8')

    @staticmethod
    def from_json(raw: bytes) -> 'Manifest':
        d = json.loads(raw.decode('utf-8'))
        if int(d.get('version', 0)) > MANIFEST_VERSION:
            raise SyncError('KARA-7105', f"manifest version {d.get('version')}")
        return Manifest(speaker=d.get('speaker', ''), updated=float(d.get('updated', 0.0)), version=int(d.get('version', 1)), items={k: Item(path=k, sha=v['sha'], size=int(v['size'])) for k, v in d.get('items', {}).items()})

    def total_bytes(self) -> int:
        return sum((i.size for i in self.items.values()))

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(CHUNK), b''):
            h.update(block)
    return h.hexdigest()

def speaker_root(speaker: str) -> Path:
    return DATA / speaker

def payload_files(speaker: str, *, include_model: bool=False) -> list[Path]:
    root = speaker_root(speaker)
    out: list[Path] = []
    for name in INCLUDE_FILES:
        p = root / name
        if p.is_file():
            out.append(p)
    for d in INCLUDE_DIRS:
        base = root / d
        if not base.is_dir():
            continue
        for p in sorted(base.rglob('*')):
            if p.is_file() and (not any((part in NEVER for part in p.parts))):
                out.append(p)
    if include_model:
        out.extend(_active_model_files(speaker))
    return out

def _active_model_files(speaker: str) -> list[Path]:
    out: list[Path] = []
    for d in sorted(MODELS.glob(f'whisper-*-{speaker}-lora*')):
        if d.is_dir():
            out.extend((p for p in sorted(d.rglob('*')) if p.is_file()))
    return out

def folder_reachable(path: str | Path | None) -> bool:
    if not path:
        return False
    p = Path(path)
    if p.is_dir():
        return True
    parent = p.parent
    return parent != p and parent.is_dir()

def payload_fingerprint(speaker: str, *, include_model: bool=False) -> str:
    n = total = 0
    newest = 0.0
    for p in payload_files(speaker, include_model=include_model):
        st = p.stat()
        n += 1
        total += st.st_size
        newest = max(newest, st.st_mtime)
    return f'{n}:{total}:{newest:.0f}'

def scan(speaker: str, *, include_model: bool=False) -> Manifest:
    root = speaker_root(speaker)
    man = Manifest(speaker=speaker, updated=time.time())
    for p in payload_files(speaker, include_model=include_model):
        try:
            rel = p.relative_to(root).as_posix()
        except ValueError:
            rel = f'__models__/{p.relative_to(MODELS).as_posix()}'
        man.items[rel] = Item(path=rel, sha=sha256_file(p), size=p.stat().st_size)
    return man

@dataclass
class Report:
    files: int = 0
    uploaded: int = 0
    skipped: int = 0
    bytes_moved: int = 0
    errors: list[str] = field(default_factory=list)

    def ok(self) -> bool:
        return not self.errors
Progress = Callable[[int, int, str], None]

def _require_online(backend: Backend) -> None:
    if isinstance(backend, LocalBackend):
        return
    if config.load().get('offline_mode', True):
        raise SyncError('KARA-7002')

def backup(speaker: str, backend: Backend, *, include_model: bool=False, progress: Progress | None=None) -> Report:
    _require_online(backend)
    man = scan(speaker, include_model=include_model)
    root = speaker_root(speaker)
    rep = Report(files=len(man.items))
    log = karalog.get('cloudsync')
    for n, (rel, item) in enumerate(sorted(man.items.items()), 1):
        key = f'blobs/{item.sha}'
        if progress:
            progress(n, rep.files, rel)
        try:
            if backend.has(key):
                rep.skipped += 1
                continue
            src = root / rel if not rel.startswith('__models__/') else MODELS / rel[len('__models__/'):]
            backend.put(key, src.read_bytes())
            rep.uploaded += 1
            rep.bytes_moved += item.size
        except Exception as e:
            rep.errors.append(f'{rel}: {e}')
    if rep.errors:
        log.error('backup incomplete: %d of %d failed', len(rep.errors), rep.files)
        return rep
    backend.put(MANIFEST_KEY, man.to_json())
    log.info('backup ok: %d files, %d uploaded, %d skipped, %.1f MB moved', rep.files, rep.uploaded, rep.skipped, rep.bytes_moved / 1000000.0)
    return rep

def restore(speaker: str, backend: Backend, *, progress: Progress | None=None, overwrite: bool=False) -> Report:
    _require_online(backend)
    log = karalog.get('cloudsync')
    try:
        man = Manifest.from_json(backend.get(MANIFEST_KEY))
    except SyncError:
        raise
    except Exception as e:
        raise SyncError('KARA-7101', str(e))
    root = speaker_root(speaker)
    rep = Report(files=len(man.items))
    for n, (rel, item) in enumerate(sorted(man.items.items()), 1):
        if progress:
            progress(n, rep.files, rel)
        dest = root / rel if not rel.startswith('__models__/') else MODELS / rel[len('__models__/'):]
        try:
            if dest.exists() and (not overwrite):
                if sha256_file(dest) == item.sha:
                    rep.skipped += 1
                    continue
                rep.errors.append(f'{rel}: exists locally and differs')
                continue
            data = backend.get(f'blobs/{item.sha}')
            got = hashlib.sha256(data).hexdigest()
            if got != item.sha:
                rep.errors.append(f'{rel}: hash mismatch')
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            atomicio.write_bytes(dest, data)
            rep.uploaded += 1
            rep.bytes_moved += len(data)
        except Exception as e:
            rep.errors.append(f'{rel}: {e}')
    log.info('restore: %d files, %d written, %d already present, %d errors', rep.files, rep.uploaded, rep.skipped, len(rep.errors))
    return rep

def remote_summary(backend: Backend) -> dict:
    try:
        man = Manifest.from_json(backend.get(MANIFEST_KEY))
    except Exception:
        return {'exists': False, 'files': 0, 'bytes': 0, 'updated': 0.0}
    return {'exists': True, 'files': len(man.items), 'bytes': man.total_bytes(), 'updated': man.updated}
