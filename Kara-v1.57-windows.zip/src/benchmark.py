import argparse
import csv
import json
from pathlib import Path
import jiwer
from transformers.models.whisper.english_normalizer import EnglishTextNormalizer
import asr
ROOT = Path(__file__).resolve().parent.parent
MANIFEST = ROOT / 'data' / 'speaker' / 'manifest.csv'
RESULTS = ROOT / 'results'
normalize = EnglishTextNormalizer({})

def load_clips(manifest: Path, prompt_set: str | None) -> list[dict]:
    if not manifest.exists():
        raise SystemExit(f'No manifest at {manifest}. Record something first: python src/record.py')
    with manifest.open(encoding='utf-8-sig', newline='') as f:
        clips = list(csv.DictReader(f))
    if prompt_set:
        clips = [c for c in clips if c['prompt_set'] == prompt_set]
    if not clips:
        raise SystemExit(f"No clips for set '{prompt_set}'.")
    return clips

def main() -> None:
    parser = argparse.ArgumentParser(description='Benchmark off-the-shelf Whisper.')
    parser.add_argument('--models', nargs='+', default=['small', 'medium', 'large-v3'])
    parser.add_argument('--set', dest='prompt_set', default=None, help='limit to one prompt set')
    parser.add_argument('--speaker', help='benchmark data/<speaker>/manifest.csv')
    parser.add_argument('--manifest', type=Path, default=None, help='explicit manifest csv path')
    parser.add_argument('--no-safeguards', dest='safeguards', action='store_false', help="decode without Whisper's anti-degeneracy thresholds")
    parser.add_argument('--adapter', default=None, help='LoRA adapter dir to evaluate')
    parser.add_argument('--bf16', action='store_true', help='decode in bf16 (stable for fine-tuned large-v3)')
    parser.add_argument('--bias', action='store_true', help='bias decoding with data/<speaker>/vocab.json names')
    parser.add_argument('--test-split', type=Path, default=None, help='json with test_ids: score only the held-out clips')
    args = parser.parse_args()
    if args.manifest is None:
        args.manifest = ROOT / 'data' / args.speaker / 'manifest.csv' if args.speaker else MANIFEST
    bias = None
    if args.bias:
        if not args.speaker:
            raise SystemExit('--bias needs --speaker (reads data/<speaker>/vocab.json)')
        vocab = json.loads((ROOT / 'data' / args.speaker / 'vocab.json').read_text(encoding='utf-8'))
        import corrector as _corr
        words = _corr.vocab_words(vocab)
        bias = 'Vocabulary: ' + ', '.join(words) + '.'
        print(f'biasing with {len(words)} vocab entries')
    clips = load_clips(args.manifest, args.prompt_set)
    if args.test_split:
        test_ids = set(json.loads(args.test_split.read_text())['test_ids'])
        clips = [c for c in clips if c['prompt_id'] in test_ids]
        print(f'held-out test set: {len(clips)} clips')
    refs = [normalize(c['prompt_text']) for c in clips]
    if any((not r for r in refs)):
        raise SystemExit('A prompt normalizes to empty text. Remove it and re-run.')
    RESULTS.mkdir(exist_ok=True)
    paths = [ROOT / c['wav_path'] for c in clips]
    per_utterance = []
    summary = []
    for model_name in args.models:
        tag = '  (fine-tuned)' if args.adapter else '' if args.safeguards else '  (safeguards OFF)'
        print(f'\n{model_name}{tag}')
        raw_hyps = asr.transcribe_isolated(model_name, paths, safeguards=args.safeguards, adapter=args.adapter, precision='bf16' if args.bf16 else 'fp16', bias=bias)
        if raw_hyps is None:
            continue
        hyps = [normalize(h) for h in raw_hyps]
        out = jiwer.process_words(refs, hyps)
        corpus_wer = out.wer
        errors = out.substitutions + out.deletions + out.insertions
        words = errors + out.hits
        summary.append({'model': model_name, 'wer': corpus_wer, 'errors': errors, 'words': words, 'clips': len(clips)})
        print(f'  WER {corpus_wer:.1%}  ({errors} errors / {words} words, {len(clips)} clips)')
        for clip, ref, hyp, raw in zip(clips, refs, hyps, raw_hyps):
            per_utterance.append({'model': model_name, 'prompt_id': clip['prompt_id'], 'wer': f'{(jiwer.wer(ref, hyp) if hyp else 1.0):.4f}', 'reference': ref, 'hypothesis': hyp, 'raw_hypothesis': raw})
    if not summary:
        raise SystemExit('\nEvery model crashed. Nothing written.')
    with (RESULTS / 'summary.csv').open('w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['model', 'wer', 'errors', 'words', 'clips'])
        writer.writeheader()
        for row in summary:
            writer.writerow({**row, 'wer': f"{row['wer']:.4f}"})
    with (RESULTS / 'per_utterance.csv').open('w', encoding='utf-8', newline='') as f:
        fields = ['model', 'prompt_id', 'wer', 'reference', 'hypothesis', 'raw_hypothesis']
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(per_utterance)
    print('\nWrote results/summary.csv and results/per_utterance.csv\n')
    for row in sorted(summary, key=lambda s: s['wer']):
        print(f"  {row['wer']:6.1%}  {row['model']:<16} {row['errors']:>3} errors")
    if len(summary) > 1:
        ranked = sorted(summary, key=lambda s: s['wer'])
        gap = ranked[1]['errors'] - ranked[0]['errors']
        if gap <= 3:
            print(f'\nThe top two models differ by {gap} word(s). That is not a result.')
            print('Record more clips before choosing between them.')
    print('\nNow sort per_utterance.csv by wer descending and read the worst ten.')
    print('Check raw_hypothesis for fluent-but-invented text. That is hallucination,')
    print('and it matters more than WER for someone who cannot easily correct it.')
