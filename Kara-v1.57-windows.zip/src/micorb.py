from __future__ import annotations
import math
import random
from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QRadialGradient
from PySide6.QtWidgets import QWidget
from i18n import t
BEIGE = '#a58970'
BROWN = '#34190e'
RED = '#c94f3d'
BLUE = '#3f74c9'
DIM = '#5c5148'
GOOD_LO, GOOD_HI = (0.25, 0.5)
QUIET, HOT = (0.15, 0.8)
RED_BLEND = 0.4
BLUE_BLEND = 0.5

def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t

def _mix(c1: QColor, c2: QColor, t: float) -> QColor:
    return QColor(int(_lerp(c1.red(), c2.red(), t)), int(_lerp(c1.green(), c2.green(), t)), int(_lerp(c1.blue(), c2.blue(), t)))

class MicOrb(QWidget):
    clicked = Signal()
    pressed = Signal()
    released = Signal()
    N_SPIKES = 48
    SIZE = 240

    def __init__(self, source=None, parent=None, accent=BEIGE, canvas=BROWN, size: int | None=None):
        super().__init__(parent)
        self.SIZE = int(size or self.SIZE)
        self._k = self.SIZE / 240.0
        self.setFixedSize(self.SIZE, self.SIZE)
        self.setCursor(Qt.PointingHandCursor)
        self._source = source or (lambda: 0.0)
        self._state = 'disabled'
        self._accent = QColor(accent)
        self._canvas = QColor(canvas)
        self._red = QColor(RED)
        self._blue = QColor(BLUE)
        self._dim = QColor(DIM)
        self._env = 0.0
        self._cenv = 0.0
        self._t = 0.0
        self._spin = 0.0
        self._hover = False
        self._pressed = False
        rng = random.Random(7)
        self._jit = [rng.uniform(0.7, 1.3) for _ in range(self.N_SPIKES)]
        self._phase = [rng.uniform(0.0, math.tau) for _ in range(self.N_SPIKES)]
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(16)
        self._describe()
    _SAID = {'disabled': 'Microphone — not available', 'idle': 'Microphone — tap to talk', 'listening': 'Microphone — listening, tap again to stop', 'thinking': 'Microphone — working out what you said'}

    def _describe(self) -> None:
        self.setAccessibleName(t('Microphone'))
        self.setAccessibleDescription(t(self._SAID[self._state]))

    def set_state(self, state: str):
        if state not in ('disabled', 'idle', 'listening', 'thinking'):
            raise ValueError(state)
        self._state = state
        if state != 'listening':
            self._env = self._cenv = 0.0
        self.setCursor(Qt.ForbiddenCursor if state == 'disabled' else Qt.PointingHandCursor)
        self._describe()
        self.update()

    def state(self) -> str:
        return self._state

    def set_source(self, source):
        self._source = source

    def mousePressEvent(self, ev):
        if ev.button() == Qt.LeftButton and self._state != 'disabled':
            self._pressed = True
            self.update()
            self.pressed.emit()

    def mouseReleaseEvent(self, ev):
        if ev.button() == Qt.LeftButton and self._pressed:
            self._pressed = False
            self.update()
            self.released.emit()
            if self.rect().contains(ev.position().toPoint()):
                self.clicked.emit()

    def enterEvent(self, ev):
        self._hover = True
        self.update()

    def leaveEvent(self, ev):
        self._hover = False
        self.update()

    def _tick(self):
        dt = 0.016
        self._t += dt
        if self._state == 'listening':
            raw = 0.0
            try:
                raw = max(0.0, min(1.0, float(self._source())))
            except Exception:
                pass
            a = 1 - math.exp(-dt / (0.05 if raw > self._env else 0.3))
            self._env += (raw - self._env) * a
            c = 1 - math.exp(-dt / (0.25 if raw > self._cenv else 0.8))
            self._cenv += (raw - self._cenv) * c
        elif self._state == 'thinking':
            self._spin = (self._spin + dt * 380.0) % 360.0
        self.update()

    def _live_colour(self) -> QColor:
        lvl = self._cenv
        if lvl > GOOD_HI:
            f = min(1.0, (lvl - GOOD_HI) / (HOT - GOOD_HI)) * RED_BLEND
            return _mix(self._accent, self._red, f)
        if lvl < GOOD_LO:
            f = min(1.0, (GOOD_LO - lvl) / (GOOD_LO - QUIET)) * BLUE_BLEND
            return _mix(self._accent, self._blue, f)
        return QColor(self._accent)

    def paintEvent(self, ev):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        cx = cy = self.SIZE / 2.0
        centre = QPointF(cx, cy)
        state = self._state
        k = min(1.25, self._env / 0.5) if state == 'listening' else 0.0
        scale = (0.96 if self._pressed else 1.0) * self._k
        if state == 'disabled':
            ring, glow_a = (QColor(self._dim), 0.0)
            r0, th = (66.0, 3.0)
        elif state == 'idle':
            breathe = 0.5 + 0.5 * math.sin(self._t * math.tau / 3.2)
            ring = QColor(self._accent)
            glow_a = 0.1 + 0.14 * breathe
            r0 = 66.0 + 2.2 * breathe
            th = 3.4
        elif state == 'thinking':
            ring, glow_a = (QColor(self._accent), 0.1)
            r0, th = (66.0, 3.0)
        else:
            ring = self._live_colour()
            glow_a = 0.16 + 0.3 * min(1.0, k)
            r0 = 66.0 + 7.0 * k
            th = 3.4 + 2.6 * k
        if self._hover and state in ('idle', 'listening'):
            ring = ring.lighter(112)
        r0 *= scale
        th *= self._k
        glow_r = 42.0 * self._k
        if glow_a > 0.0:
            g = QRadialGradient(centre, r0 + glow_r)
            gc = QColor(ring)
            gc.setAlphaF(glow_a)
            g.setColorAt(max(0.0, (r0 - 26.0 * self._k) / (r0 + glow_r)), QColor(0, 0, 0, 0))
            g.setColorAt(r0 / (r0 + glow_r), gc)
            g.setColorAt(1.0, QColor(0, 0, 0, 0))
            p.setPen(Qt.NoPen)
            p.setBrush(g)
            p.drawEllipse(centre, r0 + glow_r, r0 + glow_r)
        inner = QRadialGradient(centre, r0)
        ic = QColor(ring)
        ic.setAlphaF(0.05 if state != 'listening' else 0.05 + 0.07 * k)
        inner.setColorAt(0.55, QColor(0, 0, 0, 0))
        inner.setColorAt(1.0, ic)
        p.setPen(Qt.NoPen)
        p.setBrush(inner)
        p.drawEllipse(centre, r0, r0)
        if state == 'listening':
            base = r0 + th / 2.0 + 2.0 * self._k
            pen = QPen(ring)
            pen.setCapStyle(Qt.RoundCap)
            for i in range(self.N_SPIKES):
                ang = math.tau * i / self.N_SPIKES + 0.06 * math.sin(self._t * 0.5)
                wave = 0.55 + 0.45 * math.sin(3.0 * ang + 1.7 * self._t + self._phase[i]) * math.sin(5.0 * ang - 2.3 * self._t)
                length = (1.5 + 26.0 * k * wave) * self._jit[i] * self._k
                alpha = 0.28 + 0.62 * min(1.0, k * wave + 0.15)
                col = QColor(ring)
                col.setAlphaF(min(1.0, alpha))
                pen.setColor(col)
                pen.setWidthF((1.6 + 1.2 * k * wave) * self._k)
                p.setPen(pen)
                ca, sa = (math.cos(ang), math.sin(ang))
                p.drawLine(QPointF(cx + ca * base, cy + sa * base), QPointF(cx + ca * (base + length), cy + sa * (base + length)))
        pen = QPen(ring)
        pen.setWidthF(th)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        p.setBrush(Qt.NoBrush)
        if state == 'thinking':
            faint = QColor(ring)
            faint.setAlphaF(0.22)
            p.setPen(QPen(faint, th, Qt.SolidLine, Qt.RoundCap))
            p.drawEllipse(centre, r0, r0)
            p.setPen(pen)
            rect = QRectF(cx - r0, cy - r0, 2 * r0, 2 * r0)
            p.drawArc(rect, int(-self._spin * 16), 80 * 16)
        else:
            p.drawEllipse(centre, r0, r0)
        glyph = QColor(ring if state != 'disabled' else self._dim)
        glyph.setAlphaF(0.55 if state == 'listening' else 0.4)
        pen = QPen(glyph)
        pen.setWidthF(3.0 * self._k)
        pen.setCapStyle(Qt.RoundCap)
        p.setPen(pen)
        s = scale
        cap = QRectF(cx - 9 * s, cy - 22 * s, 18 * s, 28 * s)
        p.setBrush(Qt.NoBrush)
        p.drawRoundedRect(cap, 9 * s, 9 * s)
        arc = QRectF(cx - 16 * s, cy - 14 * s, 32 * s, 32 * s)
        p.drawArc(arc, 200 * 16, 140 * 16)
        p.drawLine(QPointF(cx, cy + 18 * s), QPointF(cx, cy + 26 * s))
        p.end()

class _FakeVoice:
    SCRIPT = [(2.8, 0.36), (0.9, 0.0), (2.2, 0.72), (0.9, 0.0), (2.4, 0.1), (1.2, 0.0)]

    def __init__(self):
        self._t = 0.0
        self._total = sum((d for d, _ in self.SCRIPT))

    def __call__(self) -> float:
        import time
        t = time.perf_counter() % self._total
        for dur, level in self.SCRIPT:
            if t < dur:
                if level == 0.0:
                    return 0.0
                syll = max(0.0, math.sin(t * math.tau * 3.1))
                trem = 0.8 + 0.2 * math.sin(t * 37.0)
                return level * (0.35 + 0.65 * syll) * trem
            t -= dur
        return 0.0

def _demo():
    import sys
    from PySide6.QtWidgets import QApplication, QHBoxLayout, QLabel, QPushButton, QSlider, QVBoxLayout
    app = QApplication(sys.argv)
    win = QWidget()
    win.setWindowTitle('MicOrb')
    win.setStyleSheet(f'background:{BROWN}; color:{BEIGE};')
    fake = _FakeVoice()
    manual = {'value': None}

    def source():
        return manual['value'] if manual['value'] is not None else fake()
    orb = MicOrb(source=source)
    orb.set_state('idle')
    orb.clicked.connect(lambda: orb.set_state('listening' if orb.state() == 'idle' else 'idle'))
    lay = QVBoxLayout(win)
    lay.addWidget(orb, alignment=Qt.AlignCenter)
    row = QHBoxLayout()
    for s in ('disabled', 'idle', 'listening', 'thinking'):
        b = QPushButton(s)
        b.setStyleSheet(f'background:{BEIGE}; color:{BROWN}; padding:6px 10px;border:none; border-radius:6px;')
        b.clicked.connect(lambda _, st=s: orb.set_state(st))
        row.addWidget(b)
    lay.addLayout(row)
    slider = QSlider(Qt.Horizontal)
    slider.setRange(0, 100)
    slider.setValue(0)
    lab = QLabel('level: synthetic voice (drag to override, 0 releases)')

    def on_slide(v):
        manual['value'] = None if v == 0 else v / 100.0
        lab.setText(f"level: {('synthetic voice' if v == 0 else v / 100.0)}")
    slider.valueChanged.connect(on_slide)
    lay.addWidget(slider)
    lay.addWidget(lab)
    win.show()
    sys.exit(app.exec())

def _shots(outdir: str):
    import sys
    from PySide6.QtWidgets import QApplication
    app = QApplication(sys.argv)
    from pathlib import Path
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    cases = [('idle', 'idle', None), ('disabled', 'disabled', None), ('thinking', 'thinking', None), ('quiet', 'listening', 0.08), ('normal', 'listening', 0.38), ('loud', 'listening', 0.85)]
    from PySide6.QtWidgets import QVBoxLayout
    for name, state, level in cases:
        frame = QWidget()
        frame.setStyleSheet(f'background:{BROWN};')
        frame.setFixedSize(MicOrb.SIZE + 20, MicOrb.SIZE + 20)
        orb = MicOrb(source=lambda lv=level: lv or 0.0, parent=frame)
        QVBoxLayout(frame).addWidget(orb, alignment=Qt.AlignCenter)
        orb.set_state(state)
        for _ in range(90):
            orb._tick()
        img = frame.grab()
        img.save(str(out / f'orb_{name}.png'))
        print(f'wrote orb_{name}.png  (env={orb._env:.2f} cenv={orb._cenv:.2f})')
    sys.exit(0)
