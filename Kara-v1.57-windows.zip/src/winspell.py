from __future__ import annotations
import ctypes
import threading
from ctypes import POINTER, byref, c_int, c_uint, c_void_p, c_wchar_p
_CLSID_FACTORY = '{7AB36653-1796-484B-BDFA-E74F1DB7C1DC}'
_IID_FACTORY = '{8E018A9D-2415-4677-BF08-794EA61F94BB}'
S_OK, S_FALSE = (0, 1)
COINIT_APARTMENTTHREADED = 2
RPC_E_CHANGED_MODE = -2147417850
_local = threading.local()
_broken = False
_lock = threading.Lock()

class _GUID(ctypes.Structure):
    _fields_ = [('Data1', ctypes.c_ulong), ('Data2', ctypes.c_ushort), ('Data3', ctypes.c_ushort), ('Data4', ctypes.c_ubyte * 8)]

def _guid(text: str) -> _GUID:
    g = _GUID()
    if ctypes.oledll.ole32.CLSIDFromString(c_wchar_p(text), byref(g)) != S_OK:
        raise OSError(f'bad guid {text}')
    return g

def _method(ptr: c_void_p, index: int, *argtypes):
    vtable = ctypes.cast(ptr, POINTER(POINTER(c_void_p)))[0]
    proto = ctypes.WINFUNCTYPE(ctypes.HRESULT, c_void_p, *argtypes)
    return (proto(vtable[index]), ptr)

def _call(ptr: c_void_p, index: int, argtypes, *args) -> int:
    fn, this = _method(ptr, index, *argtypes)
    return fn(this, *args)

def _release(ptr: c_void_p) -> None:
    if ptr:
        try:
            vtable = ctypes.cast(ptr, POINTER(POINTER(c_void_p)))[0]
            ctypes.WINFUNCTYPE(ctypes.c_ulong, c_void_p)(vtable[2])(ptr)
        except Exception:
            pass

def _fail() -> None:
    global _broken
    _broken = True

def _checker(language: str='en-US'):
    if _broken:
        return None
    got = getattr(_local, 'checker', None)
    if got is not None and getattr(_local, 'language', '') == language:
        return got
    try:
        hr = ctypes.oledll.ole32.CoInitializeEx(None, COINIT_APARTMENTTHREADED)
    except OSError as e:
        if getattr(e, 'winerror', 0) != RPC_E_CHANGED_MODE:
            _fail()
            return None
    try:
        factory = c_void_p()
        ctypes.oledll.ole32.CoCreateInstance(byref(_guid(_CLSID_FACTORY)), None, 1, byref(_guid(_IID_FACTORY)), byref(factory))
        supported = c_int(0)
        _call(factory, 4, (c_wchar_p, POINTER(c_int)), c_wchar_p(language), byref(supported))
        if not supported.value:
            _release(factory)
            return None
        checker = c_void_p()
        _call(factory, 5, (c_wchar_p, POINTER(c_void_p)), c_wchar_p(language), byref(checker))
        _release(factory)
        if not checker:
            _fail()
            return None
        _local.checker, _local.language = (checker, language)
        return checker
    except Exception:
        _fail()
        return None

def available(language: str='en-US') -> bool:
    return _checker(language) is not None

def languages() -> list[str]:
    out = []
    for tag in ('en-US', 'en-GB', 'en-AU', 'en-CA', 'en-IN', 'en-NZ', 'en-ZA'):
        if available(tag):
            out.append(tag)
        _local.checker, _local.language = (None, '')
    return out

def is_known(word: str, language: str='en-US') -> bool:
    errs = check(word, language)
    return not errs

def check(text: str, language: str='en-US') -> list[tuple]:
    sc = _checker(language)
    if sc is None or not (text or '').strip():
        return []
    errors_ptr = c_void_p()
    try:
        if _call(sc, 4, (c_wchar_p, POINTER(c_void_p)), c_wchar_p(text), byref(errors_ptr)) != S_OK or not errors_ptr:
            return []
    except Exception:
        _fail()
        return []
    found = []
    try:
        while True:
            err = c_void_p()
            if _call(errors_ptr, 3, (POINTER(c_void_p),), byref(err)) != S_OK or not err:
                break
            start, length, action = (c_uint(0), c_uint(0), c_uint(0))
            _call(err, 3, (POINTER(c_uint),), byref(start))
            _call(err, 4, (POINTER(c_uint),), byref(length))
            _call(err, 5, (POINTER(c_uint),), byref(action))
            repl = c_wchar_p()
            try:
                _call(err, 6, (POINTER(c_wchar_p),), byref(repl))
            except Exception:
                repl = c_wchar_p()
            found.append((start.value, length.value, action.value, repl.value or ''))
            if repl:
                ctypes.windll.ole32.CoTaskMemFree(repl)
            _release(err)
    except Exception:
        _fail()
    finally:
        _release(errors_ptr)
    return found

def unknown(words, language: str='en-US') -> set:
    sc = _checker(language)
    if sc is None:
        return set()
    out = set()
    for w in words:
        if check(w, language):
            out.add(w)
    return out

def suggest(word: str, limit: int=5, language: str='en-US') -> list[str]:
    sc = _checker(language)
    if sc is None or not word:
        return []
    enum = c_void_p()
    try:
        if _call(sc, 5, (c_wchar_p, POINTER(c_void_p)), c_wchar_p(word), byref(enum)) not in (S_OK, S_FALSE) or not enum:
            return []
    except Exception:
        _fail()
        return []
    out = []
    try:
        while len(out) < limit:
            item = c_wchar_p()
            fetched = c_uint(0)
            if _call(enum, 3, (c_uint, POINTER(c_wchar_p), POINTER(c_uint)), 1, byref(item), byref(fetched)) != S_OK or not fetched.value:
                break
            if item.value:
                out.append(item.value)
            if item:
                ctypes.windll.ole32.CoTaskMemFree(item)
    except Exception:
        _fail()
    finally:
        _release(enum)
    return out
