from __future__ import annotations
CONSONANTS = set(range(2325, 2362)) | set(range(2392, 2400))
INDEPENDENT_VOWELS = set(range(2308, 2325))
MATRAS = set(range(2366, 2381)) | {2402, 2403}
VIRAMA = 2381
NUKTA = 2364
SIGNS = {2305, 2306, 2307}
DIGITS = set(range(2406, 2416))

def is_devanagari(word: str) -> bool:
    return any((2304 <= ord(c) <= 2431 for c in word))

def why_impossible(word: str) -> str:
    codes = [ord(c) for c in word]
    if not codes:
        return ''
    first = codes[0]
    if first in MATRAS:
        return 'starts with a vowel sign, which needs a consonant before it'
    if first == VIRAMA:
        return 'starts with a halant'
    if first == NUKTA:
        return 'starts with a nukta'
    previous = None
    matra_run = 0
    for code in codes:
        if code in MATRAS:
            matra_run += 1
            if matra_run > 2:
                return 'three vowel signs in a row'
            if previous is not None and previous in MATRAS | {VIRAMA}:
                if previous == VIRAMA:
                    return 'a vowel sign straight after a halant'
            if previous is not None and previous in INDEPENDENT_VOWELS:
                return 'a vowel sign on a standalone vowel'
        else:
            matra_run = 0
        if code == VIRAMA and previous is not None and (previous in MATRAS):
            return 'a halant straight after a vowel sign'
        if code == NUKTA and (previous is None or previous not in CONSONANTS):
            return 'a nukta not on a consonant'
        previous = code
    return ''

def check(text: str) -> list[tuple[int, int, str]]:
    out: list[tuple[int, int, str]] = []
    start = None
    for i, ch in enumerate(text + ' '):
        if ch.isspace() or (not is_devanagari(ch) and (not ch.isalnum())):
            if start is not None:
                word = text[start:i]
                if is_devanagari(word):
                    why = why_impossible(word)
                    if why:
                        out.append((start, i, why))
                start = None
        elif start is None:
            start = i
    return out

def is_known(word: str) -> bool:
    return not (is_devanagari(word) and why_impossible(word))
