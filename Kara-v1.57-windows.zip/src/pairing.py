from __future__ import annotations
import difflib
import re
__all__ = ['align', 'normalise', 'similarity']
_PUNCT = re.compile("[^\\w']+")
MIN_SIMILARITY = 0.55
MAX_LENGTH_RATIO = 2.0

def normalise(word: str) -> str:
    return _PUNCT.sub('', (word or '').lower())

def _words(text: str) -> list[str]:
    return [w for w in (text or '').split() if w]

def similarity(a: str, b: str) -> float:
    na, nb = ([normalise(w) for w in _words(a)], [normalise(w) for w in _words(b)])
    if not na and (not nb):
        return 1.0
    if not na or not nb:
        return 0.0
    return difflib.SequenceMatcher(None, na, nb, autojunk=False).ratio()

def align(utterances: list[dict], final_text: str, min_similarity: float=MIN_SIMILARITY) -> list[dict]:
    results: list[dict] = []
    src: list[str] = []
    owner: list[int] = []
    for i, u in enumerate(utterances):
        for w in _words(u.get('asr')):
            src.append(w)
            owner.append(i)
    tgt = _words(final_text)
    if not src:
        return [{'id': u.get('id'), 'asr': u.get('asr', ''), 'corrected': '', 'status': 'unmatched', 'similarity': 0.0} for u in utterances]
    sm = difflib.SequenceMatcher(None, [normalise(w) for w in src], [normalise(w) for w in tgt], autojunk=False)
    mapped: list[list[int]] = [[] for _ in src]
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == 'equal':
            for k in range(i2 - i1):
                mapped[i1 + k] = [j1 + k]
        elif tag == 'replace':
            block = list(range(j1, j2))
            for k in range(i1, i2):
                mapped[k] = block
        elif tag == 'delete':
            for k in range(i1, i2):
                mapped[k] = []
    cursor = 0
    for i, u in enumerate(utterances):
        asr = (u.get('asr') or '').strip()
        idxs = [j for k, m in enumerate(mapped) if owner[k] == i for j in m]
        if not asr:
            results.append({'id': u.get('id'), 'asr': asr, 'corrected': '', 'status': 'unmatched', 'similarity': 0.0})
            continue
        if not idxs:
            results.append({'id': u.get('id'), 'asr': asr, 'corrected': '', 'status': 'unmatched', 'similarity': 0.0})
            continue
        lo, hi = (max(min(idxs), cursor), max(idxs) + 1)
        if hi <= lo:
            results.append({'id': u.get('id'), 'asr': asr, 'corrected': '', 'status': 'unmatched', 'similarity': 0.0})
            continue
        cursor = hi
        corrected = ' '.join(tgt[lo:hi]).strip()
        sim = similarity(asr, corrected)
        same = [normalise(w) for w in _words(asr)] == [normalise(w) for w in _words(corrected)]
        n_a, n_c = (len(_words(asr)), len(_words(corrected)))
        ratio = max(n_a, n_c) / max(1, min(n_a, n_c))
        if same:
            status = 'unchanged'
        elif sim < min_similarity or ratio > MAX_LENGTH_RATIO:
            status = 'unmatched'
        else:
            status = 'corrected'
        results.append({'id': u.get('id'), 'asr': asr, 'corrected': corrected, 'status': status, 'similarity': round(sim, 3)})
    return results
