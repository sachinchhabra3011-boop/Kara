from __future__ import annotations
import csv
import io
import json
import os
import shutil
from pathlib import Path
__all__ = ['write_text', 'write_bytes', 'write_json', 'write_csv', 'backup_path', 'restore_from_backup', 'append_line']

def backup_path(path: Path | str) -> Path:
    p = Path(path)
    return p.with_name(p.name + '.bak')

def _tmp_path(path: Path) -> Path:
    return path.with_name(path.name + '.tmp')

def write_text(path: Path | str, text: str, *, encoding: str='utf-8', newline: str | None='', backup: bool=False) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_path(path)
    with tmp.open('w', encoding=encoding, newline=newline) as f:
        f.write(text)
        f.flush()
        os.fsync(f.fileno())
    if backup and path.exists():
        try:
            shutil.copy2(path, backup_path(path))
        except OSError:
            pass
    os.replace(tmp, path)

def write_bytes(path: Path | str, data: bytes, *, backup: bool=False) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_path(path)
    with tmp.open('wb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    if backup and path.exists():
        try:
            shutil.copy2(path, backup_path(path))
        except OSError:
            pass
    os.replace(tmp, path)

def write_json(path: Path | str, obj, *, indent: int=2, backup: bool=False) -> None:
    write_text(path, json.dumps(obj, indent=indent, ensure_ascii=False), newline=None, backup=backup)

def write_csv(path: Path | str, fieldnames: list[str], rows: list[dict], *, backup: bool=True) -> None:
    buf = io.StringIO(newline='')
    writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction='ignore')
    writer.writeheader()
    writer.writerows(rows)
    write_text(path, buf.getvalue(), backup=backup)

def append_line(path: Path | str, text: str, *, encoding: str='utf-8') -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    needs_nl = False
    if path.exists() and path.stat().st_size:
        try:
            with path.open('rb') as f:
                f.seek(-1, os.SEEK_END)
                needs_nl = f.read(1) not in (b'\n', b'\r')
        except OSError:
            needs_nl = False
    with path.open('a', encoding=encoding, newline='') as f:
        if needs_nl:
            f.write('\r\n')
        f.write(text)
        f.flush()
        os.fsync(f.fileno())

def restore_from_backup(path: Path | str) -> bool:
    path = Path(path)
    bak = backup_path(path)
    if not bak.exists() or not bak.stat().st_size:
        return False
    if path.exists() and path.stat().st_size:
        return False
    try:
        shutil.copy2(bak, path)
        return True
    except OSError:
        return False
