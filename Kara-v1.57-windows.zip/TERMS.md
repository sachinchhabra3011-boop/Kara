# Kara — Terms of Use

**DRAFT — REQUIRES LEGAL REVIEW.** Placeholders in [SQUARE BRACKETS] must be
completed before distribution.

Version 1.0-draft · Last updated: [DATE]

These Terms govern your use of Kara. They sit alongside:

- **LICENSE** — what you may and may not do with the software itself
- **PRIVACY.md** — what happens to your data
- **THIRD-PARTY-NOTICES.md** — the open-source components Kara uses

By installing or using Kara, you agree to these Terms. If you do not agree, do
not use Kara.

---

## 1. What Kara is

Kara is a personalised speech-to-text application for Windows. You record
yourself reading prompts; Kara builds a recognition model tuned to your voice;
you then dictate text, edit it by voice, and send it to other applications.

Kara is aimed at people whose speech is not reliably recognised by general
dictation software, including people with dysarthria and other speech
differences.

Kara is provided **free of charge** for personal use.

---

## 2. What Kara is not — please read this section

**Kara is not a medical device.** It does not diagnose, treat, assess, monitor or
manage any condition, and it is not speech therapy. It has not been reviewed or
approved by any medical device regulator.

**Kara is not reliable enough for critical use.** Speech recognition makes
mistakes — including mistakes that change meaning rather than producing obvious
nonsense. You must not use Kara for:

- emergency or distress communication;
- medical information, instructions, prescriptions or records;
- legal documents, filings or evidence;
- financial or payment instructions;
- operating vehicles, machinery or safety systems;
- any purpose where an error could cause harm, loss or injury.

**Always read what Kara has written before you send it or rely on it.**

---

## 3. Accuracy

How well Kara works depends on your voice, your microphone, the room you are in,
how many recordings you made, and your computer. Some people will get excellent
results; others will not. We make no promise about accuracy for any individual.

Kara may:
- write a word you did not say, or miss one you did;
- apply an edit to different text than you intended;
- mis-hear a command as dictation, or dictation as a command.

Where Kara is unsure which word you meant, it will ask rather than guess — but it
cannot detect every error, and it cannot know when it has heard you wrongly but
plausibly.

---

## 4. Your responsibilities

You agree to:

- review Kara's output before relying on it;
- keep your own backups of anything you care about;
- use Kara only for lawful purposes;
- respect other people's privacy when entering their names;
- not use Kara to create unlawful, harassing, defamatory or infringing content;
- secure your own computer, since your recordings and writing are stored on it.

---

## 5. Your content

Anything you dictate or write with Kara is **yours**. We claim no ownership of it
and no licence to use it. We never receive it — see PRIVACY.md.

You are responsible for your content, including for any personal data of other
people that you put into Kara.

---

## 6. Data and privacy

Kara stores your recordings, documents, vocabulary and settings **on your own
computer**. **Your voice never leaves it.** There is no server of ours and no
telemetry.

Some things can use the network, and none of them are your voice: a one-time
speech-model download, an update check that sends no content, and two optional
features that are off unless you switch them on — a grammar service (the only
thing that ever sends your writing) and backup to a folder you choose.
**PRIVACY.md section 4 lists every one of them exactly**, and is the authority
if this summary and it ever disagree.

**Kara has no account and no sign-in.** There is nothing to register for and
nothing in the software that can hold a credential.

Important practical points:
- your files are **not encrypted**;
- profiles are **not password-protected** and are not a security boundary;
- **deleting a document sends the file to the Windows Recycle Bin**, so an
  accidental tap is recoverable by you, in Windows — and emptying the Recycle
  Bin destroys it for good. If the Recycle Bin is unavailable, the file is
  deleted outright, because "deleted" has to mean deleted;
- Kara keeps the audio of your **last few utterances** so that correcting it
  teaches it something. It is a fixed-size buffer, it never leaves your
  machine, and you can switch it off — see PRIVACY.md section 2;
- uninstalling Kara does not delete your data unless you confirm.

The full detail is in PRIVACY.md, which forms part of these Terms.

---

## 7. Availability, updates and support

Kara is provided as-is. We are not obliged to provide updates, fixes, support, or
continued availability, and we may stop distributing or developing Kara at any
time. Because Kara runs entirely on your computer, it will keep working if we do
— it does not depend on any service we operate.

---

## 8. Third-party components

Kara is built on open-source software listed in THIRD-PARTY-NOTICES.md. Those
components are licensed under their own terms, which prevail in respect of them.
Kara's use of the Qt framework under the LGPL-3.0 grants you specific rights in
respect of that component, described in that document.

---

## 9. Disclaimers and liability

**Kara is provided "as is", without warranties of any kind**, to the maximum
extent permitted by law. See Section 9 of the LICENSE for the full disclaimer.

**Our liability to you is limited** to the maximum extent permitted by law. See
Section 10 of the LICENSE.

Nothing in these Terms excludes or limits liability for death or personal injury
caused by negligence, for fraud, or for anything else that cannot lawfully be
excluded. **Nothing in these Terms affects your statutory rights as a consumer.**

---

## 10. Accessibility

Kara is built with accessibility as its purpose, but it is not certified against
any accessibility standard and we make no claim of conformance. If something
about Kara makes it hard for you to use, we would genuinely like to hear about
it: [CONTACT EMAIL].

---

## 11. Ending these Terms

You may stop using Kara at any time. These Terms end automatically if you breach
them. Sections 2, 3, 5, 9 and 12 continue to apply afterwards.

---

## 12. General

**Governing law:** [JURISDICTION].
**Courts:** [JURISDICTION], except where mandatory consumer law lets you bring
proceedings where you live.
**Changes:** if we change these Terms materially, the new version will be shown
in the app and you will be asked to confirm you have read it. Continuing to use
Kara after that means you accept the change.
**Severability:** if part of these Terms is unenforceable, the rest continues.
**Entire agreement:** these Terms, the LICENSE, PRIVACY.md and
THIRD-PARTY-NOTICES.md are the whole agreement between us about Kara.

---

## Contact

[LEGAL NAME]
[CONTACT EMAIL]
