# Kara — Privacy Notice

**DRAFT — REQUIRES LEGAL REVIEW.** Placeholders in [SQUARE BRACKETS] must be
completed. If Kara is distributed in the EU/UK, or to children, the flagged
sections need specialist advice before release.

Version 1.0-draft · Last updated: [DATE]

---

## The short version

**Your voice never leaves your computer.**

Your recordings, the text you write and the names you enter are ordinary files
on your own machine. There is no server of ours, and no analytics. We — the
makers of Kara — never receive any of it, never see it, and have no way to.

Kara works with the network unplugged. Around that, a few things *can* use it,
and none of them are your voice:

- a **one-time download** of a general-purpose speech model, which sends
  nothing about you;
- an **update check** that asks whether a newer version exists and sends no
  content at all;
- an optional **grammar service** that sends **the text you have written** —
  the only thing that ever sends your writing, and **off by default**;
- optional **backup to a folder you choose**, which is you moving your own
  data — and if that folder syncs to the cloud, your copy goes with it.

Section 4 lists all of it exactly. "We keep it local" is a claim worth being
precise about, so the precision is there rather than here.

---

## 1. Who is responsible

[LEGAL NAME] ("we", "us") makes Kara available.
Contact: [CONTACT EMAIL]
[Postal address, if required in your jurisdiction]

Because Kara processes your data only on your own device and we never receive
it, we do not act as a data controller in respect of that data in normal use.
**You** control it. This notice is provided so you can understand what the
software does with it.

> ⚠ **For legal review:** confirm this characterisation for each jurisdiction of
> distribution. Some regulators take the view that the software provider is a
> controller in respect of design decisions even where no data is transmitted.

---

## 2. What Kara stores, and where

All of the following is written to your computer's disk, inside Kara's own
folder, under your Windows user account:

| What | Why | Format |
|---|---|---|
| Voice recordings made during setup | To build a speech model tuned to your voice | Audio files (`.wav`) |
| A record of what each recording was meant to say | To pair audio with text for training | Spreadsheet (`.csv`) |
| Documents you dictate | So your writing is saved and can be reopened | Plain text (`.txt`) |
| Names and places you enter | So Kara spells the people and places you talk about correctly | Text (`.json`) |
| Your personalised speech model | It is what makes Kara understand you | Model files |
| Settings — chosen microphone, speaker, model | To remember your preferences | Text (`.json`) |
| A profile photo, if you add one | To identify your profile on screen | Image file you choose |
| Words you added to your dictionary, or told Kara to ignore | So it stops underlining words you know are right | Text (`.json`) |
| Voice commands you add yourself | So your own phrases keep working | Text (`.json`) |
| Practice scores | To show progress over time. Numbers only — no audio, no words | Text (`.json`) |
| A technical log | So a fault can be diagnosed. It contains no recordings, no writing and no names | Text (`.log`) |

### The last few things you said are kept, on purpose

**Kara keeps the audio of your most recent utterances — currently the last 40 —
on your computer.** This is on by default and you can turn it off in
Settings ▸ Privacy.

It exists for one reason: when you correct something Kara got wrong, it can
only learn from the correction if it still has the audio that caused it. That
is what makes Kara get better at your voice over time rather than staying as it
was on the first day.

What that means concretely:

- It is a **fixed-size buffer**. The 41st recording pushes out the first. It
  does not grow.
- It is **never included in a backup or a diagnostics file**, and never leaves
  your machine.
- **Turning the setting off deletes the ones already kept**, and there is a
  *Forget recordings* button that clears them without turning the setting off.

Everything older than that buffer is written to a temporary file, transcribed,
and deleted. The recordings you deliberately make during setup are separate and
are kept until you delete them.

> ⚠ **Corrected 2026-08-17.** An earlier version of this notice said audio of
> day-to-day dictation was "not kept… deleted immediately". That was wrong and
> had been since the adaptation loop was added. It is recorded here rather than
> quietly replaced, because a privacy notice that overstates what a product
> deletes is the kind of error a reader deserves to know was made.

---

## 3. Things you should know about how it is stored

We would rather tell you these plainly than let you assume otherwise.

- **The files are not encrypted.** They are ordinary files. Anyone who can log
  into your Windows account, or who has physical access to an unencrypted disk,
  can open them. If you need protection against that, use full-disk encryption
  such as Windows BitLocker.

- **Profiles are not password-protected.** If more than one person uses Kara on
  the same computer, profiles keep their recordings and writing separate for
  convenience, but any profile can be opened from within the app without a
  password. Profiles are an organisational feature, **not a security boundary**.

- **Deleting a document sends it to the Windows Recycle Bin.** Kara keeps no
  hidden copy. It goes to the Recycle Bin rather than vanishing outright so that
  an accidental tap is recoverable — but it is recoverable *by you, in Windows*,
  and emptying the Recycle Bin destroys it for good.

- **Uninstalling asks what to do with your data.** The uninstaller offers to
  delete your recordings, writing and trained models, and keeps them unless you
  explicitly confirm. It never deletes them silently, because they are hours of
  work that cannot be recreated without redoing the whole setup.

- **You can erase everything from inside Kara.** Settings ▸ About ▸ *Delete
  everything for this profile* removes all recordings, pages, models, names and
  settings for that profile. It asks twice, tells you exactly what will go, and
  cannot be undone.

---

## 4. Network activity — in full

Kara is designed to work offline, and **your voice never leaves your computer
under any circumstances.** That is the promise, and it has no exceptions.

Around it there are four things that *can* use the network. Three are off, or
one-time, or send nothing about you. One sends the text you write, and it is
off by default. Here is every one of them:

| What | When | What it sends | Default |
|---|---|---|---|
| **Speech model download** | Once, the first time a base model is needed | Nothing about you — an ordinary file request to `huggingface.co` | — |
| **Update check** | On launch | Asks a URL whether a newer version exists. **No content**: no recordings, no writing, no identifier | **On** |
| **Grammar service** | Only while Offline Mode is **off** | **The sentences you have written**, to a LanguageTool server, to be checked | **Off** |
| **Folder backup** | Only if you choose a folder | A copy of your recordings and writing. If you point it inside OneDrive or Google Drive, **that service takes it off your machine** | **Off** |

**Kara has no account and no sign-in of any kind.** An optional Google sign-in
existed in earlier versions — identity only; it never uploaded anything — and it
was **removed entirely on 2026-08-17**, along with the code that stored a token
on your machine. There is now nothing in Kara that can hold a credential.

Three of those deserve saying in plain words rather than in a table:

- **The grammar service is the only thing that ever sends your writing**, and
  it is why Offline Mode exists as a switch rather than an assumption. With
  Offline Mode on — the default — Kara does not use the network for grammar at
  all, and the check it does locally is worse but private. Turning it off buys
  a better grammar check and is the moment your text starts leaving the
  machine. The server address is yours to change: point it at a LanguageTool
  server you run and the text stays on your own network.
- **The update check is a separate setting from Offline Mode** precisely
  because it sends nothing. You can leave updates on while everything else
  stays local. It can be turned off in Settings ▸ About.
- **Folder backup is you moving your own data.** Kara copies to the folder you
  name. If that folder happens to be inside a syncing service, the copy leaves
  your computer — not because Kara sent it anywhere, but because you put it
  somewhere that syncs. The app says so at the moment you choose the folder.

Kara contains **no** analytics, telemetry, crash reporting, advertising, or
tracking of any kind.

### Diagnostics you send deliberately

Settings ▸ About ▸ *Save diagnostics* writes a zip file for you to send to
whoever is helping you. Nothing sends it automatically — you choose to, and you
can open it and read it first.

It contains the technical log and a description of your computer. It
**deliberately and permanently excludes** your recordings, your documents, the
list of sentences you were asked to read, the names you taught Kara, and your
profile photo. Profile names are stripped out of the log both when it is written
and again when the zip is built.

> ⚠ **Corrected 2026-08-17.** An earlier version of this section said there was
> "exactly one exception" and that Kara contained no automatic update
> mechanism. Both were out of date: the update check, the optional grammar
> service, sign-in and folder backup had all been added since. The voice-never-
> leaves promise was and is true; the "one exception" framing around it was not.
> **Updated again the same day**, when sign-in was removed from the product and
> this table lost a row.

---

## 5. Special categories of data

We flag this because it matters, and because being vague about it would be worse
than saying it directly.

- A **voice recording is biometric-adjacent data**. In some jurisdictions,
  recordings processed for the purpose of identifying a person are "biometric
  data" and receive heightened protection. Kara does not use your voice to
  identify you — it uses it to transcribe you — but the recordings exist.

- Kara is designed for people whose speech differs from the norm, often because
  of a disability. The existence of a Kara profile, and the content of the
  recordings, may therefore **imply information about health or disability**,
  which is a special category of personal data under the UK/EU GDPR and similar
  laws.

Kara's answer to both is architectural: this data never leaves your device, and
we never receive it. That materially reduces the risk, but you should be aware
of what the files on your disk contain.

> ⚠ **For legal review:** if Kara is distributed in the UK/EU, confirm whether a
> lawful basis analysis and/or DPIA is required notwithstanding local-only
> processing. Also confirm the position under India's DPDP Act 2023 and any
> other jurisdiction of distribution.

---

## 6. Other people's personal data

During setup, Kara invites you to enter the names of people you talk about, so
that it spells them correctly. Those names are personal data about **other
people**, stored on your machine.

You are responsible for that. Only enter what you need, and be aware that those
names sit in a file on your computer like any other note you might keep.

---

## 7. Children

Kara has no age verification. If a child uses Kara, the person responsible for
them should read this notice and decide whether it is appropriate, and should be
aware that recordings of the child's voice will be stored on the device.

> ⚠ **For legal review:** if under-18s are an expected user group — which is
> plausible for assistive technology — additional obligations may apply,
> including the UK Age Appropriate Design Code, COPPA in the US, and equivalents.

---

## 8. Your rights over your data

Because your data is on your own computer and we never hold a copy, you exercise
your rights directly rather than by asking us:

- **Access / portability** — open the files. Documents are plain text, readable
  in any editor. Recordings are standard `.wav` files.
- **Erasure** — Settings ▸ About ▸ *Delete everything for this profile* erases
  it all from inside the app. You can also delete the files or the whole Kara
  data folder yourself, and the uninstaller offers to do it.
- **Rectification** — edit the text in Kara or in any editor.
- **Objection / restriction** — stop using Kara; nothing continues in the
  background.

If you believe we hold personal data about you notwithstanding the above,
contact [CONTACT EMAIL].

You also have the right to complain to a supervisory authority
([relevant authority, e.g. the ICO in the UK]).

---

## 9. Retention

We set no retention period, because we hold nothing. Your data stays on your
computer until you delete it. Kara will not delete your setup recordings or
your documents on its own.

**One thing does expire, by design:** the buffer of recent utterance audio
described in section 2. It holds a fixed number of recordings — currently 40 —
and each new one pushes out the oldest. That is the only data Kara deletes
without being asked, and it deletes it to keep the buffer from growing rather
than to tidy up after you.

---

## 10. Security

Kara reduces risk mainly by not moving your data: there is no server to breach
and no transmission to intercept. Beyond that, the security of the data depends
on the security of your computer — your Windows account password, disk
encryption, and who has physical access to the machine.

We do not claim the software is free of vulnerabilities. If you find one, please
report it to [SECURITY CONTACT EMAIL].

---

## 11. Changes to this notice

If this notice changes materially, the updated version will be presented in the
application and you will be asked to confirm you have read it.

---

## 12. Contact

[LEGAL NAME]
[CONTACT EMAIL]
