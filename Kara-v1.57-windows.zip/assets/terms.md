# In-app summary of TERMS.md / PRIVACY.md / LICENSE, written in plain language.
#
# This is what the setup wizard shows on its "Before you start" page. It is a
# SUMMARY and says so; the full documents live at the top level of the project
# and are what actually binds. Keep this file and those documents in step.
#
# Edit freely -- the app re-reads this at runtime, no code change needed. Lines
# starting with "#" at the top are stripped as comments.
#
# WHEN THE MEANING CHANGES: bump TERMS_VERSION in src/gui.py, or people stay
# "accepted" against words they never saw.

## What Kara does

Kara turns what you say into written text, and learns your voice so it
understands you better over time.

It is free to use for yourself, your family, or someone you support.

## Everything stays on this computer

Kara has no account and no sign-in. There are no servers. Your recordings, the
pages you write, and the names you add are saved on this computer only. We never
receive them and cannot see them.

The one exception is the very first setup, when Kara downloads the general
speech model it starts from. That download tells us nothing about you.

## What is saved here

- The recordings you make during setup
- The pages you write
- Names and places you add, so Kara spells them correctly
- Your personal speech model, once it is trained

What you dictate day to day is **not** kept as audio — only the words.

Three things worth knowing:

- These are ordinary files, and they are **not locked or encrypted**. Anyone who
  can sign in to this Windows account can open them.
- If several people use Kara here, their profiles are kept separate for tidiness,
  but there is **no password** on them.
- Deleting a page sends it to the Recycle Bin, so a slip is recoverable — Kara
  keeps no hidden copy of its own.

You can delete everything at any time: **Settings ▸ About ▸ Delete everything**.
Uninstalling Kara also asks whether to remove your data.

## Kara makes mistakes

Kara will sometimes write a word you did not say. How often depends on your
voice, your microphone, the room, and how much you recorded.

**Please read what Kara writes before you send it.**

## What Kara is not

Kara is a writing tool. It is **not a medical device**, it does not diagnose or
treat anything, and it is not speech therapy.

Please do not use Kara where a mistake could hurt someone — emergency messages,
medical instructions, legal or money matters, or anything you must be able to
rely on completely.

## Your writing is yours

We claim no ownership of anything you write, and no right to use it.

If you add someone else's name so Kara can spell it, that is your call, and it
stays on this computer like everything else.

## The legal part

Kara is provided as it is, with no promise that it will be accurate or fault
free. Our responsibility to you is limited as far as the law allows — but
nothing here takes away rights the law gives you.

The full Terms, Privacy Notice and Licence are included with Kara and are what
formally applies.

By continuing, you confirm you have read this.
