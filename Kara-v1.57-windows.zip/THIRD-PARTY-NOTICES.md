# Third-party notices

**DRAFT — verify before distribution.** Licence identifiers below were read from
the installed package metadata on 2026-07-27. Versions and terms must be
re-checked whenever dependencies change.

Kara incorporates the third-party components listed here. Each is provided under
its own licence, which governs that component and takes precedence over Kara's
own licence in respect of it. Full licence texts are distributed with each
package inside the application's Python environment (`.venv/Lib/site-packages/`)
and are reproduced in `licenses/` where required.

---

## ⚠ Qt / PySide6 — LGPL-3.0 (obligations apply)

**PySide6, PySide6-Essentials, PySide6-Addons, shiboken6** — v6.11.1
Copyright © The Qt Company Ltd.
Licensed under **GNU Lesser General Public License v3.0** (LGPL-3.0-only), with
the option of GPL-2.0-only or GPL-3.0-only.

This is the component with the most significant obligations. Because Kara is
distributed as Python source or bytecode with PySide6 as a **separate,
dynamically-loaded package**, the LGPL's relinking requirement is satisfied in
the ordinary case. To remain compliant, any distribution of Kara **must**:

1. State that Kara uses Qt via PySide6 under the LGPL-3.0 (this document does so);
2. Include or link to the full text of the LGPL-3.0 and GPL-3.0;
3. Keep PySide6 replaceable — i.e. do **not** statically link, bundle it into a
   single-file frozen executable in a way that prevents substitution, or
   otherwise prevent the user from swapping in their own build of Qt/PySide6;
4. Not impose terms that restrict the user's LGPL rights in that component.

> **Action required if you ever package Kara with PyInstaller/Nuitka into a
> one-file executable:** that may compromise item 3. Use a one-folder build, or
> provide the object files/instructions needed to relink, or obtain a commercial
> Qt licence.

Qt source: <https://download.qt.io/>
LGPL-3.0: <https://www.gnu.org/licenses/lgpl-3.0.html>

---

## Speech models

**OpenAI Whisper models** (`whisper-small`, `whisper-medium`, `whisper-large-v3`)
Copyright © OpenAI. Licensed under the **MIT Licence**.
Model weights are downloaded from the Hugging Face Hub on first use and are not
redistributed with Kara. Kara distributes **fine-tuned adapter weights** derived
from these models where a personalised model is shared; those derivatives are
subject to the same MIT terms.
<https://github.com/openai/whisper>

---

## Machine-learning stack

| Component | Version | Licence |
|---|---|---|
| PyTorch (`torch`) | 2.5.1+cu121 | BSD-3-Clause |
| `transformers` | 5.13.0 | Apache-2.0 |
| `peft` | 0.19.1 | Apache-2.0 |
| `accelerate` | 1.14.0 | Apache-2.0 |
| `tokenizers` | 0.22.2 | Apache-2.0 |
| `safetensors` | 0.8.0 | Apache-2.0 |
| `huggingface-hub` | 1.23.0 | Apache-2.0 |
| `faster-whisper` | 1.2.1 | MIT |
| `ctranslate2` | 4.8.1 | MIT |
| `onnxruntime` | 1.28.0 | MIT |
| `av` (PyAV) | 18.0.0 | BSD-3-Clause |
| `numpy` | 2.5.1 | BSD-3-Clause |
| `sympy` | 1.13.1 | BSD-3-Clause |
| `networkx` | 3.6.1 | BSD-3-Clause |

**Apache-2.0 components** require that you retain the licence, the NOTICE file
where one exists, and a statement of any changes you make to those files.

> **Note on CUDA.** The `+cu121` PyTorch build links NVIDIA CUDA runtime
> libraries, which are governed by the **NVIDIA Software Licence Agreement**,
> not by an open-source licence. Redistributing those binaries has its own
> conditions — verify before shipping a bundled installer.
> <https://docs.nvidia.com/cuda/eula/>

---

## Audio

| Component | Version | Licence |
|---|---|---|
| `soundfile` | 0.14.0 | BSD-3-Clause |
| `sounddevice` | 0.5.5 | MIT |
| `soxr` | 1.1.0 | LGPL-2.1 (bindings: BSD) |

`soundfile` and `sounddevice` wrap **libsndfile** (LGPL-2.1) and **PortAudio**
(MIT). `soxr` wraps **libsoxr** (LGPL-2.1). The LGPL relinking considerations in
the Qt section apply equally to these libraries if you produce a statically
linked build.

---

## Utilities

| Component | Version | Licence |
|---|---|---|
| `psutil` | 7.2.2 | BSD-3-Clause |
| `pyspellchecker` | 0.9.0 | MIT |
| `pyperclip` | 1.11.0 | BSD-3-Clause |
| `PyYAML` | 6.0.3 | MIT |
| `filelock` | 3.29.0 | Unlicense |
| `charset-normalizer` | 3.4.9 | MIT |
| `requests` | 2.34.2 | Apache-2.0 |
| `urllib3` | 2.7.0 | MIT |
| `idna` | 3.18 | BSD-3-Clause |
| `Jinja2` / `MarkupSafe` | 3.1.6 / 3.0.3 | BSD-3-Clause |
| `regex` | 2026.6.28 | Apache-2.0 |
| `packaging` | 26.2 | Apache-2.0 / BSD-2-Clause |
| `fsspec` | 2026.4.0 | BSD-3-Clause |
| `tqdm` | 4.68.4 | MPL-2.0 AND MIT |
| `certifi` | 2026.6.17 | MPL-2.0 |

`pyspellchecker` bundles an English word-frequency list derived from public
domain and permissively licensed corpora, shipped inside the wheel. It is what
lets the spelling checker work with no network access at any point, which is a
requirement here rather than a convenience.
| `jiwer` | 4.0.0 | Apache-2.0 |
| `cffi` | 2.1.0 | MIT |

**MPL-2.0 components** (`certifi`, part of `tqdm`) are file-level copyleft: if
you modify those files you must publish the modified files under MPL-2.0.
Unmodified use imposes no such duty.

---

## Fonts and assets

**Source Sans 3** — used as Kara's display typeface where available on the
system. Copyright © Adobe. Licensed under the **SIL Open Font License 1.1**.
Kara does not currently bundle this font; it is used if installed, otherwise
Kara falls back to fonts supplied with the operating system.
<https://github.com/adobe-fonts/source-sans>

**Segoe UI / Segoe UI Variable** — supplied with Microsoft Windows and used, not
redistributed, under the terms of the operating system licence.

> **Removed 2026-07-27:** a proprietary brand typeface previously present in
> `assets/` was removed because it could not lawfully be redistributed. Do not
> reintroduce any font without confirming its licence permits redistribution.

---

## Prompt corpora

Kara's onboarding prompts (`data/prompts/setup_*.txt`) are original works
created for this project and are covered by Kara's own licence.

The **Harvard/IEEE sentences** (`data/prompts/harvard.txt`), where used, are from
IEEE Recommended Practice for Speech Quality Measurements and are in the public
domain.

---

## How to obtain source code

Where a component's licence entitles you to its source code (including the
LGPL-licensed components above), it may be obtained from the linked project pages
or from the Python Package Index at <https://pypi.org/>. Requests may also be
sent to [CONTACT EMAIL].
