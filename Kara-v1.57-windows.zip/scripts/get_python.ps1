# Install Python 3.12 for someone who should not have to do it themselves.
#
# WHY THIS EXISTS. "Go to python.org, download the 64-bit installer, and
# remember to tick Add to PATH" is three chances to get it wrong before Kara has
# even started -- and the person Kara is for cannot type. A dictation tool whose
# first instruction is a manual download has already failed the user it was
# built for.
#
#   powershell -ExecutionPolicy Bypass -File scripts\get_python.ps1
#
# Exit 0 = Python 3.12 is now available. Anything else = it is not, and the
# caller should fall back to telling the person what to download.

$ErrorActionPreference = "Stop"
$VER = "3.12.10"

function Say($m)  { Write-Host "`n=== $m" -ForegroundColor Cyan }
function Ok($m)   { Write-Host "  OK   $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  WARN $m" -ForegroundColor Yellow }

function Find-Python312 {
    # `py -3.12` is the honest test -- it is what setup.ps1 uses. But a
    # just-installed Python is NOT on this process's PATH: the environment was
    # captured when this shell started, and nothing refreshes it. So the known
    # per-user location is checked too, and returned as a full path.
    try {
        & py -3.12 --version 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { return "py" }
    } catch { }
    $candidates = @(
        "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
        "$env:ProgramFiles\Python312\python.exe"
    )
    foreach ($c in $candidates) {
        if (Test-Path $c) {
            try {
                $v = & $c --version 2>$null
                if ($v -match "3\.12") { return $c }
            } catch { }
        }
    }
    return $null
}

Say "Python 3.12"
$found = Find-Python312
if ($found) { Ok "already installed"; exit 0 }

Write-Host "  Not installed. Kara will fetch it -- about 25 MB."
Write-Host "  Installing for you only, so Windows will not ask for an administrator."

# ---------------------------------------------------------------- winget
# FIRST CHOICE. winget ships with Windows 10/11, verifies what it downloads
# against its own catalogue, and knows how to put python on PATH -- all of
# which is work this script would otherwise be doing by hand, less well.
$wingetOk = $false
try { & winget --version *> $null; $wingetOk = ($LASTEXITCODE -eq 0) } catch { }

if ($wingetOk) {
    Say "Installing with winget"
    try {
        $prev = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        # --scope user keeps it out of Program Files, which is what avoids the
        # administrator prompt. The two --accept flags are required for an
        # unattended run; without them winget waits for a keypress nobody is
        # there to give.
        & winget install --id Python.Python.3.12 -e --source winget `
            --scope user --accept-package-agreements --accept-source-agreements `
            --disable-interactivity *> $null
        $ErrorActionPreference = $prev
    } catch {
        $ErrorActionPreference = "Stop"
        Warn "winget could not do it; trying the direct download"
    }
    $found = Find-Python312
    if ($found) { Ok "installed via winget"; exit 0 }
    Warn "winget did not leave a usable Python; trying the direct download"
}

# ------------------------------------------------------- direct download
# FALLBACK, straight from python.org over HTTPS. Same file a person would
# download by hand, with the two options they would have to remember set for
# them: user-scope, and on PATH.
Say "Downloading from python.org"
$url = "https://www.python.org/ftp/python/$VER/python-$VER-amd64.exe"
$exe = Join-Path $env:TEMP "python-$VER-amd64.exe"
try {
    # The progress bar makes Invoke-WebRequest an order of magnitude slower on
    # a large file, and nobody is watching this one.
    $ProgressPreference = "SilentlyContinue"
    Invoke-WebRequest -Uri $url -OutFile $exe -UseBasicParsing -TimeoutSec 600
} catch {
    Warn "download failed: $($_.Exception.Message)"
    exit 1
}

# CHECK WHAT ARRIVED BEFORE RUNNING IT, and check it properly.
#
# A captive-portal login page or a truncated transfer is still a file, and this
# script is about to execute whatever it just fetched on somebody else's
# computer. Shape first -- ~25 MB, starts with "MZ" -- and then the thing that
# actually matters: the installer is Authenticode-signed by the Python Software
# Foundation, so Windows can confirm both WHO made it and that not a byte has
# changed since. HTTPS alone says the connection was private, not that the file
# is the right one.
$size = (Get-Item $exe).Length
$head = [System.IO.File]::ReadAllBytes($exe)[0..1]
if ($size -lt 10MB -or -not ($head[0] -eq 0x4D -and $head[1] -eq 0x5A)) {
    Warn "what downloaded is not a Windows installer ($([math]::Round($size/1MB,1)) MB). Not running it."
    Remove-Item $exe -Force -ErrorAction SilentlyContinue
    exit 1
}
$sig = Get-AuthenticodeSignature $exe
if ($sig.Status -ne "Valid" -or $sig.SignerCertificate.Subject -notmatch "Python Software Foundation") {
    Warn "the download is not validly signed by the Python Software Foundation."
    Warn "status: $($sig.Status). Not running it."
    Remove-Item $exe -Force -ErrorAction SilentlyContinue
    exit 1
}
Ok "downloaded $([math]::Round($size/1MB,1)) MB, signed by the Python Software Foundation"

Say "Installing"
Write-Host "  This takes a minute and shows no window."
$p = Start-Process -FilePath $exe -Wait -PassThru -ArgumentList @(
    "/quiet",
    "InstallAllUsers=0",      # just this user -- no administrator prompt
    "PrependPath=1",          # the tick people forget, which breaks everything after
    "Include_test=0",
    "Include_launcher=1",     # `py` itself, which is what setup.ps1 looks for
    "SimpleInstall=1"
)
Remove-Item $exe -Force -ErrorAction SilentlyContinue

$found = Find-Python312
if ($found) { Ok "installed"; exit 0 }

Warn "the installer finished with code $($p.ExitCode) but Python is still not visible"
Warn "A restart of the computer usually settles this -- PATH is read once when a"
Warn "program starts, and Kara is already running from the old one."
exit 1
