import argparse
import ctypes
import math
import os
import re
import sys
import tempfile
import textwrap
import threading
import time
from pathlib import Path
import numpy as np
import soundfile as sf
from PySide6.QtCore import QPoint, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QSyntaxHighlighter, QTextCharFormat
from PySide6.QtWidgets import QApplication, QCheckBox, QComboBox, QDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QProgressBar, QPushButton, QScrollArea, QSlider, QStackedWidget, QTextEdit, QVBoxLayout, QWidget
import analytics
import app as appmod
import cloudsync
import config
import editing
import errors
import library
import karalog
import profiles as profile
import proofing
import prompts as promptsets
import punctuation
import record
import setup_prompts
import spelling
import usercommands
import voices
import transfer
import utterances
import icons
from icons import Avatar, AvatarButton, GlyphIcon, IconButton, Mark, Spinner, ToggleSwitch, Wordmark
from micorb import MicOrb
ROOT = Path(__file__).resolve().parent.parent
DEFAULT_MODEL = 'medium'
DEFAULT_ADAPTER = None
MODEL_OPTIONS = {'tiny': {'label': 'Tiny — for older computers', 'bf16': False, 'note': 'Runs on almost anything and answers instantly. Least accurate of the six.'}, 'base': {'label': 'Base — light', 'bf16': False, 'note': 'A step up from Tiny and still light on the machine.'}, 'small': {'label': 'Small — fast', 'bf16': False, 'note': 'Quick to respond, and a little rougher.'}, 'medium': {'label': 'Medium — recommended', 'bf16': False, 'note': 'The daily driver: accurate, and quick enough to feel immediate on most machines.'}, 'large-v3-turbo': {'label': 'Large Turbo — quicker Large', 'bf16': True, 'note': 'Much faster than Large for a small accuracy cost, if you have a good graphics card.'}, 'large-v3': {'label': 'Large — most accurate', 'bf16': True, 'note': 'Most accurate, slowest to load and run. Needs the GPU.'}}

def accuracy_clause(key: str, speaker: str | None=None) -> str:
    if speaker:
        try:
            import analytics
            for row in reversed(analytics.history(speaker)):
                if row.get('model') == key and row.get('candidate_wer') is not None:
                    return t('%.1f%% error, measured on your voice.') % (float(row['candidate_wer']) * 100,)
        except Exception:
            pass
    try:
        import calibrate
        wer = (calibrate.MODELS.get(key, {}).get('typical_wer') or '').strip()
    except Exception:
        wer = ''
    if not wer or wer == 'not measured':
        return t('Not yet measured.')
    return t('%s error on the voice it was measured on — not yours.') % (wer,)
MODEL_LADDER = list(MODEL_OPTIONS)
RECOMMENDED_MODEL = 'medium'
BETA_FEATURES = {'hindi_ui': "Kara's own words in Hindi or Hinglish", 'hindi_speech': 'dictating in Hindi', 'correction': 'the Correction panel'}

def _is_beta_language(code: str | None) -> bool:
    c = (code or 'en').strip().lower()
    return c != 'en' and (c in i18n.NEEDS_REVIEW or c.split('-')[0] != 'en')

def _adapter_for(model: str, speaker: str) -> str | None:
    a = profile.adapter_for(speaker, model)
    return str(a) if a else None
APP_NAME = 'Kara'
VERSION = '1.1'
THEMES = {'brown': {'canvas': '#34190e', 'surface': '#42231a', 'line': '#5a3527', 'ink': '#f4ece4', 'ink_soft': '#c3ab98', 'beige': '#a58970', 'beige_text': '#c9ae94', 'blue': '#7aa5d6', 'red': '#e08a78', 'green': '#9fc98a', 'purple': '#e2a184', 'amber': '#e0b463', 'on_accent': '#34190e', 'blue_bg': '#26313f', 'red_bg': '#4d2a20', 'green_bg': '#2b3a26', 'purple_bg': '#4d2a20', 'amber_bg': '#4a3320', 'beige_bg': '#4a2c20', 'hover': '#4e2c21', 'disabled_bg': '#3d2118', 'disabled_fg': '#7a6659', 'blue_hover': '#9dbde2', 'red_hover': '#eaa595', 'paper': '#a58970', 'paper_ink': '#34190e', 'paper_dim': '#4a2c1c', 'hi_bg': '#7a3f14', 'hi_fg': '#f7ecdf'}, 'dark': {'canvas': '#1b1c1e', 'surface': '#26282b', 'line': '#3c4043', 'ink': '#e8eaed', 'ink_soft': '#9aa0a6', 'beige': '#8ab4f8', 'beige_text': '#a8c7fa', 'blue': '#8ab4f8', 'red': '#f28b82', 'green': '#81c995', 'purple': '#d7aefb', 'amber': '#fdd663', 'on_accent': '#202124', 'blue_bg': '#1f2a3d', 'red_bg': '#3a2523', 'green_bg': '#1f3327', 'purple_bg': '#2e2440', 'amber_bg': '#3a3320', 'beige_bg': '#1f2a3d', 'hover': '#2f3134', 'disabled_bg': '#303134', 'disabled_fg': '#6b6f74', 'blue_hover': '#a8c7fa', 'red_hover': '#f6a9a1', 'paper': '#26282b', 'paper_ink': '#e8eaed', 'paper_dim': '#9aa0a6', 'hi_bg': '#3a3320', 'hi_fg': '#fdd663'}, 'dusk': {'canvas': '#15111c', 'surface': '#1f1929', 'line': '#332a42', 'ink': '#f0e9f3', 'ink_soft': '#a99db6', 'beige': '#e8a06a', 'beige_text': '#f0b98a', 'blue': '#8fb8e8', 'red': '#f28b84', 'green': '#9fd0a8', 'purple': '#c9a8e8', 'amber': '#e8c07a', 'on_accent': '#15111c', 'blue_bg': '#22304a', 'red_bg': '#43242c', 'green_bg': '#23342a', 'purple_bg': '#2f2440', 'amber_bg': '#3d3222', 'beige_bg': '#3a2a2a', 'hover': '#2a2135', 'disabled_bg': '#241d2f', 'disabled_fg': '#6f6480', 'blue_hover': '#a9c9ef', 'red_hover': '#f6a49e', 'paper': '#1f1929', 'paper_ink': '#f0e9f3', 'paper_dim': '#a99db6', 'hi_bg': '#5a3a5e', 'hi_fg': '#fbeef7'}, 'daylight': {'canvas': '#faf7f4', 'surface': '#ffffff', 'line': '#d8d0c8', 'ink': '#1c1720', 'ink_soft': '#5d5566', 'beige': '#ad5826', 'beige_text': '#8f4a18', 'blue': '#1f5fa8', 'red': '#b3241c', 'green': '#2f6b38', 'purple': '#6b3fa0', 'amber': '#8a6212', 'on_accent': '#ffffff', 'blue_bg': '#dfe9f6', 'red_bg': '#f8e3e1', 'green_bg': '#e2efe4', 'purple_bg': '#ece3f6', 'amber_bg': '#f6eeda', 'beige_bg': '#f6e6da', 'hover': '#f0eae4', 'disabled_bg': '#ece7e2', 'disabled_fg': '#9a9189', 'blue_hover': '#17497f', 'red_hover': '#8d1c16', 'paper': '#ffffff', 'paper_ink': '#1c1720', 'paper_dim': '#6b6374', 'hi_bg': '#ffe2b8', 'hi_fg': '#3a2a10'}}

def _theme_name() -> str:
    try:
        import config as _config
        want = (_config.load().get('theme') or 'dusk').strip()
        return want if want in THEMES else 'dusk'
    except Exception:
        return 'dusk'
THEME = _theme_name()
P = THEMES[THEME]
import i18n
from i18n import t

def _ui_language() -> str:
    try:
        import config as _config
        return (_config.load().get('ui_language') or 'en').strip().lower() or 'en'
    except Exception:
        return 'en'
i18n.use(_ui_language())
DISPLAY_STACK = ['Sitka Display', 'Sitka Text', 'Century Gothic', 'Segoe UI Semibold', 'Segoe UI Variable Display', 'Segoe UI', 'Georgia', 'Arial']
SANS_STACK = "'Segoe UI Variable Text', 'Segoe UI', 'Source Sans 3', Roboto, sans-serif"
PAPER_STACK = "'Sitka Text', 'Constantia', 'Georgia', 'Cambria', serif"
CAPTION_SIZE = 12
CAPTION_TRACK = '1.2px'

def display_font(size: int=14, weight: int=600) -> QFont:
    f = QFont()
    f.setFamilies(DISPLAY_STACK)
    f.setPointSize(size)
    f.setWeight(QFont.Weight(weight))
    return f
MODES = [('dictation', t('Dictation'), P['beige'], P['beige_bg']), ('editing', t('Editing'), P['beige'], P['beige_bg']), ('spelling', t('Spelling'), P['beige'], P['beige_bg'])]
LANGUAGES = [('en', 'English'), ('hi', 'हिन्दी (Hindi) — beta')]
UI_LANGUAGES = [('en', 'English'), ('hi', 'हिन्दी (Hindi) — beta'), ('hi_latn', 'Hinglish (Roman Hindi) — beta')]
LANGUAGE_NOTES = {'hi': 'Beta. Kara will hear and write Hindi, but spell checking is off (no Hindi dictionary is installed) and the voice commands are still English. Accuracy is whatever the general model manages until you record Hindi clips and train on them.'}
_LT_LOCALE = {'en': 'en-US', 'pt': 'pt-PT', 'de': 'de-DE'}

def _lt_language(code: str) -> str:
    return _LT_LOCALE.get(code, code or 'en')
TEXT_APPS = {'notepad.exe', 'wordpad.exe', 'write.exe', 'notepad++.exe', 'code.exe', 'sublime_text.exe', 'atom.exe', 'gvim.exe', 'obsidian.exe', 'typora.exe', 'onenote.exe', 'onenoteim.exe', 'joplin.exe', 'standardnotes.exe', 'winword.exe', 'excel.exe', 'powerpnt.exe', 'outlook.exe', 'onenotem.exe', 'soffice.bin', 'soffice.exe', 'wps.exe', 'et.exe', 'wpp.exe', 'chrome.exe', 'msedge.exe', 'firefox.exe', 'brave.exe', 'opera.exe', 'vivaldi.exe', 'arc.exe', 'chromium.exe', 'thunderbird.exe', 'hxmail.exe', 'em client.exe', 'emclient.exe', 'slack.exe', 'discord.exe', 'teams.exe', 'ms-teams.exe', 'telegram.exe', 'whatsapp.exe', 'signal.exe', 'skype.exe', 'zoom.exe', 'element.exe', 'claude.exe', 'chatgpt.exe', 'cursor.exe', 'windsurf.exe', 'zed.exe', 'perplexity.exe', 'raycast.exe', 'notion.exe', 'evernote.exe', 'acrobat.exe', 'acrord32.exe', 'figma.exe', 'applicationframehost.exe'}
SILENCE_TIMEOUT = 15
ONLINE_RETRY_AFTER = 60.0
AUTO_BACKUP_EVERY = 10 * 60 * 1000
AUTO_BACKUP_FIRST = 90 * 1000
MODE_HINTS = {'dictation': 'Talk and it types. Say "spelled" then letters for a hard word.', 'editing': 'Commands, punctuation, capitals — "delete last word", "add a comma after hope", "second paragraph, delete the comma".', 'spelling': 'Say letters one at a time — "R, O, H, A, N".'}
BG_TEXTURE = (ROOT / 'assets' / 'background.png').as_posix()
_ROOT_BG = f'background-image: url("{BG_TEXTURE}"); background-repeat: repeat; background-position: top left;' if THEME == 'brown' else f"background: {P['canvas']};"
_SCROLLBAR = f"\nQScrollBar:vertical {{\n    background: transparent; width: 10px; margin: 2px 2px 2px 0;\n    border: none;\n}}\nQScrollBar:horizontal {{\n    background: transparent; height: 10px; margin: 0 2px 2px 2px;\n    border: none;\n}}\nQScrollBar::handle:vertical {{\n    background: {P['line']}; min-height: 36px;\n    border-radius: 5px; border: none;\n}}\nQScrollBar::handle:horizontal {{\n    background: {P['line']}; min-width: 36px;\n    border-radius: 5px; border: none;\n}}\nQScrollBar::handle:hover {{ background: {P['ink_soft']}; }}\n/* No step arrows and no page track: both are pure decoration here. */\nQScrollBar::add-line, QScrollBar::sub-line {{\n    height: 0; width: 0; border: none; background: none;\n}}\nQScrollBar::add-page, QScrollBar::sub-page {{ background: none; }}\nQAbstractScrollArea::corner {{ background: transparent; border: none; }}\n"
STYLESHEET = f"""\nQWidget {{\n    background: transparent; color: {P['ink']};\n    font-family: {SANS_STACK};\n}}\n{_SCROLLBAR}\n#Root {{ {_ROOT_BG} }}\n#Header {{ background: transparent; }}\n\n/* The ⓘ beside a settings heading, and the explanation it unfolds. Quiet\n   until pressed, accent while it is showing — the state has to be visible or\n   he cannot tell which heading he opened. */\nQPushButton#Info {{ background: transparent; color: {P['ink_soft']};\n    border: 1px solid {P['line']}; border-radius: 9px; min-width: 18px;\n    max-width: 18px; min-height: 18px; max-height: 18px;\n    font-size: 11px; font-weight: 700; padding: 0px; text-align: center; }}\nQPushButton#Info:hover {{ color: {P['ink']}; border-color: {P['beige']}; }}\nQPushButton#Info:checked {{ background: {P['beige']}; color: {P['on_accent']};\n    border-color: {P['beige']}; }}\nQLabel#Explain {{ color: {P['ink_soft']}; font-size: 13px;\n    border-left: 2px solid {P['beige']}; padding: 2px 0px 2px 10px; }}\n\n/* The live "might not be what you said" panel. */\nQFrame#SayCard {{ background: {P['surface']}; border: 1px solid {P['line']};\n    border-radius: 11px; }}\n/* BETA, and it has to read as a label rather than as a control: a pill in the\n   accent, small, never something you would try to press. */\nQLabel#BetaTag {{ background: {P['beige']}; color: {P['on_accent']};\n    border-radius: 7px; padding: 1px 7px; font-size: 9px; font-weight: 700;\n    letter-spacing: 1px; }}\n\n/* Header scaffolding (the temporary Setup button): quiet enough that it does\n   not compete with the wordmark it sits beside, obvious enough to find. */\nQPushButton#HeaderGhost {{ background: transparent; color: {P['ink_soft']};\n    border: 1px solid {P['line']}; border-radius: 8px; padding: 4px 11px;\n    font-size: 12px; font-weight: 600; }}\nQPushButton#HeaderGhost:hover {{ color: {P['ink']}; border-color: {P['beige']}; }}\n\n/* The accent button, GLOBALLY. #Primary was only ever styled inside the setup\n   wizard's own stylesheet, so the main window's Send button -- the most\n   consequential control in the app -- rendered as unstyled grey. */\nQPushButton#Primary {{\n    background: {P['beige']}; color: {P['on_accent']};\n    border: none; border-radius: 10px;\n    padding: 10px 24px; font-size: 14px; font-weight: 700;\n}}\nQPushButton#Primary:hover {{ background: {P['beige_text']}; }}\nQPushButton#Primary:disabled {{ background: {P['disabled_bg']}; color: {P['disabled_fg']}; }}\n/* The quieter sibling: outlined, for actions that are not the main one. */\nQPushButton#Test {{\n    background: transparent; color: {P['beige_text']};\n    border: 1px solid {P['line']}; border-radius: 10px;\n    padding: 8px 16px; font-size: 13px; font-weight: 600;\n}}\nQPushButton#Test:hover {{ border-color: {P['beige']}; color: {P['ink']}; }}\n/* The "N things wrong" chip, on the paper. Solid, so it never blends in. */\nQPushButton#GrammarChip {{\n    background: {P['red']}; color: {P['on_accent']};\n    border: none; border-radius: 6px;\n    padding: 3px 10px; font-size: 11px; font-weight: 700;\n}}\nQPushButton#GrammarChip:hover {{ background: {P['red_hover']}; }}\n\n/* #Mode (the old cycling pill) was removed 2026-08-03 -- the segmented control\n   replaced it and styles itself inline, per selected state. */\n\n/* The card is the writing surface. */\n#Card {{ background: {P['paper']}; border: 1px solid {P['line']}; border-radius: 14px; }}\n/* transparent, or it paints a strip across the paper */\n/* THE THREE CAPTIONS. #CardLabel, #SideHead and the grammar panel's heading\n   are the same object wearing three hats, and they used to differ in size,\n   tracking and vertical placement -- which is why the row of them across the\n   top read as slightly broken. One rule now: display face, one size, one\n   tracking, one weight, and a FIXED HEIGHT so all three sit on the same\n   baseline regardless of what is beside them in their row. */\n#CardLabel, #SideHead {{\n    background: transparent;\n    font-family: {DISPLAY_STACK[0]!r}, {DISPLAY_STACK[1]!r}, sans-serif;\n    font-size: {CAPTION_SIZE}px; font-weight: 700;\n    letter-spacing: {CAPTION_TRACK};\n    min-height: 22px; max-height: 22px;\n}}\n#CardLabel {{ color: {P['paper_dim']}; }}\n#SideHead {{ color: {P['ink_soft']}; }}\n/* The word count sits immediately beside the document caption, so it takes the\n   same face -- a bold sans against a serif label, an inch apart, was the other\n   half of why that row looked wrong. */\n#Count {{\n    background: transparent;\n    font-family: {DISPLAY_STACK[0]!r}, {DISPLAY_STACK[1]!r}, sans-serif;\n    font-size: {CAPTION_SIZE}px; font-weight: 600; color: {P['paper_dim']};\n    min-height: 22px; max-height: 22px;\n}}\n\n#Buffer {{\n    background: {P['paper']}; border: none;\n    font-family: {PAPER_STACK};\n    /* 20px, up from 19: for someone who reads slowly, size is a bigger lever\n       than the typeface. A serif also sets slightly smaller at the same\n       nominal size, so this holds the measure rather than shrinking it. */\n    font-size: 20px; line-height: 165%; color: {P['paper_ink']}; padding: 4px;\n    selection-background-color: {P['paper_ink']};\n    selection-color: {P['paper']};\n}}\n#Target {{ font-size: 12px; color: {P['ink_soft']}; }}\n#Status {{ font-size: 13px; color: {P['ink_soft']}; }}\n\n/* TEMPORARY review link in the header (see the Startup button). */\nQPushButton#TempLink {{\n    background: transparent; color: {P['ink_soft']};\n    border: 1px solid {P['line']}; border-radius: 6px;\n    padding: 4px 12px; font-size: 12px;\n}}\nQPushButton#TempLink:hover {{ color: {P['ink']}; border-color: {P['beige']}; }}\n\n/* The library sidebar: a quiet column, so the beige page stays the subject. */\n#Sidebar {{ background: {P['surface']}; border-right: 1px solid {P['line']}; }}\n#SideNote {{ background: transparent; font-size: 12px; color: {P['ink_soft']}; }}\nQPushButton#NewDoc {{\n    background: transparent; color: {P['beige_text']};\n    border: 1px solid {P['line']}; border-radius: 10px;\n    padding: 10px 12px; font-size: 14px; font-weight: 600; text-align: left;\n}}\nQPushButton#NewDoc:hover {{ border-color: {P['beige']}; background: {P['hover']}; }}\n/* The two pinned actions at the foot of the library. Quieter than "New page":\n   they leave the writing rather than adding to it, so they read as chrome. */\nQPushButton#SideFoot {{\n    background: transparent; color: {P['ink_soft']};\n    border: none; border-radius: 10px;\n    padding: 9px 10px; font-size: 13.5px; text-align: left;\n}}\nQPushButton#SideFoot:hover {{ background: {P['hover']}; color: {P['ink']}; }}\nQFrame#Sep {{ background: {P['line']}; border: none; max-height: 1px; }}\nQListWidget#DocList {{\n    background: transparent; border: none; outline: none;\n    font-size: 13px; color: {P['ink']};\n}}\nQListWidget#DocList::item {{\n    padding: 9px 10px; border-radius: 10px; margin-bottom: 2px;\n    color: {P['ink']};\n}}\nQListWidget#DocList::item:hover {{ background: {P['hover']}; }}\nQListWidget#DocList::item:selected {{\n    background: {P['beige_bg']}; color: {P['beige_text']};\n}}\n\n/* Processing bar: a hairline, beige on a barely-there trough. Indeterminate,\n   because transcription gives no progress signal to honour -- it is there to\n   say "working", and anything chunkier competes with the orb. */\nQProgressBar#Work {{\n    background: {P['line']}; border: none; border-radius: 3px;\n}}\nQProgressBar#Work::chunk {{ background: {P['beige']}; border-radius: 3px; }}\n"""
_ANIMATIONS = None
SPI_GETCLIENTAREAANIMATION = 4162

def animations_on() -> bool:
    global _ANIMATIONS
    if _ANIMATIONS is None:
        _ANIMATIONS = True
        try:
            import ctypes
            enabled = ctypes.c_int(1)
            ok = ctypes.windll.user32.SystemParametersInfoW(SPI_GETCLIENTAREAANIMATION, 0, ctypes.byref(enabled), 0)
            if ok:
                _ANIMATIONS = bool(enabled.value)
        except Exception:
            pass
        if not _ANIMATIONS:
            karalog.get('gui').info('system animations are off; Kara will not animate')
    return _ANIMATIONS

def motion_ms(ms: int) -> int:
    return ms if animations_on() else 0

def _short(text: str, limit: int=110) -> str:
    flat = ' '.join(str(text).split())
    return flat if len(flat) <= limit else flat[:limit - 1].rstrip() + '…'

def _ordinal_word(n: int) -> str:
    return {1: 'first', 2: 'second', 3: 'third', 4: 'fourth', 5: 'fifth', 6: 'sixth', 7: 'seventh', 8: 'eighth', 9: 'ninth', 10: 'tenth'}.get(n, str(n))

class LineNumbers(QWidget):

    def __init__(self, editor: QTextEdit):
        super().__init__()
        self.editor = editor
        self.setFixedWidth(26)
        editor.textChanged.connect(self.update)
        editor.verticalScrollBar().valueChanged.connect(self.update)

    def paintEvent(self, event):
        from PySide6.QtGui import QColor, QPainter
        painter = QPainter(self)
        painter.fillRect(event.rect(), QColor(P['paper']))
        font = painter.font()
        font.setPointSizeF(max(7.0, font.pointSizeF() - 2.0))
        painter.setFont(font)
        painter.setPen(QColor(P['paper_dim']))
        from PySide6.QtGui import QTextCursor
        import punctuation
        text = self.editor.toPlainText()
        if not text.strip():
            return
        from PySide6.QtCore import QPoint
        dy = self.editor.viewport().mapTo(self.editor, QPoint(0, 0)).y()
        cursor = QTextCursor(self.editor.document())
        for n, (start, _end) in enumerate(punctuation._line_spans(text), start=1):
            cursor.setPosition(min(start, len(text)))
            rect = self.editor.cursorRect(cursor)
            y = rect.top() + dy
            if y > self.height():
                break
            if y + rect.height() > 0:
                painter.drawText(0, y, self.width() - 6, rect.height(), Qt.AlignRight | Qt.AlignVCenter, str(n))

class Mic:
    SILENCE_PEAK = 0.02

    def __init__(self, device_spec=None):
        self.frames: list[np.ndarray] = []
        self.peak = 0.0
        self._stream = None
        self._last_voice = None
        self.device = self._resolve(device_spec)

    def _resolve(self, spec):
        try:
            return record.resolve_device(spec, allow_virtual=spec is not None)
        except SystemExit:
            if spec is not None:
                return record.resolve_device(None)
            raise

    def set_device(self, spec) -> str:
        self.device = self._resolve(spec)
        return self.device[1]

    def _cb(self, data, *_):
        self.frames.append(data.copy())
        peak = float(np.max(np.abs(data))) if data.size else 0.0
        self.peak = peak
        if peak >= self.SILENCE_PEAK:
            self._last_voice = time.monotonic()

    def silent_for(self) -> float:
        if self._stream is None or self._last_voice is None:
            return 0.0
        return time.monotonic() - self._last_voice

    def start(self):
        import sounddevice as sd
        self.frames, self.peak = ([], 0.0)
        self._last_voice = time.monotonic()
        self._stream = sd.InputStream(device=self.device[0], samplerate=record.SAMPLE_RATE, channels=1, dtype='float32', callback=self._cb)
        self._stream.start()

    def stop(self) -> np.ndarray:
        if self._stream:
            self._stream.stop()
            self._stream.close()
            self._stream = None
        self.peak = 0.0
        self._last_voice = None
        if not self.frames:
            return np.zeros(0, dtype=np.float32)
        return np.concatenate(self.frames, axis=0).squeeze(axis=-1)

class ModelLoader(QThread):
    done = Signal(object)
    failed = Signal(str)

    def __init__(self, speaker: str, model: str, adapter: str):
        super().__init__()
        self.speaker, self.model, self.adapter = (speaker, model, adapter)

    def run(self):
        try:
            import cpu_engine
            bf16 = self.model == 'large-v3'
            if cpu_engine.has_cuda():
                from pipeline import Pipeline
                self.done.emit(Pipeline(self.speaker, model=self.model, adapter=self.adapter, bf16=bf16, correct=True))
                return
            if cpu_engine.available(self.speaker, self.model):
                self.done.emit(cpu_engine.CPUEngine(self.speaker, self.model))
                return
            raise RuntimeError(f'This computer has no NVIDIA GPU, so Kara needs the CPU build of the {self.model} model. It has not been prepared yet — run:\n\n    python src\\cpu_engine.py --fetch-base --model {self.model}')
        except Exception as e:
            self.failed.emit(str(e))

class Transcriber(QThread):
    done = Signal(dict)
    failed = Signal(str)

    def __init__(self, pipe, editor, anchors, speaker, audio, mode, pending=None, keep_audio: bool=False, direct: bool=False):
        super().__init__()
        self.pipe, self.ed, self.anchors = (pipe, editor, anchors)
        self.speaker, self.audio, self.mode = (speaker, audio, mode)
        self.pending = pending
        self.keep_audio = keep_audio
        self.direct = direct
        self.utt_id = None

    def _transcribe(self, wav: str) -> str:
        self._wav = wav
        return self.pipe.raw(wav)

    def _word_probs(self) -> list:
        wav = getattr(self, '_wav', '')
        if not wav or not hasattr(self.pipe, 'word_probs'):
            return []
        try:
            return self.pipe.word_probs(wav)
        except Exception:
            return []

    def _ambiguous_change(self, raw: str) -> bool:
        try:
            args = editing.resolve_change(raw, self.ed.text) or editing.parse_command(raw)[1]
            if not args or len(args) != 2:
                return False
            target, replacement = (args[0].strip(), args[1].strip())
            if not target:
                return False
            hits = punctuation.word_occurrences(self.ed.text, target)
            if len(hits) <= 1:
                return False
            n = len(hits)
            self.done.emit({'heard': raw, 'choices': {'choices': hits, 'phrase': target, 'command': raw, 'block': 1, 'change': [target, replacement]}, 'say': f'{n} of {target!r} - say first, second... up to {_ordinal_word(n)}'})
            return True
        except Exception as e:
            karalog.get('gui').warning('ambiguity check failed: %s', e)
            return False

    def _learn(self, heard: str, meant: str, trust: str) -> None:
        try:
            import adapt
            heard, meant = ((heard or '').strip(), (meant or '').strip())
            if not heard or not meant or heard.lower() == meant.lower():
                return
            wav = ''
            prev = [u for u in utterances.latest(self.speaker, 4) if u.get('id') != self.utt_id and u.get('mode') == 'dictation']
            if prev:
                wav = prev[0].get('wav', '')
                utterances.note_correction(self.speaker, prev[0]['id'], meant)
            adapt.log_correction(self.speaker, wav, heard, meant, trust=trust)
            karalog.get('adapt').info('correction logged [%s] wav=%s', trust, 'yes' if wav else 'none')
        except Exception as e:
            karalog.get('adapt').warning('could not log correction: %s', e)

    def run(self):
        try:
            kept = None
            if self.keep_audio:
                kept = utterances.save(self.speaker, self.audio, record.SAMPLE_RATE, mode=self.mode)
            if kept:
                self.utt_id = kept['id']
                wav = str(ROOT / kept['wav'])
                raw = self._transcribe(wav)
            else:
                with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tf:
                    wav = tf.name
                sf.write(wav, self.audio, record.SAMPLE_RATE, subtype='PCM_16')
                try:
                    raw = self._transcribe(wav)
                finally:
                    Path(wav).unlink(missing_ok=True)
            if self.utt_id:
                utterances.note_asr(self.speaker, self.utt_id, raw)
            if self.mode == 'spelling':
                word = spelling.parse_spelling(raw, self.anchors).capitalize()
                if not word:
                    self.done.emit({'heard': raw, 'say': "didn't catch the letters"})
                    return
                self.ed.dictate(word)
                spelling.add_to_vocab(word, self.speaker)
                self.done.emit({'heard': raw, 'say': f'spelled: "{word}"'})
            elif self.mode == 'editing':
                if self.pending:
                    pick = punctuation.parse_choice(raw)
                    if pick is not None:
                        hits = self.pending['choices']
                        if not 1 <= pick <= len(hits):
                            self.done.emit({'heard': raw, 'say': f'there are only {len(hits)}'})
                            return
                        swap = self.pending.get('change')
                        if swap:
                            a, b = hits[pick - 1]
                            self.ed._snapshot()
                            self.ed.text = self.ed.text[:a] + swap[1] + self.ed.text[b:]
                            self.done.emit({'heard': raw, 'clear_pending': True, 'say': f'changed the {_ordinal_word(pick)} {swap[0]!r} to {swap[1]!r}'})
                            return
                        new, ok, msg = punctuation._apply_at(self.ed.text, hits[pick - 1], self.pending['command'])
                        if ok:
                            self.ed._snapshot()
                            self.ed.text = new
                        self.done.emit({'heard': raw, 'say': msg, 'clear_pending': True})
                        return
                scope, rest = punctuation.parse_scope(raw)
                if scope and rest:
                    new, ok, msg = punctuation.apply_scoped(self.ed.text, scope, rest)
                    if isinstance(msg, dict):
                        n = len(msg['choices'])
                        self.done.emit({'heard': raw, 'choices': msg, 'say': f"{n} of {msg['phrase']!r} in paragraph {msg['block']} - say first, second... up to {_ordinal_word(n)}"})
                        return
                    if ok:
                        self.ed._snapshot()
                        self.ed.text = new
                    self.done.emit({'heard': raw, 'say': msg})
                    return
                spelled_edit = punctuation.apply_spelled(self.ed.text, raw)
                if spelled_edit is not None:
                    new, ok, msg = spelled_edit
                    if isinstance(msg, dict):
                        n = len(msg['choices'])
                        self.done.emit({'heard': raw, 'choices': msg, 'say': f"{n} of {msg['phrase']!r} - say first, second... up to {_ordinal_word(n)}"})
                        return
                    if ok:
                        self.ed._snapshot()
                        self.ed.text = new
                    self.done.emit({'heard': raw, 'say': msg})
                    return
                shaped = punctuation.parse_edit(raw)
                if shaped:
                    _, msg = self.ed.punctuate(shaped)
                    if isinstance(msg, dict):
                        n = len(msg['choices'])
                        self.done.emit({'heard': raw, 'choices': msg, 'say': f"{n} of {msg['phrase']!r} - say first, second... up to {_ordinal_word(n)}"})
                        return
                    self.done.emit({'heard': raw, 'say': msg})
                    return
                cmd, args = editing.parse_command(raw)
                if cmd == 'send':
                    self.done.emit({'heard': raw, 'send': True})
                elif cmd == 'spell':
                    self.done.emit({'heard': raw, 'switch_mode': 'spelling'})
                elif cmd == 'read':
                    self.done.emit({'heard': raw, 'read_aloud': True})
                elif cmd == 'change_spell':
                    target, spell_text = args
                    word = spelling.parse_spelling(spell_text, self.anchors).capitalize()
                    if word and self.ed.change(target, word):
                        self._learn(target, word, 'spelled')
                        self.done.emit({'heard': raw, 'say': f'changed to "{word}"'})
                    else:
                        self.done.emit({'heard': raw, 'say': f"couldn't change {target!r}"})
                elif cmd == 'unknown':
                    snippet = None
                    try:
                        import usercommands
                        snippet = usercommands.match_insert(raw, self.speaker)
                    except Exception:
                        snippet = None
                    if snippet:
                        self.ed.dictate(snippet)
                        self.done.emit({'heard': raw, 'say': f'typed {_short(snippet, 30)!r}'})
                    else:
                        self.done.emit({'heard': raw, 'say': f'not a command: "{raw}"'})
                elif cmd == 'change' and self._ambiguous_change(raw):
                    return
                elif self.direct and cmd in appmod.KEYSTROKES:
                    self.done.emit({'heard': raw, 'keystroke': cmd, 'say': ''})
                else:
                    say = editing.apply_command(self.ed, raw, on_change=lambda t, r, ok: ok and self._learn(t, r, 'commanded'))
                    if say == 'SELECT_LAST':
                        self.done.emit({'heard': raw, 'select_last': True, 'say': 'selected the last word'})
                    else:
                        self.done.emit({'heard': raw, 'say': say})
            else:
                cmd, score = editing.command_confidence(raw)
                if cmd and score >= editing.RESCUE_CONFIDENCE and (len(raw.split()) >= editing.RESCUE_MIN_WORDS):
                    self.done.emit({'heard': raw, 'rescue': cmd, 'say': ''})
                    return
                import corrector
                clean = corrector.correct(spelling.expand_inline(raw), self.pipe.vocab, use_llm=False)
                if self.direct:
                    self.done.emit({'heard': raw, 'direct': clean, 'say': '', 'quiet': True})
                    return
                at = len(self.ed.text)
                self.ed.dictate(clean)
                self.done.emit({'heard': raw, 'say': '', 'quiet': True, 'probs': self._word_probs(), 'at': at})
        except Exception as e:
            self.failed.emit(str(e))

class CalibrateWorker(QThread):
    done = Signal(dict)
    failed = Signal(str)

    def __init__(self, speaker: str):
        super().__init__()
        self.speaker = speaker
        self._proc = None

    def run(self):
        import json
        import subprocess
        py = Path(sys.executable)
        if py.name.lower() == 'pythonw.exe':
            py = py.with_name('python.exe')
        try:
            self._proc = subprocess.Popen([str(py), str(ROOT / 'src' / 'calibrate.py'), '--json', '--speaker', self.speaker, '--steps', '5'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8', errors='replace', creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            out, err = self._proc.communicate(timeout=600)
            if self._proc.returncode != 0:
                self.failed.emit((err or '').strip()[-300:] or 'measurement failed')
                return
            self.done.emit(json.loads(out))
        except Exception as e:
            self.failed.emit(str(e))

    def cancel(self):
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.terminate()
            except Exception:
                pass

class TrainWorker(QThread):
    progress = Signal(dict)
    finished_ok = Signal(str)
    failed = Signal(str)
    SAVE_EVERY_CLIPS = 20

    def __init__(self, speaker: str, size: str, out_dir: Path, epochs: int, resume: bool, extra_manifest: Path | None=None):
        super().__init__()
        self.speaker, self.size, self.out_dir = (speaker, size, out_dir)
        self.epochs, self.resume = (epochs, resume)
        self.extra_manifest = extra_manifest
        self._proc = None
        self._stopping = False

    def run(self):
        import json as _json
        import subprocess
        py = Path(sys.executable)
        if py.name.lower() == 'pythonw.exe':
            py = py.with_name('python.exe')
        cmd = [str(py), str(ROOT / 'src' / 'finetune.py'), '--speaker', self.speaker, '--model', self.size, '--epochs', str(self.epochs), '--batch', '2', '--save-every-clips', str(self.SAVE_EVERY_CLIPS), '--progress-json', '--out', str(self.out_dir)]
        cmd += ['--lr', '0.0003' if self.size in ('small', 'medium') else '0.0001']
        if self.extra_manifest and Path(self.extra_manifest).exists():
            cmd += ['--extra-manifest', str(self.extra_manifest)]
        if self.resume:
            cmd.append('--resume')
        try:
            self._proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, encoding='utf-8', errors='replace', bufsize=1, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            last = {}
            for line in self._proc.stdout:
                line = line.strip()
                if not line.startswith('{'):
                    continue
                try:
                    msg = _json.loads(line)
                except ValueError:
                    continue
                if msg.get('event') == 'done':
                    self.finished_ok.emit(msg.get('out', str(self.out_dir)))
                    return
                last = msg
                self.progress.emit(msg)
            code = self._proc.wait()
            if self._stopping:
                self.failed.emit('paused')
            elif code != 0:
                self.failed.emit(f'training stopped unexpectedly (exit {code})')
            else:
                self.finished_ok.emit(str(self.out_dir))
        except Exception as e:
            self.failed.emit(str(e))

    def stop(self):
        self._stopping = True
        if self._proc and self._proc.poll() is None:
            try:
                self._proc.terminate()
            except Exception:
                pass

class _Veil(QWidget):

    def __init__(self, parent):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_NoSystemBackground)

    def paintEvent(self, _e):
        from PySide6.QtGui import QColor, QLinearGradient, QPainter
        r = self.rect()
        top = QColor(P['canvas'])
        top.setAlphaF(0.0)
        bottom = QColor(P['canvas'])
        bottom.setAlphaF(0.96)
        g = QLinearGradient(0, r.top(), 0, r.bottom())
        g.setColorAt(0.0, top)
        g.setColorAt(1.0, bottom)
        p = QPainter(self)
        p.fillRect(r, g)
        p.end()

class FadingScroll(QScrollArea):
    FADE = 26

    def __init__(self, parent=None):
        super().__init__(parent)
        self._veil = _Veil(self.viewport())
        self._veil.hide()
        bar = self.verticalScrollBar()
        bar.valueChanged.connect(self._sync_veil)
        bar.rangeChanged.connect(lambda *_: self._sync_veil())

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._sync_veil()

    def _sync_veil(self, *_):
        bar = self.verticalScrollBar()
        more = bar.maximum() > 0 and bar.value() < bar.maximum() - 1
        vp = self.viewport().rect()
        self._veil.setGeometry(0, vp.height() - self.FADE, vp.width(), self.FADE)
        self._veil.setVisible(more)
        if more:
            self._veil.raise_()
            self._veil.update()

class SettingsDialog(QDialog):
    _voice_done = Signal(str, bool, str)
    _update_checked = Signal(dict)
    _update_installed = Signal(bool, str)
    _update_progress = Signal(str)

    def __init__(self, window: 'Window'):
        super().__init__(window)
        self.win = window
        self._voice_busy = ''
        self._update_url = ''
        self._voice_done.connect(self._voice_downloaded)
        self._update_checked.connect(self._update_result)
        self._update_installed.connect(self._update_done)
        self._update_progress.connect(lambda m: self.update_note.setText(m) if hasattr(self, 'update_note') else None)
        self.cfg = dict(window.config)
        self._pending: dict = {}
        self._pending_model: str | None = None
        self._expanded_inputs = False
        self.setWindowTitle(t('Settings'))
        self.setMinimumSize(820, 600)
        self.resize(980, 760)
        self.setStyleSheet(f"""\n            QDialog {{ background: {P['canvas']}; }}\n            {_SCROLLBAR}\n            QLabel {{ color: {P['ink']}; font-family: {SANS_STACK}; }}\n            /* THE HIERARCHY WAS UPSIDE DOWN. A section heading was 12px\n               grey caps while the field labels it organised were 14px in\n               full ink -- so the thing doing the organising was quieter than\n               the things being organised, and every page read as a flat list\n               of controls with some small grey text scattered through it.\n               Now the heading takes the accent (which already means "this is\n               yours to act on" everywhere else in Kara) and the labels drop\n               to soft, so the eye lands on the section first and walks down\n               into it. No colour changed; only which size and weight uses\n               which. */\n            QLabel#Section {{ font-size: 12px; font-weight: 700;\n                letter-spacing: 1.6px; color: {P['beige_text']}; }}\n            QLabel#Field {{ font-size: 12.5px; font-weight: 600;\n                color: {P['ink_soft']}; }}\n            QLabel#Note {{ font-size: 12px; color: {P['ink_soft']}; }}\n            QFrame#SectionRule {{ background: {P['line']}; border: none;\n                max-height: 1px; }}\n            /* Empty states. A dashed outline claims the space the missing\n               content would occupy, so an empty section reads as empty rather\n               than as broken. */\n            QLabel#Empty {{ font-size: 12.5px; color: {P['ink_soft']};\n                border: 1px dashed {P['line']}; border-radius: 10px;\n                padding: 18px 14px; }}\n            QListWidget#Nav {{\n                background: {P['surface']}; border: none; border-radius: 10px;\n                padding: 6px; font-size: 14px; outline: none;\n            }}\n            QListWidget#Nav::item {{\n                padding: 10px 14px; border-radius: 6px; color: {P['ink_soft']};\n            }}\n            QListWidget#Nav::item:selected {{\n                background: {P['beige_bg']}; color: {P['beige_text']};\n            }}\n            QListWidget#Nav::item:hover {{ background: {P['hover']}; }}\n            QComboBox {{\n                background: {P['surface']}; color: {P['ink']};\n                border: 1px solid {P['line']}; border-radius: 10px;\n                padding: 8px 12px; font-size: 14px; min-height: 20px;\n            }}\n            QComboBox:hover {{ border-color: {P['beige']}; }}\n            /* ONE FIELD STYLE. QLineEdit inherited Qt's default -- a thin\n               bordered strip -- while the pickers beside it were filled\n               10px-radius boxes, so one page carried two kinds of input that\n               differed only by which year they were written. The filled box\n               is the one to keep: it is the bigger target, which is the whole\n               argument on this project. */\n            QLineEdit {{\n                background: {P['surface']}; color: {P['ink']};\n                border: 1px solid {P['line']}; border-radius: 10px;\n                padding: 8px 12px; font-size: 14px; min-height: 20px;\n            }}\n            QLineEdit:hover {{ border-color: {P['beige']}; }}\n            QLineEdit:focus {{ border-color: {P['beige']}; }}\n            QComboBox::drop-down {{ border: none; width: 26px; }}\n            QComboBox QAbstractItemView {{\n                background: {P['surface']}; color: {P['ink']};\n                border: 1px solid {P['line']};\n                selection-background-color: {P['beige_bg']};\n                selection-color: {P['beige_text']};\n            }}\n            /* Settings uses ToggleSwitch (icons.py), which paints itself --\n               these rules remain only for any stray Qt checkbox. */\n            QPushButton#Test {{\n                background: transparent; color: {P['beige_text']};\n                border: 1px solid {P['line']}; border-radius: 10px;\n                padding: 8px 16px; font-size: 13px; font-weight: 600;\n            }}\n            QPushButton#Test:hover {{ border-color: {P['beige']}; }}\n            QPushButton#Done {{\n                background: {P['beige']}; color: {P['on_accent']};\n                border: none; border-radius: 10px;\n                padding: 9px 26px; font-size: 14px; font-weight: 600;\n            }}\n            QPushButton#Done:hover {{ background: {P['beige_text']}; }}\n            QProgressBar#Level {{ background: {P['line']}; border: none;\n                border-radius: 3px; }}\n            QProgressBar#Level::chunk {{ background: {P['beige']};\n                border-radius: 3px; }}\n            /* The model ladder. A 22px handle because the intended user may have limited\n               fine motor control; Qt's default is 12px -- the same reasoning that made\n               the mic orb 240px and the mode segments 40px tall. The groove\n               is deliberately thin so the handle is the thing you aim at. */\n            QSlider::groove:horizontal {{ height: 5px; border-radius: 3px;\n                background: {P['line']}; }}\n            QSlider::sub-page:horizontal {{ height: 5px; border-radius: 3px;\n                background: {P['beige']}; }}\n            QSlider::handle:horizontal {{ background: {P['beige']};\n                border: 2px solid {P['canvas']}; width: 22px; height: 22px;\n                margin: -9px 0; border-radius: 11px; }}\n            QSlider::handle:horizontal:hover {{ background: {P['ink']}; }}\n            QSlider::tick:horizontal {{ background: {P['line']}; }}\n        """)
        self._build()

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(18, 18, 18, 14)
        outer.setSpacing(14)
        row = QHBoxLayout()
        row.setSpacing(16)
        self.nav = QListWidget()
        self.nav.setObjectName('Nav')
        self.nav.setFixedWidth(150)
        for name in ('Look & sound', 'Writing', 'Privacy', 'Backup', 'Voice model', 'About'):
            self.nav.addItem(t(name))
        self._page_builders = [lambda: self._combined(self._page_appearance, self._page_audio), lambda: self._combined(self._page_language, self._page_modes, self._page_commands), lambda: self._combined(self._page_offline, self._page_data), lambda: self._combined(self._page_backup), lambda: self._combined(self._page_processing, self._page_training, self._page_analytics), lambda: self._combined(self._page_about)]
        self._built: dict[int, QWidget] = {}
        self.stack = QStackedWidget()
        for _ in self._page_builders:
            self.stack.addWidget(QWidget())
        self.nav.currentRowChanged.connect(self._open_page)
        self.nav.setCurrentRow(0)
        row.addWidget(self.nav)
        row.addWidget(self.stack, 1)
        outer.addLayout(row, 1)
        btn_row = QHBoxLayout()
        self.pending_note = QLabel('')
        self.pending_note.setObjectName('Note')
        btn_row.addWidget(self.pending_note)
        btn_row.addStretch()
        for label, slot, primary in (('OK', self._ok, True), ('Cancel', self._cancel, False), ('Apply', self._apply, False)):
            b = QPushButton(t(label))
            b.setObjectName('Done' if primary else 'Test')
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(slot)
            btn_row.addWidget(b)
            if label == 'Apply':
                self.apply_btn = b
        outer.addLayout(btn_row)
        self._sync_buttons()

    def _stage(self, key: str, value) -> None:
        self.cfg[key] = value
        self._pending[key] = value
        self._sync_buttons()

    def _sync_buttons(self) -> None:
        if not hasattr(self, 'apply_btn'):
            return
        n = len(self._pending) + (1 if self._pending_model else 0)
        self.apply_btn.setEnabled(bool(n))
        self.pending_note.setText('' if not n else t('1 change not saved yet') if n == 1 else t('%s changes not saved yet') % (n,))
    NEEDS_RESTART = {'theme': 'the colours', 'language': 'the language Kara listens for', 'ui_language': 'the language Kara speaks to you in', 'offline_mode': 'whether Kara may use the internet'}

    def _apply(self) -> None:
        if not self._pending and (not self._pending_model):
            return
        keys = set(self._pending)
        config.save(self.cfg)
        self._pending.clear()
        self._sync_buttons()
        karalog.get('settings').info('applied: %s', ','.join(sorted(keys)))
        self._push_live(keys)
        self._offer_restart(keys)

    def _offer_restart(self, keys: set) -> None:
        changed = []
        if 'theme' in keys and (self.cfg.get('theme') or 'dusk') != THEME:
            changed.append(t(self.NEEDS_RESTART['theme']))
        if 'language' in keys:
            changed.append(t(self.NEEDS_RESTART['language']))
        if 'ui_language' in keys and (self.cfg.get('ui_language') or 'en') != i18n.language():
            changed.append(t(self.NEEDS_RESTART['ui_language']))
        if 'offline_mode' in keys and bool(self.cfg.get('offline_mode', True)) != bool(self.win.offline):
            changed.append(t(self.NEEDS_RESTART['offline_mode']))
        if not changed:
            return
        if len(changed) == 1:
            what = changed[0]
        else:
            what = t('%s and %s') % (', '.join(changed[:-1]), changed[-1])
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Question)
        box.setWindowTitle(t('Restart Kara?'))
        box.setText(t('Kara needs to start again to change %s.') % what)
        box.setInformativeText(t('Your writing is saved first, and Kara will reopen straight away.'))
        go = box.addButton(t('Restart now'), QMessageBox.AcceptRole)
        box.addButton(t('Later'), QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is go:
            karalog.get('settings').info('restarting to apply: %s', ', '.join(changed))
            self.accept()
            self.win.restart()

    def _push_live(self, keys: set) -> None:
        w = self.win
        w.config = config.load()
        if 'speak_responses' in keys:
            w.speak_on = bool(w.config.get('speak_responses', False))
        if 'input_device' in keys:
            try:
                w.apply_input_device()
            except Exception:
                pass
        if 'include_spelling' in keys:
            w.apply_modes()
        if 'language' in keys:
            w._proof = None
            w._online_cache = None
        if {'language', 'grammar_service'} & keys:
            w._last_proof_err = None
            try:
                w._recheck()
            except Exception:
                pass
        if 'auto_backup' in keys and w.config.get('auto_backup'):
            QTimer.singleShot(0, w._maybe_auto_backup)
        if 'keep_utterances' in keys and (not w.config.get('keep_utterances')):
            n = utterances.forget_all(w.speaker)
            karalog.get('settings').info('retention off; forgot %d utterances', n)
            if hasattr(self, 'keep_utt'):
                self._fill_inventory()
        if self._pending_model is not None:
            want, self._pending_model = (self._pending_model, None)
            w.switch_model(want)

    def _ok(self) -> None:
        self._apply()
        self.accept()

    def _cancel(self) -> None:
        if self._pending:
            karalog.get('settings').info('cancelled: %d change(s) discarded', len(self._pending))
        self._pending.clear()
        self._pending_model = None
        self.reject()

    def _combined(self, *builders) -> QWidget:
        holder = QWidget()
        lay = QVBoxLayout(holder)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(14)
        for i, build in enumerate(builders):
            if i:
                rule = QFrame()
                rule.setFrameShape(QFrame.HLine)
                rule.setFixedHeight(1)
                rule.setStyleSheet(f"background:{P['line']}; border:none;")
                lay.addWidget(rule)
            section = build()
            inner = section.layout()
            if inner is not None and inner.count():
                last = inner.itemAt(inner.count() - 1)
                if last is not None and last.spacerItem() is not None:
                    inner.takeAt(inner.count() - 1)
            lay.addWidget(section)
        lay.addStretch()
        return holder

    def _open_page(self, idx: int):
        if idx < 0 or idx >= len(self._page_builders):
            return
        if idx not in self._built:
            try:
                page = self._page_builders[idx]()
            except Exception as e:
                karalog.get('settings').exception('page %d failed: %s', idx, e)
                page = QLabel(t('This page could not be opened.'))
                page.setObjectName('Note')
            scroll = FadingScroll()
            scroll.setWidgetResizable(True)
            scroll.setFrameShape(QFrame.NoFrame)
            scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            scroll.setWidget(page)
            placeholder = self.stack.widget(idx)
            self.stack.insertWidget(idx, scroll)
            self.stack.removeWidget(placeholder)
            placeholder.deleteLater()
            self._built[idx] = page
        self.stack.setCurrentIndex(idx)

    def _page(self) -> tuple[QWidget, QVBoxLayout]:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(2, 2, 2, 2)
        lay.setSpacing(12)
        self._first_section = True
        return (w, lay)
    THEME_CHOICES = [('dusk', 'Dusk — dark'), ('daylight', 'Daylight — light')]

    def _page_appearance(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('APPEARANCE'))
        self.theme_combo = QComboBox()
        current = self.cfg.get('theme') or 'dusk'
        for key, label in self.THEME_CHOICES:
            self.theme_combo.addItem(t(label), key)
            if key == current:
                self.theme_combo.setCurrentIndex(self.theme_combo.count() - 1)
        self.theme_combo.currentIndexChanged.connect(self._theme_changed)
        lay.addWidget(self.theme_combo)
        self.theme_note = QLabel('')
        self.theme_note.setObjectName('Note')
        self.theme_note.setWordWrap(True)
        lay.addWidget(self.theme_note)
        self._describe_theme()
        return page

    def _describe_theme(self):
        if not hasattr(self, 'theme_note'):
            return
        want = self.theme_combo.currentData() or 'dusk'
        if want == THEME:
            self.theme_note.setText('')
        else:
            self.theme_note.setText(t('Kara will look like this the next time you open it.'))

    def _theme_changed(self):
        self._stage('theme', self.theme_combo.currentData() or 'dusk')
        self._describe_theme()

    def _page_audio(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('AUDIO'))
        lay.addWidget(self._field_label('Microphone'))
        self.mic_combo = QComboBox()
        self._fill_inputs()
        self.mic_combo.currentIndexChanged.connect(self._input_changed)
        lay.addWidget(self.mic_combo)
        mic_note = QLabel(t('Tap the circle on the main window to check the level.'))
        mic_note.setObjectName('Note')
        mic_note.setWordWrap(True)
        lay.addWidget(mic_note)
        lay.addSpacing(10)
        lay.addWidget(self._field_label('Speaker (read-back)'))
        out_row = QHBoxLayout()
        out_row.setSpacing(8)
        self.out_combo = QComboBox()
        self._fill_outputs()
        self.out_combo.currentIndexChanged.connect(self._output_changed)
        self.test_btn = QPushButton(t('Test'))
        self.test_btn.setObjectName('Test')
        self.test_btn.setCursor(Qt.PointingHandCursor)
        self.test_btn.clicked.connect(self._test_output)
        out_row.addWidget(self.out_combo, 1)
        out_row.addWidget(self.test_btn)
        lay.addLayout(out_row)
        lay.addSpacing(14)
        lay.addWidget(self._field_label('Reading voice'))
        vrow = QHBoxLayout()
        vrow.setSpacing(8)
        self.voice_combo = QComboBox()
        self.voice_try = QPushButton(t('Try it'))
        self.voice_try.setObjectName('Test')
        self.voice_try.setCursor(Qt.PointingHandCursor)
        self.voice_try.clicked.connect(self._try_voice)
        self._fill_voices()
        self.voice_combo.currentIndexChanged.connect(self._voice_changed)
        vrow.addWidget(self.voice_combo, 1)
        vrow.addWidget(self.voice_try)
        lay.addLayout(vrow)
        lay.addWidget(self._field_label('Reading speed'))
        self.rate_combo = QComboBox()
        for label, val in (('Much slower', -6), ('Slower', -3), ('Normal', 0), ('Faster', 3), ('Much faster', 6)):
            self.rate_combo.addItem(t(label), val)
        want_rate = int(self.cfg.get('tts_rate', 0) or 0)
        idx = min(range(self.rate_combo.count()), key=lambda i: abs(self.rate_combo.itemData(i) - want_rate))
        self.rate_combo.setCurrentIndex(idx)
        self.rate_combo.currentIndexChanged.connect(self._rate_changed)
        lay.addWidget(self.rate_combo)
        self.voice_note = QLabel('')
        self.voice_note.setObjectName('Note')
        self.voice_note.setWordWrap(True)
        lay.addWidget(self.voice_note)
        self._describe_voices()
        lay.addSpacing(14)
        self.glow_chk = ToggleSwitch('Glow while listening')
        self.glow_chk.setChecked(bool(self.cfg.get('listening_glow', False)))
        self.glow_chk.setToolTip(t('A slow warm light behind the page while Kara is listening. It tells you nothing the microphone does not already show — it is there because some people find it easier to see at a glance, and some find it distracting.'))
        self.glow_chk.toggled.connect(lambda on: self._stage('listening_glow', bool(on)))
        lay.addWidget(self.glow_chk)
        lay.addSpacing(14)
        self.speak_chk = ToggleSwitch('Read every response aloud')
        self.speak_chk.setChecked(bool(self.cfg.get('speak_responses', False)))
        self.speak_chk.toggled.connect(self._speak_toggled)
        lay.addWidget(self.speak_chk)
        lay.addStretch()
        return page

    def _fill_voices(self):
        self.voice_combo.blockSignals(True)
        self.voice_combo.clear()
        found = voices.catalogue()
        want = self.cfg.get('tts_voice')
        for v in found:
            self.voice_combo.addItem(v.label, v.id)
            if v.id == want:
                self.voice_combo.setCurrentIndex(self.voice_combo.count() - 1)
        have = {v.token.split('-')[1] for v in found if '-' in v.token}
        for stem, label, size in voices.PIPER_CATALOGUE:
            parts_all = stem.split('-')
            if len(parts_all) > 1 and parts_all[1] in have:
                continue
            parts = stem.split('-')
            who = ' '.join((w.capitalize() for w in parts[1].split('_')))
            region = stem.split('_', 1)[1].split('-', 1)[0].upper()
            self.voice_combo.addItem(t('%s  ·  %s  ·  %.0f MB  —  download') % (who, region, size / (1 << 20)), f'get:{stem}')
        if not self.voice_combo.count():
            self.voice_combo.addItem(t('No voices available'), None)
        self.voice_combo.setEnabled(self.voice_combo.count() > 0)
        if hasattr(self, 'voice_try'):
            self.voice_try.setEnabled(bool(found))
        self.voice_combo.blockSignals(False)

    def _describe_voices(self):
        if not hasattr(self, 'voice_note'):
            return
        self.voice_note.setText(getattr(self, '_voice_busy', ''))
        self.voice_note.setVisible(bool(getattr(self, '_voice_busy', '')))

    def _voice_changed(self):
        data = self.voice_combo.currentData()
        if isinstance(data, str) and data.startswith('get:'):
            self._download_voice(data[4:])
            return
        self._stage('tts_voice', data)

    def _download_voice(self, stem: str):
        if getattr(self, '_voice_busy', ''):
            return
        import threading
        import urllib.request
        self._voice_busy = f'Downloading {stem}…  this happens once.'
        self._describe_voices()
        self.voice_combo.setEnabled(False)

        def work():
            ok, why = (False, '')
            try:
                got, engine_why = voices.install_piper()
                if not got:
                    self._voice_done.emit(stem, False, f'speech engine: {engine_why}')
                    return
                model_url, cfg_url = voices.piper_download_url(stem)
                voices.PIPER_VOICES.mkdir(parents=True, exist_ok=True)
                dest = voices.PIPER_VOICES / f'{stem}.onnx'
                part = dest.with_suffix('.onnx.part')
                urllib.request.urlretrieve(model_url, part)
                urllib.request.urlretrieve(cfg_url, str(dest) + '.json')
                part.replace(dest)
                ok = dest.stat().st_size > 1000000
                why = '' if ok else 'the download was incomplete'
            except Exception as e:
                why = f'{type(e).__name__}'
            self._voice_done.emit(stem, ok, why)
        threading.Thread(target=work, daemon=True, name='kara-voice-dl').start()

    def _voice_downloaded(self, stem: str, ok: bool, why: str):
        self._voice_busy = '' if ok else f'Could not download that voice ({why}).'
        self.voice_combo.setEnabled(True)
        if ok:
            karalog.get('gui').info('voice downloaded: %s', stem)
            voices.catalogue(refresh=True)
            self._fill_voices()
            self._stage('tts_voice', f'piper:{stem}')
            idx = self.voice_combo.findData(f'piper:{stem}')
            if idx >= 0:
                self.voice_combo.blockSignals(True)
                self.voice_combo.setCurrentIndex(idx)
                self.voice_combo.blockSignals(False)
        self._describe_voices()

    def _rate_changed(self):
        self._stage('tts_rate', int(self.rate_combo.currentData()))

    def _try_voice(self):
        dev = record.output_device_index(self.cfg.get('output_device'))
        threading.Thread(target=editing.speak, args=('This is how Kara will read your writing back to you.', dev), kwargs={'voice': self.voice_combo.currentData(), 'rate': int(self.rate_combo.currentData())}, daemon=True).start()

    def _speak_toggled(self, on: bool):
        self._stage('speak_responses', bool(on))

    def _page_language(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('LANGUAGE', 'Your voice model was trained on English. Another language falls back to what the general model knows, which for a voice it has never learned is far worse. Hindi is beta: it is recognised, but spell checking is off and the voice commands stay English.'))
        lay.addLayout(self._label_with_beta('What you dictate', 'lang_beta'))
        self.lang_combo = QComboBox()
        current = self.cfg.get('language') or 'en'
        for code, label in LANGUAGES:
            self.lang_combo.addItem(label, code)
            if code == current:
                self.lang_combo.setCurrentIndex(self.lang_combo.count() - 1)
        self.lang_combo.currentIndexChanged.connect(self._language_changed)
        lay.addWidget(self.lang_combo)
        note = QLabel(t('Recognition, spelling and grammar. This is the language you speak, not the one Kara answers in.'))
        note.setObjectName('Note')
        note.setWordWrap(True)
        lay.addWidget(note)
        lay.addSpacing(14)
        lay.addLayout(self._label_with_beta("Kara's own words", 'ui_lang_beta'))
        self.ui_lang_combo = QComboBox()
        ui_current = self.cfg.get('ui_language') or 'en'
        for code, label in UI_LANGUAGES:
            self.ui_lang_combo.addItem(label, code)
            if code == ui_current:
                self.ui_lang_combo.setCurrentIndex(self.ui_lang_combo.count() - 1)
        self.ui_lang_combo.currentIndexChanged.connect(self._ui_language_changed)
        lay.addWidget(self.ui_lang_combo)
        note = QLabel(t('The buttons and messages in Kara itself. Kara sets these as it starts, so changing it asks to restart.'))
        note.setObjectName('Note')
        note.setWordWrap(True)
        lay.addWidget(note)
        self.lang_split_note = QLabel('')
        self.lang_split_note.setObjectName('Note')
        self.lang_split_note.setWordWrap(True)
        lay.addWidget(self.lang_split_note)
        lay.addSpacing(14)
        self.lang_warning = QLabel('')
        self.lang_warning.setObjectName('Field')
        self.lang_warning.setWordWrap(True)
        lay.addWidget(self.lang_warning)
        lay.addStretch()
        self._describe_language()
        self._describe_split()
        self._describe_beta()
        return page

    def _describe_split(self):
        if not hasattr(self, 'lang_split_note'):
            return
        spoken = self.lang_combo.currentData() or 'en'
        shown = self.ui_lang_combo.currentData() or 'en'
        if spoken == 'en' or shown != 'en':
            self.lang_split_note.setVisible(False)
            self.lang_split_note.setText('')
            return
        name = dict(LANGUAGES).get(spoken, spoken).split(' — ')[0]
        self.lang_split_note.setVisible(True)
        self.lang_split_note.setText(t("You are dictating in %s, but Kara's own buttons and messages are still set to English. Change them above if you want them in %s too.") % (name, name))

    def _describe_language(self):
        if not hasattr(self, 'lang_warning'):
            return
        code = self.lang_combo.currentData() or 'en'
        if code == 'en':
            self.lang_warning.setText('')
            self.lang_warning.setVisible(False)
            return
        self.lang_warning.setVisible(True)
        label = dict(LANGUAGES).get(code, code)
        extra = t(LANGUAGE_NOTES.get(code, '')) if LANGUAGE_NOTES.get(code) else ''
        self.lang_warning.setText(t('⚠  Your voice model was trained on ENGLISH. In %s, Kara falls back to the general model. On the speaker this was measured on, that meant 34.7%% of words wrong — against 4.5%% in English.\n\n') % (label,) + (extra or t('Dictation will be noticeably worse. Spelling and grammar will still be checked for %s.') % (label,)))
        self.lang_warning.setStyleSheet(f"color:{P['ink']};")

    def _language_changed(self):
        code = self.lang_combo.currentData() or 'en'
        self._stage('language', code)
        self._describe_language()
        self._describe_split()
        self._describe_beta()
        if _is_beta_language(code):
            self.win.warn_beta_once('hindi_speech')

    def _ui_language_changed(self):
        code = self.ui_lang_combo.currentData() or 'en'
        self._stage('ui_language', code)
        self._describe_split()
        self._describe_beta()
        if _is_beta_language(code):
            self.win.warn_beta_once('hindi_ui')

    def _page_offline(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('OFFLINE MODE', 'Turning it off allows one thing only: sentences go to a grammar service for a better check. Your recordings are never uploaded either way.'))
        self.offline_chk = ToggleSwitch('Keep everything on this computer')
        self.offline_chk.setChecked(bool(self.cfg.get('offline_mode', True)))
        self.offline_chk.setStyleSheet('font-size:15px; font-weight:600;')
        self.offline_chk.toggled.connect(self._toggle_offline)
        lay.addWidget(self.offline_chk)
        self.offline_note = QLabel('')
        self.offline_note.setObjectName('Note')
        self.offline_note.setWordWrap(True)
        lay.addWidget(self.offline_note)
        self._describe_offline()
        lay.addSpacing(14)
        lay.addWidget(self._section('GRAMMAR SERVER'))
        self.service_edit = QLineEdit(self.cfg.get('grammar_service') or proofing.DEFAULT_SERVICE)
        self.service_edit.setToolTip(t('Point this at a LanguageTool server you run yourself to keep your writing on your own network.'))
        self.service_edit.editingFinished.connect(self._service_changed)
        lay.addWidget(self.service_edit)
        hint = QLabel(t('Only used when Offline Mode is switched off.'))
        hint.setObjectName('Note')
        hint.setWordWrap(True)
        lay.addWidget(hint)
        lay.addStretch()
        return page

    @staticmethod
    def _suggest_backup_dir() -> str:
        for var in ('OneDrive', 'OneDriveConsumer', 'OneDriveCommercial'):
            base = os.environ.get(var)
            if base and Path(base).is_dir():
                return str(Path(base) / 'Kara Backup')
        return ''

    def _page_backup(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('BACKUP', 'Point it at a synced folder and the copy reaches the cloud; point it at a drive and it stays there. After the first backup only what changed is copied, so later ones are quick.'))
        lay.addWidget(self._field_label('Backup folder'))
        prow = QHBoxLayout()
        prow.setSpacing(8)
        self.backup_path = QLineEdit(self.cfg.get('cloud_local_path') or self._suggest_backup_dir())
        self.backup_path.editingFinished.connect(self._backup_path_changed)
        prow.addWidget(self.backup_path, 1)
        browse = QPushButton(t('Browse…'))
        browse.setObjectName('Test')
        browse.setCursor(Qt.PointingHandCursor)
        browse.clicked.connect(self._pick_backup_dir)
        prow.addWidget(browse)
        lay.addLayout(prow)
        self.auto_backup_chk = ToggleSwitch('Back up on its own')
        self.auto_backup_chk.setChecked(bool(self.cfg.get('auto_backup', False)))
        self.auto_backup_chk.setStyleSheet('font-size:15px; font-weight:600;')
        self.auto_backup_chk.toggled.connect(self._auto_backup_changed)
        lay.addWidget(self.auto_backup_chk)
        anote = QLabel(t('Kara checks every few minutes and copies anything new, whenever the folder is there. If nothing has changed it does nothing, and if the folder is missing it waits quietly until it is back.'))
        anote.setObjectName('Note')
        anote.setWordWrap(True)
        lay.addWidget(anote)
        lay.addSpacing(16)
        lay.addWidget(self._section('EARLIER VOICE MODELS', 'Kara keeps the model it was using before each training, so a bad one is never the end of it. Pick a date to go back to that one.'))
        self.versions_box = QWidget()
        self.versions_lay = QVBoxLayout(self.versions_box)
        self.versions_lay.setContentsMargins(0, 4, 0, 0)
        self.versions_lay.setSpacing(4)
        lay.addWidget(self.versions_box)
        self._fill_versions()
        lay.addSpacing(10)
        self.backup_model_chk = ToggleSwitch('Also copy the trained voice model')
        self.backup_model_chk.setChecked(bool(self.cfg.get('cloud_backup_model', False)))
        self.backup_model_chk.toggled.connect(self._backup_model_changed)
        lay.addWidget(self.backup_model_chk)
        mnote = QLabel(t('The model is 152 MB — more than twice everything else — and can be retrained from the recordings. Including it makes moving to a new computer instant instead of a retrain.'))
        mnote.setObjectName('Note')
        mnote.setWordWrap(True)
        lay.addWidget(mnote)
        brow = QHBoxLayout()
        brow.setSpacing(8)
        self.backup_btn = QPushButton(t('Back up now'))
        self.backup_btn.setObjectName('Test')
        self.backup_btn.setCursor(Qt.PointingHandCursor)
        self.backup_btn.clicked.connect(lambda: self._run_backup('backup'))
        brow.addWidget(self.backup_btn)
        self.restore_btn = QPushButton(t('Restore from backup'))
        self.restore_btn.setObjectName('Test')
        self.restore_btn.setCursor(Qt.PointingHandCursor)
        self.restore_btn.clicked.connect(lambda: self._run_backup('restore'))
        brow.addWidget(self.restore_btn)
        brow.addStretch()
        lay.addLayout(brow)
        self.backup_bar = QProgressBar()
        self.backup_bar.setObjectName('Level')
        self.backup_bar.setTextVisible(False)
        self.backup_bar.setFixedHeight(6)
        self.backup_bar.setVisible(False)
        lay.addWidget(self.backup_bar)
        self.backup_state = QLabel('')
        self.backup_state.setObjectName('Note')
        self.backup_state.setWordWrap(True)
        lay.addWidget(self.backup_state)
        lay.addStretch()
        self._describe_backup()
        return page

    def _describe_backup(self):
        if not hasattr(self, 'backup_state'):
            return
        worker = getattr(self, '_backup', None)
        busy = worker is not None and worker.isRunning()
        path = (self.backup_path.text() or '').strip()
        self.backup_btn.setEnabled(bool(path) and (not busy))
        self.restore_btn.setEnabled(bool(path) and (not busy))
        self.backup_path.setEnabled(not busy)
        if busy:
            return
        self.backup_bar.setVisible(False)
        if not path:
            self.backup_state.setText(t('Choose a folder. Somewhere inside OneDrive or Google Drive means the copy leaves this computer by itself.'))
            return
        try:
            summary = cloudsync.remote_summary(cloudsync.LocalBackend(path))
        except Exception:
            summary = {'exists': False}
        if summary.get('exists'):
            when = self.cfg.get('last_backup') or '—'
            self.backup_state.setText(t('%s files · %.0f MB in this folder · last backed up %s') % (summary['files'], summary['bytes'] / 1000000.0, when))
        else:
            self.backup_state.setText(t('Nothing has been backed up here yet.'))

    def _backup_path_changed(self):
        self._stage('cloud_local_path', (self.backup_path.text() or '').strip() or None)
        self._stage('cloud_provider', 'local')
        self._describe_backup()

    def _pick_backup_dir(self):
        from PySide6.QtWidgets import QFileDialog
        start = (self.backup_path.text() or '').strip() or str(Path.home())
        chosen = QFileDialog.getExistingDirectory(self, t('Choose a backup folder'), start)
        if chosen:
            self.backup_path.setText(chosen)
            self._backup_path_changed()

    def _auto_backup_changed(self, on: bool):
        self._stage('auto_backup', bool(on))

    def _fill_versions(self):
        import modelstore
        box = getattr(self, 'versions_lay', None)
        if box is None:
            return
        while box.count():
            item = box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        rows = modelstore.read_index(self.win.speaker)
        if not rows:
            empty = QLabel(t('Nothing kept yet. The first one is filed the next time you train.'))
            empty.setObjectName('Note')
            empty.setWordWrap(True)
            box.addWidget(empty)
            return
        for r in rows:
            line = QHBoxLayout()
            line.setSpacing(8)
            lab = QLabel(modelstore.describe(r))
            lab.setObjectName('Note')
            line.addWidget(lab, 1)
            b = QPushButton(t('Use this one'))
            b.setObjectName('Test')
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, d=str(r['dir']): self._restore_version(d))
            line.addWidget(b)
            holder = QWidget()
            holder.setLayout(line)
            box.addWidget(holder)
        total = modelstore.total_bytes(self.win.speaker)
        note = QLabel(t('%s kept  ·  %.0f MB  ·  the oldest is dropped past %s') % (len(rows), total / 1000000.0, modelstore.KEEP))
        note.setObjectName('Note')
        note.setWordWrap(True)
        box.addWidget(note)

    def _restore_version(self, version_dir: str):
        import modelstore
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Question)
        box.setWindowTitle(t('Go back to this model?'))
        box.setText(t('Kara will use this earlier model instead of the one it has now.'))
        box.setInformativeText(t('The one being replaced is kept too, so you can come back. Kara needs to start again for the change to take effect.'))
        yes = box.addButton(t('Use this one'), QMessageBox.AcceptRole)
        box.addButton(t('Cancel'), QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is not yes:
            return
        if modelstore.restore(self.win.speaker, version_dir):
            karalog.get('settings').info('restored an earlier voice model')
            self._fill_versions()
            self.win._say(t('Earlier model restored. Restart Kara to use it.'))
        else:
            QMessageBox.warning(self, t('Could not go back'), t('That version is no longer on this computer.'))
            self._fill_versions()

    def _backup_model_changed(self, on: bool):
        self._stage('cloud_backup_model', bool(on))

    def _run_backup(self, mode: str):
        path = (self.backup_path.text() or '').strip()
        if not path:
            info = errors.look_up('KARA-7102')
            self.backup_state.setText(f'{info.fix}  ({info.code})')
            return
        if mode == 'restore':
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Warning)
            box.setWindowTitle(t('Restore from backup'))
            box.setText(t('Copy the recordings from the backup folder back onto this computer?'))
            box.setInformativeText(t('Anything already here that is different is left alone and reported, never overwritten.'))
            go = box.addButton(t('Restore'), QMessageBox.AcceptRole)
            box.addButton(t('Cancel'), QMessageBox.RejectRole)
            box.exec()
            if box.clickedButton() is not go:
                return
        self.win._retire_thread(getattr(self, '_backup', None))
        self._backup = BackupWorker(mode, self.win.speaker, path, bool(self.backup_model_chk.isChecked()))
        self._backup.progress.connect(self._backup_progress)
        self._backup.done_ok.connect(self._backup_done)
        self._backup.failed.connect(self._backup_failed)
        self._backup.start()
        self._describe_backup()
        self.backup_bar.setRange(0, 0)
        self.backup_bar.setVisible(True)
        self.backup_state.setText('Copying…' if mode == 'backup' else 'Restoring…')

    def _backup_progress(self, n: int, total: int, what: str):
        if total and self.backup_bar.maximum() != total:
            self.backup_bar.setRange(0, total)
        self.backup_bar.setValue(n)
        self.backup_state.setText(f'{n} of {total} — {Path(what).name}')

    def _backup_done(self, rep: dict):
        if rep['errors']:
            karalog.get('settings').warning('backup finished with %d problems', len(rep['errors']))
            self.backup_state.setText(t('Finished, but %s file(s) had a problem. %s') % (len(rep['errors']), rep['errors'][0]))
            self.backup_bar.setVisible(False)
            return
        saved = config.load()
        saved['last_backup'] = time.strftime('%d %b %Y, %H:%M')
        try:
            saved['last_backup_fingerprint'] = cloudsync.payload_fingerprint(self.win.speaker, include_model=bool(self.cfg.get('cloud_backup_model')))
        except OSError:
            saved['last_backup_fingerprint'] = None
        config.save(saved)
        self.cfg['last_backup'] = saved['last_backup']
        self.win.config = config.load()
        karalog.get('settings').info('backup ok: %d files, %d written, %d already there, %.1f MB', rep['files'], rep['written'], rep['skipped'], rep['bytes'] / 1000000.0)
        self._describe_backup()
        moved = rep['bytes'] / 1000000.0
        self.win._hint(t('Backed up — %s new file(s), %.0f MB') % (rep['written'], moved) if rep['written'] else t('Backed up — everything was already there'))

    def _backup_failed(self, code: str, detail: str):
        info = errors.look_up(code)
        self.backup_bar.setVisible(False)
        self.backup_state.setText(f'{info.say} {info.fix}  ({info.code})')
        karalog.get('settings').warning('backup failed [%s] %s', code, detail)
        self._describe_backup()

    def _page_processing(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('RECOGNITION MODEL', 'Bigger is slower to load and needs more of the graphics card. Medium and large measured as a statistical tie on the voice they were tested on, so medium is the sensible default rather than a compromise.'))
        self.model_slider = QSlider(Qt.Horizontal)
        self.model_slider.setRange(0, len(MODEL_LADDER) - 1)
        self.model_slider.setPageStep(1)
        self.model_slider.setSingleStep(1)
        self.model_slider.setTickPosition(QSlider.TicksBelow)
        self.model_slider.setTickInterval(1)
        try:
            self.model_slider.setValue(MODEL_LADDER.index(self.win.model))
        except ValueError:
            self.model_slider.setValue(MODEL_LADDER.index(RECOMMENDED_MODEL))
        self.model_slider.setAccessibleName(t('Recognition model'))
        self.model_slider.valueChanged.connect(self._model_slider_moved)
        lay.addWidget(self.model_slider)
        ends = QHBoxLayout()
        ends.setContentsMargins(2, 0, 2, 0)
        left = QLabel(t('Lighter · faster · rougher'))
        left.setObjectName('Note')
        right = QLabel(t('Heavier · slower · more accurate'))
        right.setObjectName('Note')
        ends.addWidget(left)
        ends.addStretch()
        ends.addWidget(right)
        lay.addLayout(ends)
        self.model_name = QLabel('')
        self.model_name.setObjectName('Field')
        lay.addWidget(self.model_name)
        self.model_note = QLabel('')
        self.model_note.setObjectName('Note')
        self.model_note.setWordWrap(True)
        lay.addWidget(self.model_note)
        self._describe_model(self.model_slider.value())
        lay.addSpacing(18)
        lay.addWidget(self._section('FINE-TUNING', "How long re-personalising each size would take here. Error rates are from one speaker's measured results, so a size without one has never been tested on this voice — that is not something measuring this machine can find out."))
        self.hw_line = QLabel('')
        self.hw_line.setObjectName('Note')
        lay.addWidget(self.hw_line)
        self.est_labels = {}
        for key in MODEL_OPTIONS:
            r = QLabel('')
            r.setObjectName('Field')
            self.est_labels[key] = r
            lay.addWidget(r)
        est_row = QHBoxLayout()
        self.measure_btn = QPushButton(t('Measure this machine'))
        self.measure_btn.setObjectName('Test')
        self.measure_btn.setCursor(Qt.PointingHandCursor)
        self.measure_btn.clicked.connect(self._measure)
        self.measure_note = QLabel('')
        self.measure_note.setObjectName('Note')
        self.measure_note.setWordWrap(True)
        est_row.addWidget(self.measure_btn)
        est_row.addWidget(self.measure_note, 1)
        lay.addLayout(est_row)
        self.measure_bar = QProgressBar()
        self.measure_bar.setObjectName('Level')
        self.measure_bar.setRange(0, 0)
        self.measure_bar.setTextVisible(False)
        self.measure_bar.setFixedHeight(6)
        self.measure_bar.setVisible(False)
        lay.addWidget(self.measure_bar)
        self._show_estimate()
        lay.addStretch()
        return page

    def _page_training(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('TRAINING', 'This runs on your computer and can take hours, and Kara is unusable while it does — start it when you do not need it. The model in use is not replaced unless the new one measures better.'))
        record.RECORDINGS, record.MANIFEST = record.speaker_paths(self.win.speaker)
        clips = profile.clip_count(self.win.speaker)
        lay.addWidget(self._field_label('Model to train'))
        self.train_model_name = QLabel('')
        self.train_model_name.setObjectName('Field')
        lay.addWidget(self.train_model_name)
        self.train_info = QLabel('')
        self.train_info.setObjectName('Note')
        self.train_info.setWordWrap(True)
        lay.addWidget(self.train_info)
        self.train_bar = QProgressBar()
        self.train_bar.setObjectName('Level')
        self.train_bar.setRange(0, 100)
        self.train_bar.setTextVisible(False)
        self.train_bar.setFixedHeight(8)
        self.train_bar.hide()
        lay.addWidget(self.train_bar)
        self.train_status = QLabel('')
        self.train_status.setObjectName('Note')
        self.train_status.setWordWrap(True)
        lay.addWidget(self.train_status)
        row = QHBoxLayout()
        self.train_btn = QPushButton(t('Start training'))
        self.train_btn.setObjectName('Test')
        self.train_btn.setCursor(Qt.PointingHandCursor)
        self.train_btn.clicked.connect(self._train_start)
        self.pause_btn = QPushButton(t('Pause'))
        self.pause_btn.setObjectName('Test')
        self.pause_btn.setCursor(Qt.PointingHandCursor)
        self.pause_btn.clicked.connect(self._train_pause)
        self.pause_btn.setEnabled(False)
        row.addWidget(self.train_btn)
        row.addWidget(self.pause_btn)
        row.addStretch()
        lay.addLayout(row)
        self.train_note = QLabel('')
        self.train_note.setObjectName('Note')
        self.train_note.setWordWrap(True)
        lay.addWidget(self.train_note)
        self._train_size_changed()
        lay.addSpacing(10)
        lay.addWidget(self._field_label('Remind me to train'))
        self.remind_combo = QComboBox()
        for label, days in (('Every week', 7), ('Every two weeks', 14), ('Every month', 30), ('Never', 0)):
            self.remind_combo.addItem(t(label), days)
        want = int(self.cfg.get('train_reminder_days', 7) or 0)
        idx = next((i for i in range(self.remind_combo.count()) if self.remind_combo.itemData(i) == want), 0)
        self.remind_combo.setCurrentIndex(idx)
        self.remind_combo.currentIndexChanged.connect(lambda: self._stage('train_reminder_days', int(self.remind_combo.currentData() or 0)))
        lay.addWidget(self.remind_combo)
        lay.addSpacing(16)
        lay.addWidget(self._section('WORDS KARA KEEPS GETTING WRONG', '“Two” and “too” sound identical, so no amount of extra training separates them. Teaching Kara which you meant fixes that word from then on.'))
        self.wordfix_box = QVBoxLayout()
        self.wordfix_box.setSpacing(6)
        lay.addLayout(self.wordfix_box)
        self._fill_wordfix()
        lay.addSpacing(16)
        lay.addWidget(self._section('LEARN WORDS FROM YOUR WRITING', 'Nothing is used unless you tick it, and unticking a page makes Kara forget what it learned from that page.'))
        kept = QLabel(t('Only the WORDS are kept, never what you wrote.'))
        kept.setObjectName('Note')
        kept.setWordWrap(True)
        lay.addWidget(kept)
        self.doc_boxes = []
        try:
            import librarytrain
            rows = librarytrain.choices(self.win.speaker)
        except Exception:
            rows = []
        if not rows:
            empty = QLabel(t('You have not written any pages yet.'))
            empty.setObjectName('Note')
            lay.addWidget(empty)
        for r in rows:
            cb = ToggleSwitch(_short(r['title'], 46))
            cb.setChecked(bool(r['included']))
            cb.toggled.connect(lambda on, i=r['id']: self._doc_training_changed(i, bool(on)))
            self.doc_boxes.append(cb)
            lay.addWidget(cb)
        self.doc_note = QLabel('')
        self.doc_note.setObjectName('Note')
        self.doc_note.setWordWrap(True)
        lay.addWidget(self.doc_note)
        self._describe_doc_training()
        lay.addStretch()
        self._train_refresh_info(clips)
        return page

    def _train_out_dir(self, size: str) -> Path:
        return ROOT / 'models' / self.win.speaker / f'candidate-{size}'

    def _train_model(self) -> str:
        slider = getattr(self, 'model_slider', None)
        if slider is None:
            return self.win.model
        return MODEL_LADDER[max(0, min(slider.value(), len(MODEL_LADDER) - 1))]

    def _train_refresh_info(self, clips: int | None=None):
        import calibrate
        size = self._train_model()
        if clips is None:
            clips = profile.clip_count(self.win.speaker)
        import practice as _practice
        extra = _practice.clip_count(self.win.speaker)
        rep = calibrate.estimate_report(self.win.speaker, clips + extra)
        row = next((r for r in rep['options'] if r['model'] == size), None)
        est = calibrate.human(row['hours']) if row and row.get('hours') else '—'
        resumable = any(self._train_out_dir(size).glob('checkpoint-*'))
        line = t('%s clips recorded · about %s on this computer') % (clips, est)
        if extra:
            line += t('  ·  %s from practice') % (extra,)
        if resumable:
            line += t('  ·  a paused run can be resumed')
        self.train_info.setText(line)
        self.train_btn.setText(t('Resume training') if resumable else t('Start training'))

    def _check_update(self):
        import threading
        self.update_btn.setEnabled(False)
        self.update_note.setText(t('Checking…'))

        def work():
            try:
                import updates
                info = updates.available(VERSION, self.cfg.get('update_source') or None)
            except Exception as e:
                info = {'ok': False, 'why': type(e).__name__, 'newer': False}
            self._update_checked.emit(info)
        threading.Thread(target=work, daemon=True, name='kara-update').start()

    def _update_result(self, info: dict):
        self.update_btn.setEnabled(True)
        if not info.get('ok'):
            self.update_note.setText(info.get('why') or 'Could not check.')
            return
        if not info.get('newer'):
            self.update_note.setText(t('Kara is up to date (v%s).') % (VERSION,))
            return
        self._update_url = info.get('url') or ''
        self.update_note.setText(t('Version %s is available. Kara will restart to finish installing it.') % (info['version'],))
        self.update_btn.setText(t('Install %s') % (info['version'],))
        self.update_btn.setObjectName('Primary')
        self.update_btn.style().unpolish(self.update_btn)
        self.update_btn.style().polish(self.update_btn)
        self.update_btn.clicked.disconnect()
        self.update_btn.clicked.connect(self._install_update)

    def _install_update(self):
        import threading
        self.update_btn.setEnabled(False)

        def work():
            try:
                import updates
                ok, why = updates.install(self._update_url, progress=lambda m: self._update_progress.emit(m))
            except Exception as e:
                ok, why = (False, type(e).__name__)
            self._update_installed.emit(ok, why)
        threading.Thread(target=work, daemon=True, name='kara-install').start()

    def _update_done(self, ok: bool, why: str):
        if not ok:
            self.update_btn.setEnabled(True)
            self.update_note.setText(t('Could not install it (%s). Nothing has changed.') % (why,))
            return
        self.update_note.setText(t('Installed. Restarting Kara…'))
        karalog.get('update').info('installed; restarting')
        QTimer.singleShot(900, self.win.restart)

    def _fill_wordfix(self):
        box = getattr(self, 'wordfix_box', None)
        if box is None:
            return
        while box.count():
            item = box.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        try:
            import wordfix
            rows = wordfix.candidates(self.win.speaker)
            already = wordfix.taught(self.win.speaker)
        except Exception:
            rows, already = ([], [])
        offered = [r for r in rows if not r['known']]
        if not offered:
            note = QLabel(t('Nothing yet — this fills in when you correct the same word three times.'))
            note.setObjectName('Note')
            note.setWordWrap(True)
            box.addWidget(note)
        for r in offered:
            row = QWidget()
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 0, 0, 0)
            h.setSpacing(8)
            lab = QLabel(t('“%s” → “%s”   ·   %s times') % (r['heard'], r['meant'], r['count']))
            lab.setObjectName('Field')
            b = QPushButton(t('Always fix this'))
            b.setObjectName('Test')
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, h_=r['heard'], m=r['meant']: self._teach_wordfix(h_, m))
            h.addWidget(lab, 1)
            h.addWidget(b)
            box.addWidget(row)
        if already:
            cap = QLabel(t('Kara is already fixing %s word(s):') % (len(already),))
            cap.setObjectName('Note')
            box.addWidget(cap)
        for heard, meant in already[:12]:
            row = QWidget()
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 0, 0, 0)
            h.setSpacing(8)
            lab = QLabel(f'“{heard}” → “{meant}”')
            lab.setObjectName('Note')
            b = QPushButton(t('Stop'))
            b.setObjectName('Test')
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda _=False, h_=heard: self._forget_wordfix(h_))
            h.addWidget(lab, 1)
            h.addWidget(b)
            box.addWidget(row)

    def _teach_wordfix(self, heard: str, meant: str):
        try:
            import wordfix
            wordfix.teach(self.win.speaker, heard, meant)
            karalog.get('gui').info('taught a word correction')
        except Exception as e:
            karalog.get('gui').warning('could not teach word: %s', e)
        self._fill_wordfix()

    def _forget_wordfix(self, heard: str):
        try:
            import wordfix
            wordfix.forget(self.win.speaker, heard)
            karalog.get('gui').info('removed a word correction')
        except Exception as e:
            karalog.get('gui').warning('could not remove word: %s', e)
        self._fill_wordfix()

    def _doc_training_changed(self, doc_id: str, on: bool):
        try:
            import librarytrain
            if on:
                librarytrain.include(self.win.speaker, doc_id)
            else:
                librarytrain.forget(self.win.speaker, doc_id)
            karalog.get('gui').info('library training: %s a document', 'added' if on else 'removed')
        except Exception as e:
            karalog.get('gui').warning('library training failed: %s', e)
        self._describe_doc_training()

    def _describe_doc_training(self):
        if not hasattr(self, 'doc_note'):
            return
        try:
            import librarytrain
            known = self.win.proof.is_known if hasattr(self.win, 'proof') else None
            s = librarytrain.summary(self.win.speaker, known)
        except Exception:
            self.doc_note.setText('')
            return
        if not s['documents']:
            self.doc_note.setText(t('No pages chosen. Kara is not learning from anything you have written.'))
            return
        line = f"{s['documents']} page(s) chosen — {s['words']} word(s) Kara did not already know."
        if s['sample']:
            line += '  ' + ', '.join(s['sample'][:12])
            if s['words'] > 12:
                line += ', …'
        self.doc_note.setText(line)

    def _train_size_changed(self):
        if not hasattr(self, 'train_note'):
            return
        size = self._train_model()
        big = size == 'large-v3'
        name = t(MODEL_OPTIONS[size]['label'].split(' — ')[0])
        self.train_model_name.setText(name + (t('  ·  cannot be paused') if big else ''))
        self._train_pausable = not big
        if big:
            self.train_note.setText(t('Large cannot be paused. Saving part-way through would turn off the check that keeps the BEST version — and large gets worse if it trains past its best point, while still looking like it is improving. It has to run start to finish, and it is slow: leave it overnight.'))
        else:
            self.train_note.setText('')

    def _train_start(self):
        size = self._train_model()
        clips = profile.clip_count(self.win.speaker)
        if clips < 20:
            QMessageBox.information(self, t('Not enough recordings'), t('There are only %s clips. Practice adds more — about 50 is the point where a model starts being useful.') % (clips,))
            return
        if not self.win.start_training():
            return
        worker = self.win._trainer
        worker.progress.connect(self._train_progress)
        worker.finished_ok.connect(self._train_done)
        worker.failed.connect(self._train_failed)
        self.train_bar.setValue(0)
        self.train_bar.show()
        self.train_btn.setEnabled(False)
        self.pause_btn.setEnabled(getattr(self, '_train_pausable', True))
        self._lock_model_control(True)
        self.train_status.setText(t('Starting… (loading the model can take a minute)'))

    def _lock_model_control(self, locked: bool):
        slider = getattr(self, 'model_slider', None)
        if slider is not None:
            slider.setEnabled(not locked)

    def _train_progress(self, msg: dict):
        total, step = (msg.get('total', 0), msg.get('step', 0))
        if total:
            self.train_bar.setValue(int(100 * step / total))
        bits = [f'step {step}' + (f' of {total}' if total else ''), f"epoch {msg.get('epoch', 0)}"]
        if 'loss' in msg:
            bits.append(f"loss {msg['loss']}")
        if 'wer' in msg:
            bits.append(f"error {msg['wer'] * 100:.1f}%")
        if msg.get('saved'):
            bits.append('saved')
        self.train_status.setText('  ·  '.join(bits))

    def _train_pause(self):
        self.win.stop_training()
        self.pause_btn.setEnabled(False)
        self.train_status.setText(t('Pausing… the last checkpoint is kept.'))

    def _train_done(self, out: str):
        self.train_bar.setValue(100)
        self.train_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self._lock_model_control(False)
        self.train_status.setText(t('Finished. Kara will use it next time it starts.'))
        self._train_refresh_info()

    def _train_failed(self, err: str):
        self.train_btn.setEnabled(True)
        self.pause_btn.setEnabled(False)
        self._lock_model_control(False)
        if err == 'paused':
            self.train_status.setText(t('Paused. Everything trained so far is saved — press Resume training to continue.'))
        else:
            self.train_status.setText(t('Training stopped: %s') % (err,))
        self._train_refresh_info()

    def _page_analytics(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('WHAT RECORDING MORE BUYS YOU'))
        self.curve_chart = WerChart()
        lay.addWidget(self.curve_chart)
        self.curve_note = QLabel('')
        self.curve_note.setObjectName('Note')
        self.curve_note.setWordWrap(True)
        lay.addWidget(self.curve_note)
        lay.addSpacing(16)
        lay.addWidget(self._section('THE ADAPTATION LOOP', 'A retrained model is only put into use if it beats the current one on the same held-out clips. Every attempt is recorded here, including the ones that were not good enough.'))
        self.hist_chart = WerChart()
        lay.addWidget(self.hist_chart)
        self.hist_note = QLabel('')
        self.hist_note.setObjectName('Note')
        self.hist_note.setWordWrap(True)
        lay.addWidget(self.hist_note)
        lay.addStretch()
        self._refresh_analytics()
        return page

    def _refresh_analytics(self):
        if not hasattr(self, 'curve_chart'):
            return
        try:
            data = analytics.summary(self.win.speaker)
        except Exception as e:
            karalog.get('settings').warning('analytics: %s', e)
            self.curve_note.setText(t('Could not read the measurements.'))
            return
        curve = data['curve']
        self.curve_chart.set_points([(c['clips_trained'], c['wer'], f"{c['clips_trained']}") for c in curve], empty='No benchmark files in results/ yet.', mark='clips recorded  →')
        if curve:
            first, best = (curve[0], min(curve, key=lambda c: c['wer']))
            self.curve_note.setText(t('%s clips already gets to %.1f%%. The real gain is between 200 and 300, and it flattens after: best measured is %.1f%% at %s clips. Every point is scored on the same %s held-out clips.') % (first['clips_trained'], first['wer'] * 100, best['wer'] * 100, best['clips_trained'], first['clips']))
        hist = data['history']
        self.hist_chart.set_points([(i + 1, h['candidate_wer'], time.strftime('%d %b', time.localtime(h.get('at', 0))) if h.get('at') else str(i + 1)) for i, h in enumerate(hist)], empty=t('No retrain has been scored yet — this fills in the first time the adaptation loop runs.'))
        if hist:
            latest = data['latest']
            self.hist_note.setText(t('%s evaluation(s), %s deployed. Latest: %.2f%% against %.2f%% in use — %s.') % (data['evaluations'], data['deployed'], latest['candidate_wer'] * 100, latest['current_wer'] * 100, t('deployed') if latest.get('deploy') else t('kept the current model')))
        else:
            self.hist_note.setText(t('Nothing scored yet — this fills in after the first retrain.'))

    def _page_modes(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('MODES'))
        self.spell_chk = ToggleSwitch('Include Spelling Mode')
        self.spell_chk.setChecked(self.cfg.get('include_spelling', True))
        self.spell_chk.toggled.connect(self._spelling_toggled)
        lay.addWidget(self.spell_chk)
        lay.addStretch()
        return page

    def _page_commands(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('YOUR OWN COMMANDS', 'A new phrase is checked against ordinary sentences first. If it is close to something you might simply say out loud, Kara refuses it — otherwise a command starts eating your writing.'))
        self.cmd_list = QVBoxLayout()
        self.cmd_list.setSpacing(6)
        holder = QWidget()
        holder.setLayout(self.cmd_list)
        lay.addWidget(holder)
        lay.addWidget(self._field_label('When I say'))
        self.cmd_phrase = QLineEdit()
        self.cmd_phrase.setPlaceholderText(t('“morning email”'))
        self.cmd_phrase.textChanged.connect(self._check_phrase)
        lay.addWidget(self.cmd_phrase)
        lay.addWidget(self._field_label('Kara should'))
        self.cmd_action = QComboBox()
        self.cmd_action.addItem(t('Type some text…'), usercommands.INSERT)
        for key in ('send', 'undo', 'redo', 'new_line', 'read', 'clear', 'delete_word', 'delete_sentence', 'capitalize'):
            self.cmd_action.addItem(RESCUE_NAMES.get(key, key.replace('_', ' ')), key)
        self.cmd_action.currentIndexChanged.connect(self._check_phrase)
        lay.addWidget(self.cmd_action)
        self.cmd_text_label = self._field_label('Kara types')
        lay.addWidget(self.cmd_text_label)
        self.cmd_text = QLineEdit()
        self.cmd_text.setPlaceholderText(t('Dear Priya,'))
        lay.addWidget(self.cmd_text)
        self.cmd_verdict = QLabel('')
        self.cmd_verdict.setObjectName('Note')
        self.cmd_verdict.setWordWrap(True)
        lay.addWidget(self.cmd_verdict)
        self.cmd_add = QPushButton(t('Add this command'))
        self.cmd_add.setObjectName('Test')
        self.cmd_add.setCursor(Qt.PointingHandCursor)
        self.cmd_add.clicked.connect(self._add_command)
        lay.addWidget(self.cmd_add, alignment=Qt.AlignLeft)
        self._fill_commands()
        self._check_phrase()
        lay.addSpacing(18)
        lay.addWidget(self._section('EVERYTHING YOU CAN SAY'))
        try:
            import sayhelp
            total = 0
            for title, rows in sayhelp.sections(self.win.speaker, self.cfg.get('language')):
                lay.addWidget(self._field_label(title))
                for what, say in rows:
                    r = QHBoxLayout()
                    r.setSpacing(12)
                    w = QLabel(t(what))
                    w.setObjectName('Note')
                    w.setWordWrap(True)
                    s = QLabel(f'“{say}”')
                    s.setStyleSheet(f"color:{P['beige']};font-weight:600;")
                    s.setWordWrap(True)
                    r.addWidget(w, 3)
                    r.addWidget(s, 2)
                    lay.addLayout(r)
                    total += 1
            note = QLabel(t('%s things you can say. Every one is read from the tables Kara actually parses, so this list cannot promise something it will not accept.') % (total,))
            note.setObjectName('Note')
            note.setWordWrap(True)
            lay.addSpacing(6)
            lay.addWidget(note)
        except Exception as e:
            karalog.get('gui').warning('command list failed to build: %s', e)
        lay.addStretch()
        return page

    def _fill_commands(self):
        while self.cmd_list.count():
            item = self.cmd_list.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        rows = usercommands.load(self.win.speaker)
        if not rows:
            empty = QLabel(t('Nothing yet. A phrase you add here becomes something you can say out loud.'))
            empty.setObjectName('Empty')
            empty.setWordWrap(True)
            empty.setAlignment(Qt.AlignCenter)
            self.cmd_list.addWidget(empty)
            return
        for i, row in enumerate(rows):
            line = QHBoxLayout()
            what = f'''type "{_short(row.get('text', ''), 28)}"''' if row['action'] == usercommands.INSERT else RESCUE_NAMES.get(row['action'], row['action'])
            lab = QLabel(f"“{row['phrases'][0]}”  →  {what}")
            lab.setObjectName('Field')
            lab.setWordWrap(True)
            line.addWidget(lab, 1)
            rm = QPushButton(t('Remove'))
            rm.setObjectName('Test')
            rm.setCursor(Qt.PointingHandCursor)
            rm.clicked.connect(lambda _=False, k=i: self._remove_command(k))
            line.addWidget(rm)
            box = QWidget()
            box.setLayout(line)
            self.cmd_list.addWidget(box)

    def _check_phrase(self):
        if not hasattr(self, 'cmd_verdict'):
            return
        phrase = (self.cmd_phrase.text() or '').strip()
        is_insert = self.cmd_action.currentData() == usercommands.INSERT
        self.cmd_text.setVisible(is_insert)
        if not phrase:
            self.cmd_verdict.setText('')
            self.cmd_add.setEnabled(False)
            return
        c = usercommands.collision(phrase, self.win.speaker)
        b = usercommands.check_against_builtins(phrase)
        if b['clash']:
            self.cmd_verdict.setText(t('Kara already has that one — it does “%s”.') % (RESCUE_NAMES.get(b['command'], b['command']),))
            self.cmd_add.setEnabled(False)
            return
        example = c['examples'][0] if c['examples'] else ''
        if c['verdict'] == 'refuse':
            self.cmd_verdict.setText(t('Too close to something you actually say — “%s”. If this were a command, saying that sentence would trigger it instead of writing it. Pick a different phrase.') % (example,))
            self.cmd_add.setEnabled(False)
        elif c['verdict'] == 'warn':
            self.cmd_verdict.setText(t('A bit close to “%s”. It should be fine, but if Kara starts running this when you meant to write, change it.') % (example,))
            self.cmd_add.setEnabled(True)
        elif c['verdict'] == 'unmeasured':
            self.cmd_verdict.setText(t('Kara cannot check this one — it has no ordinary %s sentences to compare it against. You can still add it, but watch whether it starts firing while you write.') % (t(c.get('script', '')),))
            self.cmd_add.setEnabled(True)
        else:
            self.cmd_verdict.setText(t('Safe — nothing you normally say sounds like this.'))
            self.cmd_add.setEnabled(True)

    def _add_command(self):
        phrase = (self.cmd_phrase.text() or '').strip().lower()
        action = self.cmd_action.currentData()
        if not phrase:
            return
        row = {'phrases': [phrase], 'action': action}
        if action == usercommands.INSERT:
            text = (self.cmd_text.text() or '').strip()
            if not text:
                self.cmd_verdict.setText(t('Type the text it should write.'))
                return
            row['text'] = text
        rows = usercommands.load(self.win.speaker) + [row]
        usercommands.save(self.win.speaker, rows)
        self.win._reload_user_commands()
        self.cmd_phrase.clear()
        self.cmd_text.clear()
        self._fill_commands()
        self._check_phrase()
        karalog.get('settings').info('custom command added (%s)', action)

    def _remove_command(self, index: int):
        rows = usercommands.load(self.win.speaker)
        if 0 <= index < len(rows):
            rows.pop(index)
            usercommands.save(self.win.speaker, rows)
            self.win._reload_user_commands()
            self._fill_commands()

    def _page_about(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('ABOUT KARA'))
        lay.addWidget(Wordmark(30, colour=P['beige'], ink=P['ink'], void=P['canvas'], families=DISPLAY_STACK))
        lay.addSpacing(4)
        blurb = QLabel(t('Kara turns speech into writing, and learns your voice so it understands you better.\n\nEverything stays on this computer. There is no account and no server.'))
        blurb.setObjectName('Field')
        blurb.setWordWrap(True)
        lay.addWidget(blurb)
        ver = QLabel(t('Version %s   ·   terms version %s') % (VERSION, TERMS_VERSION) + (t('  ·  accepted') if terms_accepted() else t('  ·  not accepted')))
        ver.setObjectName('Note')
        lay.addWidget(ver)
        lay.addSpacing(12)
        lay.addWidget(self._section('UPDATES'))
        row = QHBoxLayout()
        row.setSpacing(8)
        self.update_btn = QPushButton(t('Check for an update'))
        self.update_btn.setObjectName('Test')
        self.update_btn.setCursor(Qt.PointingHandCursor)
        self.update_btn.clicked.connect(self._check_update)
        row.addWidget(self.update_btn)
        row.addStretch()
        lay.addLayout(row)
        self.update_note = QLabel('')
        self.update_note.setObjectName('Note')
        self.update_note.setWordWrap(True)
        lay.addWidget(self.update_note)
        self.update_chk = ToggleSwitch('Look for updates automatically')
        self.update_chk.setChecked(bool(self.cfg.get('update_check', True)))
        self.update_chk.toggled.connect(lambda on: self._stage('update_check', bool(on)))
        lay.addWidget(self.update_chk)
        lay.addWidget(self._field_label('Where to check'))
        self.update_src = QLineEdit(self.cfg.get('update_source') or '')
        self.update_src.setPlaceholderText(t('https://api.github.com/repos/…/releases/latest'))
        self.update_src.setToolTip(t('A GitHub releases endpoint, a JSON file on any web host, or a file:// path in a shared folder. See RELEASING.md.'))
        self.update_src.editingFinished.connect(self._update_source_changed)
        lay.addWidget(self.update_src)
        if not (self.cfg.get('update_source') or ''):
            self.update_btn.setEnabled(False)
            self.update_note.setText(t('No update source is set up yet.'))
        lay.addSpacing(12)
        lay.addWidget(self._section('LEGAL'))
        for title, path in LEGAL_DOCS:
            b = QPushButton(t(title))
            b.setObjectName('Test')
            b.setCursor(Qt.PointingHandCursor)
            b.setEnabled(path.exists())
            if not path.exists():
                b.setText(t('%s  (missing)') % (title,))
            b.clicked.connect(lambda _=False, t=title, p=path: self._show_doc(t, p))
            lay.addWidget(b, alignment=Qt.AlignLeft)
        lay.addStretch()
        return page

    def _page_data(self) -> QWidget:
        page, lay = self._page()
        lay.addWidget(self._section('YOUR DATA ON THIS COMPUTER'))
        self.inv_table = QWidget()
        self.inv_lay = QVBoxLayout(self.inv_table)
        self.inv_lay.setContentsMargins(0, 6, 0, 0)
        self.inv_lay.setSpacing(2)
        lay.addWidget(self.inv_table)
        self._fill_inventory()
        lay.addSpacing(14)
        lay.addWidget(self._section('WORDS KARA NO LONGER FLAGS'))
        note = QLabel(t('Words you added to your dictionary, or told Kara to ignore. Remove one to start seeing the red underline again.'))
        note.setObjectName('Note')
        note.setWordWrap(True)
        lay.addWidget(note)
        self.dict_box = QWidget()
        self.dict_lay = QVBoxLayout(self.dict_box)
        self.dict_lay.setContentsMargins(0, 6, 0, 0)
        self.dict_lay.setSpacing(2)
        lay.addWidget(self.dict_box)
        self._fill_dictionary()
        self.keep_utt = ToggleSwitch('Keep the last few recordings so Kara can learn from my corrections')
        self.keep_utt.setChecked(bool(self.cfg.get('keep_utterances', True)))
        self.keep_utt.setToolTip(t('The last %s things you say are kept on this computer so that when you correct Kara, it can see what it got wrong.\nOlder ones are deleted automatically. They are never put in a backup or a diagnostics file, and never leave this machine.\nTurning this off deletes the ones already kept.') % (utterances.KEEP,))
        self.keep_utt.toggled.connect(self._toggle_keep_utterances)
        lay.addWidget(self.keep_utt)
        btns = QHBoxLayout()
        openf = QPushButton(t('Open the folder'))
        openf.setObjectName('Test')
        openf.setCursor(Qt.PointingHandCursor)
        openf.clicked.connect(self._open_data_folder)
        forget = QPushButton(t('Forget recordings'))
        forget.setObjectName('Test')
        forget.setCursor(Qt.PointingHandCursor)
        forget.setToolTip(t('Delete the recent recordings now, keeping the setting on.'))
        forget.clicked.connect(self._forget_utterances)
        diag = QPushButton(t('Save diagnostics…'))
        diag.setObjectName('Test')
        diag.setCursor(Qt.PointingHandCursor)
        diag.setToolTip(t('A file describing this computer and what Kara has been doing, to send to whoever is helping you.\nIt contains no recordings, no writing and no names.'))
        diag.clicked.connect(self._save_diagnostics)
        wipe = QPushButton(t('Delete everything'))
        wipe.setObjectName('Test')
        wipe.setCursor(Qt.PointingHandCursor)
        wipe.clicked.connect(self._erase_profile)
        btns.addWidget(openf)
        btns.addWidget(forget)
        btns.addWidget(diag)
        btns.addWidget(wipe)
        btns.addStretch()
        lay.addLayout(btns)
        lay.addStretch()
        return page

    def _fill_inventory(self):
        while self.inv_lay.count():
            item = self.inv_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        rows = profile.data_inventory(self.win.speaker)
        total = 0
        for r in rows:
            total += r['bytes']
            w = QWidget()
            rl = QHBoxLayout(w)
            rl.setContentsMargins(0, 4, 0, 4)
            rl.setSpacing(8)
            left = QLabel(f"{r['what']}\n{r['detail']}")
            left.setObjectName('Field')
            size = QLabel(profile.human_bytes(r['bytes']))
            size.setObjectName('Note')
            size.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            size.setFixedWidth(70)
            w.setToolTip(f"{r['why']}\n\n{r['where']}")
            rl.addWidget(left, 1)
            rl.addWidget(size)
            self.inv_lay.addWidget(w)
        tot = QLabel(t('Total: %s') % (profile.human_bytes(total),))
        tot.setObjectName('Field')
        self.inv_lay.addWidget(tot)

    def _open_data_folder(self):
        import subprocess
        path = profile.paths(self.win.speaker)['base']
        path.mkdir(parents=True, exist_ok=True)
        try:
            subprocess.Popen(['explorer', str(path)])
        except Exception as e:
            info = errors.classify(e, default='KARA-3002')
            karalog.get('settings').warning('open folder failed [%s]: %s', info.code, e)
            QMessageBox.warning(self, info.title, info.message(str(e)))

    def _describe_offline(self):
        if self.offline_chk.isChecked():
            self.offline_note.setText(t('Nothing leaves this computer. Your voice, your writing and the spelling checker all run here.\n\nTurn this off for one thing only: better grammar checking (subject-verb agreement, tense, word order). Backing up to a folder works either way.'))
        else:
            self.offline_note.setText(t('Your voice is still recognised on this computer and never uploaded — but the text you write is sent to a grammar server to be checked. You can point that at a server you run yourself, below, to keep it on your own network.'))

    def _service_changed(self):
        url = self.service_edit.text().strip() or proofing.DEFAULT_SERVICE
        if url == self.cfg.get('grammar_service'):
            return
        self._stage('grammar_service', url)
        self._describe_offline()

    def _toggle_offline(self, on: bool):
        self._stage('offline_mode', bool(on))
        self._describe_offline()

    def _fill_dictionary(self):
        while self.dict_lay.count():
            item = self.dict_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        d = proofing.load_dictionary(self.win.speaker)
        rows = [(w, 'in my dictionary') for w in d['added']] + [(w, 'ignored') for w in d['ignored']]
        if not rows:
            empty = QLabel(t('Nothing yet. Right-click a red word in your writing to add or ignore it.'))
            empty.setObjectName('Note')
            empty.setWordWrap(True)
            self.dict_lay.addWidget(empty)
            return
        for word, why in sorted(rows, key=lambda r: r[0].lower()):
            row = QWidget()
            rl = QHBoxLayout(row)
            rl.setContentsMargins(0, 2, 0, 2)
            rl.setSpacing(8)
            lab = QLabel(f'{word}')
            lab.setObjectName('Field')
            tag = QLabel(t(why))
            tag.setObjectName('Note')
            rm = QPushButton(t('Remove'))
            rm.setObjectName('Test')
            rm.setCursor(Qt.PointingHandCursor)
            rm.clicked.connect(lambda _=False, w=word: self._forget_word(w))
            rl.addWidget(lab)
            rl.addWidget(tag)
            rl.addStretch()
            rl.addWidget(rm)
            self.dict_lay.addWidget(row)

    def _forget_word(self, word: str):
        proofing.forget_word(self.win.speaker, word)
        karalog.get('settings').info('dictionary: removed %r', word)
        try:
            if self.win._proof is not None:
                self.win.proof.reload()
                self.win._recheck()
        except Exception:
            pass
        self._fill_dictionary()

    def _toggle_keep_utterances(self, on: bool):
        self._stage('keep_utterances', bool(on))

    def _forget_utterances(self):
        n = utterances.forget_all(self.win.speaker)
        karalog.get('settings').info('forgot %d utterances on request', n)
        self._fill_inventory()
        QMessageBox.information(self, t('Forgotten'), t('%s recent recording(s) deleted.') % (n,) if n else t('There were no recent recordings to delete.'))

    def _save_diagnostics(self):
        from PySide6.QtWidgets import QFileDialog
        default = str(Path.home() / 'Desktop' / karalog.default_bundle_name())
        path, _ = QFileDialog.getSaveFileName(self, t('Save diagnostics'), default, 'Zip file (*.zip)')
        if not path:
            return
        try:
            out = karalog.diagnostics_bundle(path, self.win.speaker)
        except Exception as e:
            info = errors.classify(e, default='KARA-3001')
            karalog.get('settings').error('diagnostics failed [%s]: %s', info.code, e)
            QMessageBox.warning(self, info.title, info.message(str(e)))
            return
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Information)
        box.setWindowTitle(t('Diagnostics saved'))
        box.setText(t('Saved to:\n%s') % (out,))
        box.exec()

    def _erase_profile(self):
        name = self.win.speaker
        s = profile.data_summary(name)
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle(t('Delete everything?'))
        box.setText(t('This permanently deletes everything for “%s”:\n\n  · %s voice recordings\n  · %s pages of writing\n  · %s trained model(s)\n  · names, settings and photo\n\nThat is %s. It cannot be undone, and the recordings cannot be recreated without doing the setup again.') % (name, s['recordings'], s['documents'], s['models'], s['human']))
        box.addButton(t('Keep my data'), QMessageBox.RejectRole)
        go = box.addButton(t('Delete everything'), QMessageBox.DestructiveRole)
        box.setDefaultButton(box.buttons()[0])
        box.exec()
        if box.clickedButton() is not go:
            return
        again = QMessageBox(self)
        again.setIcon(QMessageBox.Critical)
        again.setWindowTitle(t('Last check'))
        again.setText(t('Really delete everything? There is no undo.'))
        again.addButton(t('Cancel'), QMessageBox.RejectRole)
        sure = again.addButton(t('Yes, delete it all'), QMessageBox.DestructiveRole)
        again.setDefaultButton(again.buttons()[0])
        again.exec()
        if again.clickedButton() is not sure:
            return
        profile.delete_all_data(name)
        QMessageBox.information(self, t('Deleted'), t('Everything for “%s” has been removed.\n\nKara will close now.') % (name,))
        QApplication.quit()

    def _show_doc(self, title: str, path: Path):
        dlg = QDialog(self)
        dlg.setWindowTitle(title)
        dlg.resize(720, 620)
        dlg.setStyleSheet(f"\n            QDialog {{ background:{P['canvas']}; }}\n            QTextEdit {{ background:{P['paper']}; color:{P['paper_ink']};\n                border:1px solid {P['line']}; border-radius:10px;\n                padding:16px 18px; font-size:13px; }}\n            QPushButton {{ background:{P['beige']}; color:{P['on_accent']};\n                border:none; border-radius:10px; padding:8px 22px;\n                font-size:13px; font-weight:600; }}\n        ")
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(18, 18, 18, 14)
        lay.setSpacing(10)
        view = QTextEdit()
        view.setReadOnly(True)
        try:
            text = path.read_text(encoding='utf-8')
        except OSError as e:
            text = f'Could not open {path.name}: {e}'
        if path.suffix.lower() == '.md':
            view.setMarkdown(text)
        else:
            view.setPlainText(text)
        lay.addWidget(view, 1)
        row = QHBoxLayout()
        row.addStretch()
        close = QPushButton(t('Close'))
        close.setCursor(Qt.PointingHandCursor)
        close.clicked.connect(dlg.accept)
        row.addWidget(close)
        lay.addLayout(row)
        dlg.exec()

    def _section(self, text: str, explain: str | None=None) -> QWidget:
        text = t(text)
        explain = t(explain) if explain else explain
        box = QWidget()
        col = QVBoxLayout(box)
        col.setContentsMargins(0, 0, 0, 0)
        col.setSpacing(4)
        if not getattr(self, '_first_section', True):
            rule = QFrame()
            rule.setObjectName('SectionRule')
            rule.setFixedHeight(1)
            col.addWidget(rule)
            col.addSpacing(10)
        self._first_section = False
        row = QHBoxLayout()
        row.setSpacing(7)
        lab = QLabel(text)
        lab.setObjectName('Section')
        row.addWidget(lab)
        if explain:
            hover = textwrap.fill(explain, 64)
            info = QPushButton('i')
            info.setObjectName('Info')
            info.setCheckable(True)
            info.setFixedSize(18, 18)
            info.setCursor(Qt.PointingHandCursor)
            info.setToolTip(hover)
            info.setAccessibleName(f'What {text.title()} does')
            info.setAccessibleDescription(explain)
            lab.setToolTip(hover)
            row.addWidget(info, 0, Qt.AlignVCenter)
        row.addStretch()
        col.addLayout(row)
        if explain:
            body = QLabel(explain)
            body.setObjectName('Explain')
            body.setWordWrap(True)
            body.setVisible(False)
            col.addWidget(body)
            info.toggled.connect(body.setVisible)
        return box

    def _field_label(self, text: str) -> QLabel:
        lab = QLabel(t(text))
        lab.setObjectName('Field')
        return lab

    def _update_source_changed(self):
        value = (self.update_src.text() or '').strip()
        self._stage('update_source', value)
        self.update_btn.setEnabled(bool(value))
        self.update_note.setText('' if value else t('No update source is set up yet.'))

    def _label_with_beta(self, text: str, attr: str) -> QHBoxLayout:
        row = QHBoxLayout()
        row.setSpacing(8)
        row.addWidget(self._field_label(text))
        tag = QLabel(t('BETA'))
        tag.setObjectName('BetaTag')
        tag.setVisible(False)
        setattr(self, attr, tag)
        row.addWidget(tag, 0, Qt.AlignVCenter)
        row.addStretch()
        return row

    def _describe_beta(self):
        for attr, combo in (('lang_beta', 'lang_combo'), ('ui_lang_beta', 'ui_lang_combo')):
            tag = getattr(self, attr, None)
            box = getattr(self, combo, None)
            if tag is None or box is None:
                continue
            tag.setVisible(_is_beta_language(box.currentData()))

    def _fill_inputs(self):
        self.mic_combo.blockSignals(True)
        self.mic_combo.clear()
        self.mic_combo.addItem(t('Automatic (recommended)'), None)
        current = self.cfg.get('input_device')
        devs = record.unique_devices(record.input_devices())
        usable = [(n, a) for _i, n, a in devs if not record.has_marker(n, record.VIRTUAL_MARKERS)]
        hidden = [(n, a) for _i, n, a in devs if record.has_marker(n, record.VIRTUAL_MARKERS)]
        for name, _api in usable:
            degraded = record.has_marker(name, record.DEGRADED_MARKERS)
            self.mic_combo.addItem(record.pretty_name(name) + ('   (Bluetooth — lower quality)' if degraded else ''), name)
        if self._expanded_inputs:
            for name, _api in hidden:
                self.mic_combo.addItem(record.pretty_name(name) + '   (may not be compatible)', name)
        elif hidden:
            self.mic_combo.addItem(t('Show more…'), '__more__')
        self._select_input(current)
        self.mic_combo.blockSignals(False)

    def _select_input(self, name):
        for i in range(self.mic_combo.count()):
            if self.mic_combo.itemData(i) == name:
                self.mic_combo.setCurrentIndex(i)
                return
        self.mic_combo.setCurrentIndex(0)

    def _fill_outputs(self):
        self.out_combo.blockSignals(True)
        self.out_combo.addItem(t('System default'), None)
        current = self.cfg.get('output_device')
        for _i, name, api in record.unique_devices(record.output_devices()):
            self.out_combo.addItem(record.pretty_name(name), name)
            if name == current:
                self.out_combo.setCurrentIndex(self.out_combo.count() - 1)
        self.out_combo.blockSignals(False)

    def _input_changed(self):
        data = self.mic_combo.currentData()
        if data == '__more__':
            self._expanded_inputs = True
            self._fill_inputs()
            self.mic_combo.showPopup()
            return
        if data and record.has_marker(data, record.VIRTUAL_MARKERS):
            if not self._warn_incompatible(data):
                self._fill_inputs()
                return
        self._stage('input_device', data)

    def _warn_incompatible(self, name: str) -> bool:
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle(t('Are you sure?'))
        box.setText(t('“%s” may not be compatible with the program.\n\nIt looks like a virtual or voice-changing device. Audio through it is altered before Kara hears it, so recognition may be poor or fail. Use it anyway?') % (name,))
        box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        box.setDefaultButton(QMessageBox.No)
        return box.exec() == QMessageBox.Yes

    def _output_changed(self):
        self._stage('output_device', self.out_combo.currentData())

    def _describe_model(self, index: int) -> str:
        key = MODEL_LADDER[max(0, min(index, len(MODEL_LADDER) - 1))]
        name = t(MODEL_OPTIONS[key]['label'].split(' — ')[0])
        if key == RECOMMENDED_MODEL:
            self.model_name.setText(t('%s — recommended') % (name,))
        else:
            self.model_name.setText(name)
        self.model_note.setText(t(MODEL_OPTIONS[key]['note']) + '  ' + accuracy_clause(key, self.win.speaker))
        return key

    def _model_slider_moved(self, index: int):
        key = self._describe_model(index)
        self._pending_model = None if key == self.win.model else key
        if hasattr(self, 'train_note'):
            self._train_size_changed()
            self._train_refresh_info()
        self._sync_buttons()

    def _spelling_toggled(self, on: bool):
        self._stage('include_spelling', bool(on))

    def _render_report(self, report: dict, measuring: bool=False):
        if not hasattr(self, 'hw_line'):
            return
        import calibrate
        hw = report['hardware']
        gpu = f"{hw['gpu']}  ·  {hw['vram_gb']} GB" if hw['gpu'] else 'no GPU (CPU only)'
        self.hw_line.setText(t('Graphics: %s      Clips recorded: %s') % (gpu, report['clips']))
        for r in report['options']:
            lab = self.est_labels[r['model']]
            name = t(MODEL_OPTIONS[r['model']]['label'].split(' — ')[0])
            if not r['available']:
                lab.setText(t('%s:  unavailable — %s') % (name, r['reason']))
                continue
            hours = calibrate.human(r['hours']) if r['hours'] is not None else '—'
            row_txt = (t('%s:  ~%s') if r.get('measured') else t('%s:  ~%s  (estimated)')) % (name, hours)
            wer = (r.get('typical_wer') or '').strip()
            if wer and wer != 'not measured':
                row_txt += t('   ·   %s error on the measured voice') % (wer,)
            lab.setText(row_txt)

    def _measured_speeds(self) -> dict:
        out = {}
        for key, val in (self.cfg.get('sec_per_step') or {}).items():
            try:
                out[str(key)] = float(val)
            except (TypeError, ValueError):
                continue
        return out

    def _show_estimate(self):
        import calibrate
        import practice as _practice
        clips = profile.clip_count(self.win.speaker) + _practice.clip_count(self.win.speaker)
        self._render_report(calibrate.estimate_report(self.win.speaker, clips, sec_per_step=self._measured_speeds() or None))

    def _measure(self):
        self.measure_btn.setEnabled(False)
        self.measure_bar.setVisible(True)
        self.measure_note.setText(t('Measuring… this runs real training steps, about 1–2 minutes. You can keep using Kara.'))
        self.win._retire_thread(getattr(self, '_cal', None))
        self._cal = CalibrateWorker(self.win.speaker)
        self._cal.done.connect(self.win._calibrated)
        self._cal.done.connect(self._measured)
        self._cal.failed.connect(self._measure_failed)
        self._cal.start()

    def _measured(self, report: dict):
        self.measure_btn.setEnabled(True)
        self.measure_bar.setVisible(False)
        self.measure_note.setText(t('Measured on this machine.'))
        self.cfg = config.load()
        self._show_estimate()

    def _measure_failed(self, err: str):
        self.measure_btn.setEnabled(True)
        self.measure_bar.setVisible(False)
        self.measure_note.setText(t("Couldn't measure — showing estimates."))

    def _test_output(self):
        dev = record.output_device_index(self.cfg.get('output_device'))
        threading.Thread(target=editing.speak, args=('Kara audio test.', dev), daemon=True).start()

    def _teardown(self):
        cal = getattr(self, '_cal', None)
        if cal is not None and cal.isRunning():
            self.win._retire_thread(cal)
        self._cal = None
        for attr, grace in (('_backup', 10000),):
            t = getattr(self, attr, None)
            if t is None or not t.isRunning():
                continue
            for stopper in ('cancel', 'stop'):
                if hasattr(t, stopper):
                    try:
                        getattr(t, stopper)()
                    except Exception:
                        pass
            if not t.wait(grace):
                self.win._retire_thread(t)
            setattr(self, attr, None)

    def closeEvent(self, e):
        self._teardown()
        super().closeEvent(e)

    def done(self, r):
        self._teardown()
        super().done(r)
SETUP_ORDER = ['setup_letters', 'setup_commands', 'personal_setup', 'setup_core', 'setup_function', 'setup_words', 'setup_punctuation']
SETUP_MAX = 100
TIER_QUICK, TIER_SOLID = (50, 250)
RESCUE_NAMES = {'delete_word': 'delete last word', 'delete_sentence': 'delete last sentence', 'delete_line': 'delete last line', 'clear': 'start over', 'new_line': 'new line', 'undo': 'undo', 'redo': 'redo', 'send': 'send', 'read': 'read it back', 'spell': 'spelling mode', 'exit': 'stop editing'}
TERMS_PATH = ROOT / 'assets' / 'terms.md'
TERMS_VERSION = '1.1-draft'
LEGAL_DOCS = [('Terms of Use', ROOT / 'TERMS.md'), ('Privacy Notice', ROOT / 'PRIVACY.md'), ('Licence', ROOT / 'LICENSE'), ('Third-party notices', ROOT / 'THIRD-PARTY-NOTICES.md')]

def load_terms() -> str:
    try:
        raw = TERMS_PATH.read_text(encoding='utf-8')
    except OSError:
        return 'Terms could not be loaded from assets/terms.md.\n\nKara keeps your recordings and writing on this computer only.'
    lines = raw.splitlines()
    i = 0
    while i < len(lines) and (lines[i].startswith('# ') or not lines[i].strip() or lines[i].startswith('#\n') or (lines[i].rstrip() == '#')):
        if lines[i].startswith('## '):
            break
        i += 1
    return '\n'.join(lines[i:]).strip()

def terms_accepted() -> bool:
    return config.load().get('terms_accepted') == TERMS_VERSION

def accept_terms() -> None:
    cfg = config.load()
    cfg['terms_accepted'] = TERMS_VERSION
    config.save(cfg)

class SetupWizard(QDialog):

    def __init__(self, window: 'Window'):
        super().__init__(window)
        self.win = window
        self.speaker = window.speaker
        self.queue: list[tuple[str, str, str]] = []
        self.cursor = 0
        self.mic = None
        self.recording = False
        self._audio = None
        self.setWindowTitle(t('Set up Kara for your voice'))
        self.setWindowFlags(self.windowFlags() | Qt.WindowMaximizeButtonHint | Qt.WindowMinimizeButtonHint)
        self.setSizeGripEnabled(True)
        self.setMinimumSize(700, 560)
        self.setStyleSheet(f"\n            QDialog {{ background: {P['canvas']}; }}\n            QLabel {{ color: {P['ink']}; font-family: {SANS_STACK}; }}\n            QLabel#H1 {{ font-size: 22px; font-weight: 600; color: {P['ink']}; }}\n            /* 34px, the size practice mode uses for the line you read aloud\n               (QLabel#Say). It was 26px here, which is a different answer to\n               the same question asked on two screens. */\n            QLabel#Prompt {{ font-size: 34px; color: {P['paper_ink']};\n                background: {P['paper']}; border-radius: 10px; padding: 24px; }}\n            QLabel#Note {{ font-size: 13px; color: {P['ink_soft']}; }}\n            QLabel#Field {{ font-size: 14px; color: {P['ink']}; font-weight: 600; }}\n            QLabel#Count {{ font-size: 14px; color: {P['beige_text']}; font-weight: 600; }}\n            QLineEdit, QTextEdit {{\n                background: {P['surface']}; color: {P['ink']};\n                border: 1px solid {P['line']}; border-radius: 10px;\n                padding: 8px 10px; font-size: 14px;\n            }}\n            QLineEdit:focus, QTextEdit:focus {{ border-color: {P['beige']}; }}\n            /* The terms: readable prose, not a cramped legal box. */\n            QTextEdit#Terms {{\n                background: {P['paper']}; color: {P['paper_ink']};\n                border: 1px solid {P['line']}; border-radius: 10px;\n                padding: 16px 18px; font-size: 14px;\n            }}\n            QPushButton#Primary {{\n                background: {P['beige']}; color: {P['on_accent']};\n                border: none; border-radius: 10px;\n                padding: 10px 26px; font-size: 14px; font-weight: 600;\n            }}\n            QPushButton#Primary:hover {{ background: {P['beige_text']}; }}\n            QPushButton#Primary:disabled {{ background: {P['disabled_bg']};\n                color: {P['disabled_fg']}; }}\n            QPushButton#Ghost {{\n                background: transparent; color: {P['beige_text']};\n                border: 1px solid {P['line']}; border-radius: 10px;\n                padding: 10px 20px; font-size: 14px; font-weight: 600;\n            }}\n            QPushButton#Ghost:hover {{ border-color: {P['beige']}; }}\n        ")
        self.stack = QStackedWidget()
        self.stack.addWidget(self._page_welcome())
        self.stack.addWidget(self._page_terms())
        self.stack.addWidget(self._page_form())
        self.stack.addWidget(self._page_record())
        self.stack.addWidget(self._page_done())
        self.steps = QHBoxLayout()
        self.steps.setSpacing(5)
        self._pips = []
        for _ in range(self.stack.count()):
            bar = QFrame()
            bar.setFixedHeight(5)
            self._pips.append(bar)
            self.steps.addWidget(bar)
        self.step_note = QLabel('')
        self.step_note.setObjectName('Note')
        self.step_note.setAlignment(Qt.AlignRight)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(28, 26, 28, 22)
        lay.addLayout(self.steps)
        lay.addWidget(self.step_note)
        lay.addSpacing(6)
        lay.addWidget(self.stack)
        self.stack.currentChanged.connect(self._paint_steps)
        self._paint_steps(0)
        self._meter = QTimer(self)
        self._meter.timeout.connect(self._tick_orb)
        self._meter.start(60)
    STEP_NAMES = ['Welcome', 'Before you start', 'Your words', 'Recording', 'Done']

    def _paint_steps(self, idx: int):
        for i, bar in enumerate(self._pips):
            colour = P['green'] if i < idx else P['beige'] if i == idx else P['line']
            bar.setStyleSheet(f'background:{colour};border-radius:3px;')
        if 0 <= idx < len(self.STEP_NAMES):
            self.step_note.setText(t('Step %s of %s · %s') % (idx + 1, len(self._pips), self.STEP_NAMES[idx]))

    def _page_welcome(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(16)
        lay.addWidget(Wordmark(40, colour=P['beige'], ink=P['ink'], void=P['canvas'], families=DISPLAY_STACK))
        lay.addWidget(self._h1('Teach Kara your voice'))
        body = QLabel(t('Kara learns your voice from a set of short recordings. You will read sentences, a few single words, the letters, and the commands — one at a time, tapping to record.\n\nIt all stays on this computer. Nothing is uploaded, ever.\n\nYou can stop whenever you like and pick up later; every clip is saved as you go. About 50 gets you started; 150 is the sweet spot.'))
        body.setObjectName('Note')
        body.setWordWrap(True)
        body.setStyleSheet(f"font-size:15px; color:{P['ink']};")
        lay.addWidget(body)
        lay.addStretch()
        row = QHBoxLayout()
        row.addStretch()
        nxt = QPushButton(t('Continue'))
        nxt.setObjectName('Primary')
        nxt.setCursor(Qt.PointingHandCursor)
        nxt.clicked.connect(lambda: self.stack.setCurrentIndex(2 if terms_accepted() else 1))
        row.addWidget(nxt)
        lay.addLayout(row)
        return w

    def _page_terms(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(12)
        lay.addWidget(self._h1('Before you start'))
        view = QTextEdit()
        view.setObjectName('Terms')
        view.setReadOnly(True)
        view.setMarkdown(load_terms())
        lay.addWidget(view, 1)
        row = QHBoxLayout()
        back = QPushButton(t('Back'))
        back.setObjectName('Ghost')
        back.setCursor(Qt.PointingHandCursor)
        back.clicked.connect(lambda: self.stack.setCurrentIndex(0))
        row.addWidget(back)
        row.addStretch()
        nxt = QPushButton(t('Continue'))
        nxt.setObjectName('Primary')
        nxt.setCursor(Qt.PointingHandCursor)
        nxt.clicked.connect(self._accept_terms)
        row.addWidget(nxt)
        lay.addLayout(row)
        return w

    def _accept_terms(self):
        accept_terms()
        self.stack.setCurrentIndex(2)

    def _page_form(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(10)
        lay.addWidget(self._h1('Your words'))
        intro = QLabel(t("These become sentences you'll record, and Kara learns to spell them right away. Separate several with commas."))
        intro.setObjectName('Note')
        intro.setWordWrap(True)
        lay.addWidget(intro)
        self.f_name = QLineEdit()
        self.f_name.setPlaceholderText(t('the name you go by'))
        self.f_people = QLineEdit()
        self.f_people.setPlaceholderText(t('family and friends, separated by commas'))
        self.f_places = QLineEdit()
        self.f_places.setPlaceholderText(t('places you go, separated by commas'))
        self.f_org = QLineEdit()
        self.f_org.setPlaceholderText(t('your school or workplace (optional)'))
        self.f_phrases = QTextEdit()
        self.f_phrases.setFixedHeight(70)
        self.f_phrases.setPlaceholderText(t('things you say often, one per line (optional)'))
        for label, field in (('Your name', self.f_name), ('People you talk about', self.f_people), ('Places you go', self.f_places), ('School / work', self.f_org), ('Phrases you use a lot', self.f_phrases)):
            lab = QLabel(t(label))
            lab.setObjectName('Field')
            lay.addWidget(lab)
            lay.addWidget(field)
        lay.addStretch()
        row = QHBoxLayout()
        back = QPushButton(t('Back'))
        back.setObjectName('Ghost')
        back.setCursor(Qt.PointingHandCursor)
        back.clicked.connect(lambda: self.stack.setCurrentIndex(self._step_before(2)))
        row.addWidget(back)
        row.addStretch()
        nxt = QPushButton(t('Continue'))
        nxt.setObjectName('Primary')
        nxt.setCursor(Qt.PointingHandCursor)
        nxt.clicked.connect(self._start_recording)
        row.addWidget(nxt)
        lay.addLayout(row)
        return w

    def _page_record(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(14)
        top = QHBoxLayout()
        self.rec_count = QLabel('')
        self.rec_count.setObjectName('Count')
        self.rec_tier = QLabel('')
        self.rec_tier.setObjectName('Note')
        top.addWidget(self.rec_count)
        top.addStretch()
        top.addWidget(self.rec_tier)
        lay.addLayout(top)
        self.rec_prompt = QLabel('')
        self.rec_prompt.setObjectName('Prompt')
        self.rec_prompt.setWordWrap(True)
        self.rec_prompt.setAlignment(Qt.AlignCenter)
        self.rec_prompt.setMinimumHeight(150)
        lay.addWidget(self.rec_prompt, 1)
        self.rec_orb = MicOrb(source=self._orb_level, accent=P['beige'], canvas=P['canvas'])
        self.rec_orb.set_state('idle')
        self.rec_orb.clicked.connect(self._toggle_rec)
        lay.addWidget(self.rec_orb, alignment=Qt.AlignCenter)
        self.rec_hint = QLabel(t('Tap the circle, read the line, tap again to stop.'))
        self.rec_hint.setObjectName('Note')
        self.rec_hint.setAlignment(Qt.AlignCenter)
        lay.addWidget(self.rec_hint)
        lay.addStretch()
        row = QHBoxLayout()
        self.back_btn = QPushButton(t('Back'))
        self.back_btn.setObjectName('Ghost')
        self.back_btn.setCursor(Qt.PointingHandCursor)
        self.back_btn.clicked.connect(self._prev)
        self.next_btn = QPushButton(t('Next'))
        self.next_btn.setObjectName('Ghost')
        self.next_btn.setCursor(Qt.PointingHandCursor)
        self.next_btn.clicked.connect(self._skip)
        self.pause_btn = QPushButton(t('Done'))
        self.pause_btn.setObjectName('Primary')
        self.pause_btn.setCursor(Qt.PointingHandCursor)
        self.pause_btn.clicked.connect(self._finish_now)
        row.addWidget(self.back_btn)
        row.addWidget(self.next_btn)
        row.addStretch()
        row.addWidget(self.pause_btn)
        lay.addLayout(row)
        return w

    def _page_done(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setSpacing(16)
        lay.addWidget(self._h1('Saved'))
        self.done_body = QLabel('')
        self.done_body.setObjectName('Note')
        self.done_body.setWordWrap(True)
        self.done_body.setStyleSheet(f"font-size:15px; color:{P['ink']};")
        lay.addWidget(self.done_body)
        lay.addStretch()
        row = QHBoxLayout()
        row.addStretch()
        more = QPushButton(t('Record more'))
        more.setObjectName('Ghost')
        more.setCursor(Qt.PointingHandCursor)
        more.clicked.connect(lambda: self.stack.setCurrentIndex(3))
        close = QPushButton(t('Done'))
        close.setObjectName('Primary')
        close.setCursor(Qt.PointingHandCursor)
        close.clicked.connect(self.accept)
        row.addWidget(more)
        row.addSpacing(10)
        row.addWidget(close)
        lay.addLayout(row)
        return w

    def _h1(self, text: str) -> QLabel:
        lab = QLabel(t(text))
        lab.setObjectName('H1')
        return lab

    def _start_recording(self):
        record.RECORDINGS, record.MANIFEST = record.speaker_paths(self.speaker)
        fields = {'name': self.f_name.text(), 'people': setup_prompts.parse_list(self.f_people.text()), 'places': setup_prompts.parse_list(self.f_places.text()), 'org': self.f_org.text(), 'phrases': setup_prompts.parse_list(self.f_phrases.toPlainText())}
        personal, vocab = setup_prompts.build_personal(fields)
        if personal:
            setup_prompts.write_prompt_set(personal, self.speaker, 'personal_setup')
        if any(vocab.values()):
            setup_prompts.seed_vocab(vocab, self.speaker)
        full = self._build_queue()
        recorded = record.already_recorded() if record.MANIFEST.exists() else set()
        start = next((i for i, (pid, _s, _t) in enumerate(full) if pid not in recorded), 0)
        self.queue = full[start:start + SETUP_MAX]
        self.cursor = 0
        try:
            self.mic = Mic(self.win.config.get('input_device'))
        except SystemExit as e:
            info = errors.classify(str(e), default='KARA-1001')
            karalog.get('gui').error('wizard mic unavailable [%s]: %s', info.code, e)
            QMessageBox.warning(self, info.title, info.message(str(e)))
            return
        self.stack.setCurrentIndex(3)
        self._show_prompt()

    def _build_queue(self):
        q = []
        for set_name in SETUP_ORDER:
            try:
                for pid, text in promptsets.load(set_name):
                    q.append((pid, set_name, text))
            except SystemExit:
                continue
        return q

    def _count_recorded(self) -> int:
        return len(record.already_recorded()) if record.MANIFEST.exists() else 0

    def _show_prompt(self):
        if self.cursor >= len(self.queue):
            self.stack.setCurrentIndex(4)
            self._update_done()
            return
        pid, set_name, text = self.queue[self.cursor]
        self.rec_prompt.setText(text)
        done = self._count_recorded()
        self.rec_count.setText(t('%s recorded  ·  %s of %s') % (done, self.cursor + 1, len(self.queue)))
        if done < TIER_QUICK:
            self.rec_tier.setText(t('%s more for a basic model') % (TIER_QUICK - done,))
        elif done < TIER_SOLID:
            self.rec_tier.setText(t('Enough to train · %s more for the target') % (TIER_SOLID - done,))
        else:
            self.rec_tier.setText(t('Target reached — extra clips keep helping'))
        self.back_btn.setEnabled(True)

    def _toggle_rec(self):
        if not self.mic:
            return
        if not self.recording:
            self.recording = True
            self.rec_orb.set_state('listening')
            self.rec_hint.setText(t('Recording — tap again when you finish the line.'))
            self.mic.start()
            return
        self.recording = False
        self.rec_orb.set_state('idle')
        audio = self.mic.stop()
        if audio.size < record.SAMPLE_RATE // 5:
            self.rec_hint.setText(t('That was too short — tap and try again.'))
            return
        self._save(audio)

    def _save(self, audio):
        import datetime
        pid, set_name, text = self.queue[self.cursor]
        rec_dir, _man = record.speaker_paths(self.speaker)
        rec_dir.mkdir(parents=True, exist_ok=True)
        wav_path = rec_dir / f'{pid}.wav'
        sf.write(str(wav_path), audio, record.SAMPLE_RATE, subtype='PCM_16')
        if pid in (record.already_recorded() if record.MANIFEST.exists() else set()):
            record.drop_from_manifest([pid])
        peak = float(np.max(np.abs(audio))) if audio.size else 0.0
        record.append_manifest({'prompt_id': pid, 'prompt_set': set_name, 'prompt_text': text, 'wav_path': str(wav_path.relative_to(record.ROOT)), 'duration_s': round(audio.size / record.SAMPLE_RATE, 3), 'peak': round(peak, 4), 'recorded_at': 'setup'})
        warn = record.quality_warning(audio)
        self.rec_hint.setText(warn + ' — you can re-record.' if warn else 'Saved. Tap to record the next line.')
        self.cursor += 1
        self._show_prompt()

    def _step_before(self, page: int) -> int:
        prev = max(0, page - 1)
        if prev == 1 and terms_accepted():
            return 0
        return prev

    def _prev(self):
        if self.recording:
            return
        if self.cursor <= 0:
            self.stack.setCurrentIndex(self._step_before(3))
            return
        self.cursor -= 1
        self._show_prompt()
        self.rec_hint.setText(t('Tap to record this line again.'))

    def _skip(self):
        if self.recording:
            return
        self.cursor += 1
        self._show_prompt()

    def _finish_now(self):
        if self.recording and self.mic:
            self.recording = False
            self.mic.stop()
        self.accept()

    def _update_done(self):
        done = self._count_recorded()
        if done < TIER_QUICK:
            note = f"You've recorded {done} clips. A few more (around {TIER_QUICK}) and there's enough to train a first model."
        elif done < TIER_SOLID:
            note = f'{done} clips recorded — enough to train now. Around {TIER_SOLID} gives the best results.'
        else:
            note = f"{done} clips recorded — that's the target range. You can train whenever you're ready."
        self.done_body.setText(note + '\n\nEverything is saved on this computer. Training happens separately, from Settings.')

    def _orb_level(self) -> float:
        return self.mic.peak if self.mic and self.recording else 0.0

    def _tick_orb(self):
        pass

    def _teardown(self):
        self._meter.stop()
        if self.recording and self.mic:
            self.mic.stop()
            self.recording = False

    def closeEvent(self, e):
        self._teardown()
        super().closeEvent(e)

    def done(self, r):
        self._teardown()
        super().done(r)

class ReadAloudWorker(QThread):
    sentence = Signal(int, int)
    finished_reading = Signal()
    stopped_at = Signal(int)

    def __init__(self, spans: list, text: str, device, start_word: int=0):
        super().__init__()
        self.spans, self.text, self.device = (spans, text, device)
        self.start_word = max(0, int(start_word))
        self._stop = False

    def _words_in(self, a: int, b: int) -> int:
        return len(self.text[a:b].split())

    def run(self):
        spoken = 0
        resume_at = -1
        for a, b in self.spans:
            if self._stop:
                break
            n = self._words_in(a, b)
            if spoken + n <= self.start_word:
                spoken += n
                continue
            chunk_words = self.text[a:b].split()
            skip = max(0, self.start_word - spoken)
            chunk = ' '.join(chunk_words[skip:]).strip()
            if not chunk:
                spoken += n
                continue
            offset = a
            if skip:
                head = ' '.join(chunk_words[:skip])
                found = self.text.find(head, a, b)
                if found >= 0:
                    offset = found + len(head)
            self.sentence.emit(offset, b)
            heard = 1.0
            try:
                heard = voices.speak_tracked(chunk, self.cfg_voice, self.device, self.cfg_rate)
            except Exception:
                try:
                    editing.speak(chunk, self.device)
                except Exception:
                    pass
            said = len(chunk.split())
            if self._stop or heard < 0.999:
                done = int(said * max(0.0, min(1.0, heard)))
                resume_at = max(0, spoken + skip + done - 1)
                break
            spoken += n
        self.stopped_at.emit(resume_at)
        self.finished_reading.emit()
    cfg_voice = None
    cfg_rate = 0

    def stop(self):
        self._stop = True
        try:
            voices.stop_speaking()
        except Exception:
            pass

class ModelFailureDialog(QDialog):

    def __init__(self, parent, why: str, detail: str, current: str, fallback: str | None, fix: str='', code: str=''):
        super().__init__(parent)
        self.choice = 'none'
        self.setWindowTitle(t("Couldn't start the recogniser"))
        self.setMinimumWidth(430)
        self.setStyleSheet(f"\n            QDialog {{ background:{P['canvas']}; }}\n            QLabel {{ color:{P['ink']}; font-family:{SANS_STACK}; }}\n            QLabel#Why {{ font-size:15px; font-weight:600; }}\n            QLabel#Sub {{ font-size:12px; color:{P['ink_soft']}; }}\n            QLabel#Code {{ font-size:11px; color:{P['ink_soft']}; }}\n            QPushButton#Choice {{\n                background:{P['surface']}; color:{P['ink']};\n                border:1px solid {P['line']}; border-radius:10px;\n                padding:12px 14px; font-size:14px; font-weight:600; text-align:left;\n            }}\n            QPushButton#Choice:hover {{ border-color:{P['beige']}; background:{P['hover']}; }}\n            QPushButton#Ghost {{\n                background:transparent; color:{P['ink_soft']};\n                border:none; font-size:13px; padding:6px;\n            }}\n            QPushButton#Ghost:hover {{ color:{P['ink']}; }}\n            QTextEdit {{ background:{P['surface']}; color:{P['ink_soft']};\n                border:1px solid {P['line']}; border-radius:10px; font-size:11px; }}\n        ")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 22, 24, 18)
        lay.setSpacing(10)
        head = QLabel(t(why))
        head.setObjectName('Why')
        head.setWordWrap(True)
        lay.addWidget(head)
        sub = QLabel(t(fix) if fix else t("Kara can't listen until a model loads. You can still type."))
        sub.setObjectName('Sub')
        sub.setWordWrap(True)
        lay.addWidget(sub)
        if code:
            tag = QLabel(code)
            tag.setObjectName('Code')
            lay.addWidget(tag)
        lay.addSpacing(6)

        def row(label, note, value):
            b = QPushButton(f'{label}\n{note}')
            b.setObjectName('Choice')
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda: self._pick(value))
            lay.addWidget(b)
        row('Try again', 'Load the same model once more.', 'retry')
        if fallback:
            row(f'Use the {fallback} model', 'Needs less memory and loads faster.', 'fallback')
        row('Continue without it', 'Type instead; retry later from Settings.', 'none')
        self.detail = QTextEdit()
        self.detail.setReadOnly(True)
        self.detail.setPlainText(detail)
        self.detail.setFixedHeight(90)
        self.detail.hide()
        lay.addWidget(self.detail)
        show = QPushButton(t('Show technical details'))
        show.setObjectName('Ghost')
        show.setCursor(Qt.PointingHandCursor)
        show.clicked.connect(lambda: (self.detail.setVisible(not self.detail.isVisible()), self.adjustSize()))
        lay.addWidget(show, alignment=Qt.AlignLeft)

    def _pick(self, value):
        self.choice = value
        self.accept()

    def ask(self) -> str:
        self.exec()
        return self.choice

class OnlineGrammarWorker(QThread):
    done = Signal(list, str, str)

    def __init__(self, text: str, service: str, language: str='en-US'):
        super().__init__()
        self.text, self.service, self.language = (text, service, language)

    def run(self):
        try:
            marks, err = proofing.check_online(self.text, self.service, language=self.language)
        except Exception as e:
            marks, err = ([], f'grammar service failed ({type(e).__name__})')
        self.done.emit(list(marks), err or '', self.text)

class WerChart(QWidget):

    def __init__(self, parent=None, height: int=190):
        super().__init__(parent)
        self.setMinimumHeight(height)
        self._points: list[tuple[float, float, str]] = []
        self._empty = 'Nothing measured yet.'
        self._mark: str = ''

    def set_points(self, points, *, empty: str='', mark: str=''):
        self._points = [(float(x), float(y), str(lab)) for x, y, lab in points]
        if empty:
            self._empty = empty
        self._mark = mark
        self.update()

    def paintEvent(self, _ev):
        from PySide6.QtGui import QPainter, QPen, QPainterPath
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        w, h = (self.width(), self.height())
        left, right, top, bottom = (48, 14, 18, 34)
        plot_w, plot_h = (w - left - right, h - top - bottom)
        if not self._points or plot_w <= 10 or plot_h <= 10:
            p.setPen(QColor(P['ink_soft']))
            p.setFont(QFont(SANS_STACK.split(',')[0].strip('\'" '), 10))
            p.drawText(self.rect(), Qt.AlignCenter, self._empty)
            return
        ys = [y for _x, y, _l in self._points]
        top_y = max(ys) * 1.35 or 0.05
        xs = [x for x, _y, _l in self._points]
        x_lo, x_hi = (min(xs), max(xs))
        span = x_hi - x_lo or 1.0

        def px(x):
            return left + (x - x_lo) / span * plot_w

        def py(y):
            return top + plot_h - y / top_y * plot_h
        p.setFont(QFont(SANS_STACK.split(',')[0].strip('\'" '), 8))
        for i in range(5):
            frac = top_y * i / 4
            y = py(frac)
            p.setPen(QPen(QColor(P['line']), 1))
            p.drawLine(int(left), int(y), int(w - right), int(y))
            p.setPen(QColor(P['ink_soft']))
            p.drawText(0, int(y) - 7, left - 8, 14, Qt.AlignRight | Qt.AlignVCenter, f'{frac * 100:.0f}%')
        path = QPainterPath()
        for i, (x, y, _l) in enumerate(self._points):
            pt = (px(x), py(y))
            path.moveTo(*pt) if i == 0 else path.lineTo(*pt)
        p.setPen(QPen(QColor(P['beige']), 2))
        p.drawPath(path)
        for x, y, label in self._points:
            cx, cy = (px(x), py(y))
            p.setBrush(QColor(P['beige']))
            p.setPen(QPen(QColor(P['canvas']), 2))
            p.drawEllipse(int(cx) - 4, int(cy) - 4, 8, 8)
            p.setPen(QColor(P['ink']))
            p.setFont(QFont(SANS_STACK.split(',')[0].strip('\'" '), 9, QFont.Bold))
            p.drawText(int(cx) - 26, int(cy) - 22, 52, 16, Qt.AlignCenter, f'{y * 100:.1f}%')
            p.setPen(QColor(P['ink_soft']))
            p.setFont(QFont(SANS_STACK.split(',')[0].strip('\'" '), 8))
            p.drawText(int(cx) - 30, h - bottom + 6, 60, 14, Qt.AlignCenter, label)
        if self._mark:
            p.setPen(QColor(P['ink_soft']))
            p.setFont(QFont(SANS_STACK.split(',')[0].strip('\'" '), 8))
            p.drawText(left, 2, plot_w, 14, Qt.AlignRight | Qt.AlignVCenter, self._mark)

class BackupWorker(QThread):
    progress = Signal(int, int, str)
    done_ok = Signal(dict)
    failed = Signal(str, str)

    def __init__(self, mode: str, speaker: str, path: str, include_model: bool):
        super().__init__()
        self.mode, self.speaker = (mode, speaker)
        self.path, self.include_model = (path, include_model)
        self._cancelled = False

    def cancel(self):
        self._cancelled = True

    def run(self):

        def tick(n, total, what):
            if self._cancelled:
                raise cloudsync.SyncError('KARA-7106', 'cancelled')
            self.progress.emit(n, total, what)
        try:
            backend = cloudsync.LocalBackend(self.path)
            if self.mode == 'backup':
                rep = cloudsync.backup(self.speaker, backend, include_model=self.include_model, progress=tick)
            else:
                rep = cloudsync.restore(self.speaker, backend, progress=tick)
        except cloudsync.SyncError as e:
            self.failed.emit(e.code, e.detail or '')
            return
        except Exception as e:
            self.failed.emit('KARA-9001', f'{type(e).__name__}: {e}')
            return
        self.done_ok.emit({'files': rep.files, 'written': rep.uploaded, 'skipped': rep.skipped, 'bytes': rep.bytes_moved, 'errors': list(rep.errors)})

class ProofHighlighter(QSyntaxHighlighter):

    def __init__(self, document):
        super().__init__(document)
        self._marks: list = []
        self._fmt = {}
        for kind, colour in ((proofing.SPELLING, P['red']), (proofing.GRAMMAR, P['blue'])):
            f = QTextCharFormat()
            f.setUnderlineStyle(QTextCharFormat.SpellCheckUnderline)
            f.setUnderlineColor(QColor(colour))
            self._fmt[kind] = f
        unsure = QTextCharFormat()
        unsure.setUnderlineStyle(QTextCharFormat.DotLine)
        unsure.setUnderlineColor(QColor(P['ink_soft']))
        self._fmt[proofing.UNSURE] = unsure
        self._highlight_all = False
        self._hl = {}
        for kind in (proofing.SPELLING, proofing.GRAMMAR):
            f = QTextCharFormat(self._fmt[kind])
            f.setBackground(QColor(P['hi_bg']))
            f.setForeground(QColor(P['hi_fg']))
            self._hl[kind] = f

    def set_highlight(self, on: bool):
        if bool(on) == self._highlight_all:
            return
        self._highlight_all = bool(on)
        self.rehighlight()

    def set_marks(self, marks, unsure=()):
        self._marks = list(unsure or []) + list(marks or [])
        self.rehighlight()

    def highlightBlock(self, _text):
        block_start = self.currentBlock().position()
        block_end = block_start + self.currentBlock().length()
        for m in self._marks:
            start, end = (m.start, m.end)
            if end <= block_start or start >= block_end:
                continue
            if end == start:
                end = min(end + 1, block_end - 1)
            a = max(start, block_start) - block_start
            b = min(end, block_end) - block_start
            if b > a:
                table = self._hl if self._highlight_all and m.kind in self._hl else self._fmt
                self.setFormat(a, b - a, table.get(m.kind, self._fmt[proofing.GRAMMAR]))
_KEYSTROKE_SAID = {'delete_word': 'deleted a word', 'backspace': 'deleted a character', 'press_enter': 'new line', 'new_line': 'new line', 'tab': 'tab', 'space': 'space', 'select_last': 'selected the last word', 'undo': 'undo', 'redo': 'redo', 'clear': 'selected everything — say the new text, or say undo'}
_FIX_LABELS = {'joined_words': 'Split them', 'sentence_case': 'Capitalise', 'lone_i': 'Capitalise', 'space_before_punct': 'Close the gap', 'no_space_after_punct': 'Add a space', 'double_space': 'Remove extra space', 'repeat_punct': 'Remove the repeat', 'space_before_close': 'Close the gap'}

class SayLivePanel(QFrame):
    WIDTH = 320
    COLLAPSED = 46

    def __init__(self, window: 'Window'):
        super().__init__(window)
        self.win = window
        self.setObjectName('Sidebar')
        self.setFixedWidth(self.WIDTH)
        self._open = True
        self._dismissed: set = set()
        self._items: list = []
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 12, 10, 12)
        lay.setSpacing(8)
        head = QHBoxLayout()
        head.setSpacing(6)
        self.chevron = QLabel('▾')
        self.chevron.setStyleSheet(f"color:{P['ink_soft']};font-size:13px;")
        self.title = QLabel(t('CORRECTION'))
        self.title.setObjectName('PanelTitle')
        self.title.setWordWrap(True)
        beta = QLabel(t('BETA'))
        beta.setObjectName('BetaTag')
        self.beta = beta
        head.addWidget(self.chevron)
        head.addWidget(self.title, 1)
        head.addWidget(beta, 0, Qt.AlignTop)
        self.header = QWidget()
        self.header.setLayout(head)
        self.header.setCursor(Qt.PointingHandCursor)
        self.header.mouseReleaseEvent = lambda _e: self.toggle()
        lay.addWidget(self.header)
        self.count = QLabel('')
        self.count.setObjectName('Note')
        self.count.setWordWrap(True)
        lay.addWidget(self.count)
        self.stub = QLabel('')
        self.stub.setObjectName('BetaTag')
        self.stub.setAlignment(Qt.AlignCenter)
        self.stub.setVisible(False)
        lay.addWidget(self.stub, 0, Qt.AlignHCenter)
        self.body = QWidget()
        self.rows = QVBoxLayout(self.body)
        self.rows.setContentsMargins(0, 0, 0, 0)
        self.rows.setSpacing(8)
        lay.addWidget(self.body)
        lay.addStretch()

    def toggle(self):
        self._open = not self._open
        self.body.setVisible(self._open)
        self.chevron.setText('▾' if self._open else '▸')
        self.setFixedWidth(self.WIDTH if self._open else self.COLLAPSED)
        self.title.setVisible(self._open)
        self.count.setVisible(self._open)
        self.beta.setVisible(self._open)
        self.stub.setVisible(not self._open)
        self.stub.setText(str(len(self._items)) if self._items else '')
        self.setToolTip('' if self._open else t('Correction — %s things that might not be what you said. Click to open.') % (len(self._items),))

    def refresh(self):
        while self.rows.count():
            item = self.rows.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        try:
            import saylive
            found = saylive.suspicions(self.win.ed.text, self.win.speaker)
        except Exception as e:
            karalog.get('gui').warning('suspicions failed: %s', e)
            found = []
        self._items = [s for s in found if (s['said'], s['meant'], s['start']) not in self._dismissed]
        if not self._open:
            self.stub.setText(str(len(self._items)) if self._items else '')
        if not self._items:
            ok = QLabel(t('Nothing looks misheard on this page.'))
            ok.setObjectName('Note')
            ok.setWordWrap(True)
            self.rows.addWidget(ok)
            self.count.setText('')
            return
        self.count.setText(t('%s that might not be what you said · strongest first. Nothing changes until you say so.') % (len(self._items),))
        for s in self._items:
            self.rows.addWidget(self._card(s))

    def _card(self, s: dict) -> QFrame:
        import saylive
        card = QFrame()
        card.setObjectName('SayCard')
        cl = QVBoxLayout(card)
        cl.setContentsMargins(12, 9, 12, 11)
        cl.setSpacing(3)
        colour = P['beige']
        tag = QLabel(saylive.TIER_NAME.get(s['tier'], 'YOURS'))
        tag.setObjectName('Eyebrow')
        tag.setStyleSheet(f'color:{colour};font-size:10px;font-weight:700;letter-spacing:1.5px;')
        cl.addWidget(tag)
        swap = QLabel(t("<span style='color:%s'>%s</span>  →  <b>%s</b>") % (P['ink_soft'], s['said'], s['meant']))
        swap.setWordWrap(True)
        swap.setStyleSheet(f'font-family:{PAPER_STACK};font-size:15px;')
        cl.addWidget(swap)
        why = QLabel(t(s['why']))
        why.setObjectName('Note')
        why.setWordWrap(True)
        cl.addWidget(why)
        row = QHBoxLayout()
        row.setSpacing(6)
        use = QPushButton(t('Use “%s”') % (_short(str(s['meant']), 16),))
        use.setObjectName('Test')
        use.setCursor(Qt.PointingHandCursor)
        use.clicked.connect(lambda _=False, x=s: self._use(x))
        no = QPushButton(t('Leave it'))
        no.setObjectName('Ghost')
        no.setCursor(Qt.PointingHandCursor)
        no.clicked.connect(lambda _=False, x=s: self._leave(x))
        row.addWidget(use)
        row.addWidget(no)
        row.addStretch()
        cl.addSpacing(3)
        cl.addLayout(row)
        return card

    def _use(self, s: dict):
        import saylive
        before = self.win.ed.text
        after = saylive.apply(before, s)
        if after == before:
            self.win._say('That word has moved — checking again.')
            self.refresh()
            return
        self.win.ed._snapshot()
        self.win.ed.text = after
        self.win._say(t('Changed to “%s”.') % (s['meant'],))
        try:
            import adapt
            adapt.log_correction(self.win.speaker, '', str(s['said']), str(s['meant']), trust='panel')
        except Exception as e:
            karalog.get('adapt').warning('panel correction not logged: %s', e)
        self.win._refresh_now()
        start = s.get('start')
        if isinstance(start, int) and start >= 0:
            self.win.wash_words([(start, start + len(str(s['meant'])))])
        self.refresh()

    def _leave(self, s: dict):
        self._dismissed.add((s['said'], s['meant'], s['start']))
        self.refresh()

class GrammarPanel(QFrame):
    WIDTH = 300

    def __init__(self, window: 'Window'):
        super().__init__(window)
        self.win = window
        self.setObjectName('Sidebar')
        self.setFixedWidth(self.WIDTH)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 12, 10, 12)
        lay.setSpacing(8)
        head = QHBoxLayout()
        title = QLabel(t('GRAMMAR'))
        title.setObjectName('SideHead')
        head.addWidget(title)
        head.addStretch()
        close = IconButton('menu', 'Hide')
        close.clicked.connect(window.toggle_grammar)
        head.addWidget(close)
        lay.addLayout(head)
        self.summary = QLabel('')
        self.summary.setObjectName('Note')
        self.summary.setWordWrap(True)
        lay.addWidget(self.summary)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.NoFrame)
        self.rows_box = QWidget()
        self.rows_lay = QVBoxLayout(self.rows_box)
        self.rows_lay.setContentsMargins(0, 0, 0, 0)
        self.rows_lay.setSpacing(6)
        self.rows_lay.addStretch()
        self.scroll.setWidget(self.rows_box)
        lay.addWidget(self.scroll, 1)
        self.tidy = QPushButton(t('Tidy up everything'))
        self.tidy.setObjectName('Primary')
        self.tidy.setCursor(Qt.PointingHandCursor)
        self.tidy.setToolTip(t('Fix the spacing and punctuation problems in one step. Spelling is left alone — those need a choice.'))
        self.tidy.clicked.connect(window.tidy_up)
        lay.addWidget(self.tidy)

    def _clear_rows(self):
        while self.rows_lay.count() > 1:
            item = self.rows_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _row(self, mark):
        box = QFrame()
        box.setObjectName('GRow')
        red = mark.kind == proofing.SPELLING
        box.setStyleSheet(f"#GRow {{ background:{P['surface']}; border:1px solid {P['line']}; border-left:3px solid {(P['red'] if red else P['blue'])}; border-radius:10px; }}")
        v = QVBoxLayout(box)
        v.setContentsMargins(9, 7, 9, 8)
        v.setSpacing(5)
        title = QLabel(mark.word if red else mark.message)
        title.setWordWrap(True)
        title.setStyleSheet(f"color:{P['ink']}; font-size:13px; font-weight:600; border:none;")
        v.addWidget(title)
        if red and mark.message:
            why = QLabel(t(mark.message))
            why.setWordWrap(True)
            why.setStyleSheet(f"color:{P['ink_soft']}; font-size:11px; border:none;")
            v.addWidget(why)
        acts = QHBoxLayout()
        acts.setSpacing(5)

        def button(label, slot, primary=False):
            b = QPushButton(label)
            b.setCursor(Qt.PointingHandCursor)
            b.setMinimumHeight(30)
            b.setMinimumWidth(74 if not primary else 0)
            b.setStyleSheet(f"QPushButton {{ background:{(P['beige'] if primary else 'transparent')}; color:{(P['on_accent'] if primary else P['beige_text'])}; border:1px solid {(P['beige'] if primary else P['line'])}; border-radius:6px; padding:3px 10px; font-size:12px; font-weight:600; }}QPushButton:hover {{ border-color:{P['beige']}; }}")
            b.clicked.connect(slot)
            acts.addWidget(b)
            return b
        if red:
            for s in mark.suggestions[:2]:
                button(s, lambda _=False, m=mark, r=s: self.win.apply_mark(m, r), primary=True)
        elif mark.fix is not None:
            button(_FIX_LABELS.get(mark.rule, 'Fix'), lambda _=False, m=mark: self.win.apply_mark(m), primary=True)
        if red:
            button('Remove', lambda _=False, m=mark: self.win._remove_mark(m))
            button('Keep', lambda _=False, w=mark.word: self.win._teach_word(w, correct=True))
        acts.addStretch()
        v.addLayout(acts)
        return box

    def refresh(self, marks):
        self._clear_rows()
        for m in marks:
            self.rows_lay.insertWidget(self.rows_lay.count() - 1, self._row(m))
        spell = [m for m in marks if m.kind == proofing.SPELLING]
        gram = [m for m in marks if m.kind == proofing.GRAMMAR]
        if not marks:
            self.summary.setText(t('Nothing to fix. '))
        else:
            bits = []
            if spell:
                bits.append(f'{len(spell)} spelling')
            if gram:
                bits.append(f'{len(gram)} grammar')
            self.summary.setText(' · '.join(bits))
        self.tidy.setVisible(bool(gram))

class TrainReviewDialog(QDialog):

    def __init__(self, window: 'Window'):
        super().__init__(window)
        self.win = window
        self.rows: list[tuple[QCheckBox, dict]] = []
        self.setWindowTitle(t('What should Kara learn from?'))
        self.setMinimumSize(620, 520)
        self.setSizeGripEnabled(True)
        self.setStyleSheet(f"\n            QDialog {{ background: {P['canvas']}; }}\n            QLabel {{ color: {P['ink']}; font-family: {SANS_STACK};\n                      font-size: 13px; }}\n            QLabel#H1 {{ font-size: 19px; font-weight: 600; }}\n            QLabel#Note {{ color: {P['ink_soft']}; font-size: 12px; }}\n            QLabel#Group {{ color: {P['beige_text']}; font-size: 11px;\n                      font-weight: 700; letter-spacing: 1.5px; }}\n            QCheckBox {{ color: {P['ink']}; font-size: 13px; padding: 2px 0; }}\n            QPushButton {{ font-size: 13px; font-weight: 600;\n                      border-radius: 9px; padding: 9px 20px; }}\n            QPushButton#Primary {{ background: {P['beige']};\n                      color: {P['on_accent']}; border: none; }}\n            QPushButton#Ghost {{ background: transparent;\n                      color: {P['beige_text']};\n                      border: 1px solid {P['line']}; }}\n            QScrollArea {{ border: none; background: transparent; }}\n        ")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 24, 26, 20)
        lay.setSpacing(10)
        lay.addWidget(self._h1())
        intro = QLabel(t('Everything here is already checked. Untick anything Kara got right, or that you would not want it to copy.'))
        intro.setObjectName('Note')
        intro.setWordWrap(True)
        lay.addWidget(intro)
        inner = QWidget()
        self.list_lay = QVBoxLayout(inner)
        self.list_lay.setContentsMargins(0, 6, 0, 6)
        self.list_lay.setSpacing(3)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(inner)
        lay.addWidget(scroll, 1)
        self._fill(self.list_lay)
        self.count_note = QLabel('')
        self.count_note.setObjectName('Note')
        self.count_note.setWordWrap(True)
        lay.addWidget(self.count_note)
        self._recount()
        row = QHBoxLayout()
        cancel = QPushButton(t('Not now'))
        cancel.setObjectName('Ghost')
        cancel.setCursor(Qt.PointingHandCursor)
        cancel.clicked.connect(self.reject)
        self.go = QPushButton(t('Start training'))
        self.go.setObjectName('Primary')
        self.go.setCursor(Qt.PointingHandCursor)
        self.go.clicked.connect(self.accept)
        row.addWidget(cancel)
        row.addStretch()
        row.addWidget(self.go)
        lay.addLayout(row)

    def _h1(self) -> QLabel:
        lab = QLabel(t('What should Kara learn from?'))
        lab.setObjectName('H1')
        return lab

    def _fill(self, lay: QVBoxLayout):
        import adapt
        try:
            pairs = adapt.training_pairs(self.win.speaker)
        except Exception:
            pairs = []
        groups: dict[str, list[dict]] = {}
        for r in pairs:
            groups.setdefault(adapt.trust_of(r), []).append(r)
        labels = {'prompted': 'Sentences you were asked to read', 'spelled': 'Words you spelled out for Kara', 'commanded': 'Corrections you asked for out loud'}
        for name in sorted(groups, key=lambda k: -adapt.TRUST_RANK.get(k, 0)):
            head = QLabel(t(labels.get(name, name)).upper())
            head.setObjectName('Group')
            lay.addWidget(head)
            for r in groups[name]:
                text = (r.get('accepted') or '').strip()
                heard = (r.get('asr_output') or '').strip()
                cb = QCheckBox(_short(text, 70))
                cb.setChecked(True)
                if heard and heard != text:
                    cb.setToolTip(t('Kara heard: %s') % (heard,))
                cb.stateChanged.connect(self._recount)
                lay.addWidget(cb)
                self.rows.append((cb, r))
        try:
            import practice
            n_practice = practice.clip_count(self.win.speaker)
        except Exception:
            n_practice = 0
        if n_practice:
            head = QLabel(t('FROM PRACTICE'))
            head.setObjectName('Group')
            lay.addWidget(head)
            note = QLabel(t('%s clips, each read from a sentence Kara showed you. Always included — the words were known before you spoke them.') % (n_practice,))
            note.setObjectName('Note')
            note.setWordWrap(True)
            lay.addWidget(note)
        if not pairs and (not n_practice):
            empty = QLabel(t('Nothing to learn from yet. Practice, or correct Kara out loud when it gets a word wrong.'))
            empty.setObjectName('Note')
            empty.setWordWrap(True)
            lay.addWidget(empty)
        lay.addStretch()

    def _recount(self):
        n = sum((1 for cb, _r in self.rows if cb.isChecked()))
        self.count_note.setText(t('%s of %s corrections included.') % (n, len(self.rows)))

    def excluded(self) -> list[dict]:
        return [r for cb, r in self.rows if not cb.isChecked()]

class ModeBar(QWidget):

    def __init__(self, on_layout):
        super().__init__()
        self._on_layout = on_layout

    def showEvent(self, e):
        super().showEvent(e)
        self._on_layout()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._on_layout()

class Aurora(QWidget):
    PERIOD_S = 3.2
    MAX_ALPHA = 0.22
    REACH = 0.46

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.setAttribute(Qt.WA_NoSystemBackground)
        self._t = 0.0
        self._on = False
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self.hide()

    def set_listening(self, on: bool):
        on = bool(on) and bool(motion_ms(1))
        if on == self._on:
            return
        self._on = on
        if on:
            self._t = 0.0
            self.show()
            self.raise_()
            self._timer.start(33)
        else:
            self._timer.stop()
            self.hide()

    def _tick(self):
        self._t += 0.033
        self.update()

    def paintEvent(self, _e):
        from PySide6.QtGui import QColor, QPainter, QRadialGradient
        breathe = 0.5 + 0.5 * math.sin(self._t * math.tau / self.PERIOD_S)
        alpha = self.MAX_ALPHA * (0.45 + 0.55 * breathe)
        c = QColor(P['beige'])
        c.setAlphaF(alpha)
        edge = QColor(P['beige'])
        edge.setAlphaF(0.0)
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        r = self.rect()
        span = r.height() * self.REACH * (1.0 + 0.08 * breathe)
        g = QRadialGradient(r.center().x(), r.bottom(), max(1.0, span))
        g.setColorAt(0.0, c)
        mid = QColor(c)
        mid.setAlphaF(alpha * 0.35)
        g.setColorAt(0.55, mid)
        g.setColorAt(1.0, edge)
        p.fillRect(r, g)
        p.end()

class EvaluateWorker(QThread):
    done = Signal(dict)
    failed = Signal(str)

    def __init__(self, speaker: str, candidate: Path, size: str):
        super().__init__()
        self.speaker, self.candidate, self.size = (speaker, candidate, size)

    def run(self):
        try:
            import adapt
            self.done.emit(adapt.evaluate(self.speaker, self.candidate, self.size))
        except Exception as e:
            self.failed.emit(str(e))

class TrainCard(QFrame):
    REST, HOVER = (18, 46)

    def __init__(self, window: 'Window'):
        super().__init__()
        self.win = window
        self.setObjectName('TrainCard')
        self.setCursor(Qt.PointingHandCursor)
        self.setStyleSheet(f"\n            QFrame#TrainCard {{\n                background: {(P['surface_hi'] if 'surface_hi' in P else P['surface'])};\n                border: 1px solid {P['line']}; border-radius: 10px;\n            }}\n            QLabel#TrainTitle {{ color: {P['ink']}; font-family: {DISPLAY_STACK};\n                font-size: 13px; font-weight: 700; }}\n            QLabel#TrainNote {{ color: {P['ink_soft']}; font-size: 11px; }}\n            QProgressBar#TrainBar {{\n                background: {P['line']}; border: none; border-radius: 3px;\n            }}\n            QProgressBar#TrainBar::chunk {{\n                background: {P['beige']}; border-radius: 3px;\n            }}\n        ")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 9, 12, 10)
        lay.setSpacing(3)
        row = QHBoxLayout()
        row.setSpacing(6)
        self.title = QLabel(t('Train'))
        self.title.setObjectName('TrainTitle')
        row.addWidget(self.title)
        row.addStretch()
        lay.addLayout(row)
        self.note = QLabel('')
        self.note.setObjectName('TrainNote')
        self.note.setWordWrap(True)
        lay.addWidget(self.note)
        self.bar = QProgressBar()
        self.bar.setObjectName('TrainBar')
        self.bar.setRange(0, 100)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(6)
        self.bar.setVisible(False)
        lay.addWidget(self.bar)
        from PySide6.QtCore import QEasingCurve, QPropertyAnimation
        from PySide6.QtGui import QColor
        from PySide6.QtWidgets import QGraphicsDropShadowEffect
        glow = QGraphicsDropShadowEffect(self)
        glow.setOffset(0, 0)
        glow.setColor(QColor(P['beige']))
        glow.setBlurRadius(self.REST)
        self.setGraphicsEffect(glow)
        self._glow = glow
        self._anim = QPropertyAnimation(glow, b'blurRadius', self)
        self._anim.setDuration(170)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._pulse = QPropertyAnimation(glow, b'blurRadius', self)
        self._pulse.setDuration(3200)
        self._pulse.setEasingCurve(QEasingCurve.InOutSine)
        self._pulse.setLoopCount(-1)
        self._pulse.setKeyValueAt(0.0, self.REST)
        self._pulse.setKeyValueAt(0.5, self.HOVER)
        self._pulse.setKeyValueAt(1.0, self.REST)
        self.setAccessibleName(t('Train'))
        self.refresh()

    def refresh(self):
        if self.win.is_training():
            return
        try:
            import calibrate
            import practice as _practice
            corpus = profile.clip_count(self.win.speaker)
            extra = _practice.clip_count(self.win.speaker)
            total = corpus + extra
            rep = calibrate.estimate_report(self.win.speaker, total, sec_per_step=self.win.config.get('sec_per_step') or None)
            row = next((r for r in rep['options'] if r['model'] == self.win.model), None)
            hours = calibrate.human(row['hours']) if row and row.get('hours') else None
        except Exception:
            total, hours = (0, None)
        if not total:
            self.note.setText(t('Nothing recorded yet — practice first.'))
        elif hours:
            self.note.setText(t('%s clips  ·  about %s') % (total, hours))
        else:
            self.note.setText(t('%s clips recorded') % (total,))

    def started(self):
        self.bar.setValue(0)
        self.bar.setVisible(True)
        self.note.setText(t('Starting…'))
        self._anim.stop()
        self._pulse.start()

    def progress(self, msg: dict):
        total, step = (msg.get('total', 0), msg.get('step', 0))
        if total:
            self.bar.setValue(int(100 * step / total))
        bits = [t('epoch %s') % (msg.get('epoch', 0),)]
        if total:
            bits.append(t('step %s of %s') % (step, total))
        self.note.setText('  ·  '.join(bits))

    def checking(self, message: str):
        self.bar.setRange(0, 0)
        self.bar.setVisible(True)
        self.note.setText(message)

    def finished(self, message: str):
        self._pulse.stop()
        self._glow.setBlurRadius(self.REST)
        self.bar.setRange(0, 100)
        self.bar.setVisible(False)
        self.note.setText(message)
        QTimer.singleShot(45000, self.refresh)

    def enterEvent(self, _e):
        if not self.win.is_training():
            self._glow_to(self.HOVER)

    def leaveEvent(self, _e):
        if not self.win.is_training():
            self._glow_to(self.REST)

    def _glow_to(self, value: int):
        self._anim.stop()
        self._anim.setStartValue(self._glow.blurRadius())
        self._anim.setEndValue(value)
        self._anim.start()

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.LeftButton and self.rect().contains(e.position().toPoint()):
            self.win.start_training()

class LibrarySidebar(QFrame):
    WIDTH = 260

    def __init__(self, window: 'Window'):
        super().__init__(window)
        self.win = window
        self.setObjectName('Sidebar')
        self.setFixedWidth(self.WIDTH)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 12, 10, 12)
        lay.setSpacing(8)
        title = QLabel(t('YOUR WRITING'))
        title.setObjectName('SideHead')
        lay.addWidget(title)
        new = QPushButton('＋   ' + t('New page'))
        new.setObjectName('NewDoc')
        new.setCursor(Qt.PointingHandCursor)
        new.clicked.connect(self.win.new_document)
        lay.addWidget(new)
        self.list = QListWidget()
        self.list.setObjectName('DocList')
        self.list.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.list.setWordWrap(False)
        self.list.setTextElideMode(Qt.ElideRight)
        self.list.itemClicked.connect(self._open)
        self.list.setContextMenuPolicy(Qt.CustomContextMenu)
        self.list.customContextMenuRequested.connect(self._menu)
        self.empty = QLabel(t('Nothing saved yet.\nWhat you dictate is kept here.'))
        self.empty.setObjectName('SideNote')
        self.empty.setWordWrap(True)
        self.empty.setAlignment(Qt.AlignHCenter | Qt.AlignTop)
        self.empty.setContentsMargins(6, 18, 6, 0)
        self.body = QStackedWidget()
        self.body.addWidget(self.list)
        self.body.addWidget(self.empty)
        lay.addWidget(self.body, 1)
        foot = QVBoxLayout()
        foot.setSpacing(4)
        line = QFrame()
        line.setObjectName('Sep')
        line.setFixedHeight(1)
        foot.addWidget(line)
        self.train_card = TrainCard(window)
        foot.addWidget(self.train_card)
        for glyph, label, slot in (('◎', 'Practice', self.win.open_practice), ('⚙︎', 'Settings', self.win._settings)):
            b = QPushButton(f'  {glyph}    {label}')
            b.setObjectName('SideFoot')
            b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(slot)
            foot.addWidget(b)
        lay.addLayout(foot)
        self.refresh()

    def refresh(self):
        self.list.clear()
        docs = library.list_docs(self.win.speaker)
        for d in docs:
            title = d['title']
            if len(title) > 30:
                title = title[:29].rstrip() + '…'
            item = QListWidgetItem(f"{title}\n{library.when(d.get('modified', 0))}  ·  {d.get('words', 0)} words")
            item.setToolTip(d['title'])
            item.setData(Qt.UserRole, d['id'])
            if d['id'] == self.win.doc_id:
                f = item.font()
                f.setBold(True)
                item.setFont(f)
            self.list.addItem(item)
        self.body.setCurrentIndex(0 if docs else 1)
        if hasattr(self, 'train_card'):
            self.train_card.refresh()

    def _open(self, item):
        doc_id = item.data(Qt.UserRole)
        if doc_id and doc_id != self.win.doc_id:
            self.win.open_document(doc_id)

    def _menu(self, pos):
        from PySide6.QtWidgets import QMenu
        item = self.list.itemAt(pos)
        if not item:
            return
        doc_id = item.data(Qt.UserRole)
        menu = QMenu(self)
        menu.setStyleSheet(f"\n            QMenu {{ background:{P['surface']}; color:{P['ink']};\n                     border:1px solid {P['line']}; border-radius:10px; padding:4px; }}\n            QMenu::item {{ padding:8px 18px; border-radius:6px; }}\n            QMenu::item:selected {{ background:{P['hover']}; }}\n        ")
        act_rename = menu.addAction(t('Rename…'))
        act_delete = menu.addAction(t('Delete'))
        chosen = menu.exec(self.list.mapToGlobal(pos))
        if chosen is act_rename:
            self.win.rename_document(doc_id)
        elif chosen is act_delete:
            self.win.delete_document(doc_id)

class TransferWorker(QThread):
    progress = Signal(int, int, str)
    done_ok = Signal(str)
    failed = Signal(str)

    def __init__(self, mode: str, **kw):
        super().__init__()
        self.mode, self.kw = (mode, kw)
        self._stop = False

    def run(self):
        try:
            if self.mode == 'export':
                dest = transfer.export_profile(self.kw['name'], Path(self.kw['dest']), include_models=self.kw.get('include_models', True), include_documents=self.kw.get('include_documents', True), progress=lambda d, t, l: self.progress.emit(d, t, l), should_stop=lambda: self._stop)
                self.done_ok.emit(str(dest))
            else:
                got = transfer.import_profile(Path(self.kw['path']), new_name=self.kw.get('new_name'), overwrite=self.kw.get('overwrite', False), progress=lambda d, t, l: self.progress.emit(d, t, l))
                self.done_ok.emit(got)
        except InterruptedError:
            self.failed.emit('cancelled')
        except Exception as e:
            self.failed.emit(str(e))

    def stop(self):
        self._stop = True

class BackupDialog(QDialog):

    def __init__(self, window: 'Window'):
        super().__init__(window)
        self.win = window
        self.setWindowTitle(t('Back up or restore'))
        self.setMinimumWidth(470)
        self.setStyleSheet(f"\n            QDialog {{ background:{P['canvas']}; }}\n            QLabel {{ color:{P['ink']}; font-family:{SANS_STACK}; font-size:14px; }}\n            QLabel#Head {{ font-size:12px; font-weight:700; letter-spacing:1.4px;\n                color:{P['ink_soft']}; }}\n            QLabel#Note {{ font-size:12px; color:{P['ink_soft']}; }}\n            QCheckBox {{ color:{P['ink']}; font-size:13px; spacing:9px; }}\n            QCheckBox::indicator {{ width:18px; height:18px; border-radius:6px;\n                border:1px solid {P['line']}; background:{P['surface']}; }}\n            QCheckBox::indicator:checked {{ background:{P['beige']};\n                border-color:{P['beige']}; }}\n            QPushButton {{ background:transparent; color:{P['beige_text']};\n                border:1px solid {P['line']}; border-radius:10px;\n                padding:10px 18px; font-size:13px; font-weight:600; }}\n            QPushButton:hover {{ border-color:{P['beige']}; }}\n            QPushButton:disabled {{ color:{P['disabled_fg']}; }}\n            QProgressBar {{ background:{P['line']}; border:none; border-radius:3px; }}\n            QProgressBar::chunk {{ background:{P['beige']}; border-radius:3px; }}\n        ")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 22, 26, 20)
        lay.setSpacing(10)
        name = window.speaker
        lay.addWidget(self._head('EXPORT PROFILE'))
        self.size_lab = QLabel('')
        lay.addWidget(self.size_lab)
        self.models_chk = ToggleSwitch('Include the trained voice model')
        self.models_chk.setChecked(True)
        self.models_chk.toggled.connect(self._update_size)
        lay.addWidget(self.models_chk)
        m_note = QLabel(t('The model is most of the size. Leaving it out makes a much smaller file — the recordings are still there, so it can be trained again on the new computer.'))
        m_note.setObjectName('Note')
        m_note.setWordWrap(True)
        lay.addWidget(m_note)
        self.docs_chk = ToggleSwitch('Include the pages I have written')
        self.docs_chk.setChecked(True)
        self.docs_chk.toggled.connect(self._update_size)
        lay.addWidget(self.docs_chk)
        self.docs_note = QLabel('')
        self.docs_note.setObjectName('Note')
        self.docs_note.setWordWrap(True)
        lay.addWidget(self.docs_note)
        self.export_btn = QPushButton(t('Save to a file…'))
        self.export_btn.setCursor(Qt.PointingHandCursor)
        self.export_btn.clicked.connect(self._export)
        lay.addWidget(self.export_btn, alignment=Qt.AlignLeft)
        warn = QLabel(t('⚠ The file contains your voice recordings, unlocked. Keep it somewhere private.'))
        warn.setObjectName('Note')
        warn.setWordWrap(True)
        lay.addWidget(warn)
        lay.addSpacing(14)
        lay.addWidget(self._head('RESTORE FROM A FILE'))
        r_note = QLabel(t('Bring a profile onto this computer from a backup made on another one.'))
        r_note.setObjectName('Note')
        r_note.setWordWrap(True)
        lay.addWidget(r_note)
        self.import_btn = QPushButton(t('Choose a backup file…'))
        self.import_btn.setCursor(Qt.PointingHandCursor)
        self.import_btn.clicked.connect(self._import)
        lay.addWidget(self.import_btn, alignment=Qt.AlignLeft)
        lay.addSpacing(10)
        self.bar = QProgressBar()
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(6)
        self.bar.hide()
        lay.addWidget(self.bar)
        self.status = QLabel('')
        self.status.setObjectName('Note')
        self.status.setWordWrap(True)
        lay.addWidget(self.status)
        row = QHBoxLayout()
        row.addStretch()
        self.cancel_btn = QPushButton(t('Cancel'))
        self.cancel_btn.hide()
        self.cancel_btn.setCursor(Qt.PointingHandCursor)
        self.cancel_btn.clicked.connect(self._cancel)
        self.close_btn = QPushButton(t('Close'))
        self.close_btn.setCursor(Qt.PointingHandCursor)
        self.close_btn.clicked.connect(self.accept)
        row.addWidget(self.cancel_btn)
        row.addWidget(self.close_btn)
        lay.addLayout(row)
        self._update_size()

    def _head(self, text: str) -> QLabel:
        lab = QLabel(t(text))
        lab.setObjectName('Head')
        return lab

    def _update_size(self):
        name = self.win.speaker
        total = transfer.estimate_size(name, self.models_chk.isChecked(), self.docs_chk.isChecked())
        self.size_lab.setText(t('Everything for “%s” — about %s.') % (name, profile.human_bytes(total)))
        docs = transfer.documents_size(name)
        if not docs:
            self.docs_note.setText(t('You have not written any pages yet, so this changes nothing.'))
        else:
            self.docs_note.setText(t('Your pages are %s of it. They are your writing rather than anything Kara needs to understand you, so you can leave them out and still move your voice to another computer.') % (profile.human_bytes(docs),))

    def _busy(self, on: bool, label: str=''):
        self.export_btn.setEnabled(not on)
        self.import_btn.setEnabled(not on)
        self.models_chk.setEnabled(not on)
        self.docs_chk.setEnabled(not on)
        self.bar.setVisible(on)
        self.cancel_btn.setVisible(on)
        self.close_btn.setEnabled(not on)
        if label:
            self.status.setText(label)

    def _export(self):
        from PySide6.QtWidgets import QFileDialog
        suggested = str(Path.home() / transfer.default_filename(self.win.speaker))
        path, _ = QFileDialog.getSaveFileName(self, t('Save a copy of this profile'), suggested, f'Kara profile (*{transfer.SUFFIX})')
        if not path:
            return
        self._busy(True, t('Saving…'))
        self.win._retire_thread(getattr(self, '_w', None))
        self._w = TransferWorker('export', name=self.win.speaker, dest=path, include_models=self.models_chk.isChecked(), include_documents=self.docs_chk.isChecked())
        self._w.progress.connect(self._progress)
        self._w.done_ok.connect(self._export_done)
        self._w.failed.connect(self._failed)
        self._w.start()

    def _import(self):
        from PySide6.QtWidgets import QFileDialog, QInputDialog
        patterns = ' '.join((f'*{s}' for s in transfer.READABLE_SUFFIXES))
        path, _ = QFileDialog.getOpenFileName(self, t('Choose a Kara backup'), str(Path.home()), f'Kara profile ({patterns})')
        if not path:
            return
        try:
            meta = transfer.inspect_export(Path(path))
        except Exception as e:
            QMessageBox.warning(self, t("Can't read that file"), str(e))
            return
        counts = '\n'.join((f'  · {k}: {v}' for k, v in (meta.get('counts') or {}).items()))
        name = meta.get('profile', 'imported')
        box = QMessageBox(self)
        box.setWindowTitle(t('Restore this backup?'))
        box.setText(t('Profile “%s”, saved %s:\n\n%s') % (meta.get('display_name') or name, meta.get('created_readable', 'unknown date'), counts))
        box.addButton(t('Cancel'), QMessageBox.RejectRole)
        go = box.addButton(t('Restore'), QMessageBox.AcceptRole)
        box.exec()
        if box.clickedButton() is not go:
            return
        overwrite = False
        if name in profile.list_profiles():
            ask = QMessageBox(self)
            ask.setIcon(QMessageBox.Warning)
            ask.setWindowTitle(t('That profile already exists'))
            ask.setText(t('“%s” is already on this computer.\n\nReplacing it deletes the recordings and writing already here.') % (name,))
            ask.addButton(t('Cancel'), QMessageBox.RejectRole)
            as_new = ask.addButton(t('Import under a new name'), QMessageBox.ActionRole)
            repl = ask.addButton(t('Replace it'), QMessageBox.DestructiveRole)
            ask.setDefaultButton(ask.buttons()[0])
            ask.exec()
            clicked = ask.clickedButton()
            if clicked is repl:
                overwrite = True
            elif clicked is as_new:
                new, ok = QInputDialog.getText(self, t('New name'), t('Call it:'), text=f'{name}-2')
                if not ok or not new.strip():
                    return
                name = new.strip()
            else:
                return
        self._busy(True, 'Restoring…')
        self.win._retire_thread(getattr(self, '_w', None))
        self._w = TransferWorker('import', path=path, new_name=name, overwrite=overwrite)
        self._w.progress.connect(self._progress)
        self._w.done_ok.connect(self._import_done)
        self._w.failed.connect(self._failed)
        self._w.start()

    def _progress(self, done: int, total: int, label: str):
        self.bar.setMaximum(max(1, total))
        self.bar.setValue(done)
        self.status.setText(f'{done} of {total} — {label}')

    def _export_done(self, path: str):
        self._busy(False)
        mb = Path(path).stat().st_size / 1000000.0 if Path(path).exists() else 0
        self.status.setText(t('Saved: %s  (%.0f MB)') % (path, mb))

    def _import_done(self, name: str):
        self._busy(False)
        self.status.setText(t('Restored as “%s”. Open it from the profile menu.') % (name,))

    def _failed(self, err: str):
        self._busy(False)
        self.status.setText(t('Cancelled.') if err == 'cancelled' else t("Didn't work: %s") % (err,))

    def _cancel(self):
        w = getattr(self, '_w', None)
        if w and w.isRunning():
            w.stop()
        self.status.setText(t('Cancelling…'))

    def done(self, r):
        w = getattr(self, '_w', None)
        if w is not None and w.isRunning():
            w.stop()
            if not w.wait(10000):
                self.win._retire_thread(w)
            self._w = None
        super().done(r)

class ManageProfileDialog(QDialog):

    def __init__(self, window: 'Window', name: str):
        super().__init__(window)
        self.win, self.name = (window, name)
        self.setWindowTitle(t('Manage your profile'))
        self.setMinimumWidth(400)
        self.setStyleSheet(f"\n            QDialog {{ background:{P['canvas']}; }}\n            QLabel {{ color:{P['ink']}; font-family:{SANS_STACK}; font-size:14px; }}\n            QLabel#Sub {{ font-size:12px; color:{P['ink_soft']}; }}\n            QLineEdit {{\n                background:{P['surface']}; color:{P['ink']};\n                border:1px solid {P['line']}; border-radius:10px;\n                padding:9px 11px; font-size:14px;\n            }}\n            QLineEdit:focus {{ border-color:{P['beige']}; }}\n            QPushButton#Ghost {{\n                background:transparent; color:{P['beige_text']};\n                border:1px solid {P['line']}; border-radius:10px;\n                padding:8px 16px; font-size:13px; font-weight:600;\n            }}\n            QPushButton#Ghost:hover {{ border-color:{P['beige']}; }}\n            QPushButton#Done {{\n                background:{P['beige']}; color:{P['on_accent']};\n                border:none; border-radius:10px;\n                padding:9px 26px; font-size:14px; font-weight:600;\n            }}\n            QPushButton#Done:hover {{ background:{P['beige_text']}; }}\n        ")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 22, 26, 20)
        lay.setSpacing(12)
        self.avatar = Avatar(profile.display_name(name), 84, photo=profile.photo_path(name))
        lay.addWidget(self.avatar, alignment=Qt.AlignCenter)
        photo_row = QHBoxLayout()
        photo_row.addStretch()
        pick = QPushButton(t('Choose a photo'))
        pick.setObjectName('Ghost')
        pick.setCursor(Qt.PointingHandCursor)
        pick.clicked.connect(self._pick_photo)
        self.remove = QPushButton(t('Remove'))
        self.remove.setObjectName('Ghost')
        self.remove.setCursor(Qt.PointingHandCursor)
        self.remove.clicked.connect(self._remove_photo)
        self.remove.setEnabled(bool(profile.photo_path(name)))
        photo_row.addWidget(pick)
        photo_row.addWidget(self.remove)
        photo_row.addStretch()
        lay.addLayout(photo_row)
        lay.addSpacing(8)
        lab = QLabel(t('Name'))
        lay.addWidget(lab)
        self.name_edit = QLineEdit(profile.display_name(name))
        self.name_edit.setPlaceholderText(name)
        self.name_edit.textChanged.connect(lambda t: self.avatar.set_name(t or name, profile.photo_path(name)))
        lay.addWidget(self.name_edit)
        sub = QLabel(t('Shown around the app. Your files stay under “%s”.') % (name,))
        sub.setObjectName('Sub')
        sub.setWordWrap(True)
        lay.addWidget(sub)
        lay.addSpacing(10)
        row = QHBoxLayout()
        row.addStretch()
        done = QPushButton(t('Save'))
        done.setObjectName('Done')
        done.setCursor(Qt.PointingHandCursor)
        done.clicked.connect(self._save)
        row.addWidget(done)
        lay.addLayout(row)

    def _pick_photo(self):
        from PySide6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(self, t('Choose a photo'), '', 'Pictures (*.png *.jpg *.jpeg)')
        if not path:
            return
        if profile.set_photo(self.name, path) is None:
            QMessageBox.warning(self, t("Couldn't use that picture"), t('Please choose a PNG or JPG image.'))
            return
        self.avatar.set_name(self.name_edit.text() or self.name, profile.photo_path(self.name))
        self.remove.setEnabled(True)

    def _remove_photo(self):
        profile.clear_photo(self.name)
        self.avatar.set_name(self.name_edit.text() or self.name, None)
        self.remove.setEnabled(False)

    def _save(self):
        profile.set_display_name(self.name, self.name_edit.text())
        self.accept()

class ProfilePanel(QWidget):
    SOON: dict[str, str] = {}

    def __init__(self, window: 'Window'):
        super().__init__(window, Qt.Popup | Qt.FramelessWindowHint)
        self.win = window
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setFixedWidth(330)
        self.setStyleSheet(f"\n            QFrame#Card {{ background: {P['surface']};\n                border: 1px solid {P['line']}; border-radius: 14px; }}\n            QLabel {{ color: {P['ink']}; font-family: {SANS_STACK};\n                background: transparent; }}\n            QLabel#Who {{ font-size: 12px; color: {P['ink_soft']}; }}\n            QLabel#Hi {{ font-size: 19px; font-weight: 600; }}\n            QLabel#Sub {{ font-size: 12px; color: {P['ink_soft']}; }}\n            QLabel#Soon {{ font-size: 10px; font-weight: 700; color: {P['beige_text']};\n                background: {P['beige_bg']}; border-radius: 6px; padding: 2px 7px; }}\n            QLabel#Note {{ font-size: 11px; color: {P['ink_soft']}; }}\n            QPushButton#Pill {{\n                background: transparent; color: {P['ink']};\n                border: 1px solid {P['line']}; border-radius: 14px;\n                padding: 8px 20px; font-size: 13px; font-weight: 600;\n            }}\n            QPushButton#Pill:hover {{ border-color: {P['beige']};\n                background: {P['hover']}; }}\n            QPushButton#Row {{\n                background: transparent; color: {P['ink']};\n                border: none; border-radius: 10px;\n                padding: 9px 10px; font-size: 14px; text-align: left;\n            }}\n            QPushButton#Row:hover {{ background: {P['hover']}; }}\n            QFrame#Sep {{ background: {P['line']}; max-height: 1px; border: none; }}\n        ")
        self._build()

    def _sep(self) -> QFrame:
        f = QFrame()
        f.setObjectName('Sep')
        f.setFixedHeight(1)
        return f

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        card = QFrame()
        card.setObjectName('Card')
        outer.addWidget(card)
        lay = QVBoxLayout(card)
        lay.setContentsMargins(18, 14, 18, 14)
        lay.setSpacing(10)
        me = self.win.speaker
        self._who = QLabel('')
        self._who.setObjectName('Who')
        self._who.setAlignment(Qt.AlignCenter)
        lay.addWidget(self._who)
        self._avatar_slot = QWidget()
        slot = QVBoxLayout(self._avatar_slot)
        slot.setContentsMargins(0, 0, 0, 0)
        self._avatar = Avatar(profile.display_name(me), 72, photo=profile.photo_path(me))
        slot.addWidget(self._avatar, alignment=Qt.AlignCenter)
        lay.addWidget(self._avatar_slot)
        self._hi = QLabel('')
        self._hi.setObjectName('Hi')
        self._hi.setAlignment(Qt.AlignCenter)
        lay.addWidget(self._hi)
        self._sub = QLabel('')
        self._sub.setObjectName('Sub')
        self._sub.setAlignment(Qt.AlignCenter)
        lay.addWidget(self._sub)
        manage = QPushButton(t('Manage your profile'))
        manage.setObjectName('Pill')
        manage.setCursor(Qt.PointingHandCursor)
        manage.clicked.connect(self._manage)
        lay.addWidget(manage, alignment=Qt.AlignCenter)
        self._others_box = QWidget()
        self._others_lay = QVBoxLayout(self._others_box)
        self._others_lay.setContentsMargins(0, 0, 0, 0)
        self._others_lay.setSpacing(10)
        lay.addWidget(self._others_box)
        lay.addWidget(self._sep())
        lay.addWidget(self._action_row('＋', 'Add someone new', self._add))
        lay.addWidget(self._action_row('⇄', 'Switch profile…', self._switch_dialog))
        lay.addWidget(self._sep())
        lay.addWidget(self._action_row('⇩', 'Export profile…', self._backup))
        lay.addWidget(self._action_row('☁', 'Back up and restore…', self._backup_settings))
        lay.addWidget(self._action_row('🔒', 'Privacy && data', self._privacy))
        self.note = QLabel('')
        self.note.setObjectName('Note')
        self.note.setWordWrap(True)
        self.note.setFixedHeight(28)
        lay.addWidget(self.note)
        self._rows: dict = {}
        self.profile_changed()

    def profile_changed(self):
        me = self.win.speaker
        shown = profile.display_name(me)
        self._who.setText(t('%s · on this computer') % (shown,))
        self._hi.setText(f'Hi, {shown.split()[0].capitalize()}!')
        d = profile.describe(me)
        self._sub.setText(t('not set up yet') if not d['clips'] else t('%s clips · %s') % (d['clips'], t('trained') if d['trained'] else t('not trained yet')))
        fresh = Avatar(shown, 72, photo=profile.photo_path(me))
        self._avatar_slot.layout().replaceWidget(self._avatar, fresh)
        self._avatar.deleteLater()
        self._avatar = fresh
        while self._others_lay.count():
            item = self._others_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._rows = {}
        others = [n for n in profile.list_profiles() if n != me]
        if others:
            self._others_lay.addWidget(self._sep())
            for name in others:
                self._others_lay.addWidget(self._person_row(name))

    def _person_row(self, name: str) -> QWidget:
        w = QWidget()
        row = QHBoxLayout(w)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)
        d = profile.describe(name)
        row.addWidget(Avatar(d['display_name'], 32, photo=d['photo']))
        tag = 'not set up' if not d['clips'] else f"{d['clips']} clips · {('trained' if d['trained'] else 'not trained')}"
        btn = QPushButton(f"{d['display_name']}\n{tag}")
        btn.setObjectName('Row')
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(lambda: self._switch_to(name))
        row.addWidget(btn, 1)
        self._rows[name] = btn
        return w

    def _action_row(self, glyph: str, label: str, fn) -> QPushButton:
        b = QPushButton(f'  {glyph}    {label}')
        b.setObjectName('Row')
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(fn)
        return b

    def _soon_row(self, key: str, label: str) -> QWidget:
        w = QWidget()
        row = QHBoxLayout(w)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)
        b = QPushButton(f"  {label.replace('&', '&&')}")
        b.setObjectName('Row')
        b.setCursor(Qt.PointingHandCursor)
        b.clicked.connect(lambda: self._soon(key))
        tag = QLabel(t('soon'))
        tag.setObjectName('Soon')
        row.addWidget(b, 1)
        row.addWidget(tag)
        return w

    def _soon(self, key: str):
        what = self.SOON.get(key, 'That')
        self.note.setText(t("%s isn't built yet — it's planned.") % (what,))

    def _manage(self):
        self.close()
        ManageProfileDialog(self.win, self.win.speaker).exec()
        self.win.refresh_identity()

    def _backup(self):
        self.close()
        BackupDialog(self.win).exec()

    def _backup_settings(self):
        self.close()
        dlg = SettingsDialog(self.win)
        for i in range(dlg.nav.count()):
            if dlg.nav.item(i).text() == t('Backup'):
                dlg.nav.setCurrentRow(i)
                break
        dlg.exec()

    def _privacy(self):
        self.close()
        dlg = SettingsDialog(self.win)
        dlg.nav.setCurrentRow(dlg.nav.count() - 1)
        dlg.exec()

    def _switch_to(self, name: str):
        ok, why = self.win.can_switch_profile(name)
        if not ok and why:
            self.note.setText(why)
            return
        status = self.win.switch_profile(name)
        if status == 'queued':
            who = profile.display_name(name)
            self.note.setText(t('Switching to %s when the model finishes loading…') % (who,))
            btn = self._rows.get(name)
            if btn is not None:
                btn.setText(t('%s\nswitching…') % (who,))
                btn.setEnabled(False)
            return
        self.close()

    def _switch_dialog(self):
        self.close()
        name = ProfilePicker.choose(self.win)
        if name and name != self.win.speaker:
            self.win.switch_profile(name)

    def _add(self):
        from PySide6.QtWidgets import QInputDialog
        self.close()
        name, ok = QInputDialog.getText(self.win, t('Add someone new'), t('Their name:'))
        if not ok:
            return
        try:
            profile.create(name)
        except ValueError:
            QMessageBox.warning(self.win, t('Invalid name'), t('Please use a simple name with no slashes or symbols.'))
            return
        name = name.strip()
        self.win.switch_profile(name)
        if profile.clip_count(name) == 0:
            SetupWizard(self.win).exec()

    def popup_under(self, widget: QWidget):
        self.adjustSize()
        corner = widget.mapToGlobal(QPoint(widget.width(), widget.height()))
        self.move(corner.x() - self.width(), corner.y() + 8)
        self.show()

class ProfilePicker(QDialog):

    def __init__(self, parent=None):
        super().__init__(parent)
        self.chosen = None
        self.setWindowTitle(t("Who's using Kara?"))
        self.setMinimumWidth(420)
        self.setStyleSheet(f"\n            QDialog {{ background: {P['canvas']}; }}\n            QLabel {{ color: {P['ink']}; font-family: {SANS_STACK}; }}\n            QLabel#H1 {{ font-size: 22px; font-weight: 600; }}\n            QPushButton#Profile {{\n                background: {P['surface']}; color: {P['ink']};\n                border: 1px solid {P['line']}; border-radius: 10px;\n                padding: 16px 18px; font-size: 17px; font-weight: 600;\n                text-align: left;\n            }}\n            QPushButton#Profile:hover {{ border-color: {P['beige']};\n                background: {P['hover']}; }}\n            QPushButton#Add {{\n                background: transparent; color: {P['beige_text']};\n                border: 1px solid {P['line']}; border-radius: 10px;\n                padding: 14px 18px; font-size: 15px; font-weight: 600;\n                text-align: left;\n            }}\n            QPushButton#Add:hover {{ border-color: {P['beige']}; }}\n        ")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(26, 24, 26, 22)
        lay.setSpacing(12)
        lay.addWidget(Wordmark(32, colour=P['beige'], ink=P['ink'], void=P['canvas'], families=DISPLAY_STACK))
        lay.addSpacing(2)
        h = QLabel(t("Who's using Kara?"))
        h.setObjectName('H1')
        lay.addWidget(h)
        sub = QLabel(t('Kara personalises to each person. Pick yours, or add someone new.'))
        sub.setObjectName('Note')
        sub.setWordWrap(True)
        sub.setStyleSheet(f"font-size:13px; color:{P['ink_soft']};")
        lay.addWidget(sub)
        lay.addSpacing(6)
        for name in profile.list_profiles():
            d = profile.describe(name)
            if d['clips'] == 0:
                status = 'not set up yet'
            elif d['trained']:
                status = f"{d['clips']} clips · trained"
            else:
                status = f"{d['clips']} clips · not trained yet"
            row = QWidget()
            rl = QHBoxLayout(row)
            rl.setContentsMargins(0, 0, 0, 0)
            rl.setSpacing(10)
            rl.addWidget(Avatar(d['display_name'], 38, photo=d['photo']))
            btn = QPushButton(f"{d['display_name']}\n{status}")
            btn.setObjectName('Profile')
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _=False, n=name: self._pick(n))
            rl.addWidget(btn, 1)
            lay.addWidget(row)
        add = QPushButton(t('＋  Add someone new'))
        add.setObjectName('Add')
        add.setCursor(Qt.PointingHandCursor)
        add.clicked.connect(self._add)
        lay.addWidget(add)

    def _pick(self, name: str):
        self.chosen = name
        self.accept()

    def _add(self):
        from PySide6.QtWidgets import QInputDialog
        name, ok = QInputDialog.getText(self, t('Add someone new'), t('Their name:'))
        if not ok:
            return
        try:
            profile.create(name)
        except ValueError:
            QMessageBox.warning(self, t('Invalid name'), t('Please use a simple name with no slashes or symbols.'))
            return
        self.chosen = name.strip()
        self.accept()

    @classmethod
    def choose(cls, parent=None) -> str | None:
        dlg = cls(parent)
        dlg.exec()
        return dlg.chosen

class SayHelpDialog(QDialog):

    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.setWindowTitle(t('What can I say?'))
        self.resize(560, 620)
        self.setStyleSheet(window.styleSheet())
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.setSpacing(10)
        head = QLabel(t('Say any of these while the microphone is listening.'))
        head.setObjectName('Field')
        head.setWordWrap(True)
        lay.addWidget(head)
        self.box = QLineEdit()
        self.box.setPlaceholderText(t('Search — try “capital” or “delete”'))
        self.box.textChanged.connect(self._refill)
        lay.addWidget(self.box)
        self.list = QTextEdit()
        self.list.setReadOnly(True)
        self.list.setObjectName('Buffer')
        lay.addWidget(self.list, 1)
        close = QPushButton(t('Close'))
        close.setObjectName('Primary')
        close.setCursor(Qt.PointingHandCursor)
        close.clicked.connect(self.accept)
        row = QHBoxLayout()
        row.addStretch()
        row.addWidget(close)
        lay.addLayout(row)
        self._refill('')

    def _refill(self, term: str):
        try:
            import sayhelp
            rows = sayhelp.search(term, self.win.speaker)
        except Exception:
            rows = []
        if not rows:
            self.list.setPlainText(t('Nothing matches that.'))
            return
        out, last = ([], None)
        for section, what, say in rows:
            if section != last:
                out.append(f'\n{section.upper()}')
                last = section
            out.append(f'   {what:<34}“{say}”')
        self.list.setPlainText('\n'.join(out).lstrip())

class Window(QWidget):
    _update_seen = Signal(dict)
    _update_ready = Signal(bool, str)

    def __init__(self, speaker: str, model: str, adapter: str, speak: bool, setup_only: bool=False):
        super().__init__()
        self._update_seen.connect(self._update_found)
        self._update_ready.connect(self._update_installed)
        self.speaker = speaker
        self.speak_on = speak or bool(config.load().get('speak_responses', False))
        self.config = config.load()
        self.offline = bool(self.config.get('offline_mode', True))
        self.model = profile.model_size(self.speaker)
        if self.model not in MODEL_OPTIONS:
            self.model = model if model in MODEL_OPTIONS else DEFAULT_MODEL
        self.adapter = _adapter_for(self.model, self.speaker)
        self.reloading = False
        self.pipe = None
        self.ed = editing.Editor()
        try:
            self.anchors = spelling.load_anchors(speaker)
        except (SystemExit, OSError, ValueError):
            self.anchors = {}
        self.recording = False
        self._syncing = False
        self.pending = None
        self.mode_idx = 0
        self.modes = self._active_modes()
        self.worker = None
        self.target_hwnd = 0
        self.target_title = ''
        self.doc_id = None
        self.setWindowTitle(APP_NAME)
        self.setObjectName('Root')
        self.resize(760, 900)
        self.setStyleSheet(STYLESHEET)
        self._build()
        try:
            self.mic = Mic(self.config.get('input_device'))
            self.mic_btn.setToolTip(t('Tap to talk  ·  %s') % (self.mic.device[1],))
        except SystemExit as e:
            self.mic = None
            self._no_mic(e)
        self.setup_only = setup_only
        self.loader = None
        if not setup_only:
            self._load_started = time.monotonic()
            karalog.get('gui').info('loading model=%s adapter=%s', self.model, Path(self.adapter).name if self.adapter else None)
            self.loader = ModelLoader(speaker, self.model, self.adapter)
            self.loader.done.connect(self._model_ready)
            self.loader.failed.connect(self._model_failed)
            self.loader.start()
        self._watch = QTimer(self)
        self._watch.timeout.connect(self._watch_tick)
        self._watch.start(700)
        self._meter = QTimer(self)
        self._meter.timeout.connect(self._tick_meter)
        self._meter.start(60)
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(self._autosave)
        self._mini = None
        self._reload_user_commands()
        self._auto_backup = None
        self._auto_timer = QTimer(self)
        self._auto_timer.timeout.connect(self._maybe_auto_backup)
        self._auto_timer.start(AUTO_BACKUP_EVERY)
        QTimer.singleShot(AUTO_BACKUP_FIRST, self._maybe_auto_backup)
        self._proof = None
        self._online_worker = None
        self._last_proof_err = None
        self.unsure: list = []
        self._online_cache: tuple[str, list] | None = None
        self._online_cooldown = 0.0
        self.marks: list = []
        self.highlighter = ProofHighlighter(self.buffer.document())
        self._proof_timer = QTimer(self)
        self._proof_timer.setSingleShot(True)
        self._proof_timer.timeout.connect(self._recheck)
        self.buffer.setContextMenuPolicy(Qt.CustomContextMenu)
        self.buffer.customContextMenuRequested.connect(self._buffer_menu)
        last = library.list_docs(self.speaker)
        if last:
            self.open_document(last[0]['id'])
        if setup_only:

            def _setup_session():
                SetupWizard(self).exec()
                QApplication.quit()
            QTimer.singleShot(200, _setup_session)
        else:
            QTimer.singleShot(600, self._maybe_first_run)

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        header = QFrame()
        header.setObjectName('Header')
        hl = QHBoxLayout(header)
        hl.setContentsMargins(14, 14, 18, 6)
        self.library_btn = IconButton('menu', t('Your writing'))
        self.library_btn.clicked.connect(self.toggle_library)
        self.spinner = Spinner(18)
        self.spinner.set_colour(P['beige'])
        self.settings_btn = IconButton('cog', t('Settings'))
        self.settings_btn.clicked.connect(self._settings)
        self.avatar_btn = AvatarButton(profile.display_name(self.speaker), 34, photo=profile.photo_path(self.speaker))
        self.avatar_btn.clicked.connect(self._open_profiles)
        hl.addWidget(self.library_btn)
        self.lockup = Wordmark(24, colour=P['beige'], ink=P['ink'], void=P['canvas'], families=DISPLAY_STACK)
        hl.addSpacing(10)
        hl.addWidget(self.lockup)
        self.version_lab = QLabel(f'v{VERSION}')
        self.version_lab.setObjectName('Note')
        self.version_lab.setToolTip(f'{APP_NAME} {VERSION}')
        hl.addSpacing(8)
        hl.addWidget(self.version_lab, 0, Qt.AlignVCenter)
        self.setup_btn = QPushButton(t('Setup'))
        self.setup_btn.setObjectName('HeaderGhost')
        self.setup_btn.setCursor(Qt.PointingHandCursor)
        self.setup_btn.setToolTip(t('Run the first-run setup again (temporary)'))
        self.setup_btn.clicked.connect(self._open_startup)
        hl.addSpacing(10)
        hl.addWidget(self.setup_btn, 0, Qt.AlignVCenter)
        hl.addStretch()
        hl.addWidget(self.spinner)
        hl.addSpacing(8)
        hl.addWidget(self.settings_btn)
        hl.addSpacing(6)
        hl.addWidget(self.avatar_btn)
        root.addWidget(header)
        body = QVBoxLayout()
        body.setContentsMargins(24, 0, 24, 20)
        body.setSpacing(14)
        card = QFrame()
        card.setObjectName('Card')
        cl = QVBoxLayout(card)
        cl.setContentsMargins(18, 12, 14, 14)
        cl.setSpacing(8)
        head = QHBoxLayout()
        head.setSpacing(2)
        self.doc_title = QLabel(t('YOUR TEXT'))
        self.doc_title.setObjectName('CardLabel')
        self.count_lab = QLabel('')
        self.count_lab.setObjectName('Count')
        head.addWidget(self.doc_title)
        head.addSpacing(10)
        head.addWidget(self.count_lab)
        head.addStretch()
        self.tidy_btn = QPushButton('')
        self.tidy_btn.setObjectName('GrammarChip')
        self.tidy_btn.setAccessibleName(t('Things to fix on this page'))
        self.tidy_btn.setCursor(Qt.PointingHandCursor)
        self.tidy_btn.clicked.connect(self.toggle_grammar)
        self.tidy_btn.hide()
        head.addWidget(self.tidy_btn)
        head.addSpacing(8)
        self.copy_btn = IconButton('copy', t('Copy the text'))
        self.copy_btn.clicked.connect(self.copy_text)
        self.speak_btn = IconButton('speaker', 'Read my writing aloud', checkable=True)
        self.speak_btn.clicked.connect(self.read_aloud)
        self.undo_btn = IconButton('undo', t('Undo'))
        self.undo_btn.clicked.connect(self.undo)
        self.redo_btn = IconButton('redo', t('Redo'))
        self.redo_btn.clicked.connect(self.redo)
        self.clear_btn = IconButton('trash', t('Clear everything'))
        self.clear_btn.clicked.connect(self.clear)
        for b in (self.copy_btn, self.speak_btn, self.undo_btn, self.redo_btn, self.clear_btn):
            head.addWidget(b)
        cl.addLayout(head)
        self.buffer = QTextEdit()
        self.buffer.setObjectName('Buffer')
        self.buffer.setReadOnly(False)
        self.buffer.setMinimumHeight(240)
        self.buffer.setPlaceholderText(t('Tap the microphone and talk — or type here.'))
        self.buffer.textChanged.connect(self._buffer_typed)
        textrow = QHBoxLayout()
        textrow.setSpacing(4)
        self.gutter = LineNumbers(self.buffer)
        textrow.addWidget(self.gutter)
        textrow.addWidget(self.buffer)
        cl.addLayout(textrow)
        body.addWidget(card)
        self.work = QProgressBar()
        self.work.setObjectName('Work')
        self.work.setRange(0, 0)
        self.work.setTextVisible(False)
        self.work.setFixedHeight(3)
        self.work.hide()
        body.addWidget(self.work)
        self.status = QLabel('')
        self.status.setObjectName('Status')
        self.status.setAlignment(Qt.AlignCenter)
        self.status.setWordWrap(False)
        self.status.setFixedHeight(20)
        body.addWidget(self.status)
        self.rescue_row = QWidget()
        rr = QHBoxLayout(self.rescue_row)
        rr.setContentsMargins(0, 0, 0, 0)
        rr.setSpacing(8)
        self.rescue_run = QPushButton(t('Run the command'))
        self.rescue_run.setObjectName('Primary')
        self.rescue_run.setCursor(Qt.PointingHandCursor)
        self.rescue_run.clicked.connect(lambda: self._resolve_rescue(True))
        self.rescue_write = QPushButton(t('Write it down'))
        self.rescue_write.setObjectName('Test')
        self.rescue_write.setCursor(Qt.PointingHandCursor)
        self.rescue_write.clicked.connect(lambda: self._resolve_rescue(False))
        rr.addStretch()
        rr.addWidget(self.rescue_run)
        rr.addWidget(self.rescue_write)
        rr.addStretch()
        self.rescue_row.hide()
        self._rescue = None
        body.addWidget(self.rescue_row)
        self.mode_seg = ModeBar(self._replace_thumb)
        self.mode_seg.setObjectName('ModeSeg')
        self.seg_lay = QHBoxLayout(self.mode_seg)
        self.seg_lay.setContentsMargins(3, 3, 3, 3)
        self.seg_lay.setSpacing(3)
        self.seg_buttons: dict = {}
        self.cycle_btn = IconButton('cycle', t('Next mode'), size=40, box=23.0)
        self.cycle_btn.clicked.connect(self.cycle_mode)
        self.cycle_btn.hide()
        moderow = QHBoxLayout()
        moderow.addStretch()
        moderow.addWidget(self.mode_seg)
        moderow.addStretch()
        body.addLayout(moderow)
        self.mic_btn = MicOrb(source=self._mic_level, accent=P['beige'], canvas=P['canvas'])
        self.mic_btn.clicked.connect(self.toggle_record)
        mrow = QHBoxLayout()
        mrow.addStretch()
        mrow.addWidget(self.mic_btn)
        mrow.addStretch()
        body.addLayout(mrow)
        self.target = QLabel('')
        self.target.setObjectName('Target')
        self.target.setAlignment(Qt.AlignCenter)
        body.addWidget(self.target)
        morerow = QHBoxLayout()
        morerow.addStretch()
        self.mini_btn = IconButton('mini', t('Miniplayer'), size=40, box=22.0)
        self.mini_btn.clicked.connect(self.open_mini)
        morerow.addWidget(self.mini_btn)
        self.more_btn = IconButton('more', t('Send to your document'), size=40, box=22.0)
        self.more_btn.clicked.connect(self._more_menu)
        morerow.addWidget(self.more_btn)
        body.addLayout(morerow)
        middle = QHBoxLayout()
        middle.setContentsMargins(0, 0, 0, 0)
        middle.setSpacing(0)
        self.aurora = Aurora(self)
        self.sidebar = LibrarySidebar(self)
        self.sidebar.setVisible(False)
        middle.addWidget(self.sidebar)
        self.grammar_panel = GrammarPanel(self)
        self.grammar_panel.setVisible(False)
        middle.addWidget(self.grammar_panel)
        body_wrap = QWidget()
        body_wrap.setLayout(body)
        middle.addWidget(body_wrap, 1)
        self.say_panel = SayLivePanel(self)
        self.say_panel.setVisible(False)
        middle.addWidget(self.say_panel)
        root.addLayout(middle)
        self._skin_icons()
        self._apply_mode()
        self._update_count()

    def _skin_icons(self):
        light_paper = THEME == 'brown'
        for b in (self.copy_btn, self.speak_btn, self.undo_btn, self.redo_btn, self.clear_btn):
            b.set_palette(idle=P['paper_dim'], on=P['beige'], hover=P['paper_ink'], disabled=P['disabled_fg'], hover_bg='#22000000' if light_paper else '#22ffffff')
        for b in (self.settings_btn, self.cycle_btn):
            b.set_palette(idle=P['ink_soft'], on=P['blue'], hover=P['ink'], disabled=P['disabled_fg'], hover_bg=P['hover'])

    def _chip(self, text: str, state: str='thinking'):
        busy = state in ('starting', 'thinking')
        self.spinner.start() if busy else self.spinner.stop()
        self.work.setVisible(state == 'thinking')

    def _hint(self, text: str):
        self.status.setText(_short(t(text), 150))
        self._sync_mini()

    def _offer_rescue(self, raw: str, cmd: str):
        self._rescue = {'raw': raw, 'cmd': cmd}
        self.rescue_run.setText(t('Run “%s”') % (RESCUE_NAMES.get(cmd, cmd),))
        self.rescue_row.show()
        self._say(t('Did you mean the command, or should Kara write "%s"?') % (_short(raw, 40),))

    def _clear_rescue(self):
        self._rescue = None
        self.rescue_row.hide()

    def _resolve_rescue(self, run: bool):
        pend = self._rescue
        self._clear_rescue()
        if not pend:
            return
        if run:
            karalog.get('gui').info('mis-mode rescue: ran %s', pend['cmd'])
            self._say(editing.apply_command(self.ed, pend['raw']))
        else:
            karalog.get('gui').info('mis-mode rescue: written as text')
            self.ed.dictate(pend['raw'])
            self._hint('')
        self._refresh()

    def _active_modes(self) -> list:
        skip = set()
        if not self.config.get('include_spelling', True):
            skip.add('spelling')
        return [m for m in MODES if m[0] not in skip]

    def apply_modes(self):
        key = self.current_mode()
        self.modes = self._active_modes()
        self.mode_idx = next((i for i, m in enumerate(self.modes) if m[0] == key), 0)
        self._apply_mode()

    def current_mode(self) -> str:
        return self.modes[self.mode_idx][0]
    SEG_PAD = 34
    SEG_MIN = 96

    def _rebuild_modes(self):
        from PySide6.QtGui import QFontMetrics
        while self.seg_lay.count():
            item = self.seg_lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.seg_buttons = {}
        self.seg_thumb = QWidget(self.mode_seg)
        self.seg_thumb.setObjectName('SegThumb')
        self.seg_thumb.setAttribute(Qt.WA_TransparentForMouseEvents)
        self.seg_thumb.setStyleSheet(f"#SegThumb {{ background:{P['beige']}; border-radius:19px; }}")
        self.seg_thumb.lower()
        self.seg_thumb.show()
        font = display_font(14, 600)
        fm = QFontMetrics(font)
        for key, name, _colour, _bg in self.modes:
            b = QPushButton(name)
            b.setObjectName('Seg')
            b.setCheckable(True)
            b.setCursor(Qt.PointingHandCursor)
            b.setFont(font)
            b.setFixedWidth(max(self.SEG_MIN, fm.horizontalAdvance(name) + self.SEG_PAD))
            b.setMinimumHeight(40)
            b.setToolTip(t(MODE_HINTS[key]))
            b.clicked.connect(lambda _=False, k=key: self._set_mode(k))
            self.seg_lay.addWidget(b)
            self.seg_buttons[key] = b

    def _apply_mode(self):
        self._sync_mini()
        key, name, colour, bg = self.modes[self.mode_idx]
        if not self.seg_buttons or set(self.seg_buttons) != {m[0] for m in self.modes}:
            self._rebuild_modes()
        for k, b in self.seg_buttons.items():
            on = k == key
            b.setChecked(on)
            b.setStyleSheet(f"#Seg {{ background:transparent; color:{(P['on_accent'] if on else P['beige_text'])}; border:none; border-radius:19px; padding:6px 4px; }}#Seg:hover {{ color:{(P['on_accent'] if on else P['ink'])}; }}")
        self.mode_seg.setStyleSheet(f"#ModeSeg {{ background:{P['surface']}; border:1px solid {P['line']}; border-radius:23px; }}")
        self._move_thumb(key)

    def _replace_thumb(self):
        if not getattr(self, 'modes', None):
            return
        try:
            key = self.modes[self.mode_idx][0]
        except (IndexError, AttributeError):
            return
        self._move_thumb(key, animate=False)

    def _move_thumb(self, key: str, animate: bool=True):
        thumb = getattr(self, 'seg_thumb', None)
        target = self.seg_buttons.get(key)
        if thumb is None or target is None:
            return
        placed = any((b.x() > 0 for b in self.seg_buttons.values())) or len(self.seg_buttons) == 1
        if not target.geometry().isValid() or target.width() <= 1 or (not placed):
            QTimer.singleShot(0, lambda k=key: self._move_thumb(k, animate=False))
            return
        end = target.geometry()
        thumb.setStyleSheet(f"#SegThumb {{ background:{P['beige']}; border-radius:{max(2, end.height() // 2)}px; }}")
        running = getattr(self, '_thumb_anim', None)
        if running is not None:
            running.stop()
        ms = motion_ms(260) if animate else 0
        if not ms or not thumb.isVisible() or (not thumb.geometry().isValid()) or (thumb.width() <= 1):
            thumb.setGeometry(end)
            return
        from PySide6.QtCore import QEasingCurve, QPropertyAnimation
        anim = QPropertyAnimation(thumb, b'geometry', thumb)
        anim.setDuration(ms)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.setStartValue(thumb.geometry())
        anim.setEndValue(end)
        self._thumb_anim = anim
        anim.start()

    def cycle_mode(self):
        self.mode_idx = (self.mode_idx + 1) % len(self.modes)
        self._apply_mode()

    def _set_mode(self, key: str):
        idx = next((i for i, m in enumerate(self.modes) if m[0] == key), None)
        if idx is None:
            self._hint(t('%s mode is turned off in Settings.') % (key.capitalize(),))
            return
        self.mode_idx = idx
        self._apply_mode()

    def _say(self, msg: str, force: bool=False):
        self._hint(msg)
        if (self.speak_on or force) and msg.strip():
            threading.Thread(target=editing.speak, args=(msg, self._output_index()), daemon=True).start()

    def _refresh(self):
        before = getattr(self, '_painted_text', '')
        self._syncing = True
        self.buffer.setPlainText(self.ed.text)
        cur = self.buffer.textCursor()
        cur.movePosition(cur.MoveOperation.End)
        self.buffer.setTextCursor(cur)
        self.buffer.verticalScrollBar().setValue(self.buffer.verticalScrollBar().maximum())
        self._syncing = False
        self._painted_text = self.ed.text
        self._update_count()
        self._touch()
        self._settle_arrival(before, self.ed.text)

    def _set_selection_layer(self, name: str, sels: list):
        layers = self.__dict__.setdefault('_sel_layers', {})
        if sels:
            layers[name] = sels
        else:
            layers.pop(name, None)
        self._paint_selections()

    def _paint_selections(self):
        out = []
        for _name, sels in (self.__dict__.get('_sel_layers') or {}).items():
            out.extend(sels)
        self.buffer.setExtraSelections(out)

    def _selection(self, a: int, b: int, fmt):
        from PySide6.QtGui import QTextCursor
        sel = QTextEdit.ExtraSelection()
        cur = QTextCursor(self.buffer.document())
        cur.setPosition(a)
        cur.setPosition(b, QTextCursor.KeepAnchor)
        sel.cursor, sel.format = (cur, fmt)
        return sel

    def _highlight(self, spans):
        from PySide6.QtGui import QColor, QTextCharFormat
        sels = []
        for a, b in spans:
            fmt = QTextCharFormat()
            fmt.setBackground(QColor(P['hi_bg']))
            fmt.setForeground(QColor(P['hi_fg']))
            sels.append(self._selection(a, b, fmt))
        self._set_selection_layer('match', sels)
    SETTLE_MS = 340
    SETTLE_STAGGER_MS = 40
    SETTLE_MAX_WORDS = 60

    def _settle_arrival(self, before: str, after: str):
        if not after or after == before:
            return
        if not before:
            return
        if not after.startswith(before):
            return
        tail = after[len(before):]
        if not tail.strip():
            return
        base = len(before)
        words = []
        for m in re.finditer('\\S+', tail):
            words.append((base + m.start(), base + m.end()))
        if not words or len(words) > self.SETTLE_MAX_WORDS:
            return
        if not motion_ms(self.SETTLE_MS):
            return
        self._settle_words = words
        self._settle_t0 = time.monotonic()
        timer = getattr(self, '_settle_timer', None)
        if timer is None:
            timer = QTimer(self)
            timer.timeout.connect(self._settle_tick)
            self._settle_timer = timer
        timer.start(16)
        self._settle_tick()

    def _settle_tick(self):
        from PySide6.QtGui import QColor, QTextCharFormat
        words = getattr(self, '_settle_words', None)
        if not words:
            self._settle_timer.stop()
            return
        ink = QColor(P['paper_ink'])
        elapsed = (time.monotonic() - self._settle_t0) * 1000.0
        sels, done = ([], True)
        for i, (a, b) in enumerate(words):
            p = (elapsed - i * self.SETTLE_STAGGER_MS) / self.SETTLE_MS
            if p >= 1.0:
                continue
            done = False
            p = max(0.0, p)
            eased = 1 - (1 - p) ** 3
            fmt = QTextCharFormat()
            fmt.setForeground(QColor(ink.red(), ink.green(), ink.blue(), int(255 * eased)))
            sels.append(self._selection(a, b, fmt))
        self._set_selection_layer('settle', sels)
        if done:
            self._settle_words = None
            self._settle_timer.stop()
    WASH_MS = 1100
    WASH_MAX = 4

    def wash_words(self, spans: list):
        spans = [s for s in spans or [] if s and s[1] > s[0]]
        if not spans or len(spans) > self.WASH_MAX:
            return
        if not motion_ms(self.WASH_MS):
            return
        self._wash_spans = spans
        self._wash_t0 = time.monotonic()
        timer = getattr(self, '_wash_timer', None)
        if timer is None:
            timer = QTimer(self)
            timer.timeout.connect(self._wash_tick)
            self._wash_timer = timer
        timer.start(16)
        self._wash_tick()

    def _wash_tick(self):
        from PySide6.QtGui import QColor, QTextCharFormat
        spans = getattr(self, '_wash_spans', None)
        if not spans:
            self._wash_timer.stop()
            return
        elapsed = (time.monotonic() - self._wash_t0) * 1000.0
        p = elapsed / self.WASH_MS
        if p >= 1.0:
            self._wash_spans = None
            self._wash_timer.stop()
            self._set_selection_layer('wash', [])
            return
        alpha = 1.0 if p < 0.6 else 1.0 - (p - 0.6) / 0.4
        base = QColor(P['beige'])
        fmt_a = int(60 * alpha)
        sels = []
        for a, b in spans:
            fmt = QTextCharFormat()
            fmt.setBackground(QColor(base.red(), base.green(), base.blue(), fmt_a))
            sels.append(self._selection(a, b, fmt))
        self._set_selection_layer('wash', sels)

    def read_aloud(self):
        if getattr(self, '_reader', None) and self._reader.isRunning():
            self.stop_reading()
            return
        text = self.ed.text
        if not text.strip():
            self._hint('There is nothing to read yet.')
            return
        if not voices.catalogue():
            self._hint('No natural voice yet — add one in Settings ▸ Look & sound.')
            return
        spans = punctuation._sentence_spans(text)
        if not spans:
            spans = [(0, len(text))]
        self._retire_thread(getattr(self, '_reader', None))
        resume = getattr(self, '_read_from', 0)
        if getattr(self, '_read_text', None) != text:
            resume = 0
        self._read_text = text
        self._reader = ReadAloudWorker(spans, text, self._output_index(), start_word=resume)
        self._reader.cfg_voice = self.config.get('tts_voice')
        self._reader.cfg_rate = int(self.config.get('tts_rate', 0) or 0)
        self._reader.sentence.connect(self._reading_sentence)
        self._reader.stopped_at.connect(self._reading_stopped_at)
        self._reader.finished_reading.connect(self._reading_done)
        self._reader.start()
        self.speak_btn.setChecked(True)
        self.speak_btn.setToolTip(t('Stop reading'))
        self._hint('Reading aloud — tap the speaker again to stop.' if not resume else 'Carrying on from where it stopped.')

    def _reading_stopped_at(self, word: int):
        self._read_from = max(0, word) if word >= 0 else 0

    def stop_reading(self):
        r = getattr(self, '_reader', None)
        if r and r.isRunning():
            r.stop()
        self._reading_done()

    def _reading_sentence(self, a: int, b: int):
        if not self.pending:
            self._highlight([(a, b)])
            cur = self.buffer.textCursor()
            cur.setPosition(a)
            self.buffer.setTextCursor(cur)

    def _reading_done(self):
        if not self.pending:
            self._highlight([])
        self.speak_btn.setChecked(False)
        self.speak_btn.setToolTip(t('Read my writing aloud'))

    def copy_text(self):
        QApplication.clipboard().setText(self.ed.text)
        self._hint('Copied.')

    def _maybe_first_run(self):
        record.RECORDINGS, record.MANIFEST = record.speaker_paths(self.speaker)
        if record.MANIFEST.exists() and record.already_recorded():
            return
        box = QMessageBox(self)
        box.setWindowTitle(t('Welcome to Kara'))
        box.setText(t('Kara works best after it learns your voice.\n\nWould you like to record a short setup now? You can stop anytime, and it all stays on this computer.'))
        box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        box.setButtonText(QMessageBox.Yes, 'Set up my voice')
        box.setButtonText(QMessageBox.No, 'Later')
        if box.exec() == QMessageBox.Yes:
            SetupWizard(self).exec()

    def toggle_library(self):
        show = not self.sidebar.isVisible()
        if show:
            self.grammar_panel.setVisible(False)
            self.sidebar.refresh()
        self._slide_panel(self.sidebar, show)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        glow = getattr(self, 'aurora', None)
        if glow is not None:
            glow.setGeometry(self.rect())

    def _set_aurora(self, on: bool):
        glow = getattr(self, 'aurora', None)
        if glow is None:
            return
        glow.set_listening(on and bool(self.config.get('listening_glow', False)))

    def _slide_panel(self, panel, show: bool):
        width = getattr(panel, 'WIDTH', None) or panel.sizeHint().width()
        running = getattr(panel, '_slide', None)
        if running is not None:
            running.stop()
        ms = motion_ms(180)
        if not ms:
            panel.setVisible(show)
            panel.setFixedWidth(width)
            return
        start = panel.width() if panel.isVisible() else 0
        if show:
            panel.setMinimumWidth(0)
            panel.setMaximumWidth(start)
            panel.setVisible(True)
        else:
            panel.setMinimumWidth(0)
        from PySide6.QtCore import QEasingCurve, QPropertyAnimation
        anim = QPropertyAnimation(panel, b'maximumWidth', panel)
        anim.setDuration(ms)
        anim.setEasingCurve(QEasingCurve.OutCubic)
        anim.setStartValue(start)
        anim.setEndValue(width if show else 0)

        def landed():
            if not show:
                panel.setVisible(False)
            panel.setFixedWidth(width)
        anim.finished.connect(landed)
        panel._slide = anim
        anim.start()

    def _autosave(self):
        text = self.ed.text
        if self.doc_id is None:
            if not text.strip():
                return
            self.doc_id = library.create(self.speaker, text)['id']
        else:
            library.save(self.speaker, self.doc_id, text)
        if self.sidebar.isVisible():
            self.sidebar.refresh()
        self._show_doc_title()

    def _show_doc_title(self):
        row = next((r for r in library.list_docs(self.speaker) if r['id'] == self.doc_id), None)
        self.doc_title.setText((row['title'] if row else 'YOUR TEXT').upper()[:38])

    def new_document(self):
        self._autosave()
        self._harvest('new page')
        self.doc_id = None
        self.ed = editing.Editor()
        self.pending = None
        self._highlight([])
        self._refresh()
        self.doc_title.setText(t('YOUR TEXT'))
        self.sidebar.refresh()
        self._hint('New page.')

    def open_document(self, doc_id: str):
        self._autosave()
        self._harvest('switch page')
        text = library.read(self.speaker, doc_id)
        self.doc_id = doc_id
        self.ed = editing.Editor(text)
        self.pending = None
        self._highlight([])
        self._refresh()
        self._show_doc_title()
        self.sidebar.refresh()

    def rename_document(self, doc_id: str):
        from PySide6.QtWidgets import QInputDialog
        row = next((r for r in library.list_docs(self.speaker) if r['id'] == doc_id), None)
        name, ok = QInputDialog.getText(self, t('Rename'), t('Title:'), text=row['title'] if row else '')
        if ok and name.strip():
            library.rename(self.speaker, doc_id, name)
            self.sidebar.refresh()
            if doc_id == self.doc_id:
                self._show_doc_title()

    def delete_document(self, doc_id: str):
        row = next((r for r in library.list_docs(self.speaker) if r['id'] == doc_id), None)
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Warning)
        box.setWindowTitle(t('Delete this page?'))
        box.setText(t('“%s” will be removed from your writing.\n\nThe file goes to the Windows Recycle Bin, so you can still get it back from there.') % (row['title'] if row else doc_id,))
        box.addButton(t('Keep it'), QMessageBox.RejectRole)
        gone = box.addButton(t('Delete'), QMessageBox.DestructiveRole)
        box.setDefaultButton(box.buttons()[0])
        box.exec()
        if box.clickedButton() is not gone:
            return
        library.delete(self.speaker, doc_id)
        if doc_id == self.doc_id:
            self.doc_id = None
            self.ed = editing.Editor()
            self._refresh()
            self.doc_title.setText(t('YOUR TEXT'))
        self.sidebar.refresh()

    def _clip_count(self) -> int:
        try:
            _rec, manifest = record.speaker_paths(self.speaker)
            if not manifest.exists():
                return 0
            with manifest.open(encoding='utf-8-sig', newline='') as f:
                return max(0, sum((1 for _ in f)) - 1)
        except Exception as e:
            karalog.get('gui').warning('could not count clips: %s', e)
            return 0

    def _open_startup(self):
        SetupWizard(self).exec()
        self.sidebar.refresh()

    def refresh_identity(self):
        self.avatar_btn.set_name(profile.display_name(self.speaker), profile.photo_path(self.speaker))
        self.setWindowTitle(f'{APP_NAME} — {profile.display_name(self.speaker)}')

    def _open_profiles(self):
        ProfilePanel(self).popup_under(self.avatar_btn)

    def _settings(self):
        SettingsDialog(self).exec()

    def apply_input_device(self):
        spec = self.config.get('input_device')
        try:
            if self.mic is None:
                self.mic = Mic(spec)
                self.mic_btn.set_state('idle' if self.pipe else 'disabled')
            else:
                self.mic.set_device(spec)
            self.mic_btn.setToolTip(t('Tap to talk  ·  %s') % (self.mic.device[1],))
        except SystemExit as e:
            self.mic = None
            self._no_mic(e)

    def _harvest(self, why: str='') -> None:
        if not self.config.get('keep_utterances'):
            return
        try:
            import adapt
            counts = adapt.harvest(self.speaker, self.ed.text)
            if counts.get('paired'):
                karalog.get('adapt').info('harvest (%s): %d paired, %d corrected, %d unchanged, %d unmatched', why or '?', counts['paired'], counts['corrected'], counts['unchanged'], counts['unmatched'])
        except Exception as e:
            karalog.get('adapt').warning('harvest failed: %s', e)

    def _no_mic(self, e: BaseException) -> None:
        info = errors.classify(str(e), default='KARA-1001')
        karalog.get('gui').error('no microphone [%s]: %s', info.code, e)
        self._hint(f'{info.say} {info.fix}  ({info.code})')

    def _output_index(self):
        return record.output_device_index(self.config.get('output_device'))

    def restart(self):
        self._restart_on_exit = True
        self.close()

    def _relaunch(self):
        import subprocess
        try:
            _release_single_instance()
            args = [sys.executable] + list(sys.argv)
            if RESTART_FLAG not in args:
                args.append(RESTART_FLAG)
            subprocess.Popen(args, close_fds=True, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            karalog.get('gui').info('relaunched: %s', ' '.join(args[:2]))
        except Exception as e:
            karalog.get('gui').error('could not relaunch: %s', e)

    def open_practice(self):
        try:
            from practiceview import PracticeDialog
            PracticeDialog(self).exec()
        except Exception as e:
            karalog.get('gui').warning('practice failed to open: %s', e)
            self._hint('Practice could not open.')

    def toggle_say_panel(self):
        show = not self.say_panel.isVisible()
        self.say_panel.setVisible(show)
        if show:
            self.say_panel.refresh()
            self.warn_beta_once('correction')

    def open_say_help(self):
        dlg = SettingsDialog(self)
        dlg.nav.setCurrentRow(1)
        dlg.exec()

    def open_mini(self):
        from miniplayer import MiniPlayer
        strays = [wdg for wdg in QApplication.topLevelWidgets() if isinstance(wdg, MiniPlayer) and wdg is not self._mini]
        for stray in strays:
            karalog.get('gui').warning('closing an orphaned miniplayer')
            try:
                stray.close()
                stray.deleteLater()
            except Exception:
                pass
        if getattr(self, '_mini', None) is not None:
            self._mini.show()
            self._mini.raise_()
            self._mini.activateWindow()
            return
        try:
            self._mini = MiniPlayer(self)
        except Exception as e:
            karalog.get('gui').warning('miniplayer failed to open: %s', e)
            self._mini = None
            return
        self._mini.closed.connect(lambda m=self._mini: self._mini_closed(m))
        self._mini.restore_position()
        self._mini.show()
        self.hide()
        karalog.get('gui').info('miniplayer opened')

    def _mini_closed(self, which=None):
        if which is not None and which is not self._mini:
            return
        self._mini = None
        if QApplication.closingDown() or getattr(self, '_closing', False):
            return
        if not self.isVisible():
            self.showNormal()
            self.raise_()

    def _sync_mini(self):
        mini = getattr(self, '_mini', None)
        if mini is not None:
            try:
                mini.sync()
            except Exception:
                pass
    MINI_WARNINGS = (('quiet', 'Try getting closer to the mic'), ('short', 'Hold the button a little longer'), ('nothing recorded', 'Kara heard nothing — check the microphone'), ('loud', 'Try moving back from the mic'))

    def _warn_mini(self, message: str):
        mini = getattr(self, '_mini', None)
        if mini is None:
            return
        low = (message or '').lower()
        text = next((say for key, say in self.MINI_WARNINGS if key in low), 'That recording could not be used — try again')
        try:
            mini.show_warning(t(text))
        except Exception:
            pass

    def _reload_user_commands(self):
        try:
            import usercommands
            base = editing.builtins_for(self.config.get('language'))
            editing.use_commands(usercommands.merge_into(base, self.speaker))
            n = len(usercommands.load(self.speaker))
            if n:
                karalog.get('gui').info('%d custom command(s) loaded', n)
        except Exception as e:
            karalog.get('gui').warning('custom commands not loaded: %s', e)
            editing.use_commands(None)

    def _maybe_auto_backup(self):
        cfg = config.load()
        if not cfg.get('auto_backup'):
            return
        path = cfg.get('cloud_local_path')
        if not cloudsync.folder_reachable(path):
            return
        if self.recording:
            return
        running = self._auto_backup
        if running is not None and running.isRunning():
            return
        include_model = bool(cfg.get('cloud_backup_model'))
        try:
            fingerprint = cloudsync.payload_fingerprint(self.speaker, include_model=include_model)
        except OSError:
            return
        if fingerprint == cfg.get('last_backup_fingerprint'):
            return
        self._retire_thread(running)
        self._auto_backup = BackupWorker('backup', self.speaker, path, include_model)
        self._auto_backup.done_ok.connect(self._auto_backup_done)
        self._auto_backup.failed.connect(self._auto_backup_failed)
        self._auto_backup.start()

    def _auto_backup_done(self, rep: dict):
        if rep['errors']:
            karalog.get('gui').warning('auto-backup: %d file(s) failed', len(rep['errors']))
            return
        cfg = config.load()
        cfg['last_backup'] = time.strftime('%d %b %Y, %H:%M')
        try:
            cfg['last_backup_fingerprint'] = cloudsync.payload_fingerprint(self.speaker, include_model=bool(cfg.get('cloud_backup_model')))
        except OSError:
            cfg['last_backup_fingerprint'] = None
        config.save(cfg)
        self.config = cfg
        karalog.get('gui').info('auto-backup ok: %d new file(s), %.1f MB', rep['written'], rep['bytes'] / 1000000.0)
        if rep['written']:
            self._hint(t('Backed up %s new recording(s)') % (rep['written'],))

    def _auto_backup_failed(self, code: str, detail: str):
        karalog.get('gui').warning('auto-backup failed [%s] %s', code, detail)

    def is_training(self) -> bool:
        for attr in ('_trainer', '_evaluator'):
            worker = getattr(self, attr, None)
            if worker is not None and worker.isRunning():
                return True
        return False

    def start_training(self, review: bool=True) -> bool:
        if self.is_training():
            self._hint('Training already. It is running in the background.')
            return False
        if self.reloading or (self.worker and self.worker.isRunning()):
            self._hint("Finish what you're saying first.")
            return False
        import practice as _practice
        clips = profile.clip_count(self.speaker) + _practice.clip_count(self.speaker)
        if clips < 20:
            self._hint('Not enough recordings yet — practice adds them.')
            return False
        size = self.model
        out = ROOT / 'models' / self.speaker / f'candidate-{size}'
        resume = any(out.glob('checkpoint-*'))
        struck: list[dict] = []
        if review:
            dlg = TrainReviewDialog(self)
            if dlg.exec() != QDialog.Accepted:
                return False
            struck = dlg.excluded()
        try:
            import adapt
            extra, n_extra = adapt.build_training_manifest(self.speaker, dest=ROOT / 'data' / self.speaker / 'training_extra.csv', exclude=struck, include_practice=True)
            karalog.get('gui').info('training material: %d extra clip(s), %d struck out', n_extra, len(struck))
        except Exception as e:
            karalog.get('gui').warning('could not build the extra manifest: %s', e)
            extra = None
        self._retire_thread(getattr(self, '_trainer', None))
        self._trainer = TrainWorker(self.speaker, size, out, epochs=6, resume=resume, extra_manifest=extra)
        self._trainer.progress.connect(self._training_progress)
        self._trainer.finished_ok.connect(self._training_done)
        self._trainer.failed.connect(self._training_failed)
        self._trainer.start()
        karalog.get('gui').info('training started: %s (%d clips, resume=%s)', size, clips, resume)
        for card in self._train_listeners():
            card.started()
        return True

    def stop_training(self):
        worker = getattr(self, '_trainer', None)
        if worker and worker.isRunning():
            worker.stop()

    def _train_listeners(self):
        out = []
        card = getattr(getattr(self, 'sidebar', None), 'train_card', None)
        if card is not None:
            out.append(card)
        return out

    def _training_progress(self, msg: dict):
        for card in self._train_listeners():
            card.progress(msg)

    def _training_done(self, out: str):
        karalog.get('gui').info('training finished -> %s', out)
        self._candidate = Path(out)
        for card in self._train_listeners():
            card.checking(t('Trained. Checking it is actually better…'))
        self._retire_thread(getattr(self, '_evaluator', None))
        self._evaluator = EvaluateWorker(self.speaker, self._candidate, self.model)
        self._evaluator.done.connect(self._evaluated)
        self._evaluator.failed.connect(self._evaluate_failed)
        self._evaluator.start()

    def _evaluated(self, result: dict):
        import modelstore
        cur = float(result.get('current_wer') or 0.0)
        cand = float(result.get('candidate_wer') or 0.0)
        karalog.get('gui').info('gate: current %.4f candidate %.4f deploy=%s', cur, cand, result.get('deploy'))
        if result.get('deploy'):
            ok = modelstore.promote(self.speaker, self.model, self._candidate, note='a training that beat the old model', wer=cand)
            msg = t('Better: %.1f%% → %.1f%% error. Kara will use it next time it starts.') % (cur * 100, cand * 100) if ok else t('It was better, but the new model could not be saved. Nothing has changed.')
        else:
            msg = t('No better: %.1f%% → %.1f%% error, so the old model is kept. Nothing was lost.') % (cur * 100, cand * 100)
        for card in self._train_listeners():
            card.finished(msg)
        self._say(msg)

    def _evaluate_failed(self, err: str):
        import modelstore
        karalog.get('gui').warning('could not score the new model: %s', err)
        ok = modelstore.promote(self.speaker, self.model, self._candidate, note='a training that could not be scored')
        msg = t('Trained, but Kara could not check whether it is better. It is in use — if it feels worse, go back a version in Settings ▸ Backup.') if ok else t('Training finished but the model could not be saved.')
        for card in self._train_listeners():
            card.finished(msg)
        self._say(msg)

    def _training_failed(self, err: str):
        karalog.get('gui').warning('training stopped: %s', err)
        msg = t('Paused. Everything trained so far is saved.') if err == 'paused' else t('Training stopped: %s') % (err,)
        for card in self._train_listeners():
            card.finished(msg)

    def _calibrated(self, report: dict):
        try:
            sps = {r['model']: float(r['sec_per_step']) for r in report.get('options') or [] if r.get('measured') and r.get('sec_per_step')}
        except (TypeError, ValueError):
            return
        if not sps:
            return
        try:
            cfg = config.load()
            cfg['sec_per_step'] = {**(cfg.get('sec_per_step') or {}), **sps}
            config.save(cfg)
            self.config = cfg
        except Exception as e:
            karalog.get('settings').warning('measured speeds not saved: %s', e)
            return
        karalog.get('settings').info('training speed measured for %d size(s)', len(sps))

    def _retire_thread(self, t):
        if t is None or not t.isRunning():
            return
        for stopper in ('stop', 'cancel'):
            if hasattr(t, stopper):
                try:
                    getattr(t, stopper)()
                except Exception:
                    pass
        zombies = self.__dict__.setdefault('_zombies', [])
        if t not in zombies:
            zombies.append(t)
            t.finished.connect(lambda t=t: self._forget_thread(t))

    def _forget_thread(self, t):
        z = self.__dict__.get('_zombies') or []
        if t in z:
            z.remove(t)

    def _loading(self) -> bool:
        return bool(self.reloading or (self.loader and self.loader.isRunning()))

    def _busy(self) -> bool:
        return self._loading() or self.recording or bool(self.worker and self.worker.isRunning())

    def _reload_pipe(self, note: str):
        self.reloading = True
        self._load_started = time.monotonic()
        karalog.get('gui').info('loading model=%s adapter=%s', self.model, Path(self.adapter).name if self.adapter else None)
        self.pipe_prev, self.pipe = (self.pipe, None)
        self.mic_btn.set_state('disabled')
        self._chip('Loading', 'starting')
        self._hint(note)
        if getattr(self, 'pipe_prev', None) is not None:
            self.pipe_prev.unload()
            self.pipe_prev = None
        self._retire_thread(getattr(self, 'loader', None))
        self.loader = ModelLoader(self.speaker, self.model, self.adapter)
        self.loader.done.connect(self._model_ready)
        self.loader.failed.connect(self._model_failed)
        self.loader.start()

    def switch_model(self, model: str):
        if model not in MODEL_OPTIONS or model == self.model:
            return
        if self._loading():
            self._hint('Still loading — try again in a moment.')
            return
        if self.recording or (self.worker and self.worker.isRunning()):
            self._hint('Finish the current utterance first, then switch.')
            return
        profile.set_active(self.speaker, model_size=model)
        self.config = config.load()
        self.model, self.adapter = (model, _adapter_for(model, self.speaker))
        self._reload_pipe(f"Loading the {MODEL_OPTIONS[model]['label'].split(' — ')[0]} model…")

    def can_switch_profile(self, name: str) -> tuple[bool, str]:
        if name == self.speaker:
            return (False, '')
        if self.recording:
            return (False, "Finish what you're saying first.")
        if self.worker and self.worker.isRunning():
            return (False, 'Wait for that sentence to finish.')
        if self._loading():
            return (True, '')
        return (True, '')

    def switch_profile(self, name: str) -> str:
        if name == self.speaker:
            return 'refused'
        if self.recording or (self.worker and self.worker.isRunning()):
            self._hint("Finish what you're doing, then switch profile.")
            return 'refused'
        if self._loading():
            self._pending_profile = name
            self._hint(t('Switching to %s when this finishes loading…') % (profile.display_name(name),))
            karalog.get('gui').info('profile switch queued behind a load')
            return 'queued'
        self._autosave()
        profile.set_active(name)
        self.speaker = name
        try:
            self.anchors = spelling.load_anchors(name)
        except (SystemExit, OSError, ValueError):
            self.anchors = {}
        self.doc_id = None
        self.ed = editing.Editor()
        theirs = library.list_docs(name)
        if theirs:
            self.doc_id = theirs[0]['id']
            self.ed = editing.Editor(library.read(name, self.doc_id))
        self._refresh()
        self._show_doc_title() if self.doc_id else self.doc_title.setText(t('YOUR TEXT'))
        self.sidebar.refresh()
        record.RECORDINGS, record.MANIFEST = record.speaker_paths(name)
        self.model = profile.model_size(name)
        if self.model not in MODEL_OPTIONS:
            self.model = DEFAULT_MODEL
        self.adapter = _adapter_for(self.model, name)
        self.refresh_identity()
        who = profile.display_name(name)
        self._reload_pipe(f'Switched to {who} — loading their voice model…')
        karalog.get('gui').info('switched profile; model=%s', self.model)
        self._tell_panels_profile_changed()
        return 'switched'

    def _tell_panels_profile_changed(self):
        for panel in self.findChildren(ProfilePanel):
            if not panel.isVisible():
                continue
            try:
                panel.profile_changed()
            except Exception as e:
                karalog.get('gui').warning('could not refresh a profile panel: %s', e)

    def _buffer_typed(self):
        if getattr(self, '_syncing', False):
            return
        self.ed.text = self.buffer.toPlainText()
        self._update_count()
        self._touch()

    def _touch(self):
        if hasattr(self, '_save_timer'):
            self._save_timer.start(1200)

    def word_count(self) -> int:
        return len(self.ed.text.split())

    def _update_count(self):
        n = self.word_count()
        self.count_lab.setText('' if n == 0 else t('1 word') if n == 1 else t('%s words') % (n,))
        self._update_tidy()

    def _update_tidy(self):
        timer = getattr(self, '_proof_timer', None)
        if timer is not None:
            timer.start(400)

    @property
    def proof(self):
        if self._proof is None:
            self._proof = proofing.Proofreader(self.speaker, language=self.config.get('language') or 'en')
        return self._proof

    def _paint_marks(self, marks) -> None:
        was = getattr(self, '_syncing', False)
        self._syncing = True
        try:
            self.highlighter.set_marks(marks, getattr(self, 'unsure', ()))
        finally:
            self._syncing = was

    @staticmethod
    def _merge_marks(base: list, extra: list) -> list:
        taken = [(m.start, m.end) for m in base]
        added = [m for m in extra if not any((m.start < b and a < m.end for a, b in taken))]
        if not added:
            return base
        return sorted(base + added, key=lambda m: (m.start, m.end))

    def _show_marks(self) -> None:
        spell, gram = proofing.counts(self.marks)
        n = len(self.marks)
        self.tidy_btn.setVisible(bool(n))
        if n:
            self.tidy_btn.setText(t('Grammar  %s') % (n,))
            self.tidy_btn.setToolTip(t('%s spelling · %s grammar — click to see them') % (spell, gram))
        if self.grammar_panel.isVisible():
            self.grammar_panel.refresh(self.marks)

    def _recheck(self):
        try:
            self.marks = self.proof._local(self.ed.text)
        except Exception as e:
            karalog.get('gui').warning('proofing failed: %s', e)
            self.marks = []
        cached = self._online_cache
        if cached and cached[0] == self.ed.text:
            self.marks = self._merge_marks(self.marks, cached[1])
        self._paint_marks(self.marks)
        self._online_check()
        self._show_marks()

    def _online_check(self):
        if self.offline:
            return
        text = self.ed.text
        if not text.strip():
            return
        if self._online_cache and self._online_cache[0] == text:
            return
        if time.monotonic() < self._online_cooldown:
            return
        if getattr(self, '_online_worker', None) is not None and self._online_worker.isRunning():
            return
        self._online_worker = OnlineGrammarWorker(text, self.config.get('grammar_service') or proofing.DEFAULT_SERVICE, language=_lt_language(self.config.get('language') or 'en'))
        self._online_worker.done.connect(self._online_marks)
        self._online_worker.start()

    def _online_marks(self, found: list, err: str, text: str):
        if text != self.ed.text:
            return
        if err:
            self._online_cooldown = time.monotonic() + ONLINE_RETRY_AFTER
            if err != getattr(self, '_last_proof_err', None):
                self._hint(t('%s — using the built-in checks') % (err,))
                karalog.get('gui').warning('online grammar: %s', err)
            self._last_proof_err = err
            return
        self._last_proof_err = None
        self._online_cache = (text, list(found))
        merged = self._merge_marks(self.marks, found)
        if merged is self.marks:
            return
        self.marks = merged
        self._paint_marks(self.marks)
        self._show_marks()

    def toggle_grammar(self):
        show = not self.grammar_panel.isVisible()
        self._slide_panel(self.grammar_panel, show)
        self.highlighter.set_highlight(show)
        if show:
            self._slide_panel(self.sidebar, False)
            self._recheck()

    def apply_mark(self, mark, replacement: str | None=None):
        new = replacement if replacement is not None else mark.fix
        if new is None:
            self._remove_mark(mark)
            return
        if not 0 <= mark.start <= mark.end <= len(self.ed.text):
            self._recheck()
            return
        self.ed._snapshot()
        self.ed.text = self.ed.text[:mark.start] + new + self.ed.text[mark.end:]
        karalog.get('gui').info('fixed %s: %s', mark.rule, karalog.words(new))
        self._refresh_now()
        self.wash_words([(mark.start, mark.start + len(new))])

    def _remove_mark(self, mark):
        text = self.ed.text
        if not 0 <= mark.start <= mark.end <= len(text):
            self._recheck()
            return
        a, b = (mark.start, mark.end)
        if b < len(text) and text[b] == ' ':
            b += 1
        elif a > 0 and text[a - 1] == ' ':
            a -= 1
        self.ed._snapshot()
        self.ed.text = text[:a] + text[b:]
        karalog.get('gui').info('removed %s', mark.rule)
        self._refresh_now()
        self._say(t('Removed “%s”. Say undo to put it back.') % (mark.word,))

    def _mark_unsure(self, words, at: int):
        try:
            import confidence
            cut = float(self.config.get('unsure_threshold', confidence.LOW) or confidence.LOW)
            spans = confidence.spans_for(self.ed.text, words, start=at, threshold=cut)
            self.unsure = confidence.to_marks(spans, proofing.UNSURE, text=self.ed.text, speaker=self.speaker)
            karalog.get('gui').info('confidence: %s', confidence.summarise(words, threshold=cut))
            self._paint_marks(self.marks)
        except Exception as e:
            karalog.get('gui').warning('confidence pass failed: %s', e)

    def _select_last_word(self):
        from PySide6.QtGui import QTextCursor
        cur = self.buffer.textCursor()
        cur.movePosition(QTextCursor.End)
        cur.movePosition(QTextCursor.PreviousWord, QTextCursor.KeepAnchor)
        self.buffer.setTextCursor(cur)
        self.buffer.setFocus()

    def _refresh_now(self):
        self._refresh()
        timer = getattr(self, '_proof_timer', None)
        if timer is not None:
            timer.stop()
        self._recheck()

    def _mark_at(self, pos: int):
        return next((m for m in self.marks if m.start <= pos <= m.end), None)

    def _buffer_menu(self, point):
        from PySide6.QtGui import QTextCursor
        from PySide6.QtWidgets import QMenu
        pos = self.buffer.viewport().mapFrom(self.buffer, point)
        cursor = self.buffer.cursorForPosition(pos)
        mark = self._mark_at(cursor.position())
        karalog.get('gui').info('right-click at char %d, %d marks, hit=%s', cursor.position(), len(self.marks), mark.word if mark else None)
        if mark is None:
            probe = QTextCursor(cursor)
            probe.select(QTextCursor.WordUnderCursor)
            a, b = (probe.selectionStart(), probe.selectionEnd())
            mark = next((m for m in self.marks if m.start < b and a < m.end), None)
        menu = QMenu(self)
        menu.setStyleSheet(f"\n            QMenu {{ background:{P['surface']}; color:{P['ink']};\n                     border:1px solid {P['line']}; padding:4px; }}\n            QMenu::item {{ padding:6px 18px; border-radius:6px; }}\n            QMenu::item:selected {{ background:{P['hover']}; }}\n            QMenu::separator {{ height:1px; background:{P['line']}; margin:4px 8px; }}\n        ")
        if mark is None:
            menu.addAction(t('Copy'), self.copy_text)
            menu.addAction(t('Undo'), self.undo)
            menu.exec(self.buffer.mapToGlobal(point))
            return
        if mark.suggestions:
            for s in mark.suggestions[:5]:
                menu.addAction(s, lambda _=False, m=mark, r=s: self.apply_mark(m, r))
            menu.addSeparator()
        elif mark.kind == proofing.GRAMMAR and mark.fix is not None:
            menu.addAction(t('Fix: %s') % (mark.message,), lambda _=False, m=mark: self.apply_mark(m))
            menu.addSeparator()
        if mark.kind == proofing.SPELLING:
            word = mark.word
            menu.addAction(t('Remove “%s”') % (word,), lambda _=False, m=mark: self._remove_mark(m))
            menu.addSeparator()
            menu.addAction(t('Add “%s” to my dictionary') % (word,), lambda _=False, w=word: self._teach_word(w, correct=True))
            menu.addAction(t('Ignore “%s”') % (word,), lambda _=False, w=word: self._teach_word(w, correct=False))
        menu.exec(self.buffer.mapToGlobal(point))

    def _teach_word(self, word: str, correct: bool):
        if correct:
            proofing.add_word(self.speaker, word)
            self._say(t('“%s” added to your dictionary.') % (word,))
        else:
            proofing.ignore_word(self.speaker, word)
            self._say(t('“%s” will be left alone.') % (word,))
        karalog.get('gui').info('dictionary: %s %r', 'added' if correct else 'ignored', word)
        self.proof.reload()
        self._recheck()
        if self.grammar_panel.isVisible():
            self.grammar_panel.refresh(self.marks)

    def tidy_up(self):
        import grammar
        vocab = getattr(getattr(self, 'pipe', None), 'vocab', None)
        fixed, n = grammar.fix_all(self.ed.text, vocab)
        if not n:
            self._say('Nothing to tidy up.')
            return
        self.ed._snapshot()
        self.ed.text = fixed
        karalog.get('gui').info('tidy up: %d fixes', n)
        self._refresh()
        self._say(t('Fixed 1 thing. Say undo to put it back.') if n == 1 else t('Fixed %s things. Say undo to put it back.') % (n,))

    def _mic_level(self) -> float:
        return self.mic.peak if self.mic and self.recording else 0.0

    def _close_loading(self):
        dlg = getattr(self, '_loading_dlg', None)
        if dlg is not None:
            dlg.close()
            self._loading_dlg = None

    def _model_ready(self, pipe):
        self.pipe = pipe
        self.reloading = False
        loaded = getattr(pipe, 'size', None)
        if loaded and loaded != self.model:
            karalog.get('gui').info('model fell back: %s -> %s', self.model, loaded)
            self.model = loaded
        started = getattr(self, '_load_started', None)
        karalog.get('gui').info('model ready: %s in %s', self.model, f'{time.monotonic() - started:.1f}s' if started else '?')
        self._close_loading()
        self.mic_btn.set_state('idle' if self.mic is not None else 'disabled')
        self._chip('Ready', 'ready')
        self._hint('')
        pending = getattr(self, '_pending_profile', None)
        if pending and pending != self.speaker:
            self._pending_profile = None
            karalog.get('gui').info('applying the queued profile switch')
            QTimer.singleShot(0, lambda n=pending: self.switch_profile(n))
            return
        self._pending_profile = None
        QTimer.singleShot(0, self._settle_update)
        QTimer.singleShot(1500, self._maybe_offer_retrain)
        QTimer.singleShot(8000, self._maybe_check_update)
        QTimer.singleShot(20000, self._maybe_remind_training)

    def warn_beta_once(self, feature: str) -> None:
        if self.config.get('beta_warned'):
            return
        name = BETA_FEATURES.get(feature, feature)
        self.config['beta_warned'] = True
        try:
            config.save(self.config)
        except Exception:
            pass
        karalog.get('gui').info('beta warning shown for %s', feature)
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Information)
        box.setWindowTitle(t('This part is still in beta'))
        box.setText(t('You have turned on %s.') % (t(name),))
        box.setInformativeText(t('Beta means it works but is not finished, and it may not behave the way the rest of Kara does. Anything marked BETA is safe to try and safe to turn off again — your writing, recordings and voice model are never affected by it.\n\nYou will not be shown this again.'))
        box.addButton(t('Got it'), QMessageBox.AcceptRole)
        box.exec()

    def _settle_update(self):
        try:
            import updates
            if updates.PREVIOUS.is_dir():
                updates.settled()
                karalog.get('update').info('this build started cleanly; previous version released')
        except Exception as e:
            karalog.get('update').warning('could not release previous: %s', e)

    def _maybe_check_update(self):
        if getattr(self, '_closing', False) or self.reloading:
            return
        if not self.config.get('update_check', True):
            return
        if not (self.config.get('update_source') or ''):
            return
        if self.recording:
            QTimer.singleShot(120000, self._maybe_check_update)
            return
        import threading

        def work():
            try:
                import updates
                info = updates.available(VERSION, self.config.get('update_source') or None)
            except Exception as e:
                info = {'ok': False, 'why': type(e).__name__, 'newer': False}
            self._update_seen.emit(info)
        threading.Thread(target=work, daemon=True, name='kara-update-check').start()

    def _update_found(self, info: dict):
        if not info.get('ok'):
            karalog.get('update').info('check: %s', info.get('why') or 'failed')
            return
        version = str(info.get('version') or '')
        if not info.get('newer'):
            karalog.get('update').info('check: up to date (published %s)', version or '?')
            return
        if self.config.get('update_offered') == version:
            return
        if getattr(self, '_closing', False) or self.recording:
            QTimer.singleShot(120000, lambda: self._update_found(info))
            return
        self.config['update_offered'] = version
        try:
            config.save(self.config)
        except Exception:
            pass
        karalog.get('update').info('offering %s', version)
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Question)
        box.setWindowTitle(t('A newer Kara is available'))
        box.setText(t('Kara %s is ready to install.') % (version,))
        box.setInformativeText(t('Your writing, recordings and settings are not touched. Kara will close and reopen once, and if the new version does not start, the old one is put back automatically.'))
        go = box.addButton(t('Install it'), QMessageBox.AcceptRole)
        box.addButton(t('Not now'), QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is not go:
            self._hint(t('Left it for now — you can install it from Settings.'))
            return
        self._install_update_now(info.get('url') or '', version)

    def _install_update_now(self, url: str, version: str):
        if not url:
            self._hint(t('That update did not say where to download it from.'))
            return
        self._hint(t('Installing Kara %s…') % (version,))
        import threading

        def work():
            try:
                import updates
                ok, why = updates.install(url)
            except Exception as e:
                ok, why = (False, type(e).__name__)
            self._update_ready.emit(ok, why)
        threading.Thread(target=work, daemon=True, name='kara-install').start()

    def _update_installed(self, ok: bool, why: str):
        if not ok:
            self._hint(t('Could not install it (%s). Nothing has changed.') % (why,))
            karalog.get('update').warning('install failed: %s', why)
            return
        self._hint(t('Installed. Kara is restarting…'))
        karalog.get('update').info('installed from the prompt; restarting')
        QTimer.singleShot(900, self.restart)

    def _maybe_offer_retrain(self):
        if getattr(self, '_closing', False) or self.reloading:
            return
        try:
            import adapt
            s = adapt.retrain_suggestion(self.speaker)
        except Exception:
            return
        if not s['enough']:
            return
        if self.config.get('retrain_offered_at') == s['pairs']:
            return
        self.config['retrain_offered_at'] = s['pairs']
        try:
            config.save(self.config)
        except Exception:
            pass
        karalog.get('gui').info('offered retrain: %d pairs', s['pairs'])
        self._hint(t('%s corrections are ready to train on — Settings ▸ Voice model.') % (s['pairs'],))

    def _maybe_remind_training(self):
        if getattr(self, '_closing', False) or self.reloading or self.recording:
            return
        if self.is_training():
            return
        days = int(self.config.get('train_reminder_days', 7) or 0)
        if days <= 0:
            return
        last = float(self.config.get('train_reminded_at') or 0.0)
        now = time.time()
        if last and now - last < days * 86400:
            return
        try:
            import practice as _practice
            clips = profile.clip_count(self.speaker) + _practice.clip_count(self.speaker)
        except Exception:
            return
        if clips < 20:
            return
        self.config['train_reminded_at'] = now
        try:
            config.save(self.config)
        except Exception:
            pass
        karalog.get('gui').info('training reminder shown (%d day interval)', days)
        self._hint(t('It has been a while since Kara last learned from you — Train is at the bottom of your writing list.'))

    def _model_failed(self, err: str):
        self._close_loading()
        self.reloading = False
        self._chip('Model failed', 'error')
        order = ['small', 'medium', 'large-v3']
        smaller = [m for m in order if order.index(m) < order.index(self.model)] if self.model in order else []
        fallback = smaller[-1] if smaller else None
        info = errors.classify(err, default='KARA-2004')
        karalog.get('gui').error('model load failed [%s] model=%s: %s', info.code, self.model, err)
        dlg = ModelFailureDialog(self, info.say, str(err), self.model, fallback, fix=info.fix, code=info.code)
        choice = dlg.ask()
        if choice == 'retry':
            self._loading_dialog(f'Loading the {self.model} model…')
            self._reload_pipe(f'Loading the {self.model} model…')
        elif choice == 'fallback' and fallback:
            self.model = fallback
            self.adapter = _adapter_for(fallback, self.speaker)
            profile.set_active(self.speaker, model_size=fallback)
            self._loading_dialog(f'Loading the {fallback} model…')
            self._reload_pipe(f'Loading the {fallback} model…')
        else:
            self._hint('No recogniser — you can still type, or retry from Settings.')

    def _loading_dialog(self, note: str):
        dlg = QDialog(self)
        dlg.setWindowTitle(t('Loading'))
        dlg.setModal(True)
        dlg.setFixedWidth(360)
        dlg.setStyleSheet(f"\n            QDialog {{ background:{P['canvas']}; }}\n            QLabel {{ color:{P['ink']}; font-family:{SANS_STACK}; font-size:14px; }}\n            QLabel#Sub {{ color:{P['ink_soft']}; font-size:12px; }}\n            QProgressBar {{ background:{P['line']}; border:none; border-radius:3px; }}\n            QProgressBar::chunk {{ background:{P['beige']}; border-radius:3px; }}\n        ")
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(24, 22, 24, 20)
        lay.setSpacing(12)
        top = QHBoxLayout()
        top.setSpacing(12)
        top.addWidget(Mark(28, colour=P['beige'], void=P['canvas']))
        lbl = QLabel(note)
        lbl.setWordWrap(True)
        top.addWidget(lbl, 1)
        lay.addLayout(top)
        bar = QProgressBar()
        bar.setRange(0, 0)
        bar.setTextVisible(False)
        bar.setFixedHeight(6)
        lay.addWidget(bar)
        sub = QLabel(t('This takes about half a minute the first time.'))
        sub.setObjectName('Sub')
        sub.setWordWrap(True)
        lay.addWidget(sub)
        self._loading_dlg = dlg
        dlg.show()

    def _track_target(self):
        if self.target_hwnd and (not appmod.window_is_alive(self.target_hwnd)):
            again = self._find_titled_window(self.target_title)
            if again:
                karalog.get('gui').info('target %r reopened; re-acquired', self.target_title)
                self.target_hwnd = again
            else:
                karalog.get('gui').info('target %r closed; forgetting it', self.target_title)
                self.target_hwnd, self.target_title = (0, '')
                self.target.setText('')
        u = ctypes.windll.user32
        hwnd = u.GetForegroundWindow()
        if not hwnd or hwnd == int(self.winId()):
            return
        length = u.GetWindowTextLengthW(hwnd)
        if not length:
            return
        buf = ctypes.create_unicode_buffer(length + 1)
        u.GetWindowTextW(hwnd, buf, length + 1)
        title = buf.value.strip()
        if not title or title == APP_NAME:
            return
        if not self._accepts_text(hwnd):
            return
        self.target_hwnd, self.target_title = (hwnd, title)
        verb = 'Types into' if self._typing_straight_in() else 'Sends to'
        self.target.setText(f'{verb}  ·  {title}')

    def _watch_tick(self):
        self._set_aurora(self.recording)
        self._track_target()

    def _hint_text(self) -> str:
        try:
            return self.status.text()
        except Exception:
            return ''

    def _accepts_text(self, hwnd: int) -> bool:
        try:
            import psutil
            pid = ctypes.c_ulong()
            ctypes.windll.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            if not pid.value:
                return False
            name = psutil.Process(pid.value).name().lower()
        except Exception:
            return False
        extra = {str(a).lower() for a in self.config.get('extra_text_apps') or []}
        if name in TEXT_APPS or name in extra:
            return True
        skipped = getattr(self, '_skipped_apps', None)
        if skipped is None:
            skipped = self._skipped_apps = set()
        if name not in skipped:
            skipped.add(name)
            karalog.get('gui').info("not a known text app, so 'send' will not target it: %s (add it to extra_text_apps if it takes typed text)", name)
        return False

    def _find_titled_window(self, title: str) -> int:
        if not title:
            return 0
        from ctypes import wintypes
        u = ctypes.windll.user32
        found = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def visit(h, _):
            if not u.IsWindowVisible(h):
                return True
            n = u.GetWindowTextLengthW(h)
            if not n:
                return True
            b = ctypes.create_unicode_buffer(n + 1)
            u.GetWindowTextW(h, b, n + 1)
            if b.value.strip() == title and self._accepts_text(h):
                found.append(h)
                return False
            return True
        u.EnumWindows(visit, 0)
        return found[0] if found else 0

    def _tick_meter(self):
        if not (self.recording and self.mic):
            return
        quiet = self.mic.silent_for()
        if quiet >= SILENCE_TIMEOUT:
            self._auto_stopped = True
            self.toggle_record()
            return
        if quiet >= SILENCE_TIMEOUT - 5:
            self._hint(t('Still listening — stopping in %ss') % (int(SILENCE_TIMEOUT - quiet) + 1,))
            return
        if self.mic.peak >= record.CLIP_LEVEL:
            self._clipping_since = getattr(self, '_clipping_since', None) or time.monotonic()
            self._hint('TOO LOUD — move back from the microphone')
            return
        if getattr(self, '_clipping_since', None) and time.monotonic() - self._clipping_since < 2.0:
            self._hint('TOO LOUD — move back from the microphone')
            return
        self._clipping_since = None
        advice = record.level_advice(self.mic.peak)
        if advice:
            self._hint(advice)

    def toggle_record(self):
        if not (self.pipe and self.mic):
            return
        if not self.recording:
            self.recording = True
            self.mic_btn.set_state('listening')
            self._chip('Listening', 'listening')
            self._hint('Listening — tap again when you finish.')
            self.mic.start()
            self._set_aurora(True)
            return
        self.recording = False
        self.mic_btn.set_state('idle')
        self._set_aurora(False)
        audio = self.mic.stop()
        auto = getattr(self, '_auto_stopped', False)
        self._auto_stopped = False
        if audio.size < record.SAMPLE_RATE // 4:
            self._chip('Ready', 'ready')
            self._hint("I didn't hear anything. Try again.")
            return
        severity, message = record.quality_check(audio)
        if severity == 'fatal':
            self._chip('Ready', 'ready')
            self._hint(t('%s — try that again.') % (message,))
            karalog.get('gui').info('utterance refused: %s', message)
            self._warn_mini(message)
            return
        self._clip_warning = message if severity == 'warn' else None
        if self._clip_warning:
            karalog.get('gui').warning('degraded audio, transcribing anyway: %s', message)
        if auto:
            self._hint(t('Stopped after %ss of quiet — working on what I heard.') % (SILENCE_TIMEOUT,))
        self._chip('Thinking', 'thinking')
        self.mic_btn.set_state('thinking')
        self.worker = Transcriber(self.pipe, self.ed, self.anchors, self.speaker, audio, self.current_mode(), self.pending, keep_audio=bool(self.config.get('keep_utterances')), direct=self._typing_straight_in())
        self.worker.done.connect(self._utterance_done)
        self.worker.failed.connect(self._utterance_failed)
        self.worker.start()

    def _typing_straight_in(self) -> bool:
        return getattr(self, '_mini', None) is not None and (not self.isVisible())

    def _type_into_target(self, text: str) -> bool:
        if not self.target_hwnd:
            return False
        lead = '' if not text or text[0] in ' \n\t' else ' '
        result = appmod.inject_text(lead + text, hwnd=self.target_hwnd)
        karalog.get('gui').info('typed %s into %r -> ok=%s %s', karalog.words(text), self.target_title, result['ok'], result['reason'])
        if not result['ok'] and result.get('gone'):
            self.target_hwnd, self.target_title = (0, '')
            self.target.setText('')
        return bool(result['ok'])

    def _utterance_done(self, out: dict):
        self.mic_btn.set_state('idle')
        if out.get('probs'):
            self._mark_unsure(out['probs'], out.get('at', 0))
        if out.get('probs') and self.say_panel.isVisible():
            self.say_panel.refresh()
        if out.get('select_last'):
            self._select_last_word()
        if 'keystroke' in out:
            cmd = out['keystroke']
            vk, mods = appmod.KEYSTROKES[cmd]
            r = appmod.press_keys(self.target_hwnd or None, vk, mods)
            karalog.get('gui').info('keystroke %s -> %r ok=%s', cmd, self.target_title, r['ok'])
            if r['ok']:
                self._chip('Ready', 'ready')
                self._hint(_KEYSTROKE_SAID.get(cmd, 'done'))
            else:
                if r.get('gone'):
                    self.target_hwnd, self.target_title = (0, '')
                    self.target.setText('')
                self._chip('Ready', 'ready')
                self._hint('Could not reach that window.')
            return
        if 'direct' in out:
            text = out['direct']
            if self._type_into_target(text):
                self._chip('Ready', 'ready')
                self._hint(t('Typed into %s') % (self.target_title,) if self.target_title else t('Typed it in.'))
            else:
                self.ed.dictate(text)
                self._refresh()
                self._chip('Ready', 'ready')
                self._hint('Could not type there — kept it on your page.')
            return
        if self._rescue and (not out.get('rescue')):
            self._clear_rescue()
        if out.get('rescue'):
            self._offer_rescue(out['heard'], out['rescue'])
            self._chip('Ready', 'ready')
            return
        if out.get('choices'):
            self.pending = out['choices']
            self._highlight(self.pending['choices'])
            self._say(out['say'])
            self._chip('Ready', 'ready')
            return
        if out.get('clear_pending'):
            self.pending = None
            self._highlight([])
        if out.get('read_aloud'):
            self.read_aloud()
        elif out.get('switch_mode'):
            self._set_mode(out['switch_mode'])
        elif out.get('send'):
            self.send_now()
        elif out.get('quiet'):
            self._hint(getattr(self, '_clip_warning', '') or '')
        else:
            warn = getattr(self, '_clip_warning', '')
            self._say(f"{out['say']}  ({warn})" if warn else out['say'])
        self._clip_warning = None
        self._refresh()
        self._chip('Ready', 'ready')

    def _utterance_failed(self, err: str):
        self.mic_btn.set_state('idle')
        self._chip('Ready', 'ready')
        low = err.lower()
        if 'mel input features' in low or 'long-form' in low:
            friendly = 'That recording was very long. Try again in shorter pieces.'
            code = ''
        else:
            info = errors.classify(err, default='KARA-2005')
            friendly = f'{info.say} {info.fix}'
            code = info.code
        karalog.get('gui').error('utterance failed [%s]: %s', code or '-', err)
        self._hint(f'{friendly}  ({code})' if code else friendly)

    def send_now(self):
        if not self.ed.text.strip():
            self._say('There is nothing to send yet.')
            return
        if not self.target_hwnd:
            info = errors.look_up('KARA-6001')
            self._say(f'{info.fix}  ({info.code})')
            return
        result = appmod.inject_text(self.ed.text, hwnd=self.target_hwnd)
        karalog.get('gui').info('send %s to %r -> ok=%s focused=%s %s', karalog.words(self.ed.text), self.target_title, result['ok'], result['focused'], result['reason'])
        if not result['ok']:
            if result.get('gone'):
                info = errors.look_up('KARA-6004')
                self.target_hwnd, self.target_title = (0, '')
                self.target.setText('')
            else:
                info = errors.look_up('KARA-6003' if not result['on_clipboard'] else 'KARA-6002')
            self._chip('Not sent', 'error')
            self._say(f'{info.say} {info.fix}  ({info.code})')
            return
        self._harvest('send')
        self._chip('Sent', 'sent')
        self._fly_away()
        self._say(t('Sent to %s') % (self.target_title,))

    def _fly_away(self):
        ms = motion_ms(620)
        if not ms:
            return
        try:
            from PySide6.QtCore import QEasingCurve, QPoint, QPropertyAnimation, QParallelAnimationGroup
            from PySide6.QtWidgets import QGraphicsOpacityEffect, QLabel
            src = self.buffer
            if not src.isVisible() or src.width() < 8:
                return
            shot = src.grab()
            ghost = QLabel(self)
            ghost.setPixmap(shot)
            ghost.setAttribute(Qt.WA_TransparentForMouseEvents)
            ghost.setGeometry(src.geometry().translated(src.parentWidget().mapTo(self, QPoint(0, 0))))
            fade = QGraphicsOpacityEffect(ghost)
            ghost.setGraphicsEffect(fade)
            ghost.show()
            ghost.raise_()
            group = QParallelAnimationGroup(self)
            rise = QPropertyAnimation(ghost, b'pos', group)
            rise.setDuration(ms)
            rise.setEasingCurve(QEasingCurve.InCubic)
            rise.setStartValue(ghost.pos())
            rise.setEndValue(ghost.pos() + QPoint(0, -34))
            out = QPropertyAnimation(fade, b'opacity', group)
            out.setDuration(ms)
            out.setEasingCurve(QEasingCurve.InCubic)
            out.setStartValue(1.0)
            out.setEndValue(0.0)
            group.addAnimation(rise)
            group.addAnimation(out)
            group.finished.connect(ghost.deleteLater)
            self._fly = group
            group.start()
        except Exception as e:
            karalog.get('gui').debug('send animation skipped: %s', e)

    def _more_menu(self):
        from PySide6.QtWidgets import QMenu
        menu = QMenu(self)
        menu.setStyleSheet(f"\n            QMenu {{ background:{P['surface']}; color:{P['ink']};\n                     border:1px solid {P['line']}; border-radius:10px; padding:6px; }}\n            QMenu::item {{ padding:9px 16px; border-radius:6px;\n                           font-size:14px; }}\n            QMenu::item:selected {{ background:{P['hover']}; }}\n            QMenu::item:disabled {{ color:{P['disabled_fg']}; }}\n            QMenu::separator {{ height:1px; background:{P['line']}; margin:5px 8px; }}\n        ")
        where = self.target_title or 'your document'
        send = menu.addAction(t('Send to %s') % (_short(where, 34),))
        send.setEnabled(bool(self.ed.text.strip()))
        send.triggered.connect(self.send_now)
        menu.addSeparator()
        live = menu.addAction(t('Correction  ·  BETA'), self.toggle_say_panel)
        live.setCheckable(True)
        live.setChecked(self.say_panel.isVisible())
        clips = self._clip_count()
        if clips < TIER_SOLID:
            menu.addSeparator()
            more = menu.addAction(t('Train more  ·  %s of %s clips') % (clips, TIER_SOLID), self._open_startup)
            more.setToolTip(t('Record another sitting so Kara hears more of your voice.'))
        pos = self.more_btn.mapToGlobal(self.more_btn.rect().topRight())
        menu.exec(pos - QPoint(menu.sizeHint().width(), 0))

    def undo(self):
        self._say('Undone.' if self.ed.undo() else 'Nothing to undo.')
        self._refresh()

    def redo(self):
        self._say('Redone.' if self.ed.redo() else 'Nothing to redo.')
        self._refresh()

    def clear(self):
        words = len(self.ed.text.split())
        if words >= 5:
            box = QMessageBox(self)
            box.setIcon(QMessageBox.Warning)
            box.setWindowTitle(t('Clear the page?'))
            box.setText(t('This deletes all %s words.') % (words,))
            box.addButton(t('Keep it'), QMessageBox.RejectRole)
            wipe = box.addButton(t('Clear the page'), QMessageBox.DestructiveRole)
            box.setDefaultButton(box.buttons()[0])
            box.exec()
            if box.clickedButton() is not wipe:
                return
        self.ed.clear()
        self._refresh()
        self._say('Cleared.')

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Space and (not e.isAutoRepeat()):
            self._space_down = time.monotonic()
            self._space_started = not self.recording
            self.toggle_record()
        elif e.key() == Qt.Key_Right and (not e.isAutoRepeat()):
            self.cycle_mode()
        else:
            super().keyPressEvent(e)
    HOLD_MS = 0.35

    def keyReleaseEvent(self, e):
        if e.key() == Qt.Key_Space and (not e.isAutoRepeat()):
            down = getattr(self, '_space_down', None)
            self._space_down = None
            if down is not None and self.recording and getattr(self, '_space_started', False) and (time.monotonic() - down >= self.HOLD_MS):
                self.toggle_record()
            return
        super().keyReleaseEvent(e)

    def closeEvent(self, e):
        self._closing = True
        self._watch.stop()
        self._meter.stop()
        self._auto_timer.stop()
        extra = getattr(self, '_mini', None)
        if extra is not None:
            extra.close()
        if self.recording and self.mic:
            self.mic.stop()
        r = getattr(self, '_reader', None)
        if r is not None and r.isRunning():
            r.stop()
            r.wait(8000)
        if hasattr(self, '_save_timer'):
            self._save_timer.stop()
        try:
            self._autosave()
        except Exception:
            pass
        self._harvest('close')
        self.stop_training()
        self.hide()
        for t in [self.worker, self.loader, self.__dict__.get('_trainer'), self.__dict__.get('_evaluator'), self.__dict__.get('_online_worker'), self.__dict__.get('_auto_backup')] + list(self.__dict__.get('_zombies') or []):
            if t is not None and t.isRunning():
                t.wait(60000)
        e.accept()
        if getattr(self, '_restart_on_exit', False):
            self._relaunch()

def _crash(exc: BaseException) -> None:
    path = karalog.record_crash(exc, 'startup')
    info = errors.classify(exc)
    try:
        from PySide6.QtWidgets import QApplication, QMessageBox
        if QApplication.instance() is None:
            QApplication([])
        QMessageBox.critical(None, f'{APP_NAME} could not start', f"{info.message(f'{type(exc).__name__}: {exc}')}\n\nWritten down in:\n{path}")
    except Exception:
        pass

def _theme_titlebar(widget) -> None:
    try:
        import ctypes
        hwnd = int(widget.winId())
        dwm = ctypes.windll.dwmapi

        def colorref(hex_colour: str) -> int:
            h = hex_colour.lstrip('#')
            r, g, b = (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
            return b << 16 | g << 8 | r
        DWMWA_USE_IMMERSIVE_DARK_MODE = 20
        DWMWA_BORDER_COLOR = 34
        DWMWA_CAPTION_COLOR = 35
        DWMWA_TEXT_COLOR = 36

        def attr(which: int, value: int) -> None:
            v = ctypes.c_int(value)
            dwm.DwmSetWindowAttribute(ctypes.c_void_p(hwnd), ctypes.c_int(which), ctypes.byref(v), ctypes.sizeof(v))
        import contrast
        dark_caption = contrast.luminance(P['canvas']) < 0.4
        attr(DWMWA_USE_IMMERSIVE_DARK_MODE, 1 if dark_caption else 0)
        attr(DWMWA_CAPTION_COLOR, colorref(P['canvas']))
        attr(DWMWA_BORDER_COLOR, colorref(P['line']))
        attr(DWMWA_TEXT_COLOR, colorref(P['canvas']))
    except Exception as e:
        karalog.get('gui').info('could not theme the title bar: %s', e)
_INSTANCE_MUTEX = None
RESTART_FLAG = '--restarted'

def _release_single_instance() -> None:
    global _INSTANCE_MUTEX
    if not _INSTANCE_MUTEX:
        return
    try:
        k32 = ctypes.WinDLL('kernel32', use_last_error=True)
        k32.CloseHandle.argtypes = [ctypes.c_void_p]
        k32.CloseHandle(_INSTANCE_MUTEX)
    except Exception as e:
        karalog.get('gui').warning('could not release the instance lock: %s', e)
    finally:
        _INSTANCE_MUTEX = None

def _claim_single_instance(wait_s: float=0.0) -> bool:
    global _INSTANCE_MUTEX
    ERROR_ALREADY_EXISTS = 183
    deadline = time.monotonic() + max(0.0, wait_s)
    while True:
        got = _try_claim()
        if got or time.monotonic() >= deadline:
            return got
        time.sleep(0.25)

def _try_claim() -> bool:
    global _INSTANCE_MUTEX
    ERROR_ALREADY_EXISTS = 183
    try:
        k32 = ctypes.WinDLL('kernel32', use_last_error=True)
        k32.CreateMutexW.argtypes = [ctypes.c_void_p, ctypes.c_bool, ctypes.c_wchar_p]
        k32.CreateMutexW.restype = ctypes.c_void_p
        k32.CloseHandle.argtypes = [ctypes.c_void_p]
        handle = k32.CreateMutexW(None, False, 'Local\\Kara.VoiceToText.Desktop.1')
        if not handle:
            return True
        if ctypes.get_last_error() == ERROR_ALREADY_EXISTS:
            k32.CloseHandle(handle)
            return False
        _INSTANCE_MUTEX = handle
        return True
    except Exception:
        return True

def _wake_running_kara() -> bool:
    try:
        u = ctypes.windll.user32
        found = []

        @ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)
        def visit(hwnd, _lparam):
            length = u.GetWindowTextLengthW(hwnd)
            if not length:
                return True
            buf = ctypes.create_unicode_buffer(length + 1)
            u.GetWindowTextW(hwnd, buf, length + 1)
            if buf.value.strip() == APP_NAME:
                pid = ctypes.c_ulong()
                u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
                if pid.value != os.getpid():
                    found.append((bool(u.IsWindowVisible(hwnd)), hwnd))
            return True
        u.EnumWindows(visit, 0)
        if not found:
            return False
        found.sort(key=lambda x: not x[0])
        hwnd = found[0][1]
        u.ShowWindow(hwnd, 9)
        u.SetForegroundWindow(hwnd)
        return True
    except Exception:
        return False

def _load_fonts() -> None:
    from PySide6.QtGui import QFontDatabase
    for path in sorted(ROOT.glob('assets/*.otf')) + sorted(ROOT.glob('assets/*.ttf')):
        fid = QFontDatabase.addApplicationFont(str(path))
        if fid < 0:
            continue
        for fam in QFontDatabase.applicationFontFamilies(fid):
            if fam not in DISPLAY_STACK:
                DISPLAY_STACK.insert(0, fam)

def main() -> None:
    p = argparse.ArgumentParser(description='Kara desktop app.')
    p.add_argument('--speaker', default=None)
    p.add_argument('--pick', action='store_true', help='always show the profile picker')
    p.add_argument('--model', default=DEFAULT_MODEL)
    p.add_argument('--adapter', default=str(DEFAULT_ADAPTER))
    p.add_argument('--speak', dest='speak', action='store_true', help='speak every status line aloud')
    p.add_argument(RESTART_FLAG, dest='restarted', action='store_true', help=argparse.SUPPRESS)
    p.add_argument('--setup', action='store_true', help='open straight into the voice-setup wizard (no model load)')
    args = p.parse_args()
    karalog.setup()
    karalog.install_excepthook()
    log = karalog.get('gui')
    try:
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID('Kara.VoiceToText.Desktop.1')
    except Exception:
        pass
    if not _claim_single_instance(wait_s=6.0 if RESTART_FLAG in sys.argv else 0.0):
        if _wake_running_kara():
            log.info('another Kara is already running; brought it forward')
        else:
            log.info('another Kara is already running; could not find its window')
        return 0
    try:
        qt = QApplication(sys.argv)
        karalog.install_qt_handler()
        _load_fonts()
        qt.setWindowIcon(icons.mark_icon(colour=P['beige'], void=P['canvas']))
        font = QFont()
        font.setFamilies(['Segoe UI Variable Text', 'Segoe UI', 'Roboto', 'Arial'])
        font.setPointSize(10)
        qt.setFont(font)
        speaker = args.speaker or (None if args.pick else profile.active())
        if not speaker:
            speaker = ProfilePicker.choose()
            if not speaker:
                return
        profile.create(speaker)
        profile.set_active(speaker)
        try:
            import datetime as _dt
            stamp = _dt.datetime.fromtimestamp(Path(__file__).stat().st_mtime).strftime('%Y-%m-%d %H:%M:%S')
            log.info('build: v%s, gui.py last modified %s', VERSION, stamp)
        except OSError:
            pass
        log.info('profile=%s model=%s clips=%d trained=%s', speaker, args.model, profile.clip_count(speaker), profile.is_trained(speaker))
        w = Window(speaker, args.model, args.adapter, args.speak, setup_only=args.setup)
        w.show()
        _theme_titlebar(w)
        sys.exit(qt.exec())
    except SystemExit:
        raise
    except BaseException as e:
        _crash(e)
        sys.exit(1)
if __name__ == '__main__':
    main()
