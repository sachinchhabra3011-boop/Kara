from __future__ import annotations
import argparse
import shutil
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
MODELS = ROOT / 'models'
DEFAULT_COMPUTE = 'int8'
BASE_SPEAKER = '_base'
BASE_REPO = 'Systran/faster-whisper-%s'
SIZE_ORDER = ('small', 'medium', 'large-v3')

def ct2_dir(speaker: str, size: str) -> Path:
    return MODELS / 'ct2' / f'{speaker}-{size}'

def base_dir(size: str) -> Path:
    return ct2_dir(BASE_SPEAKER, size)

def is_converted(speaker: str, size: str) -> bool:
    d = ct2_dir(speaker, size)
    return (d / 'model.bin').exists()

def resolve(speaker: str, size: str) -> tuple[Path, str, bool] | None:
    order = (size, *(s for s in SIZE_ORDER if s != size))
    for personal in (True, False):
        for s in order:
            d = ct2_dir(speaker, s) if personal else base_dir(s)
            if (d / 'model.bin').exists():
                return (d, s, personal)
    return None

def available(speaker: str, size: str) -> bool:
    return resolve(speaker, size) is not None

def fetch_base(size: str, force: bool=False) -> Path:
    out = base_dir(size)
    if (out / 'model.bin').exists() and (not force):
        print(f'already present: {out}')
        return out
    from huggingface_hub import snapshot_download
    repo = BASE_REPO % size
    print(f'downloading {repo} ...')
    out.parent.mkdir(parents=True, exist_ok=True)
    snapshot_download(repo_id=repo, local_dir=str(out))
    if not (out / 'model.bin').exists():
        raise RuntimeError(f'{repo} downloaded but there is no model.bin in {out}. Nothing has been installed; delete that folder and try again.')
    size_mb = sum((f.stat().st_size for f in out.rglob('*') if f.is_file())) / 1000000.0
    print(f'done: {out}  ({size_mb:.0f} MB)')
    return out

def convert(speaker: str, size: str, adapter: str | None, compute: str=DEFAULT_COMPUTE, force: bool=False) -> Path:
    out = ct2_dir(speaker, size)
    if out.exists() and (not force):
        if (out / 'model.bin').exists():
            print(f'already converted: {out}')
            return out
        shutil.rmtree(out, ignore_errors=True)
    import torch
    from transformers import WhisperForConditionalGeneration, WhisperProcessor
    merged_dir = MODELS / 'ct2' / f'_merge_{speaker}_{size}'
    shutil.rmtree(merged_dir, ignore_errors=True)
    merged_dir.mkdir(parents=True, exist_ok=True)
    print(f'loading base openai/whisper-{size} ...')
    model = WhisperForConditionalGeneration.from_pretrained(f'openai/whisper-{size}', dtype=torch.float32)
    processor = WhisperProcessor.from_pretrained(f'openai/whisper-{size}')
    if adapter:
        print(f'merging adapter {adapter} ...')
        from peft import PeftModel
        model = PeftModel.from_pretrained(model, adapter).merge_and_unload()
        try:
            processor = WhisperProcessor.from_pretrained(adapter)
        except Exception:
            pass
    else:
        print('no adapter -- converting the generic base model')
    model.save_pretrained(merged_dir)
    processor.save_pretrained(merged_dir)
    del model
    import gc
    gc.collect()
    print(f'converting to CTranslate2 ({compute}) ...')
    from ctranslate2.converters import TransformersConverter
    TransformersConverter(str(merged_dir)).convert(str(out), quantization=compute, force=True)
    for name in ('tokenizer.json', 'preprocessor_config.json', 'vocabulary.json'):
        src = merged_dir / name
        if src.exists():
            shutil.copy2(src, out / name)
    shutil.rmtree(merged_dir, ignore_errors=True)
    size_mb = sum((f.stat().st_size for f in out.rglob('*'))) / 1000000.0
    print(f'done: {out}  ({size_mb:.0f} MB)')
    return out

class CPUEngine:

    def __init__(self, speaker: str, size: str, compute: str=DEFAULT_COMPUTE, threads: int=0, correct: bool=True):
        from faster_whisper import WhisperModel
        import corrector
        got = resolve(speaker, size)
        if got is None:
            raise FileNotFoundError(f'no CPU model for {speaker}/{size} and no generic one either, so nothing has been prepared for this computer. Either:\n  python src\\cpu_engine.py --fetch-base --model {size}\n  python src\\cpu_engine.py --convert --speaker {speaker} --model {size}')
        d, self.size, self.personal = got
        self.model = WhisperModel(str(d), device='cpu', compute_type=compute, cpu_threads=threads or 0)
        self.correct = correct
        self.vocab = corrector.load_vocab(speaker) if correct else None

    def _transcribe(self, wav: str, words: bool):
        segments, _info = self.model.transcribe(wav, language='en', task='transcribe', beam_size=1, vad_filter=False, condition_on_previous_text=False, word_timestamps=words)
        return list(segments)

    def raw(self, wav: str) -> str:
        return ''.join((s.text for s in self._transcribe(wav, False))).strip()

    def process(self, wav: str, confidence: bool=False) -> dict:
        import corrector
        segs = self._transcribe(wav, confidence)
        raw = ''.join((s.text for s in segs)).strip()
        clean = corrector.correct(raw, self.vocab, use_llm=False) if self.correct else raw
        out = {'raw': raw, 'clean': clean}
        if confidence:
            out['words'] = [(w.word, float(w.probability)) for s in segs for w in s.words or []]
        return out

    def unload(self):
        self.model = None
        import gc
        gc.collect()

def has_cuda() -> bool:
    try:
        import torch
        return torch.cuda.is_available()
    except Exception:
        return False

def pick_engine(speaker: str, size: str, adapter: str | None, bf16: bool):
    if has_cuda():
        from pipeline import Pipeline
        return Pipeline(speaker, model=size, adapter=adapter, bf16=bf16, correct=True)
    return CPUEngine(speaker, size)

def _bench(speaker: str, size: str, n: int=4):
    import csv
    import time
    rows = list(csv.DictReader((ROOT / 'data' / speaker / 'manifest.csv').open(encoding='utf-8-sig')))
    picks = [r for r in rows if 1.5 < float(r['duration_s']) < 6.0][:n]
    if not picks:
        raise SystemExit('no suitable clips in the manifest')
    eng = CPUEngine(speaker, size)
    times, audio_s = ([], 0.0)
    for r in picks:
        t0 = time.time()
        text = eng.raw(str(ROOT / r['wav_path']))
        times.append(time.time() - t0)
        audio_s += float(r['duration_s'])
        print(f"  {float(r['duration_s']):4.1f}s audio -> {times[-1]:5.2f}s   {text[:52]!r}")
    avg = sum(times) / len(times)
    print(f'\n  {size} on CPU (int8): {avg:.2f}s per utterance, realtime factor {sum(times) / audio_s:.2f}x')
    print(f"  {('USABLE behind a live mic' if avg < 2.0 else 'still too slow')}")

def main():
    p = argparse.ArgumentParser(description='CPU inference: convert and benchmark.')
    p.add_argument('--speaker', default=None)
    p.add_argument('--model', default='small', choices=['small', 'medium', 'large-v3'])
    p.add_argument('--adapter', default=None, help="LoRA dir to merge (default: the profile's)")
    p.add_argument('--compute', default=DEFAULT_COMPUTE)
    p.add_argument('--convert', action='store_true')
    p.add_argument('--fetch-base', dest='fetch_base', action='store_true', help='download a generic converted model (no GPU, no adapter)')
    p.add_argument('--bench', action='store_true')
    p.add_argument('--force', action='store_true')
    a = p.parse_args()
    if a.fetch_base:
        fetch_base(a.model, a.force)
    if a.convert:
        adapter = a.adapter
        if adapter is None:
            import profiles
            got = profiles.adapter_for(a.speaker, a.model)
            adapter = str(got) if got else None
        convert(a.speaker, a.model, adapter, a.compute, a.force)
    if a.bench:
        _bench(a.speaker, a.model)
    if not (a.convert or a.bench or a.fetch_base):
        have = [d.name for d in (MODELS / 'ct2').glob('*') if (d / 'model.bin').exists()]
        print(f'converted models: {have}')
        got = resolve(a.speaker, a.model)
        if got:
            d, size, personal = got
            print(f"{a.speaker}/{a.model} would run: {size} ({('personal' if personal else 'generic')}) from {d.name}")
        else:
            print(f'{a.speaker}/{a.model} would NOT start: nothing prepared. Run --fetch-base --model {a.model}')
