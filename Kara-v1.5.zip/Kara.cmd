@echo off
REM Kara -- double-click this. It is the only thing anyone needs to touch.
REM
REM IT SETS UP IF IT HAS TO, then starts. The previous version printed
REM "right-click setup.ps1 and choose Run with PowerShell" and stopped -- and
REM the first thing anybody actually does is double-click the .ps1, which on
REM Windows OPENS IT IN NOTEPAD. That is not a confusing error, it is no error
REM at all: a wall of script text where an app should have been. Reported from
REM a real first run on a second machine, which is exactly where a download's
REM first-five-minutes problems live.
REM
REM A .cmd rather than a shortcut so it survives being copied anywhere: %~dp0
REM is this file's own folder, so nothing is tied to the path it was built in.
title Kara
cd /d "%~dp0"

REM RUNNING FROM INSIDE THE ZIP is the first thing people do, and Windows lets
REM them: double-clicking a file inside a .zip extracts THAT FILE ALONE to a
REM temp folder and runs it there. Everything it needs -- src\, scripts\, the
REM requirements -- is still in the archive, so it fails on whatever it reaches
REM for first, reporting THAT file rather than the real problem. Seen on a real
REM first run: the error named get_python.ps1, and the actual fault was that
REM nothing had been unzipped.
REM
REM src\gui.py is the test: it is the app itself, so if it is not beside this
REM file, this is not a real copy of Kara.
if not exist "%~dp0src\gui.py" goto :notextracted

if exist ".venv\Scripts\pythonw.exe" goto :run

echo.
echo   Setting Kara up on this computer. This happens once.
echo   It downloads about 2 GB and takes a few minutes.
echo.

REM Python first, and by hand rather than trusting setup.ps1 to explain it:
REM "py" missing is the single most likely reason a fresh machine cannot
REM proceed, and the fix is a download rather than anything in this folder.
set "KGETPY=%~dp0get_python.ps1"
if exist "%~dp0scripts\get_python.ps1" set "KGETPY=%~dp0scripts\get_python.ps1"

call :havepython
if not errorlevel 1 goto :haveit

REM NOT THERE -- FETCH IT RATHER THAN SEND HIM AWAY. "Go to python.org, get the
REM 64-bit installer, remember to tick Add to PATH" is three chances to get it
REM wrong before Kara has started, given to somebody who cannot type. Only if
REM this fails does the manual instruction appear.
echo.
echo   Kara needs Python 3.12. Installing it for you...
echo.
if not exist "%KGETPY%" goto :notextracted
powershell -NoProfile -ExecutionPolicy Bypass -File "%KGETPY%"
if errorlevel 1 goto :nopython

call :havepython
if errorlevel 1 goto :pathstale
:haveit

REM The scripts live in scripts\ in a release and at the root in the repo, so
REM look in both rather than having two versions of this file that can drift.
set "KSETUP=%~dp0setup.ps1"
if exist "%~dp0scripts\setup.ps1" set "KSETUP=%~dp0scripts\setup.ps1"
set "KINSTALL=%~dp0install_app.ps1"
if exist "%~dp0scripts\install_app.ps1" set "KINSTALL=%~dp0scripts\install_app.ps1"

if not exist "%KSETUP%" goto :notextracted
powershell -NoProfile -ExecutionPolicy Bypass -File "%KSETUP%"
if errorlevel 1 goto :setupfailed

if not exist ".venv\Scripts\pythonw.exe" goto :setupfailed

echo.
echo   Adding Kara to the Start menu...
powershell -NoProfile -ExecutionPolicy Bypass -File "%KINSTALL%"

echo.
echo   Done. Starting Kara.
echo.

:run
REM pythonw, not python: no console window behind the app. The user should
REM never see a terminal. Anything fatal still lands in app_error.log.
start "" ".venv\Scripts\pythonw.exe" "src\gui.py" %*
exit /b 0

:notextracted
echo.
echo   ================================================================
echo     Kara has not been unzipped yet.
echo   ================================================================
echo.
echo   It looks like this was opened from inside the .zip file. Windows
echo   only unpacks the one file you double-click, so the rest of Kara
echo   is still inside the archive.
echo.
echo   To fix it:
echo.
echo     1. Close this window.
echo     2. Find Kara-v1.0.zip in your Downloads folder.
echo     3. Right-click it, choose "Extract All...", then "Extract".
echo     4. Open the folder that appears and double-click Kara in there.
echo.
pause
exit /b 1

:havepython
REM Sets errorlevel 0 when a usable Python 3.12 is reachable. `py -3.12` first,
REM then the per-user install path -- a Python installed a moment ago is not on
REM THIS process's PATH, because the environment was read when it started.
py -3.12 --version >nul 2>&1
if not errorlevel 1 exit /b 0
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" exit /b 0
exit /b 1

:pathstale
echo.
echo   Python is installed, but this window still has the old settings.
echo   Close this window and double-click Kara again -- that is all it needs.
echo.
pause
exit /b 1

:nopython
echo.
echo   Kara could not install Python automatically.
echo.
echo   1. Go to    https://www.python.org/downloads/release/python-31210/
echo   2. Download "Windows installer (64-bit)"
echo   3. IMPORTANT: tick "Add python.exe to PATH" on the first screen
echo   4. Install it, then double-click Kara again.
echo.
pause
exit /b 1

:setupfailed
echo.
echo   Setup did not finish. The messages above say where it stopped.
echo.
echo   The usual causes are no internet connection, or antivirus blocking
echo   the download. Try again once those are sorted -- nothing is broken,
echo   and running this file again picks up where it left off.
echo.
pause
exit /b 1
