from __future__ import annotations
import json
import re
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path
import atomicio
import config
import karalog
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'src'
PREVIOUS = ROOT / 'src.previous'
TIMEOUT = 30
REQUIRED = ('gui.py', 'asr.py', 'pipeline.py', 'editing.py', 'proofing.py', 'config.py', 'karalog.py')

def _log():
    return karalog.get('update')
PLATFORM_KEYS = {'win32': 'windows', 'darwin': 'mac'}
PLATFORM_MARKERS = {'windows': ('Kara.cmd',), 'mac': ('Kara.command', 'Kara.app')}

def platform_key() -> str:
    return PLATFORM_KEYS.get(sys.platform, sys.platform)

def payload_platform(unpacked: Path) -> str | None:
    roots = [unpacked]
    roots += [c for c in unpacked.iterdir() if c.is_dir()]
    for root in roots:
        for plat, markers in PLATFORM_MARKERS.items():
            if any(((root / m).exists() for m in markers)):
                return plat
    return None

def _version_tuple(text: str) -> tuple:
    nums = re.findall('\\d+', str(text or ''))
    return tuple((int(n) for n in nums)) if nums else (-1,)

def is_newer(candidate: str, current: str) -> bool:
    return _version_tuple(candidate) > _version_tuple(current)

def latest(source: str | None=None) -> dict:
    out = {'ok': False, 'version': '', 'url': '', 'notes': '', 'why': ''}
    source = source or (config.load().get('update_source') or '')
    if not source:
        out['why'] = 'no update source is configured'
        return out
    try:
        req = urllib.request.Request(source, headers={'Accept': 'application/vnd.github+json', 'User-Agent': 'Kara'})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            raw = r.read()
    except Exception as e:
        out['why'] = f'could not reach the update source ({type(e).__name__})'
        return out
    try:
        data = json.loads(raw.decode('utf-8-sig', 'replace'))
    except Exception as e:
        out['why'] = f'the update source is not readable JSON ({type(e).__name__})'
        return out
    if not isinstance(data, dict):
        out['why'] = 'the update source did not return a JSON object'
        return out
    plat = platform_key()
    version = str(data.get('tag_name') or data.get('version') or '').strip()
    platforms = data.get('platforms')
    if isinstance(platforms, dict):
        entry = platforms.get(plat)
        if isinstance(entry, dict):
            data = {**data, **entry}
            version = str(entry.get('version') or version).strip()
        elif isinstance(entry, str):
            data = {**data, 'url': entry}
        else:
            out['why'] = f'this update has no build for {plat}'
            return out
    url = str(data.get('zip') or data.get('url') or '').strip()
    if not url:
        for asset in data.get('assets') or []:
            name = str(asset.get('name') or '')
            if name.endswith('.zip'):
                url = str(asset.get('browser_download_url') or '')
                break
    if not version or not url:
        out['why'] = 'the update source did not name a version and a zip'
        return out
    out.update(ok=True, version=version, url=url, notes=str(data.get('body') or data.get('notes') or '').strip())
    return out

def available(current_version: str, source: str | None=None) -> dict:
    info = latest(source)
    info['newer'] = bool(info['ok'] and is_newer(info['version'], current_version))
    return info

def _payload_src_dir(unpacked: Path) -> Path | None:
    if (unpacked / 'src').is_dir():
        return unpacked / 'src'
    for child in unpacked.iterdir():
        if child.is_dir() and (child / 'src').is_dir():
            return child / 'src'
    return None

def verify(src_dir: Path) -> tuple[bool, str]:
    if src_dir is None or not src_dir.is_dir():
        return (False, 'the download did not contain a src folder')
    missing = [f for f in REQUIRED if not (src_dir / f).is_file()]
    if missing:
        return (False, f"the download is incomplete ({', '.join(missing[:3])})")
    import ast
    for f in src_dir.glob('*.py'):
        try:
            ast.parse(f.read_text(encoding='utf-8-sig'), filename=f.name)
        except (OSError, SyntaxError) as e:
            return (False, f'{f.name} is damaged ({type(e).__name__})')
    return (True, '')

def install(url: str, progress=None) -> tuple[bool, str]:
    tmp = Path(tempfile.mkdtemp(prefix='kara_update_'))
    try:
        if progress:
            progress('Downloading the update…')
        blob = tmp / 'payload.zip'
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Kara'}), timeout=300) as r, blob.open('wb') as f:
            shutil.copyfileobj(r, f)
        if progress:
            progress('Checking it is complete…')
        unpacked = tmp / 'unpacked'
        with zipfile.ZipFile(blob) as z:
            z.extractall(unpacked)
        got = payload_platform(unpacked)
        mine = platform_key()
        if got is not None and got != mine:
            why = f'that download is the {got} version of Kara and this is the {mine} one. Nothing has been changed.'
            _log().warning('update refused: %s', why)
            return (False, why)
        new_src = _payload_src_dir(unpacked)
        ok, why = verify(new_src)
        if not ok:
            _log().warning('update refused: %s', why)
            return (False, why)
        if progress:
            progress('Installing…')
        if PREVIOUS.exists():
            shutil.rmtree(PREVIOUS, ignore_errors=True)
        SRC.rename(PREVIOUS)
        try:
            shutil.copytree(new_src, SRC)
        except Exception as e:
            PREVIOUS.rename(SRC)
            return (False, f'could not install ({type(e).__name__})')
        _log().info('updated; previous kept at %s', PREVIOUS.name)
        return (True, '')
    except Exception as e:
        return (False, type(e).__name__)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def rollback() -> tuple[bool, str]:
    if not PREVIOUS.is_dir():
        return (False, 'there is no previous version to go back to')
    try:
        broken = ROOT / 'src.failed'
        if broken.exists():
            shutil.rmtree(broken, ignore_errors=True)
        if SRC.exists():
            SRC.rename(broken)
        PREVIOUS.rename(SRC)
        _log().warning('rolled back to the previous version')
        return (True, '')
    except Exception as e:
        return (False, type(e).__name__)

def settled() -> None:
    if PREVIOUS.is_dir():
        shutil.rmtree(PREVIOUS, ignore_errors=True)
