from __future__ import annotations
import json
import re
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path
import atomicio
import config
import karalog
ROOT = Path(__file__).resolve().parent.parent
SRC = ROOT / 'src'
PREVIOUS = ROOT / 'src.previous'
TIMEOUT = 30
REQUIRED = ('gui.py', 'asr.py', 'pipeline.py', 'editing.py', 'proofing.py', 'config.py', 'karalog.py')

def _log():
    return karalog.get('update')
PLATFORM_KEYS = {'win32': 'windows', 'darwin': 'mac'}
PLATFORM_MARKERS = {'windows': ('Kara.cmd',), 'mac': ('Kara.command', 'Kara.app')}

def platform_key() -> str:
    return PLATFORM_KEYS.get(sys.platform, sys.platform)

def payload_platform(unpacked: Path) -> str | None:
    roots = [unpacked]
    roots += [c for c in unpacked.iterdir() if c.is_dir()]
    for root in roots:
        for plat, markers in PLATFORM_MARKERS.items():
            if any(((root / m).exists() for m in markers)):
                return plat
    return None

def _version_tuple(text: str) -> tuple:
    nums = re.findall('\\d+', str(text or ''))
    return tuple((int(n) for n in nums)) if nums else (-1,)

def is_newer(candidate: str, current: str) -> bool:
    return _version_tuple(candidate) > _version_tuple(current)

def latest(source: str | None=None) -> dict:
    out = {'ok': False, 'version': '', 'url': '', 'notes': '', 'why': ''}
    source = source or (config.load().get('update_source') or '')
    if not source:
        out['why'] = 'no update source is configured'
        return out
    try:
        req = urllib.request.Request(source, headers={'Accept': 'application/vnd.github+json', 'User-Agent': 'Kara'})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            raw = r.read()
    except Exception as e:
        out['why'] = f'could not reach the update source ({type(e).__name__})'
        return out
    try:
        data = json.loads(raw.decode('utf-8-sig', 'replace'))
    except Exception as e:
        out['why'] = f'the update source is not readable JSON ({type(e).__name__})'
        return out
    if not isinstance(data, dict):
        out['why'] = 'the update source did not return a JSON object'
        return out
    plat = platform_key()
    version = str(data.get('tag_name') or data.get('version') or '').strip()
    platforms = data.get('platforms')
    if isinstance(platforms, dict):
        entry = platforms.get(plat)
        if isinstance(entry, dict):
            data = {**data, **entry}
            version = str(entry.get('version') or version).strip()
        elif isinstance(entry, str):
            data = {**data, 'url': entry}
        else:
            out['why'] = f'this update has no build for {plat}'
            return out
    url = str(data.get('zip') or data.get('url') or '').strip()
    if not url:
        want = ('win', 'windows') if platform_key() == 'windows' else ('mac', 'macos', 'darwin', 'osx')
        avoid = ('mac', 'macos', 'darwin', 'osx') if platform_key() == 'windows' else ('win', 'windows')
        spare = ''
        for asset in data.get('assets') or []:
            low = str(asset.get('name') or '').lower()
            if not low.endswith('.zip'):
                continue
            link = str(asset.get('browser_download_url') or '')
            if any((w in low for w in want)):
                url = link
                break
            if not any((a in low for a in avoid)) and (not spare):
                spare = link
        url = url or spare
    if not version or not url:
        out['why'] = 'the update source did not name a version and a zip'
        return out
    out.update(ok=True, version=version, url=url, notes=str(data.get('body') or data.get('notes') or '').strip())
    return out

def available(current_version: str, source: str | None=None) -> dict:
    info = latest(source)
    info['newer'] = bool(info['ok'] and is_newer(info['version'], current_version))
    return info

def _payload_src_dir(unpacked: Path) -> Path | None:
    if (unpacked / 'src').is_dir():
        return unpacked / 'src'
    for child in unpacked.iterdir():
        if child.is_dir() and (child / 'src').is_dir():
            return child / 'src'
    return None

def verify(src_dir: Path) -> tuple[bool, str]:
    if src_dir is None or not src_dir.is_dir():
        return (False, 'the download did not contain a src folder')
    missing = [f for f in REQUIRED if not (src_dir / f).is_file()]
    if missing:
        return (False, f"the download is incomplete ({', '.join(missing[:3])})")
    import ast
    for f in src_dir.glob('*.py'):
        try:
            ast.parse(f.read_text(encoding='utf-8-sig'), filename=f.name)
        except (OSError, SyntaxError) as e:
            return (False, f'{f.name} is damaged ({type(e).__name__})')
    return (True, '')
PAYLOAD_FILES = ('requirements-app.txt', 'README.md', 'PRIVACY.md', 'TERMS.md', 'LICENSE', 'THIRD-PARTY-NOTICES.md', 'Kara.cmd')
PAYLOAD_DIRS = ('scripts', 'assets')
_CREATE_NO_WINDOW = 134217728

def _copy_payload(unpacked: Path, root: Path) -> tuple[list[str], bool]:
    import filecmp
    src_root = unpacked
    if not (src_root / 'src').is_dir():
        for child in unpacked.iterdir():
            if child.is_dir() and (child / 'src').is_dir():
                src_root = child
                break
    changed: list[str] = []
    reqs_changed = False
    for name in PAYLOAD_FILES:
        new = src_root / name
        if not new.is_file():
            continue
        cur = root / name
        if cur.is_file() and filecmp.cmp(new, cur, shallow=False):
            continue
        shutil.copy2(new, cur)
        changed.append(name)
        if name.startswith('requirements'):
            reqs_changed = True
    for name in PAYLOAD_DIRS:
        new = src_root / name
        if not new.is_dir():
            continue
        for f in sorted((p for p in new.rglob('*') if p.is_file())):
            rel = f.relative_to(new)
            cur = root / name / rel
            if cur.is_file() and filecmp.cmp(f, cur, shallow=False):
                continue
            cur.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(f, cur)
            changed.append(f'{name}/{rel.as_posix()}')
    new_prompts = src_root / 'data' / 'prompts'
    if new_prompts.is_dir():
        dest = root / 'data' / 'prompts'
        dest.mkdir(parents=True, exist_ok=True)
        for f in sorted(new_prompts.glob('setup_*.txt')):
            cur = dest / f.name
            if not (cur.is_file() and filecmp.cmp(f, cur, shallow=False)):
                shutil.copy2(f, cur)
                changed.append(f'data/prompts/{f.name}')
    return (changed, reqs_changed)

def _install_requirements(root: Path) -> tuple[bool, str]:
    import subprocess
    py = root / '.venv' / 'Scripts' / 'python.exe'
    if not py.exists():
        return (False, 'no virtual environment found')
    req = root / 'requirements-app.txt'
    if not req.is_file():
        return (False, f'{req.name} is missing')
    try:
        r = subprocess.run([str(py), '-m', 'pip', 'install', '-q', '-r', str(req)], capture_output=True, encoding='utf-8', errors='replace', timeout=1800, creationflags=_CREATE_NO_WINDOW)
        return (r.returncode == 0, (r.stderr or '').strip()[-200:])
    except Exception as e:
        return (False, type(e).__name__)

def install(url: str, progress=None) -> tuple[bool, str]:
    tmp = Path(tempfile.mkdtemp(prefix='kara_update_'))
    try:
        if progress:
            progress('Downloading the update…')
        blob = tmp / 'payload.zip'
        with urllib.request.urlopen(urllib.request.Request(url, headers={'User-Agent': 'Kara'}), timeout=300) as r, blob.open('wb') as f:
            shutil.copyfileobj(r, f)
        if progress:
            progress('Checking it is complete…')
        unpacked = tmp / 'unpacked'
        with zipfile.ZipFile(blob) as z:
            z.extractall(unpacked)
        got = payload_platform(unpacked)
        mine = platform_key()
        if got is not None and got != mine:
            why = f'that download is the {got} version of Kara and this is the {mine} one. Nothing has been changed.'
            _log().warning('update refused: %s', why)
            return (False, why)
        new_src = _payload_src_dir(unpacked)
        ok, why = verify(new_src)
        if not ok:
            _log().warning('update refused: %s', why)
            return (False, why)
        if progress:
            progress('Installing…')
        if PREVIOUS.exists():
            shutil.rmtree(PREVIOUS, ignore_errors=True)
        SRC.rename(PREVIOUS)
        try:
            shutil.copytree(new_src, SRC)
        except Exception as e:
            PREVIOUS.rename(SRC)
            return (False, f'could not install ({type(e).__name__})')
        try:
            changed, reqs_changed = _copy_payload(unpacked, ROOT)
        except Exception as e:
            changed, reqs_changed = ([], False)
            _log().warning('could not update the files beside src/: %s', e)
        if changed:
            _log().info('update also replaced: %s', ', '.join(changed[:8]))
        if reqs_changed:
            if progress:
                progress('Getting the parts this version needs…')
            ok_req, why_req = _install_requirements(ROOT)
            _log().info('dependency install after update: ok=%s %s', ok_req, why_req)
            if not ok_req:
                _log().warning('update installed, but new dependencies did not: %s', why_req)
        _log().info('updated; previous kept at %s', PREVIOUS.name)
        return (True, '')
    except Exception as e:
        return (False, type(e).__name__)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def rollback() -> tuple[bool, str]:
    if not PREVIOUS.is_dir():
        return (False, 'there is no previous version to go back to')
    try:
        broken = ROOT / 'src.failed'
        if broken.exists():
            shutil.rmtree(broken, ignore_errors=True)
        if SRC.exists():
            SRC.rename(broken)
        PREVIOUS.rename(SRC)
        _log().warning('rolled back to the previous version')
        return (True, '')
    except Exception as e:
        return (False, type(e).__name__)

def settled() -> None:
    if PREVIOUS.is_dir():
        shutil.rmtree(PREVIOUS, ignore_errors=True)
