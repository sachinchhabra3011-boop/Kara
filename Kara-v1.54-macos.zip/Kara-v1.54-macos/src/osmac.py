"""macOS backend for the platform layer. See osbridge.py for the contract.

THE HANDLE ON THIS PLATFORM IS A PROCESS ID, not a window handle. macOS has no
global per-window identifier a normal process may hold: AXUIElement references
exist only once Accessibility is granted, and they go stale the moment the app
redraws. The pid is the thing that is stable, addressable without permission,
and enough for everything Kara actually does with a target -- check it is still
alive, bring it to the front, ask what program it is. Windows passes an HWND
through the same parameter; neither side inspects the other's value.
"""
from __future__ import annotations

import subprocess
import threading
import time
from pathlib import Path

PASTE_SETTLE = 0.16
CLIPBOARD_RESTORE_AFTER = 2.0

# Virtual key codes (Carbon kVK_*). These are POSITIONS ON THE KEYBOARD, not
# characters -- kVK_ANSI_Z is 6 whatever the layout maps that key to.
VK_A, VK_Z, VK_V = 0, 6, 9
VK_RETURN, VK_TAB, VK_SPACE, VK_DELETE = 36, 48, 49, 51
VK_LEFT = 123
MOD_CMD, MOD_SHIFT, MOD_OPT, MOD_CTRL = 0x37, 0x38, 0x3A, 0x3B

# NOT A TRANSLATION OF THE WINDOWS TABLE. The shortcuts genuinely differ, and
# getting this wrong is silent: Ctrl+Y in a Mac text field does nothing at all,
# so "redo" would report success and change nothing. Word-left is Option here,
# not Control; redo is Cmd+Shift+Z, not Cmd+Y.
KEYSTROKES = {
    'delete_word': (VK_DELETE, [MOD_OPT]),
    'backspace': (VK_DELETE, []),
    'press_enter': (VK_RETURN, []),
    'new_line': (VK_RETURN, []),
    'tab': (VK_TAB, []),
    'space': (VK_SPACE, []),
    'select_last': (VK_LEFT, [MOD_OPT, MOD_SHIFT]),
    'undo': (VK_Z, [MOD_CMD]),
    'redo': (VK_Z, [MOD_CMD, MOD_SHIFT]),
    'clear': (VK_A, [MOD_CMD]),
}

_MOD_FLAGS = {}


def _quartz():
    import Quartz
    if not _MOD_FLAGS:
        _MOD_FLAGS.update({
            MOD_CMD: Quartz.kCGEventFlagMaskCommand,
            MOD_SHIFT: Quartz.kCGEventFlagMaskShift,
            MOD_OPT: Quartz.kCGEventFlagMaskAlternate,
            MOD_CTRL: Quartz.kCGEventFlagMaskControl,
        })
    return Quartz


# ---------------------------------------------------------------- permission

def accessibility_granted(prompt: bool = False) -> bool:
    """True when this process may synthesise keystrokes.

    WITHOUT THIS, POSTING A KEY EVENT IS NOT AN ERROR -- it is silently
    discarded by the window server. Every send would report success and nothing
    would appear in the document, which is the worst failure shape available:
    the app says it worked and the page stays empty. So Kara checks first and
    says so, rather than finding out by not working.
    """
    try:
        from ApplicationServices import (AXIsProcessTrusted,
                                         AXIsProcessTrustedWithOptions,
                                         kAXTrustedCheckOptionPrompt)
    except Exception:
        return False
    try:
        if prompt:
            return bool(AXIsProcessTrustedWithOptions({kAXTrustedCheckOptionPrompt: True}))
        return bool(AXIsProcessTrusted())
    except Exception:
        return False


def open_accessibility_settings() -> bool:
    """Open the exact System Settings pane, rather than describing where it is."""
    try:
        subprocess.run(['open',
                        'x-apple.systempreferences:com.apple.preference.security'
                        '?Privacy_Accessibility'], check=False, timeout=10)
        return True
    except Exception:
        return False


PERMISSION_HINT = (
    'macOS has not given Kara permission to type into other programs yet.\n\n'
    'Open System Settings ▸ Privacy & Security ▸ Accessibility, switch Kara on, '
    'then quit and reopen Kara.\n\n'
    'Your writing is on the clipboard either way — you can press Command and V '
    'in the document instead.'
)


# ------------------------------------------------------------------ windows

def _workspace_apps():
    from AppKit import NSWorkspace
    return NSWorkspace.sharedWorkspace()


def foreground_target() -> tuple[int, str, str]:
    """(pid, human name, bundle id) of the frontmost application."""
    try:
        app = _workspace_apps().frontmostApplication()
        if app is None:
            return (0, '', '')
        return (int(app.processIdentifier()),
                str(app.localizedName() or ''),
                str(app.bundleIdentifier() or ''))
    except Exception:
        return (0, '', '')


def window_is_alive(handle: int) -> bool:
    if not handle:
        return False
    try:
        from AppKit import NSRunningApplication
        app = NSRunningApplication.runningApplicationWithProcessIdentifier_(int(handle))
        return app is not None and not app.isTerminated()
    except Exception:
        return False


def process_name(handle: int) -> str:
    try:
        from AppKit import NSRunningApplication
        app = NSRunningApplication.runningApplicationWithProcessIdentifier_(int(handle))
        if app is None:
            return ''
        return str(app.bundleIdentifier() or app.localizedName() or '').lower()
    except Exception:
        return ''


def find_titled_window(title: str) -> int:
    """Re-find a target by the name Kara showed the user, after it was closed
    and reopened. Matches on application name because that is what a pid-shaped
    handle can address -- Kara displays the app name on this platform for
    exactly that reason."""
    if not title:
        return 0
    want = title.strip().lower()
    try:
        for app in _workspace_apps().runningApplications():
            if str(app.localizedName() or '').strip().lower() == want:
                return int(app.processIdentifier())
    except Exception:
        pass
    return 0


def focus_window(handle: int) -> tuple[bool, str]:
    if not handle:
        return (False, 'gone')
    try:
        from AppKit import NSRunningApplication
        app = NSRunningApplication.runningApplicationWithProcessIdentifier_(int(handle))
        if app is None or app.isTerminated():
            return (False, 'gone')
        if app.isActive():
            return (True, '')
        # 1 << 1 is NSApplicationActivateIgnoringOtherApps. Named literally
        # because the constant moved between pyobjc releases.
        app.activateWithOptions_(1 << 1)
        for _ in range(25):
            if app.isActive():
                return (True, '')
            time.sleep(0.02)
        return (False, 'refused')
    except Exception:
        return (False, 'refused')


def caret_info() -> dict:
    """Kara uses this on Windows to guess whether the focused control takes
    text. The equivalent here needs Accessibility, and the answer is only ever
    used as a hint, so report what is knowable without it and let the caller
    fall back to its app-name check."""
    pid, name, bundle = foreground_target()
    return {'hwnd': pid, 'focus_class': bundle or name.lower(),
            'has_caret': False, 'looks_like_text': False}


# ------------------------------------------------------------------- typing

def press_keys(handle: int | None, key: int, modifiers=()) -> dict:
    if handle:
        focused, why = focus_window(handle)
        if not focused:
            return {'ok': False, 'focused': False, 'gone': why == 'gone', 'reason': why}
    if not accessibility_granted():
        return {'ok': False, 'focused': True, 'gone': False, 'reason': 'no accessibility permission'}
    time.sleep(0.05)
    try:
        Q = _quartz()
        flags = 0
        for m in modifiers:
            flags |= _MOD_FLAGS.get(m, 0)
        src = Q.CGEventSourceCreate(Q.kCGEventSourceStateHIDSystemState)
        for down in (True, False):
            e = Q.CGEventCreateKeyboardEvent(src, key, down)
            if flags:
                Q.CGEventSetFlags(e, flags)
            Q.CGEventPost(Q.kCGHIDEventTap, e)
            time.sleep(0.005)
    except Exception as e:
        return {'ok': False, 'focused': True, 'gone': False, 'reason': f'{type(e).__name__}: {e}'}
    return {'ok': True, 'focused': True, 'gone': False, 'reason': ''}


def inject_text(text: str, handle: int | None = None, restore_clipboard: bool = True) -> dict:
    import pyperclip
    previous = None
    if restore_clipboard:
        try:
            previous = pyperclip.paste()
        except Exception:
            previous = None
    try:
        pyperclip.copy(text)
    except Exception as e:
        return {'ok': False, 'focused': False, 'on_clipboard': False,
                'gone': False, 'reason': f'clipboard unavailable: {e}'}

    if handle:
        focused, why = focus_window(handle)
        if not focused:
            gone = why == 'gone'
            return {'ok': False, 'focused': False, 'on_clipboard': True, 'gone': gone,
                    'reason': 'the target program is no longer running' if gone
                              else 'the target program would not come to the front'}

    # THE TEXT IS ALREADY SAFE ON THE CLIPBOARD before this check, so a refusal
    # here still leaves the user one Cmd+V from their words. That ordering is
    # the whole reason this is recoverable rather than a dead end.
    if not accessibility_granted():
        return {'ok': False, 'focused': True, 'on_clipboard': True, 'gone': False,
                'reason': 'no accessibility permission'}

    time.sleep(PASTE_SETTLE)
    try:
        Q = _quartz()
        src = Q.CGEventSourceCreate(Q.kCGEventSourceStateHIDSystemState)
        for down in (True, False):
            e = Q.CGEventCreateKeyboardEvent(src, VK_V, down)
            Q.CGEventSetFlags(e, Q.kCGEventFlagMaskCommand)
            Q.CGEventPost(Q.kCGHIDEventTap, e)
            time.sleep(0.01)
    except Exception as e:
        return {'ok': False, 'focused': True, 'on_clipboard': True, 'gone': False,
                'reason': f'{type(e).__name__}: {e}'}

    if restore_clipboard and previous is not None and previous != text:
        def _restore_later(old=previous):
            time.sleep(CLIPBOARD_RESTORE_AFTER)
            try:
                import pyperclip as _pc
                _pc.copy(old)
            except Exception:
                pass
        threading.Thread(target=_restore_later, daemon=True, name='kara-clipboard').start()
    return {'ok': True, 'focused': True, 'on_clipboard': True, 'gone': False, 'reason': ''}


# -------------------------------------------------------------------- files

def app_support_dir() -> Path:
    """Where Windows uses %LOCALAPPDATA%. Apple's documented location for
    app-managed data the user does not browse."""
    return Path.home() / 'Library' / 'Application Support' / 'Kara'


def trash(path: Path) -> bool:
    """Move to the Trash rather than delete, so 'removed' stays undoable --
    the Recycle Bin promise Kara already makes to the user in KARA-3002 and
    the delete confirmation."""
    try:
        from Foundation import NSURL, NSFileManager
        url = NSURL.fileURLWithPath_(str(path))
        ok, _new, _err = NSFileManager.defaultManager() \
            .trashItemAtURL_resultingItemURL_error_(url, None, None)
        return bool(ok)
    except Exception:
        pass
    # AppleScript is the documented fallback and still lands in the Trash.
    try:
        script = f'tell application "Finder" to delete POSIX file "{path}"'
        r = subprocess.run(['osascript', '-e', script], capture_output=True, timeout=20)
        return r.returncode == 0
    except Exception:
        return False


TRASH_NAME = 'Trash'


def reveal(path: Path) -> bool:
    try:
        subprocess.run(['open', '-R', str(path)] if Path(path).is_file()
                       else ['open', str(path)], check=False, timeout=15)
        return True
    except Exception:
        return False


def python_exe(current: Path) -> Path:
    """Windows swaps pythonw.exe for python.exe to get a console for a child
    process. There is no such split here -- the interpreter is the interpreter."""
    return current


NO_WINDOW = 0          # subprocess creationflags; Windows-only concept


# --------------------------------------------------------- single instance

_LOCK_FD = None


def _lock_path(app_name: str) -> Path:
    return app_support_dir() / f'{app_name}.lock'


def claim_single_instance(app_name: str = 'Kara') -> bool:
    """An exclusive flock. The lock belongs to the file descriptor, so the OS
    drops it however the process dies -- no stale lock to clean up after a
    crash, which a bare pid file would leave behind.

    OPENED WITHOUT TRUNCATING, deliberately. open(path, 'w') empties the file
    at open time, BEFORE the lock is attempted -- so the copy that loses the
    race would wipe the pid the winner had just written, and wake_running_app
    below would then have nothing to bring forward. The pid is written only
    after the lock is actually held.
    """
    global _LOCK_FD
    import fcntl
    import os as _os
    try:
        d = app_support_dir()
        d.mkdir(parents=True, exist_ok=True)
        fd = _os.open(_lock_path(app_name), _os.O_RDWR | _os.O_CREAT, 0o644)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            _os.close(fd)
            return False
        _os.ftruncate(fd, 0)
        _os.write(fd, str(_os.getpid()).encode())
        _os.fsync(fd)
        _LOCK_FD = fd
        return True
    except Exception:
        # Never let the lock be the reason the app will not start.
        return True


def release_single_instance() -> None:
    global _LOCK_FD
    if _LOCK_FD is None:
        return
    try:
        import fcntl
        import os as _os
        fcntl.flock(_LOCK_FD, fcntl.LOCK_UN)
        _os.close(_LOCK_FD)
    except Exception:
        pass
    finally:
        _LOCK_FD = None


def wake_running_app(app_name: str = 'Kara') -> bool:
    """Bring the copy that already holds the lock to the front.

    BY PID, NOT BY NAME. NSWorkspace reports a process's localizedName from its
    bundle, and Kara launched from Kara.command has no bundle -- it appears as
    "Python". Matching on 'Kara' therefore NEVER matched, and the second
    double-click did nothing at all, silently, which reads as the app being
    broken. The pid in the lock file is written by whoever holds the lock, so
    it is exactly the process to raise.
    """
    from AppKit import NSRunningApplication
    import os as _os
    pid = 0
    try:
        pid = int((_lock_path(app_name).read_text(encoding='utf-8') or '0').strip())
    except (OSError, ValueError):
        pid = 0
    if pid and pid != _os.getpid():
        try:
            app = NSRunningApplication.runningApplicationWithProcessIdentifier_(pid)
            if app is not None and not app.isTerminated():
                app.activateWithOptions_(1 << 1)
                return True
        except Exception:
            pass
    # A bundled build (or a future Kara.app) does carry the name, so the
    # name match is kept as a second try rather than dropped.
    try:
        for app in _workspace_apps().runningApplications():
            if int(app.processIdentifier()) == _os.getpid():
                continue
            if str(app.localizedName() or '').strip() == app_name:
                app.activateWithOptions_(1 << 1)
                return True
    except Exception:
        pass
    return False


def set_app_id(app_id: str) -> None:
    """Windows needs an explicit AppUserModelID to group taskbar buttons.
    macOS derives identity from the bundle, so there is nothing to set."""
    return None


def theme_titlebar(widget) -> None:
    """Windows paints its own caption bar and has to be told the colours.
    macOS titlebars follow the system appearance, and Qt already tracks it."""
    return None


# ---------------------------------------------------------------- speaking

def tts_voices() -> list[dict]:
    """`say -v '?'` lists every installed voice as: Name  lang  # sample text."""
    import re as _re
    out = []
    try:
        r = subprocess.run(['say', '-v', '?'], capture_output=True,
                           encoding='utf-8', errors='replace', timeout=30)
        for line in (r.stdout or '').splitlines():
            m = _re.match(r'^(.+?)\s{2,}([a-zA-Z_\-]+)\s+#\s*(.*)$', line.strip())
            if not m:
                continue
            name, lang = m.group(1).strip(), m.group(2).strip()
            # Apple's high-quality voices carry a parenthesised grade. Treat
            # Premium/Enhanced as "natural" so they sort above the compact ones,
            # which is the same distinction the Windows side draws.
            natural = any(k in name for k in ('(Premium)', '(Enhanced)'))
            out.append({'name': name, 'lang': lang.replace('_', '-'),
                        'natural': natural, 'note': m.group(3).strip()})
    except Exception:
        return []
    return out


def tts_to_wav(text: str, out_path: Path, voice_name: str | None = None, rate: int = 0) -> bool:
    """`say` writes AIFF natively; --data-format=LEI16@22050 makes the .wav a
    real PCM wav that soundfile can read back."""
    cmd = ['say', '-o', str(out_path), '--data-format=LEI16@22050']
    if voice_name:
        cmd += ['-v', voice_name]
    # Kara's rate slider is -10..10 around a default. `say` takes words/minute;
    # 175 is the system default and each step is about 12%.
    wpm = max(90, min(500, int(round(175 * (1.0 + int(rate) * 0.12)))))
    cmd += ['-r', str(wpm)]
    try:
        subprocess.run(cmd, input=(text or '').encode('utf-8'),
                       capture_output=True, timeout=180)
    except Exception:
        return False
    return out_path.exists() and out_path.stat().st_size > 0


def tts_speak_direct(text: str, voice_name: str | None = None, rate: int = 0) -> bool:
    """Straight to the default output, no temp file. Used when Kara is not
    routing audio to a chosen device."""
    cmd = ['say']
    if voice_name:
        cmd += ['-v', voice_name]
    wpm = max(90, min(500, int(round(175 * (1.0 + int(rate) * 0.12)))))
    cmd += ['-r', str(wpm)]
    try:
        subprocess.run(cmd, input=(text or '').encode('utf-8'),
                       capture_output=True, timeout=180)
        return True
    except Exception:
        return False


def audio_player(path: Path):
    """Start playing a wav file through CoreAudio, returning a killable handle.

    WHY NOT sounddevice. PortAudio's CoreAudio backend does not resample: it is
    handed a sample rate and a device that is running at another one, and what
    comes out is not what went in. Kara's voices are 22.05 kHz and this Mac's
    speakers run at 48 kHz, and the result was described as "a bass woofer with
    an undertone of Samantha" -- the voice still there underneath a lot of
    low-frequency noise. afplay is CoreAudio's own player and does the
    conversion properly, which is why `say` always sounded right while the
    read-aloud button did not.

    Returns None if it cannot start, so callers fall back rather than go mute.
    """
    try:
        return subprocess.Popen(['afplay', str(path)],
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception:
        return None


# Piper ships a mac build too; the app downloads it on demand for higher-quality
# voices than `say` offers. Same release, different asset.
PIPER_RELEASE = ('https://github.com/rhasspy/piper/releases/download/'
                 '2023.11.14-2/piper_macos_aarch64.tar.gz')
PIPER_BINARY = 'piper'


def register_app(root: Path, version: str, log=None) -> bool:
    """Windows writes an Uninstall key so Kara appears in Settings ▸ Apps.
    macOS uninstalls by dragging to the Trash; there is no register step."""
    return False
