import csv
import json
from pathlib import Path
import config
ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'data'
MODELS = ROOT / 'models'
_NOT_PROFILES = {'prompts'}
LEGACY_ADAPTERS = {}
VOCAB_TEMPLATE = {'_comment': "This person's vocabulary and measured recogniser confusions. Personal data: never commit or share this file.", 'names': [], 'places': [], 'brands_apps': [], 'foods': [], 'spelled': [], 'confusions': {}, 'speech_patterns': []}

def list_profiles() -> list[str]:
    if not DATA.is_dir():
        return []
    out = []
    for d in DATA.iterdir():
        if not d.is_dir() or d.name in _NOT_PROFILES:
            continue
        if (d / 'manifest.csv').exists() or (d / 'vocab.json').exists():
            out.append(d.name)
    return sorted(out)

def active() -> str | None:
    name = config.load().get('active_profile')
    return name if name and (DATA / name).is_dir() else None

def set_active(name: str, model_size: str | None=None) -> None:
    cfg = config.load()
    cfg['active_profile'] = name
    if model_size:
        cfg.setdefault('profiles', {}).setdefault(name, {})['model_size'] = model_size
    config.save(cfg)

def _profile_file(name: str) -> Path:
    return DATA / name / 'profile.json'

def _recorded_adapter(name: str, size: str) -> Path | None:
    import json
    try:
        data = json.loads(_profile_file(name).read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return None
    dirname = (data.get('adapters') or {}).get(size)
    if not dirname:
        return None
    p = MODELS / str(dirname)
    return p if p.is_dir() else None

def set_adapter(name: str, size: str, adapter_dir: Path | str | None) -> None:
    import json
    import atomicio
    path = _profile_file(name)
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        data = {}
    adapters = dict(data.get('adapters') or {})
    if adapter_dir is None:
        adapters.pop(size, None)
    else:
        adapters[size] = Path(adapter_dir).name
    data['adapters'] = adapters
    path.parent.mkdir(parents=True, exist_ok=True)
    atomicio.write_json(path, data, backup=True)

def model_size(name: str) -> str:
    return config.load().get('profiles', {}).get(name, {}).get('model_size', 'medium')

def paths(name: str) -> dict:
    base = DATA / name
    return {'base': base, 'recordings': base / 'recordings', 'manifest': base / 'manifest.csv', 'vocab': base / 'vocab.json', 'anchors': base / 'anchors.json'}

def adapter_for(name: str, size: str) -> Path | None:
    legacy = LEGACY_ADAPTERS.get((name, size))
    if legacy and legacy.exists():
        return legacy
    p = MODELS / name / f'whisper-{size}-lora'
    if p.exists():
        return p
    recorded = _recorded_adapter(name, size)
    if recorded is not None:
        return recorded
    return None

def is_trained(name: str, size: str | None=None) -> bool:
    return adapter_for(name, size or model_size(name)) is not None

# THE ANCHOR ALPHABET, seeded per profile.
#
# Spelling mode works by anchor words -- say "apple" and Kara writes A.
# spelling.load_anchors raises SystemExit when data/<speaker>/anchors.json is
# absent, and nothing anywhere created it, so Spelling mode could not start on
# any machine that had not had the file copied across by hand.
#
# spelling.parse_spelling matches only the FIRST WORD of each anchor and uses
# difflib at a 0.75 cutoff, so these have to stay far enough apart to survive
# unclear consonants. Checked: no pair matches at that cutoff.
#
# Matches data/prompts/setup_letters.txt. Change one and change both, or the
# user records an alphabet Kara does not use.
ANCHOR_TEMPLATE = {
    'a': 'apple', 'b': 'bottle', 'c': 'candle', 'd': 'doctor', 'e': 'elephant',
    'f': 'flower', 'g': 'garden', 'h': 'hospital', 'i': 'insect', 'j': 'jacket',
    'k': 'kitchen', 'l': 'lemon', 'm': 'mother', 'n': 'number', 'o': 'orange',
    'p': 'pencil', 'q': 'queen', 'r': 'rabbit', 's': 'sugar', 't': 'table',
    'u': 'umbrella', 'v': 'village', 'w': 'window', 'x': 'x-ray',
    'y': 'yellow', 'z': 'zebra',
}

def create(name: str) -> Path:
    name = (name or '').strip()
    if not name or any((c in name for c in '\\/:*?"<>|')) or name in _NOT_PROFILES:
        raise ValueError(f'invalid profile name: {name!r}')
    p = paths(name)
    p['recordings'].mkdir(parents=True, exist_ok=True)
    if not p['vocab'].exists():
        p['vocab'].write_text(json.dumps(VOCAB_TEMPLATE, indent=2, ensure_ascii=False), encoding='utf-8')
    if not p['anchors'].exists():
        p['anchors'].write_text(json.dumps({'anchors': ANCHOR_TEMPLATE}, indent=2, ensure_ascii=False), encoding='utf-8')
    return p['base']

def clip_count(name: str) -> int:
    m = paths(name)['manifest']
    if not m.exists():
        return 0
    try:
        with m.open(encoding='utf-8-sig', newline='') as f:
            return sum((1 for _ in csv.DictReader(f)))
    except OSError:
        return 0

def describe(name: str) -> dict:
    return {'profile': name, 'clips': clip_count(name), 'trained': is_trained(name), 'model_size': model_size(name), 'display_name': display_name(name), 'photo': photo_path(name)}

def display_name(name: str) -> str:
    return config.load().get('profiles', {}).get(name, {}).get('display_name') or name

def set_display_name(name: str, shown: str) -> None:
    cfg = config.load()
    cfg.setdefault('profiles', {}).setdefault(name, {})['display_name'] = (shown or '').strip()[:40] or name
    config.save(cfg)

def photo_path(name: str) -> str | None:
    for ext in ('.png', '.jpg', '.jpeg'):
        p = paths(name)['base'] / f'avatar{ext}'
        if p.exists():
            return str(p)
    return None

def set_photo(name: str, source: str) -> str | None:
    import shutil
    src = Path(source)
    if not src.exists():
        return None
    ext = src.suffix.lower()
    if ext not in ('.png', '.jpg', '.jpeg'):
        return None
    base = paths(name)['base']
    base.mkdir(parents=True, exist_ok=True)
    for old in base.glob('avatar.*'):
        try:
            old.unlink()
        except OSError:
            pass
    dest = base / f'avatar{ext}'
    try:
        shutil.copyfile(src, dest)
    except OSError:
        return None
    return str(dest)

def data_inventory(name: str) -> list[dict]:
    p = paths(name)
    base = p['base']

    def files(path: Path, pattern: str='*') -> list[Path]:
        return [f for f in path.glob(pattern) if f.is_file()] if path.is_dir() else []

    def total(paths_: list[Path]) -> int:
        return sum((f.stat().st_size for f in paths_ if f.exists()))
    rows = []
    wavs = files(p['recordings'], '*.wav')
    secs = 0.0
    if p['manifest'].exists():
        try:
            with p['manifest'].open(encoding='utf-8-sig', newline='') as f:
                secs = sum((float(r.get('duration_s') or 0) for r in csv.DictReader(f)))
        except (OSError, ValueError):
            pass
    rows.append({'what': 'Voice recordings', 'detail': f'{len(wavs)} clips' + (f', {secs / 60:.0f} minutes of audio' if secs else ''), 'why': 'Used to teach Kara your voice. Made by you during setup.', 'bytes': total(wavs), 'where': str(p['recordings'])})
    rows.append({'what': 'What each recording says', 'detail': '1 file' if p['manifest'].exists() else 'none', 'why': 'Pairs each clip with its words, so a model can be trained.', 'bytes': total([p['manifest']]), 'where': str(p['manifest'])})
    lib = base / 'library'
    docs = files(lib, '*.txt')
    words = 0
    for d in docs:
        try:
            words += len(d.read_text(encoding='utf-8').split())
        except OSError:
            pass
    rows.append({'what': 'Your writing', 'detail': f'{len(docs)} pages, about {words:,} words', 'why': 'The pages you have dictated. Plain text — openable anywhere.', 'bytes': total(docs), 'where': str(lib)})
    vocab_n = 0
    if p['vocab'].exists():
        try:
            v = json.loads(p['vocab'].read_text(encoding='utf-8'))
            vocab_n = sum((len(x) for x in v.values() if isinstance(x, list)))
        except (OSError, ValueError):
            pass
    rows.append({'what': 'Names and places', 'detail': f'{vocab_n} entries', 'why': 'So Kara spells the people and places you mention correctly.', 'bytes': total([p['vocab']]), 'where': str(p['vocab'])})
    model_dirs = []
    own = MODELS / name
    if own.is_dir():
        model_dirs += [d for d in own.iterdir() if d.is_dir()]
    for (spk, size), path in LEGACY_ADAPTERS.items():
        if spk == name and path.exists():
            model_dirs.append(path)
    ct2 = MODELS / 'ct2'
    if ct2.is_dir():
        model_dirs += [d for d in ct2.glob(f'{name}-*') if d.is_dir()]
    m_bytes = sum((sum((f.stat().st_size for f in d.rglob('*') if f.is_file())) for d in model_dirs))
    rows.append({'what': 'Your voice model', 'detail': f'{len(model_dirs)} trained model(s)' if model_dirs else 'not trained yet', 'why': 'What makes Kara understand you. Built from your recordings.', 'bytes': m_bytes, 'where': str(own) if own.is_dir() else str(MODELS)})
    photo = photo_path(name)
    rows.append({'what': 'Profile photo', 'detail': '1 image' if photo else 'none', 'why': 'Shown on your profile in the app.', 'bytes': total([Path(photo)]) if photo else 0, 'where': photo or str(base)})
    try:
        import utterances
        u = utterances.inventory(name)
        rows.append({'what': 'Recent recordings', 'detail': f"{u['count']} of the last {u['keep']}" + (f", {u['seconds']:.0f} seconds" if u['seconds'] else ''), 'why': 'The last few things you said, kept so Kara can learn from your corrections. Older ones are deleted automatically. Never included in a backup or a diagnostics file.', 'bytes': u['bytes'], 'where': u['where']})
    except Exception:
        pass
    logs = ROOT / 'logs'
    log_files = files(logs)
    rows.append({'what': 'Activity log', 'detail': f'{len(log_files)} file(s)' if log_files else 'none', 'why': 'A technical diary of what the app did — never what you said or wrote. Used to work out what went wrong.', 'bytes': total(log_files), 'where': str(logs)})
    return rows

def human_bytes(n: int) -> str:
    if n <= 0:
        return '—'
    for unit in ('B', 'KB', 'MB', 'GB'):
        if n < 1024 or unit == 'GB':
            return f'{n:.0f} {unit}' if unit in ('B', 'KB') else f'{n:.1f} {unit}'
        n /= 1024
    return f'{n:.1f} GB'

def data_summary(name: str) -> dict:
    p = paths(name)

    def _size(path: Path) -> int:
        if not path.exists():
            return 0
        if path.is_file():
            return path.stat().st_size
        return sum((f.stat().st_size for f in path.rglob('*') if f.is_file()))
    lib = p['base'] / 'library'
    docs = list(lib.glob('*.txt')) if lib.is_dir() else []
    wavs = list(p['recordings'].glob('*.wav')) if p['recordings'].is_dir() else []
    adapters = [d for d in (MODELS / name).glob('*') if d.is_dir()] if (MODELS / name).is_dir() else []
    total = _size(p['base']) + _size(MODELS / name)
    return {'recordings': len(wavs), 'documents': len(docs), 'models': len(adapters) + sum((1 for k in LEGACY_ADAPTERS if k[0] == name and adapter_for(*k))), 'bytes': total, 'human': f'{total / 1000000.0:.0f} MB' if total else 'nothing'}

def delete_all_data(name: str) -> list[str]:
    import shutil
    removed = []
    base = paths(name)['base']
    if base.exists():
        shutil.rmtree(base, ignore_errors=True)
        removed.append(str(base))
    own_models = MODELS / name
    if own_models.exists():
        shutil.rmtree(own_models, ignore_errors=True)
        removed.append(str(own_models))
    ct2 = MODELS / 'ct2'
    if ct2.is_dir():
        for d in ct2.glob(f'{name}-*'):
            shutil.rmtree(d, ignore_errors=True)
            removed.append(str(d))
    logs = ROOT / 'logs'
    if logs.is_dir():
        shutil.rmtree(logs, ignore_errors=True)
        removed.append(str(logs))
    cfg = config.load()
    cfg.get('profiles', {}).pop(name, None)
    if cfg.get('active_profile') == name:
        cfg['active_profile'] = None
    config.save(cfg)
    return removed

def clear_photo(name: str) -> None:
    for old in paths(name)['base'].glob('avatar.*'):
        try:
            old.unlink()
        except OSError:
            pass
