import argparse
import csv
import json
import random
from pathlib import Path
import numpy as np
import torch
import asr
ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / 'results'
MODELS = ROOT / 'models'

def load_manifest(speaker: str) -> list[dict]:
    path = ROOT / 'data' / speaker / 'manifest.csv'
    if not path.exists():
        raise SystemExit(f"No manifest for '{speaker}' at {path}")
    with path.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def split_stratified(rows: list[dict], test_frac: float, seed: int) -> tuple[list, list, dict]:
    singles = [r for r in rows if len(r['prompt_text'].split()) == 1]
    sentences = [r for r in rows if len(r['prompt_text'].split()) > 1]
    rng = random.Random(seed)
    test, train = ([], [])
    for group in (singles, sentences):
        idx = list(range(len(group)))
        rng.shuffle(idx)
        n_test = max(1, round(len(group) * test_frac))
        for j, i in enumerate(idx):
            (test if j < n_test else train).append(group[i])
    info = {'seed': seed, 'test_frac': test_frac, 'n_train': len(train), 'n_test': len(test), 'test_ids': sorted((r['prompt_id'] for r in test))}
    return (train, test, info)

def build_examples(rows: list[dict], processor) -> list[dict]:
    examples = []
    for r in rows:
        audio = asr.load_mono_16k(str(ROOT / r['wav_path']))
        feats = processor.feature_extractor(audio, sampling_rate=16000).input_features[0]
        labels = processor.tokenizer(r['prompt_text']).input_ids
        examples.append({'input_features': np.asarray(feats, dtype=np.float32), 'labels': labels})
    return examples

class Collator:

    def __init__(self, processor):
        self.processor = processor

    def __call__(self, batch):
        feats = torch.tensor(np.stack([b['input_features'] for b in batch]))
        label_batch = self.processor.tokenizer.pad([{'input_ids': b['labels']} for b in batch], return_tensors='pt')
        labels = label_batch['input_ids'].masked_fill(label_batch.attention_mask.ne(1), -100)
        if (labels[:, 0] == self.processor.tokenizer.bos_token_id).all().cpu().item():
            labels = labels[:, 1:]
        return {'input_features': feats, 'labels': labels}

class _ProgressJSON:

    def __init__(self, n_train: int, batch: int):
        self.n_train, self.batch = (n_train, batch)

    def _emit(self, state, **extra):
        import json as _json
        total = int(getattr(state, 'max_steps', 0) or 0)
        step = int(getattr(state, 'global_step', 0) or 0)
        payload = {'event': 'step', 'step': step, 'total': total, 'epoch': round(float(getattr(state, 'epoch', 0) or 0), 2), 'clips_seen': step * self.batch, 'clips_total': self.n_train}
        payload.update(extra)
        print(_json.dumps(payload), flush=True)

    def on_log(self, args, state, control, logs=None, **kw):
        extra = {}
        if logs:
            if 'loss' in logs:
                extra['loss'] = round(float(logs['loss']), 4)
            if 'eval_wer' in logs:
                extra['wer'] = round(float(logs['eval_wer']), 4)
        self._emit(state, **extra)

    def on_save(self, args, state, control, **kw):
        self._emit(state, saved=True)

    def __getattr__(self, name):
        if name.startswith('on_'):
            return lambda *a, **k: None
        raise AttributeError(name)

def main() -> None:
    parser = argparse.ArgumentParser(description='LoRA fine-tune Whisper on a speaker.')
    parser.add_argument('--speaker', required=True)
    parser.add_argument('--model', default='medium', help='whisper size: medium, large-v3, ...')
    parser.add_argument('--epochs', type=float, default=24)
    parser.add_argument('--test-frac', type=float, default=0.15)
    parser.add_argument('--seed', type=int, default=0)
    parser.add_argument('--rank', type=int, default=32)
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--batch', type=int, default=8)
    parser.add_argument('--bf16', action='store_true', help='train in bf16 (REQUIRED for large-v3: fp16 training is unstable and produces a degenerate model). Ampere+ only.')
    parser.add_argument('--max-steps', type=int, default=-1, help='smoke test: cap steps')
    parser.add_argument('--out', type=Path, default=None)
    parser.add_argument('--split', type=Path, default=None, help='reuse an existing split json instead of generating one. REQUIRED to compare two runs: a fresh split changes the held-out set, so any WER difference confounds the hyperparameter with the test data.')
    parser.add_argument('--save-every-clips', type=int, default=0, help='checkpoint every N clips (0 = per-epoch only)')
    parser.add_argument('--resume', action='store_true', help='continue from the last checkpoint in --out')
    parser.add_argument('--progress-json', action='store_true', help="emit one JSON line per step, for the app's progress bar")
    parser.add_argument('--extra-manifest', type=Path, default=None, help='an ADDITIONAL manifest whose clips join the training set only, never the held-out set. This is how adaptation clips get in (adapt.py dataset); they stay in their own file so the verified corpus is never mixed with data inferred from usage.')
    parser.add_argument('--train-limit', type=int, default=None, help='train on only N clips (held-out unchanged). For the how-much-must-a-new-user-record sweep. Subsampled STRATIFIED so a small N keeps the single-word/sentence mix instead of drifting to one kind.')
    args = parser.parse_args()
    from transformers import WhisperProcessor, WhisperForConditionalGeneration, Seq2SeqTrainer, Seq2SeqTrainingArguments
    from peft import LoraConfig, get_peft_model
    import jiwer
    from transformers.models.whisper.english_normalizer import EnglishTextNormalizer
    out_dir = args.out or MODELS / f'whisper-{args.model}-{args.speaker}-lora'
    out_dir.mkdir(parents=True, exist_ok=True)
    normalize = EnglishTextNormalizer({})
    print(f'loading openai/whisper-{args.model} ...', flush=True)
    processor = WhisperProcessor.from_pretrained(f'openai/whisper-{args.model}', language='en', task='transcribe')
    model = WhisperForConditionalGeneration.from_pretrained(f'openai/whisper-{args.model}', dtype=torch.float32)
    model.config.forced_decoder_ids = None
    model.config.suppress_tokens = []
    model.generation_config.language = 'en'
    model.generation_config.task = 'transcribe'
    model.generation_config.forced_decoder_ids = None
    rows = load_manifest(args.speaker)
    RESULTS.mkdir(exist_ok=True)
    if args.split:
        test_ids = set(json.loads(args.split.read_text())['test_ids'])
        test_rows = [r for r in rows if r['prompt_id'] in test_ids]
        train_rows = [r for r in rows if r['prompt_id'] not in test_ids]
        missing = len(test_ids) - len(test_rows)
        print(f'reusing split {args.split.name}: {len(train_rows)} train, {len(test_rows)} held-out' + (f' ({missing} test id(s) no longer in the manifest)' if missing else ''), flush=True)
    else:
        train_rows, test_rows, info = split_stratified(rows, args.test_frac, args.seed)
        (RESULTS / f'{args.speaker}_split.json').write_text(json.dumps(info, indent=2))
        print(f"split: {info['n_train']} train, {info['n_test']} held-out test", flush=True)
    if args.extra_manifest:
        if not args.extra_manifest.exists():
            raise SystemExit(f'No such manifest: {args.extra_manifest}')
        with args.extra_manifest.open(encoding='utf-8-sig', newline='') as f:
            extra = [r for r in csv.DictReader(f) if (r.get('prompt_text') or '').strip()]
        frozen = ROOT / 'data' / args.speaker / 'frozen_test.json'
        if frozen.exists():
            frozen_ids = set(json.loads(frozen.read_text())['test_ids'])
            clash = [r for r in extra if r['prompt_id'] in frozen_ids]
            if clash:
                raise SystemExit(f'{len(clash)} adaptation clip(s) collide with the frozen test set. Refusing: the deploy gate would be worthless.')
        train_rows = train_rows + extra
        print(f'+{len(extra)} adaptation clip(s) from {args.extra_manifest.name} (train only)', flush=True)
    if args.train_limit and args.train_limit < len(train_rows):
        singles = [r for r in train_rows if len(r['prompt_text'].split()) == 1]
        sents = [r for r in train_rows if len(r['prompt_text'].split()) > 1]
        rng = random.Random(args.seed)
        rng.shuffle(singles)
        rng.shuffle(sents)
        frac = args.train_limit / len(train_rows)
        keep_s = round(len(singles) * frac)
        subset = singles[:keep_s] + sents[:args.train_limit - keep_s]
        rng.shuffle(subset)
        train_rows = subset
        print(f'train-limit: {len(train_rows)} clips ({keep_s} single words, {len(train_rows) - keep_s} sentences)', flush=True)
    print('extracting features ...', flush=True)
    train_ds = build_examples(train_rows, processor)
    test_ds = build_examples(test_rows, processor)
    lora = LoraConfig(r=args.rank, lora_alpha=args.rank * 2, target_modules=['q_proj', 'v_proj'], lora_dropout=0.05, bias='none')
    model = get_peft_model(model, lora)
    model.print_trainable_parameters()
    model.enable_input_require_grads()

    def compute_metrics(pred):
        pred_ids, label_ids = (pred.predictions, pred.label_ids)
        label_ids = np.where(label_ids == -100, processor.tokenizer.pad_token_id, label_ids)
        hyp = processor.tokenizer.batch_decode(pred_ids, skip_special_tokens=True)
        ref = processor.tokenizer.batch_decode(label_ids, skip_special_tokens=True)
        hyp = [normalize(h) or ' ' for h in hyp]
        ref = [normalize(r) or ' ' for r in ref]
        return {'wer': jiwer.wer(ref, hyp)}
    ckpt_steps = 0
    if args.save_every_clips > 0:
        if args.model.startswith('large'):
            raise SystemExit('--save-every-clips is unsafe with large-v3: it disables load_best_model_at_end, and large-v3 diverges after its early minimum (see CLAUDE.md). Train large-v3 without it.')
        ckpt_steps = max(1, args.save_every_clips // max(1, args.batch))
    best_at_end = args.max_steps < 0 and (not ckpt_steps)
    # MIXED PRECISION IS A CUDA FEATURE HERE. `fp16=True` asks accelerate for a
    # CUDA GradScaler; on a Mac there is no CUDA, so training aborted before the
    # first step with an error about fp16 requiring a GPU -- on the one path
    # that matters most, since personalising the model IS what Kara is for.
    # bf16 on MPS is accepted by torch but silently unstable for this model, so
    # neither is used off CUDA: full fp32, slower and correct.
    import torch as _torch
    _cuda = _torch.cuda.is_available()
    _fp16 = (not args.bf16) and _cuda
    _bf16 = args.bf16 and _cuda
    if not _cuda:
        print('no CUDA: training in float32 (mixed precision needs an NVIDIA card)', flush=True)
    targs = Seq2SeqTrainingArguments(output_dir=str(out_dir), per_device_train_batch_size=args.batch, per_device_eval_batch_size=args.batch, gradient_checkpointing=True, fp16=_fp16, bf16=_bf16, learning_rate=args.lr, warmup_ratio=0.1, num_train_epochs=args.epochs, max_steps=args.max_steps, predict_with_generate=True, generation_max_length=128, eval_strategy='epoch' if args.max_steps < 0 else 'no', save_strategy='steps' if ckpt_steps else 'epoch' if args.max_steps < 0 else 'no', save_steps=ckpt_steps or 500, save_total_limit=2 if ckpt_steps else 1, load_best_model_at_end=best_at_end, metric_for_best_model='eval_wer', greater_is_better=False, logging_steps=10, report_to=[], remove_unused_columns=False, label_names=['labels'])
    trainer = Seq2SeqTrainer(model=model, args=targs, train_dataset=train_ds, eval_dataset=test_ds, data_collator=Collator(processor), compute_metrics=compute_metrics, processing_class=processor)
    model.config.use_cache = False
    if args.progress_json:
        trainer.add_callback(_ProgressJSON(len(train_ds), args.batch))
    if args.resume:
        ckpts = sorted(out_dir.glob('checkpoint-*'), key=lambda p: int(p.name.split('-')[-1]) if p.name.split('-')[-1].isdigit() else 0)
        if ckpts:
            ckpt = ckpts[-1]
            done_epochs = 0.0
            state_file = ckpt / 'trainer_state.json'
            if state_file.exists():
                try:
                    done_epochs = float(json.loads(state_file.read_text(encoding='utf-8')).get('epoch', 0.0))
                except (OSError, ValueError):
                    pass
            print(f'resuming from {ckpt} (was {done_epochs:.2f} epochs in)')
            from peft import set_peft_model_state_dict
            from safetensors.torch import load_file as _load_st
            weights = ckpt / 'adapter_model.safetensors'
            if weights.exists():
                set_peft_model_state_dict(model, _load_st(str(weights)))
                print('  restored adapter weights')
            remaining = max(0.0, float(args.epochs) - done_epochs)
            if remaining <= 0:
                print('  already trained the full schedule; nothing left to do')
                model.save_pretrained(out_dir)
                processor.save_pretrained(out_dir)
                if args.progress_json:
                    print(json.dumps({'event': 'done', 'out': str(out_dir)}), flush=True)
                return
            print(f'  {remaining:.2f} epochs remaining')
            trainer.args.num_train_epochs = remaining
        else:
            print('nothing to resume from; starting fresh')
    trainer.train()
    model.save_pretrained(out_dir)
    processor.save_pretrained(out_dir)
    print(f'\nsaved adapter -> {out_dir}')
    if args.progress_json:
        print(json.dumps({'event': 'done', 'out': str(out_dir)}), flush=True)
