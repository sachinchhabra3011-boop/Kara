from __future__ import annotations
import json
import re
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
_PERSON_TEMPLATES = ['Please tell {x} that I will be a little late.', 'I am meeting {x} for lunch later today.', 'Can you ask {x} to call me back this evening.', '{x} said the plan has changed for tomorrow.', 'I sent the message to {x} an hour ago.', 'Remind me to thank {x} for the help.', '{x} and I are going out this weekend.', 'Did {x} remember to bring the tickets.']
_PLACE_TEMPLATES = ['I am heading to {x} in about ten minutes.', 'We should meet at {x} around noon.', 'The shop near {x} is open until late.', 'Can you drop me at {x} on the way.', 'I left my jacket at {x} yesterday.', 'There was a long queue outside {x} today.']
_ORG_TEMPLATES = ['I have a class at {x} in the morning.', 'The office at {x} is closed on Sunday.', 'I need to email someone at {x} tonight.']
_NAME_ALONE = ['My name is {x}.', 'Hello, this is {x} speaking.', 'You can call me {x}.']

def _clean(s: str) -> str:
    return ' '.join((s or '').split()).strip()

def _dedupe(seq):
    seen, out = (set(), [])
    for s in seq:
        k = s.lower()
        if s and k not in seen:
            seen.add(k)
            out.append(s)
    return out

def build_personal(fields: dict) -> tuple[list[str], dict]:
    name = _clean(fields.get('name', ''))
    people = _dedupe((_clean(p) for p in fields.get('people', []) if _clean(p)))
    places = _dedupe((_clean(p) for p in fields.get('places', []) if _clean(p)))
    org = _clean(fields.get('org', ''))
    phrases = _dedupe((_clean(p) for p in fields.get('phrases', []) if _clean(p)))
    prompts: list[str] = []
    if name:
        for t in _NAME_ALONE:
            prompts.append(t.format(x=name))
    for i, person in enumerate(people):
        prompts.append(_PERSON_TEMPLATES[i % len(_PERSON_TEMPLATES)].format(x=person))
        if i < 3:
            alt = _PERSON_TEMPLATES[(i + 4) % len(_PERSON_TEMPLATES)]
            prompts.append(alt.format(x=person))
    for i, place in enumerate(places):
        prompts.append(_PLACE_TEMPLATES[i % len(_PLACE_TEMPLATES)].format(x=place))
    if org:
        for t in _ORG_TEMPLATES:
            prompts.append(t.format(x=org))
    prompts.extend(phrases)
    prompts = _dedupe(prompts)
    vocab = {'names': _dedupe(([name] if name else []) + people), 'places': _dedupe(places + ([org] if org else []))}
    return (prompts, vocab)

def seed_vocab(vocab: dict, speaker: str) -> None:
    path = ROOT / 'data' / speaker / 'vocab.json'
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        db = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
    except (OSError, ValueError):
        db = {}
    for category, words in vocab.items():
        bucket = db.setdefault(category, [])
        have = {w.lower() for w in bucket}
        for w in words:
            if w.lower() not in have:
                bucket.append(w)
                have.add(w.lower())
    import atomicio
    atomicio.write_json(path, db, backup=True)

def write_prompt_set(prompts: list[str], speaker: str, set_name: str='personal_setup') -> Path:
    out = ROOT / 'data' / 'prompts' / f'{set_name}.txt'
    # MAKE THE FOLDER FIRST. data/ is gitignored and ships with nothing in it,
    # so on a fresh install data/prompts/ does not exist -- and this was a bare
    # write_text, which raises FileNotFoundError. Filling the setup form in
    # correctly was therefore a crash on any machine that had never recorded
    # before, which is every machine on its first run. seed_vocab three lines
    # down already does this; this line did not.
    out.parent.mkdir(parents=True, exist_ok=True)
    header = f"# Generated from the setup form for '{speaker}'. GITIGNORED (real names).\n# Regenerate from the app; do not hand-edit.\n\n"
    out.write_text(header + '\n'.join(prompts) + '\n', encoding='utf-8')
    return out

def parse_list(text: str) -> list[str]:
    return _dedupe((_clean(p) for p in re.split('[,\\n]', text or '') if _clean(p)))
