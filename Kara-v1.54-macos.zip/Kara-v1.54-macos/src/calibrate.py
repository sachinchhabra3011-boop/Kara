import argparse
import csv
import gc
import json
import platform
import time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
MODELS = {'tiny': {'params': '39M', 'min_ram_gb': 2, 'min_vram_gb': 1, 'typical_wer': 'not measured', 'needs_cuda': False}, 'base': {'params': '74M', 'min_ram_gb': 4, 'min_vram_gb': 2, 'typical_wer': 'not measured', 'needs_cuda': False}, 'small': {'params': '244M', 'min_ram_gb': 6, 'min_vram_gb': 3, 'typical_wer': '~7%', 'needs_cuda': False}, 'medium': {'params': '769M', 'min_ram_gb': 12, 'min_vram_gb': 6, 'typical_wer': '~4.5%', 'needs_cuda': False}, 'large-v3-turbo': {'params': '809M', 'min_ram_gb': 16, 'min_vram_gb': 6, 'typical_wer': 'not measured', 'needs_cuda': True}, 'large-v3': {'params': '1.55B', 'min_ram_gb': 32, 'min_vram_gb': 10, 'typical_wer': '~4.5%', 'needs_cuda': True}}
SEC_PER_STEP_3060 = {'tiny': 0.1, 'base': 0.18, 'small': 0.53, 'medium': 1.46, 'large-v3-turbo': 1.6, 'large-v3': 3.3}
MEASURED_SIZES = {'small', 'medium'}
BATCH = 2
EPOCHS = 10
WARMUP_STEPS = 1
EVAL_OVERHEAD = 1.25

def detect() -> dict:
    import torch
    hw = {'cpu': platform.processor() or platform.machine(), 'cuda': torch.cuda.is_available(), 'gpu': None, 'vram_gb': 0.0, 'ram_gb': 0.0, 'cores_physical': None, 'cores_logical': None}
    try:
        import psutil
        hw['ram_gb'] = round(psutil.virtual_memory().total / 1000000000.0, 1)
        hw['cores_physical'] = psutil.cpu_count(logical=False)
        hw['cores_logical'] = psutil.cpu_count()
    except Exception:
        pass
    if hw['cuda']:
        hw['gpu'] = torch.cuda.get_device_name(0)
        hw['vram_gb'] = round(torch.cuda.get_device_properties(0).total_memory / 1000000000.0, 1)
    else:
        try:
            import osbridge
            if osbridge.IS_MAC:
                # platform.processor() answers 'arm' on Apple Silicon, which is
                # shown to the user on the Measure-this-machine page and tells
                # them nothing. macOS knows the actual chip; ask it.
                import subprocess
                r = subprocess.run(['sysctl', '-n', 'machdep.cpu.brand_string'],
                                   capture_output=True, encoding='utf-8',
                                   errors='replace', timeout=10)
                name = (r.stdout or '').strip()
                if name:
                    hw['cpu'] = name
                # Apple Silicon has no separate VRAM: the GPU shares system
                # memory. Report it as the accelerator without inventing a
                # vram figure, so viable() keeps gating on cuda as before.
                if torch.backends.mps.is_available():
                    hw['mps'] = True
                    hw['gpu'] = f"{name or 'Apple Silicon'} (shared memory)"
        except Exception:
            pass
    return hw

def count_clips(speaker: str) -> int:
    manifest = ROOT / 'data' / speaker / 'manifest.csv'
    if not manifest.exists():
        return 0
    try:
        with manifest.open(encoding='utf-8-sig', newline='') as f:
            return sum((1 for _ in csv.DictReader(f)))
    except OSError:
        return 0

def viable(model: str, hw: dict) -> tuple[bool, str, str]:
    spec = MODELS[model]
    if hw['cuda'] and hw['vram_gb'] >= spec['min_vram_gb']:
        return (True, 'cuda', '')
    if spec['needs_cuda']:
        have = f"only {hw['vram_gb']} GB" if hw['cuda'] else 'no GPU'
        return (False, '', f"needs an NVIDIA GPU with {spec['min_vram_gb']} GB+ ({have})")
    if hw['ram_gb'] and hw['ram_gb'] >= spec['min_ram_gb']:
        return (True, 'cpu', '')
    if not hw['ram_gb']:
        return (True, 'cpu', '')
    return (False, '', f"needs {spec['min_ram_gb']} GB RAM (has {hw['ram_gb']} GB)")

def hours(per_step: float, clips: int, epochs: int=EPOCHS) -> float:
    steps = -(-max(clips, 1) // BATCH) * epochs
    return steps * per_step * EVAL_OVERHEAD / 3600

def human(h: float) -> str:
    if h <= 0:
        return '—'
    if h < 1:
        return f'{round(h * 60)} min'
    if h < 10:
        return f'{h:.1f} h'
    return f'{round(h)} h'

def estimate_report(speaker: str, clips: int | None=None, sec_per_step: dict | None=None) -> dict:
    hw = detect()
    clips = count_clips(speaker) if clips is None else clips
    sps = dict(SEC_PER_STEP_3060)
    if sec_per_step:
        sps.update(sec_per_step)
    options = []
    for name in MODELS:
        ok, device, why = viable(name, hw)
        row = {'model': name, 'params': MODELS[name]['params'], 'available': ok, 'device': device, 'reason': why, 'typical_wer': MODELS[name]['typical_wer'], 'sec_per_step': round(sps.get(name, 0.0), 2), 'measured': name in (sec_per_step or {}) or (name in MEASURED_SIZES and (not sec_per_step)), 'hours': round(hours(sps[name], clips), 2) if ok and name in sps else None}
        options.append(row)
    return {'hardware': hw, 'speaker': speaker, 'clips': clips, 'epochs': EPOCHS, 'options': options}

def measure(model: str, device: str, steps: int) -> tuple[float, float]:
    import psutil
    import torch
    from peft import LoraConfig, get_peft_model
    from transformers import WhisperForConditionalGeneration
    proc = psutil.Process()
    net = WhisperForConditionalGeneration.from_pretrained(f'openai/whisper-{model}', dtype=torch.float32)
    net.config.forced_decoder_ids = None
    net = get_peft_model(net, LoraConfig(r=32, lora_alpha=64, target_modules=['q_proj', 'v_proj'], lora_dropout=0.05, bias='none')).to(device)
    net.gradient_checkpointing_enable()
    net.enable_input_require_grads()
    net.config.use_cache = False
    net.train()
    opt = torch.optim.AdamW([p for p in net.parameters() if p.requires_grad], lr=0.0003)
    feats = torch.randn(BATCH, net.config.num_mel_bins, 3000, device=device)
    labels = torch.randint(0, 1000, (BATCH, 24), device=device)
    amp = torch.bfloat16 if model == 'large-v3' else torch.float16
    scaler = torch.amp.GradScaler('cuda') if device == 'cuda' and amp is torch.float16 else None

    def one():
        if device == 'cuda':
            with torch.autocast('cuda', dtype=amp):
                loss = net(input_features=feats, labels=labels).loss
            if scaler:
                scaler.scale(loss).backward()
                scaler.step(opt)
                scaler.update()
            else:
                loss.backward()
                opt.step()
        else:
            net(input_features=feats, labels=labels).loss.backward()
            opt.step()
        opt.zero_grad(set_to_none=True)
    try:
        for _ in range(WARMUP_STEPS):
            one()
        if device == 'cuda':
            torch.cuda.synchronize()
        t0 = time.time()
        for _ in range(steps):
            one()
        if device == 'cuda':
            torch.cuda.synchronize()
        per_step = (time.time() - t0) / steps
        peak = proc.memory_info().rss / 1000000000.0
    finally:
        del net, opt, feats, labels
        gc.collect()
        if device == 'cuda':
            torch.cuda.empty_cache()
    return (per_step, peak)

def measured_report(speaker: str, steps: int, clips: int | None=None) -> dict:
    hw = detect()
    clips = count_clips(speaker) if clips is None else clips
    options = []
    for name in MODELS:
        ok, device, why = viable(name, hw)
        row = {'model': name, 'params': MODELS[name]['params'], 'available': ok, 'device': device, 'reason': why, 'typical_wer': MODELS[name]['typical_wer']}
        if ok:
            try:
                per_step, peak = measure(name, device, steps)
                row.update(sec_per_step=round(per_step, 2), peak_gb=round(peak, 2), measured=True, hours=round(hours(per_step, clips), 2))
            except Exception as e:
                sps = SEC_PER_STEP_3060[name]
                row.update(sec_per_step=round(sps, 2), measured=False, hours=round(hours(sps, clips), 2), note=f"estimated (couldn't measure: {type(e).__name__})")
        else:
            row.update(sec_per_step=None, hours=None, measured=False)
        options.append(row)
    return {'hardware': hw, 'speaker': speaker, 'clips': clips, 'epochs': EPOCHS, 'options': options}

def main() -> None:
    p = argparse.ArgumentParser(description='Estimate retrain time on this machine.')
    p.add_argument('--speaker', default=None)
    p.add_argument('--clips', type=int, default=None, help='override the manifest count')
    p.add_argument('--steps', type=int, default=5, help='timed LoRA steps per size')
    p.add_argument('--instant', action='store_true', help='skip measuring; use 3060 constants')
    p.add_argument('--json', action='store_true')
    args = p.parse_args()
    report = estimate_report(args.speaker, args.clips) if args.instant else measured_report(args.speaker, args.steps, args.clips)
    if args.json:
        print(json.dumps(report, indent=2))
        return
    hw = report['hardware']
    print('\nYour computer')
    print(f"  GPU  : {hw['gpu'] or 'none detected'}" + (f"  ({hw['vram_gb']} GB)" if hw['gpu'] else ''))
    print(f"  RAM  : {hw['ram_gb'] or '?'} GB")
    print(f"\nRetrain on {report['clips']} clips ({report['epochs']} epochs):\n")
    for r in report['options']:
        if r['available']:
            tag = '' if r.get('measured') else '  (estimated)'
            print(f"  {r['model']:<9} {human(r['hours']):>8}   on {r['device'].upper()}   accuracy {r['typical_wer']}{tag}")
        else:
            print(f"  {r['model']:<9} {'—':>8}   unavailable: {r['reason']}")
    print("\n  Accuracy was measured on one speaker's voice, not yours — treat it as indicative only.")
