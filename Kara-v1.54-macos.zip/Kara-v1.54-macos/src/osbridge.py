"""The one place that knows which operating system this is.

WHY THIS EXISTS. v1.53 called Win32 directly from app.py and gui.py, and
`sys.platform` appeared nowhere in the tree -- there was no platform check to
fail, because there was no notion that there could be another one. Every such
call is now behind a name here, and each backend implements the same names.
The rest of Kara asks for what it wants ("bring that window to the front") and
never for how it is done.

THE HANDLE IS OPAQUE. Windows passes an HWND, macOS passes a process id, and
nothing outside a backend may look inside one. Kara stores it, hands it back,
and compares it to zero. That is the whole contract, and it is what let the two
platforms share every call site.

Adding Linux later means writing oslinux.py against this same list of names.
"""
from __future__ import annotations

import sys

IS_WINDOWS = sys.platform.startswith('win')
IS_MAC = sys.platform == 'darwin'

if IS_MAC:
    import osmac as _b
elif IS_WINDOWS:
    import oswin as _b
else:
    # Linux and the BSDs: no backend yet. Import the macOS one for its
    # POSIX-shaped file and process handling and let the input functions
    # report that they cannot type, rather than failing at import and
    # taking the whole app down before it can say why.
    import osmac as _b

PLATFORM = 'mac' if IS_MAC else 'windows' if IS_WINDOWS else sys.platform

# Text injection and window targeting
inject_text = _b.inject_text
press_keys = _b.press_keys
KEYSTROKES = _b.KEYSTROKES
window_is_alive = _b.window_is_alive
focus_window = _b.focus_window
foreground_target = _b.foreground_target
find_titled_window = _b.find_titled_window
process_name = _b.process_name
caret_info = _b.caret_info

# Permission (a no-op on Windows, a real gate on macOS)
accessibility_granted = _b.accessibility_granted
open_accessibility_settings = _b.open_accessibility_settings
PERMISSION_HINT = _b.PERMISSION_HINT

# Files and locations
app_support_dir = _b.app_support_dir
trash = _b.trash
reveal = _b.reveal
TRASH_NAME = _b.TRASH_NAME
python_exe = _b.python_exe
NO_WINDOW = _b.NO_WINDOW

# Process and window-manager housekeeping
claim_single_instance = _b.claim_single_instance
release_single_instance = _b.release_single_instance
wake_running_app = _b.wake_running_app
set_app_id = _b.set_app_id
theme_titlebar = _b.theme_titlebar
register_app = _b.register_app

# Speech
tts_voices = _b.tts_voices
tts_to_wav = _b.tts_to_wav
tts_speak_direct = _b.tts_speak_direct
audio_player = _b.audio_player
PIPER_RELEASE = _b.PIPER_RELEASE
PIPER_BINARY = _b.PIPER_BINARY


def venv_python(root) -> str:
    """Where setup put the interpreter, for the places Kara prints a command
    for someone to run. The layouts genuinely differ."""
    from pathlib import Path
    root = Path(root)
    return str(root / ('.venv/Scripts/python.exe' if IS_WINDOWS else '.venv/bin/python'))


def describe() -> str:
    import platform as _p
    return f'{PLATFORM} {_p.release()} ({_p.machine()})'
