from __future__ import annotations
import logging
import logging.handlers
import os
import platform
import re
import sys
import time
import zipfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
LOG_DIR = ROOT / 'logs'
LOG_FILE = LOG_DIR / 'kara.log'
CRASH_FILE = LOG_DIR / 'crash.log'
MAX_BYTES = 1000000
BACKUPS = 3
_ready = False

def words(text: str | None) -> str:
    if not text:
        return '<empty>'
    n = len(str(text).split())
    return f"<{n} word{('' if n == 1 else 's')}>"

def chars(text: str | None) -> str:
    if not text:
        return '<empty>'
    return f'<{len(str(text))} chars>'

def setup(level: int=logging.INFO, console: bool | None=None) -> logging.Logger:
    global _ready
    root = logging.getLogger('kara')
    if _ready:
        return root
    root.setLevel(level)
    root.propagate = False
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        fh = logging.handlers.RotatingFileHandler(LOG_FILE, maxBytes=MAX_BYTES, backupCount=BACKUPS, encoding='utf-8')
        fh.setFormatter(_RedactingFormatter('%(asctime)s %(levelname)-7s %(name)-14s %(message)s', datefmt='%Y-%m-%d %H:%M:%S'))
        root.addHandler(fh)
    except OSError:
        pass
    if console is None:
        console = bool(getattr(sys, 'stderr', None)) and Path(sys.executable).name.lower() not in ('pythonw.exe',)
    if console:
        sh = logging.StreamHandler()
        sh.setFormatter(logging.Formatter('%(levelname)-7s %(name)s  %(message)s'))
        root.addHandler(sh)
    _ready = True
    root.info('--- Kara starting --- python %s, %s', platform.python_version(), platform.platform())
    return root
_PROFILE_PATH = re.compile('([\\\\/]+(?:data|models)[\\\\/]+)([^\\\\/\\s\'\\"]+)', re.IGNORECASE)
_names_cache: tuple | None = None

def _profile_names() -> tuple:
    global _names_cache
    if _names_cache is None:
        try:
            _names_cache = tuple(sorted((d.name for d in (ROOT / 'data').iterdir() if d.is_dir() and len(d.name) >= 3 and (d.name != 'prompts')), key=len, reverse=True))
        except OSError:
            _names_cache = ()
    return _names_cache

def redact(text: str) -> str:
    out = _PROFILE_PATH.sub('\\1<profile>', text)
    for name in _profile_names():
        out = re.sub(f'\\b{re.escape(name)}\\b', '<profile>', out, flags=re.I)
    return out

class _RedactingFormatter(logging.Formatter):

    def format(self, record) -> str:
        return redact(super().format(record))

def get(name: str='kara') -> logging.Logger:
    if not name.startswith('kara'):
        name = f"kara.{name.rsplit('.', 1)[-1]}"
    if not _ready:
        setup()
    return logging.getLogger(name)

def record_crash(exc: BaseException, where: str='') -> Path:
    import traceback
    text = ''.join(traceback.format_exception(type(exc), exc, exc.__traceback__))
    stamp = time.strftime('%Y-%m-%d %H:%M:%S')
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        with CRASH_FILE.open('a', encoding='utf-8') as f:
            f.write(f"\n{'=' * 70}\n{stamp}  {where}\n{'=' * 70}\n{text}")
            f.flush()
            os.fsync(f.fileno())
    except OSError:
        pass
    try:
        get('crash').critical('unhandled in %s: %s: %s', where or '?', type(exc).__name__, exc)
    except Exception:
        pass
    return CRASH_FILE

def install_excepthook() -> None:
    import threading
    previous = sys.excepthook

    def hook(kind, value, tb):
        record_crash(value, 'main thread')
        previous(kind, value, tb)
    sys.excepthook = hook

    def thread_hook(args):
        if args.exc_type is SystemExit:
            return
        record_crash(args.exc_value, f"thread {getattr(args.thread, 'name', '?')}")
    threading.excepthook = thread_hook

def install_qt_handler() -> None:
    try:
        from PySide6.QtCore import QtMsgType, qInstallMessageHandler
    except ImportError:
        return
    log = get('qt')
    levels = {QtMsgType.QtDebugMsg: logging.DEBUG, QtMsgType.QtInfoMsg: logging.INFO, QtMsgType.QtWarningMsg: logging.WARNING, QtMsgType.QtCriticalMsg: logging.ERROR, QtMsgType.QtFatalMsg: logging.CRITICAL}

    def handler(mode, ctx, message):
        log.log(levels.get(mode, logging.INFO), '%s', message)
    qInstallMessageHandler(handler)

def machine_report(speaker: str | None=None) -> str:
    lines: list[str] = []

    def section(name):
        lines.append(f'\n{name}\n' + '-' * len(name))
    lines.append('Kara diagnostics')
    lines.append(time.strftime('%Y-%m-%d %H:%M:%S'))
    lines.append('')
    lines.append('This file contains NO voice recordings, NO pages you have')
    lines.append('written, NO record of anything you said, and none of the names')
    lines.append("or places you taught Kara. It contains the app's technical log,")
    lines.append('the versions of the software on this computer, and counts of')
    lines.append('how many files exist.')
    lines.append('')
    lines.append('It DOES list the microphones and speakers attached to this')
    lines.append('computer, by the names Windows gives them -- a headset you have')
    lines.append('renamed will appear under the name you chose. Most faults Kara')
    lines.append('is asked about are audio faults, and they cannot be worked out')
    lines.append('without that list. Read it before you send this file on.')
    section('Computer')
    lines.append(f'windows        {platform.platform()}')
    lines.append(f'processor      {platform.processor()}')
    lines.append(f'python         {sys.version.split()[0]}  ({sys.executable})')
    try:
        import shutil as _sh
        total, used, free = _sh.disk_usage(ROOT)
        lines.append(f'disk free      {free / 2 ** 30:.1f} GB of {total / 2 ** 30:.1f} GB')
    except OSError:
        pass
    section('Software')
    for mod in ('torch', 'transformers', 'PySide6', 'sounddevice', 'soundfile', 'faster_whisper', 'ctranslate2', 'peft', 'numpy'):
        try:
            m = __import__(mod)
            lines.append(f"{mod:<15}{getattr(m, '__version__', '?')}")
        except Exception as e:
            lines.append(f'{mod:<15}not available ({type(e).__name__})')
    section('Graphics')
    try:
        import torch
        if torch.cuda.is_available():
            lines.append(f'cuda           {torch.version.cuda}')
            lines.append(f'gpu            {torch.cuda.get_device_name(0)}')
            free_b, total_b = torch.cuda.mem_get_info()
            lines.append(f'gpu memory     {free_b / 2 ** 30:.1f} GB free of {total_b / 2 ** 30:.1f} GB')
        else:
            lines.append('cuda           not available (Kara uses the CPU build)')
    except Exception as e:
        lines.append(f'cuda           could not be queried ({type(e).__name__})')
    section('Audio devices')
    try:
        import record as _rec
        for i, name, api in _rec.unique_devices(_rec.input_devices()):
            lines.append(f'in   [{i:>2}] {_rec.pretty_name(name)}  ({api})')
        for i, name, api in _rec.unique_devices(_rec.output_devices()):
            lines.append(f'out  [{i:>2}] {_rec.pretty_name(name)}  ({api})')
    except Exception as e:
        lines.append(f'could not be listed ({type(e).__name__}: {e})')
    section('Settings')
    try:
        import config as _cfg
        cfg = _cfg.load()
        for key in ('model', 'input_device', 'output_device', 'include_spelling', 'speak_responses', 'terms_accepted'):
            lines.append(f'{key:<18}{cfg.get(key)!r}')
        lines.append(f"{'profiles':<18}{len(cfg.get('profiles') or {})} with saved settings")
    except Exception as e:
        lines.append(f'could not be read ({type(e).__name__})')
    section('Data (counts only)')
    try:
        import profiles as _prof
        names = _prof.list_profiles()
        lines.append(f'profiles       {len(names)}')
        if speaker:
            lines.append(f'active         {speaker}')
            lines.append(f'recordings     {_prof.clip_count(speaker)} clips')
            lines.append(f'trained        {_prof.is_trained(speaker)}')
            lines.append(f'model size     {_prof.model_size(speaker)}')
            lib = _prof.paths(speaker)['base'] / 'library'
            n = len(list(lib.glob('*.txt'))) if lib.is_dir() else 0
            lines.append(f'pages          {n} (contents not included)')
    except Exception as e:
        lines.append(f'could not be read ({type(e).__name__})')
    section('Models present')
    try:
        models = ROOT / 'models'
        found = sorted((d.name for d in models.iterdir() if d.is_dir())) if models.is_dir() else []
        if found:
            lines.extend((f'  {n}' for n in found))
        else:
            lines.append('  none')
    except OSError:
        lines.append('  could not be listed')
    return '\n'.join(lines) + '\n'

def _redact_file(path: Path) -> str:
    try:
        text = path.read_text(encoding='utf-8', errors='replace')
    except OSError as e:
        return f'[could not read {path.name}: {type(e).__name__}]\n'
    return redact(text)

def diagnostics_bundle(dest: Path | str, speaker: str | None=None) -> Path:
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    log = get('diag')
    part = dest.with_name(dest.name + '.part')
    with zipfile.ZipFile(part, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('report.txt', machine_report(speaker))
        if LOG_DIR.is_dir():
            for p in sorted(LOG_DIR.glob('kara.log*')) + sorted(LOG_DIR.glob('reed.log*')):
                z.writestr(f'logs/{p.name}', _redact_file(p))
        if CRASH_FILE.exists():
            z.writestr(f'logs/{CRASH_FILE.name}', _redact_file(CRASH_FILE))
        legacy = ROOT / 'app_error.log'
        if legacy.exists():
            z.writestr('logs/app_error.log', _redact_file(legacy))
    part.replace(dest)
    log.info('diagnostics written: %s (%d bytes)', dest.name, dest.stat().st_size)
    return dest

def default_bundle_name() -> str:
    return time.strftime('Kara-diagnostics-%Y%m%d-%H%M.zip')

def log_bytes() -> int:
    if not LOG_DIR.is_dir():
        return 0
    return sum((f.stat().st_size for f in LOG_DIR.glob('*') if f.is_file()))
