import argparse
import difflib
import re
import spelling
SENTENCE_END = '.!?।'
COMMANDS = {'delete_word': ['delete last word', 'delete word', 'delete that', 'remove last word', 'take that back', 'scratch that', 'delete last spoken word', 'delete last spoken phrase', 'delete last phrase'], 'delete_sentence': ['delete last sentence', 'delete sentence', 'remove last sentence'], 'delete_line': ['delete last line', 'delete line', 'delete last paragraph'], 'clear': ['delete everything', 'delete all', 'clear everything', 'clear all', 'start over', 'chart over'], 'new_line': ['new line', 'new paragraph', 'next line', 'line break'], 'undo': ['undo', 'undo that', 'go back'], 'redo': ['do it again', 'redo', 'redo that', 'ledo', 'ledo that', 'leado'], 'capitalize': ['capitalize that', 'capitalise that', 'make that uppercase'], 'read': ['read it back', 'read back', 'read that', 'read it', 'read', 'lead it back', 'lead back', 'lead that', 'leed'], 'word_count': ['word count', 'how many words', 'how long is it', 'count the words', 'how many words is that', 'word count please', 'wud count'], 'spell': ['spell mode', 'spelling mode', 'let me spell', 'spell it', 'spell that', 'supermode', 'super mode', 'smell mode', 'spell more', 'spa mode', 'spell word'], 'send': ['done', 'send', 'send it', 'finish', 'that is it', 'tend', 'tend it', 'tent', 'sent it'], 'exit': ['stop editing', 'exit editing', 'stop', 'never mind', 'stop voice typing', 'pause voice typing', 'stop dictating', 'pause dictation', 'stop dictation', 'stop listening'], 'press_enter': ['press enter', 'press return', 'hit enter', 'enter key', 'press the enter key'], 'backspace': ['press backspace', 'backspace', 'hit backspace', 'press the backspace key', 'delete a character', 'delete last letter', 'back space'], 'tab': ['press tab', 'hit tab', 'tab key', 'press the tab key'], 'space': ['press space', 'press spacebar', 'hit space', 'space bar', 'press the space key', 'add a space'], 'select_last': ['select last spoken word', 'select last word', 'select that', 'select last phrase', 'select last spoken phrase', 'select the last word']}
COMMANDS_HI = {'delete_word': ['आखिरी शब्द मिटाओ', 'शब्द मिटाओ', 'यह मिटाओ', 'आखिरी शब्द हटाओ', 'पिछला शब्द मिटाओ', 'यह हटा दो', 'आखिरी शब्द मिटा दो'], 'delete_sentence': ['आखिरी वाक्य मिटाओ', 'वाक्य मिटाओ', 'पिछला वाक्य मिटाओ', 'आखिरी वाक्य हटाओ'], 'delete_line': ['आखिरी पंक्ति मिटाओ', 'पंक्ति मिटाओ', 'लाइन मिटाओ', 'आखिरी लाइन मिटाओ', 'पिछला पैराग्राफ मिटाओ'], 'clear': ['सब मिटाओ', 'सब कुछ मिटाओ', 'सब साफ़ करो', 'नए सिरे से शुरू करो', 'सब कुछ हटा दो'], 'new_line': ['नई पंक्ति', 'नई लाइन', 'नया पैराग्राफ', 'अगली लाइन'], 'undo': ['पहले जैसा', 'पहले जैसा करो', 'वापस लो', 'अनडू'], 'redo': ['फिर से करो', 'दोबारा करो', 'रीडू', 'फिर से कर दो'], 'capitalize': ['बड़ा अक्षर करो', 'कैपिटल करो', 'इसे बड़ा करो'], 'read': ['पढ़कर सुनाओ', 'वापस पढ़ो', 'यह पढ़ो', 'पढ़ो', 'मुझे पढ़कर सुनाओ'], 'word_count': ['कितने शब्द', 'कितने शब्द हैं', 'शब्द गिनो', 'शब्द गिनती', 'कितने शब्द हो गए'], 'spell': ['स्पेलिंग मोड', 'स्पेल मोड', 'अक्षर बोलूँगा', 'मैं अक्षर बोलूँगा'], 'send': ['भेज दो', 'भेजो', 'हो गया', 'पूरा हुआ', 'भेज दीजिए'], 'exit': ['संपादन बंद करो', 'एडिटिंग बंद करो', 'रुको', 'बस करो', 'सुनना बंद करो', 'बोलना बंद'], 'press_enter': ['एंटर दबाओ', 'एंटर', 'एंटर की दबाओ'], 'backspace': ['बैकस्पेस दबाओ', 'बैकस्पेस', 'एक अक्षर मिटाओ', 'एक अक्षर पीछे'], 'tab': ['टैब दबाओ', 'टैब', 'टैब की दबाओ'], 'space': ['स्पेस दबाओ', 'स्पेस', 'जगह छोड़ो', 'एक जगह छोड़ो'], 'select_last': ['आखिरी शब्द चुनो', 'यह चुनो', 'आखिरी शब्द सेलेक्ट करो', 'पिछला शब्द चुनो']}
COMMAND_TABLES = {'hi': COMMANDS_HI}

def builtins_for(language: str | None) -> dict:
    code = (language or 'en').strip().lower().split('-')[0]
    extra = COMMAND_TABLES.get(code)
    if not extra:
        return COMMANDS
    merged = {k: list(v) for k, v in COMMANDS.items()}
    for key, phrases in extra.items():
        merged.setdefault(key, [])
        for p in phrases:
            if p not in merged[key]:
                merged[key].append(p)
    return merged
_CHANGE_SPELL = re.compile('\\b(?:change|replace|correct|fix)\\s+(.+?)\\s+(?:to\\s+|with\\s+|into\\s+)?spell(?:ing|ed|s)?\\s+(.+)')
_CHANGE_VERBS = 'chang\\w*|replac\\w*|correct\\w*|fix\\w*|mak\\w*|swap\\w*|turn\\w*|switch\\w*'
_CHANGE = re.compile(f'\\b(?:{_CHANGE_VERBS})\\s+(.+?)\\s+(?:to|with|into|for|be)\\s+(.+)')
_INSTEAD = re.compile('\\binstead\\s+of\\s+(.+?)\\s+(?:say|put|use|write)\\s+(.+)$', re.IGNORECASE)
_SCOPE = '(?:\\s+(?P<scope_kind>line|sentence|paragraph)\\s+(?P<scope_n>\\d+|\\w+))?'
_WORD_NUMBERS = {'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10, 'first': 1, 'second': 2, 'third': 3, 'fourth': 4, 'fifth': 5, 'sixth': 6, 'seventh': 7, 'eighth': 8, 'ninth': 9, 'tenth': 10, 'last': -1}

def _is_mark(word: str) -> bool:
    s = re.sub('^(?:a|an|the)\\s+', '', (word or '').strip().lower())
    try:
        import punctuation
        return s in punctuation.MARKS or s.rstrip('s') in punctuation.MARKS
    except Exception:
        return False

def _ordinal_number(text: str) -> int:
    s = (text or '').strip().lower()
    if s.isdigit():
        return int(s)
    return _WORD_NUMBERS.get(s, 0)

def scope_span(text: str, kind: str, n: int) -> tuple[int, int]:
    if n == 0:
        return (0, len(text))
    if kind == 'line':
        parts, sep = (text.split('\n'), 1)
    elif kind == 'paragraph':
        parts, sep = (text.split('\n\n'), 2)
    else:
        import punctuation
        spans = punctuation._sentence_spans(text)
        if not spans:
            return (0, len(text))
        idx = len(spans) - 1 if n == -1 else n - 1
        return spans[idx] if 0 <= idx < len(spans) else (0, len(text))
    idx = len(parts) - 1 if n == -1 else n - 1
    if not 0 <= idx < len(parts):
        return (0, len(text))
    start = sum((len(p) + sep for p in parts[:idx]))
    return (start, start + len(parts[idx]))
_ADD_WORD = re.compile('^\\s*(?:add|put|insert|place|stick)\\s+(?P<word>.+?)\\s+(?P<where>after|before)\\s+(?P<target>.+?)' + _SCOPE + '\\s*$', re.IGNORECASE)
_MATCH_CUTOFF = 0.72

def parse_command(text: str):
    t = text.strip().lower().rstrip(SENTENCE_END)
    if not t:
        return ('unknown', text)
    ms = _CHANGE_SPELL.search(t)
    if ms:
        return ('change_spell', (ms.group(1).strip(), ms.group(2).strip()))
    t = spelling.expand_spelled(t)[0]
    mi = _INSTEAD.search(t)
    if mi:
        return ('change', (mi.group(1).strip(), mi.group(2).strip()))
    m = _CHANGE.search(t)
    if m:
        return ('change', (m.group(1).strip(), m.group(2).strip()))
    ma = _ADD_WORD.match(t)
    if ma and ma.group('word').strip() and (not _is_mark(ma.group('word'))):
        scope = None
        if ma.group('scope_kind'):
            scope = (ma.group('scope_kind').lower(), _ordinal_number(ma.group('scope_n')))
        return ('insert_word', (ma.group('word').strip(), ma.group('where').lower(), ma.group('target').strip(), scope))
    best_cmd, best_score = _nearest_command(t)
    if best_score >= _MATCH_CUTOFF:
        return (best_cmd, None)
    return ('unknown', text)
ACTIVE_COMMANDS = COMMANDS

def use_commands(table: dict | None) -> None:
    global ACTIVE_COMMANDS
    ACTIVE_COMMANDS = table if table else COMMANDS

def _nearest_command(t: str) -> tuple[str | None, float]:
    best_cmd, best_score = (None, 0.0)
    for cmd, phrases in ACTIVE_COMMANDS.items():
        for p in phrases:
            score = difflib.SequenceMatcher(None, t, p).ratio()
            if score > best_score:
                best_cmd, best_score = (cmd, score)
    return (best_cmd, best_score)
RESCUE_CONFIDENCE = 0.9
RESCUE_MIN_WORDS = 2

def command_confidence(text: str) -> tuple[str | None, float]:
    t = (text or '').strip().lower().rstrip(SENTENCE_END)
    if not t:
        return (None, 0.0)
    return _nearest_command(t)
_CHANGE_VERB = re.compile(f'^\\s*(?:{_CHANGE_VERBS})\\s+(.+)$', re.IGNORECASE)
_SEPARATORS = (' to ', ' with ', ' into ', ' for ')

def _match_ratio(buffer: str, phrase: str) -> float:
    if not phrase:
        return 0.0
    if phrase.lower() in buffer.lower():
        return 1.0
    words = buffer.split()
    n = len(phrase.split())
    best = 0.0
    for size in {max(1, n - 1), n, n + 1}:
        for i in range(len(words) - size + 1):
            cand = ' '.join(words[i:i + size])
            best = max(best, difflib.SequenceMatcher(None, cand.lower(), phrase.lower()).ratio())
    return best

def resolve_change(text: str, buffer: str):
    m = _CHANGE_VERB.match(text.strip().rstrip(SENTENCE_END))
    if not m:
        return None
    rest = m.group(1)
    best = None
    for sep in _SEPARATORS:
        i = rest.find(sep)
        while i >= 0:
            replacement = rest[i + len(sep):].strip()
            for target in (rest[:i].strip(), rest[:i + len(sep)].strip()):
                if not (target and replacement):
                    continue
                score = _match_ratio(buffer, target) + min(len(target), 40) / 400.0
                if best is None or score > best[0]:
                    best = (score, target, replacement)
            i = rest.find(sep, i + 1)
    return (best[1], best[2]) if best else None

def _fuzzy_replace(text: str, target: str, replacement: str, exact: bool=False):
    idx = text.lower().find(target.lower())
    if idx >= 0:
        return (text[:idx] + replacement + text[idx + len(target):], True)
    if exact:
        return (text, False)
    words = text.split()
    n = len(target.split())
    best = (0.0, None)
    for size in {max(1, n - 1), n, n + 1}:
        for i in range(len(words) - size + 1):
            cand = ' '.join(words[i:i + size])
            r = difflib.SequenceMatcher(None, cand.lower(), target.lower()).ratio()
            if r > best[0]:
                best = (r, (i, size))
    if best[1] and best[0] >= 0.6:
        i, size = best[1]
        words[i:i + size] = [replacement]
        return (' '.join(words), True)
    return (text, False)

class Editor:

    def __init__(self, text: str=''):
        self.text = text
        self._undo: list[str] = []
        self._redo: list[str] = []

    def _snapshot(self):
        self._undo.append(self.text)
        self._redo.clear()

    def dictate(self, s: str):
        self._snapshot()
        sep = '' if not self.text or self.text.endswith(('\n', ' ')) else ' '
        self.text += sep + s.strip()

    def type_char(self, ch: str):
        self._snapshot()
        self.text += ch

    def delete_last_word(self):
        self._snapshot()
        self.text = self.text.rstrip()
        self.text = self.text[:self.text.rfind(' ') + 1].rstrip() if ' ' in self.text else ''

    def delete_last_sentence(self):
        self._snapshot()
        parts = re.split('(?<=[.!?])\\s+', self.text.rstrip())
        self.text = ' '.join(parts[:-1]).rstrip() if len(parts) > 1 else ''

    def delete_last_line(self):
        self._snapshot()
        self.text = self.text.rstrip('\n').rpartition('\n')[0]

    def change(self, target: str, replacement: str, exact: bool=False) -> bool:
        new, found = _fuzzy_replace(self.text, target, replacement, exact)
        if found:
            self._snapshot()
            self.text = new
        return found

    def punctuate(self, cmd: dict) -> tuple[bool, str]:
        import punctuation
        new, ok, msg = punctuation.apply_edit(self.text, cmd)
        if ok:
            self._snapshot()
            self.text = new
        return (ok, msg)

    def capitalize_last(self):
        self._snapshot()
        words = self.text.split(' ')
        if words and words[-1]:
            words[-1] = words[-1].capitalize()
            self.text = ' '.join(words)

    def new_line(self):
        self._snapshot()
        self.text = self.text.rstrip() + '\n'

    def clear(self):
        self._snapshot()
        self.text = ''

    def undo(self) -> bool:
        if not self._undo:
            return False
        self._redo.append(self.text)
        self.text = self._undo.pop()
        return True

    def redo(self) -> bool:
        if not self._redo:
            return False
        self._undo.append(self.text)
        self.text = self._redo.pop()
        return True

def find_target(text: str, target: str, scope=None) -> list[tuple[int, int]]:
    import punctuation
    a, b = (0, len(text))
    if scope:
        a, b = scope_span(text, scope[0], scope[1])
    hits = punctuation.word_occurrences(text[a:b], target)
    return [(s + a, e + a) for s, e in hits]

def insert_word(ed: Editor, word: str, where: str, target: str, scope=None) -> str:
    hits = find_target(ed.text, target, scope)
    if not hits:
        where_txt = f' in {scope[0]} {scope[1]}' if scope else ''
        return f"couldn't find '{target}'{where_txt}"
    if len(hits) > 1:
        return f"there are {len(hits)} of '{target}' — say which line, like 'line 2'"
    a, b = hits[0]
    ed._snapshot()
    if where == 'after':
        ed.text = ed.text[:b] + ' ' + word + ed.text[b:]
    else:
        ed.text = ed.text[:a] + word + ' ' + ed.text[a:]
    return f"added '{word}' {where} '{target}'"

def apply_command(ed: Editor, text: str, on_change=None) -> str:
    text, spelled = spelling.expand_spelled(text)
    cmd, args = parse_command(text)
    if cmd == 'change':
        args = resolve_change(text, ed.text) or args
        ok = ed.change(*args, exact=args[0].lower() in spelled)
        if on_change:
            on_change(args[0], args[1], ok)
        return f"changed to '{args[1]}'" if ok else f"couldn't find '{args[0]}'"
    if cmd == 'insert_word':
        return insert_word(ed, *args)
    if cmd == 'delete_word':
        ed.delete_last_word()
        return 'deleted last word'
    if cmd == 'delete_sentence':
        ed.delete_last_sentence()
        return 'deleted last sentence'
    if cmd == 'delete_line':
        ed.delete_last_line()
        return 'deleted last line'
    if cmd == 'clear':
        ed.clear()
        return 'cleared'
    if cmd == 'new_line' or cmd == 'press_enter':
        ed.new_line()
        return 'new line'
    if cmd == 'backspace':
        if not ed.text:
            return 'nothing to delete'
        ed._snapshot()
        ed.text = ed.text[:-1]
        return 'deleted a character'
    if cmd == 'tab':
        ed._snapshot()
        ed.text += '\t'
        return 'tab'
    if cmd == 'space':
        ed._snapshot()
        ed.text += ' '
        return 'space'
    if cmd == 'select_last':
        return 'SELECT_LAST'
    if cmd == 'capitalize':
        ed.capitalize_last()
        return 'capitalized'
    if cmd == 'undo':
        return 'undone' if ed.undo() else 'nothing to undo'
    if cmd == 'redo':
        return 'redone' if ed.redo() else 'nothing to redo'
    if cmd == 'read':
        return ed.text or '(empty)'
    if cmd == 'word_count':
        n = len(ed.text.split())
        return 'the page is empty' if n == 0 else f'{n} word' if n == 1 else f'{n} words'
    if cmd == 'spell':
        return 'SPELL'
    if cmd == 'send':
        return 'SEND'
    if cmd == 'exit':
        return 'EXIT'
    return f"didn't catch that: {text!r}"

def speak(text: str, device: int | None=None, voice: str | None=None, rate: int | None=None) -> None:
    """Say something aloud. voices.py is the good path -- Piper, or the system
    voices it enumerates. This is the fallback for when no catalogue is
    available yet, and it goes through the platform layer rather than assuming
    PowerShell exists."""
    import osbridge
    try:
        import config as _config
        import voices as _voices
        cfg = _config.load()
        want = voice if voice is not None else cfg.get('tts_voice')
        speed = rate if rate is not None else int(cfg.get('tts_rate', 0) or 0)
        if _voices.catalogue():
            _voices.speak(text, voice_id=want, device=device, rate=speed)
            return
    except Exception:
        pass
    speed = rate if rate is not None else 0
    if device is None:
        osbridge.tts_speak_direct(text, None, speed)
        return
    # A specific output device was asked for, so the audio has to become a file
    # Kara can route, rather than going straight to the default output.
    import tempfile
    from pathlib import Path as _Path
    wav = _Path(tempfile.NamedTemporaryFile(suffix='.wav', delete=False).name)
    try:
        if not osbridge.tts_to_wav(text, wav, None, speed):
            osbridge.tts_speak_direct(text, None, speed)
            return
        import sounddevice as sd
        import soundfile as sf
        data, sr = sf.read(str(wav), dtype='float32')
        sd.play(data, sr, device=device)
        sd.wait()
    except Exception:
        osbridge.tts_speak_direct(text, None, speed)
    finally:
        wav.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser(description='Editing-mode REPL (type commands as if spoken).')
    parser.add_argument('--text', default='', help='starting buffer')
    parser.add_argument('--tts', action='store_true', help='speak each result back')
    args = parser.parse_args()
    ed = Editor(args.text)
    print('Type a command (or plain text to dictate). Ctrl-C to quit.\n')
    print(f'buffer: {ed.text!r}')
    while True:
        try:
            line = input('> ').strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line.startswith('.'):
            ed.dictate(line[1:].strip())
            result = 'dictated'
        else:
            result = apply_command(ed, line)
            if result in ('SPELL', 'SEND', 'EXIT', 'SELECT_LAST'):
                print(f'[signal: {result}]')
                if result == 'EXIT':
                    break
                continue
        print(f'  {result}')
        print(f'buffer: {ed.text!r}')
        if args.tts:
            speak(result if result != ed.text else ed.text)
