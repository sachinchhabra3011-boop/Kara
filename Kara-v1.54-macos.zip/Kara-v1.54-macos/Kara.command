#!/bin/bash
# Kara -- double-click this. It is the only thing anyone needs to touch.
#
# IT SETS UP IF IT HAS TO, then starts. Same contract as Kara.cmd on Windows.
#
# %~dp0 on Windows becomes this on a Mac: resolve the script's own folder so
# nothing is tied to the path it was built in, and it survives being moved to
# Applications, the Desktop, or anywhere else.
cd "$(dirname "$(readlink -f "$0" 2>/dev/null || echo "$0")")" || exit 1
ROOT="$(pwd)"

printf '\033]0;Kara\007'   # title the Terminal window

say_block() { printf '\n  %s\n' "$@"; }

# ---------------------------------------------------------------- extracted?
# The Windows version guards against being run from inside the .zip. macOS
# Archive Utility unpacks the whole archive on double-click, so that exact
# failure does not happen here -- but a half-copied folder does, and the test
# is the same one: the app itself has to be beside this file.
if [ ! -f "$ROOT/src/gui.py" ]; then
  say_block "================================================================" \
            "  Kara is not all here." \
            "================================================================" \
            "" \
            "  src/gui.py is missing from:" \
            "    $ROOT" \
            "" \
            "  Unzip Kara again and open the folder that appears, then" \
            "  double-click Kara in there." ""
  read -r -p "  Press return to close. " _
  exit 1
fi

# --------------------------------------------------------------- Gatekeeper
# THE FIRST THING macOS DOES TO A DOWNLOAD IS QUARANTINE IT. Everything
# unpacked from a zip that came off the internet carries com.apple.quarantine,
# and a quarantined .command double-clicked in Finder is refused with
# "cannot be opened because it is from an unidentified developer" -- with no
# hint that the fix is one command. This is the Mac equivalent of the
# run-it-from-inside-the-zip trap, and it is the single most likely reason a
# first run never happens at all.
#
# Reaching this line means the script IS running, so the user already got
# past it (or Finder allowed it). Clear the flag from the whole folder so the
# SECOND launch, and every file Kara later reaches for, is not refused.
if command -v xattr >/dev/null 2>&1; then
  xattr -dr com.apple.quarantine "$ROOT" >/dev/null 2>&1 || true
fi

# The executable bit does not always survive a round trip through a zip, an
# email, or a copy off a Windows machine. Restore it rather than explain it.
chmod +x "$ROOT/Kara.command" "$ROOT/scripts/setup.sh" >/dev/null 2>&1 || true

VENV_PY="$ROOT/.venv/bin/python"

if [ ! -x "$VENV_PY" ]; then
  say_block "Setting Kara up on this computer. This happens once." \
            "It downloads about 3 GB and takes a while on a slow" \
            "connection. It shows progress throughout." ""
  bash "$ROOT/scripts/setup.sh" || {
    say_block "Setup did not finish. The messages above say where it stopped." \
              "" \
              "The usual causes are no internet connection, or the download" \
              "being interrupted. Nothing is broken -- running Kara again" \
              "picks up where it left off." ""
    read -r -p "  Press return to close. " _
    exit 1
  }
fi

if [ ! -x "$VENV_PY" ]; then
  say_block "Setup finished but the Python it installed is not there." \
            "Delete the .venv folder inside Kara and try again." ""
  read -r -p "  Press return to close. " _
  exit 1
fi

# ------------------------------------------------------------------- launch
# Windows uses pythonw.exe to avoid a console window. macOS has no such split,
# so the Terminal window stays -- but it is not doing anything useful once the
# app is up, so hand the process off and let the window be closed.
say_block "Starting Kara."
exec "$VENV_PY" "$ROOT/src/gui.py" "$@"
