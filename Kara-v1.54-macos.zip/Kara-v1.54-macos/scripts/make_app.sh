#!/bin/bash
# Build Kara.app -- the bundle that makes macOS treat Kara as an application.
#
#   bash scripts/make_app.sh [version]
#
# WHY A BUNDLE AND NOT JUST Kara.command. A .command is a shell script with an
# open-in-Terminal handler on it. macOS does not index scripts as applications,
# so Kara never appeared in Spotlight, never got a Dock icon of its own, and
# every permission prompt it triggered was attributed to Terminal. Only a real
# .app bundle is an application as far as Launch Services, Spotlight and TCC
# are concerned.
#
# THE BUNDLE IS A LAUNCHER, NOT A CONTAINER. Kara's payload -- src/, .venv/,
# models/, data/ -- stays in the folder beside it, because that is what every
# other part of Kara already assumes (config.ROOT is src/../) and because an
# app that writes gigabytes inside its own bundle breaks in ways that are hard
# to explain. Contents/MacOS/Kara walks up three levels to find the folder.

set -eu
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

VERSION="${1:-$(sed -n "s/^VERSION = '\(.*\)'$/\1/p" src/gui.py | head -1)}"
[ -z "$VERSION" ] && { echo "could not determine version"; exit 1; }

APP="$ROOT/Kara.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

# ---------------------------------------------------------------- Info.plist
# CFBundleIdentifier IS KARA'S IDENTITY TO macOS. Microphone and Accessibility
# grants are recorded against it, so it must never change between versions --
# changing it silently revokes every permission the user has already given and
# makes Kara ask again as if it were a different program.
#
# NSMicrophoneUsageDescription is NOT OPTIONAL. A bundled app that touches the
# microphone without this key is killed by the system on the spot, with a crash
# rather than a prompt. The unbundled .command escaped this only because the
# prompt was Terminal's problem.
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>                  <string>Kara</string>
    <key>CFBundleDisplayName</key>           <string>Kara</string>
    <key>CFBundleIdentifier</key>            <string>com.kara.voicetotext</string>
    <key>CFBundleExecutable</key>            <string>Kara</string>
    <key>CFBundleIconFile</key>              <string>kara</string>
    <key>CFBundlePackageType</key>           <string>APPL</string>
    <key>CFBundleSignature</key>             <string>????</string>
    <key>CFBundleShortVersionString</key>    <string>${VERSION}</string>
    <key>CFBundleVersion</key>               <string>${VERSION}</string>
    <key>CFBundleInfoDictionaryVersion</key> <string>6.0</string>
    <key>LSMinimumSystemVersion</key>        <string>12.0</string>
    <key>LSApplicationCategoryType</key>     <string>public.app-category.productivity</string>
    <key>NSHighResolutionCapable</key>       <true/>
    <key>NSSupportsAutomaticGraphicsSwitching</key> <true/>
    <key>NSHumanReadableCopyright</key>      <string>Kara. Free for personal use.</string>
    <key>NSMicrophoneUsageDescription</key>
    <string>Kara listens to your voice so it can turn what you say into writing. Recordings stay on this computer.</string>
    <key>NSSpeechRecognitionUsageDescription</key>
    <string>Kara turns your speech into writing on this computer.</string>
    <key>NSAppleEventsUsageDescription</key>
    <string>Kara puts your writing into the document you choose.</string>
</dict>
</plist>
PLIST

# ------------------------------------------------------------------ launcher
cat > "$APP/Contents/MacOS/Kara" <<'LAUNCH'
#!/bin/bash
# Kara.app launcher. Finds the Kara folder this bundle sits in, then starts.
BUNDLE="$(cd "$(dirname "$0")/../.." && pwd)"
ROOT="$(cd "$BUNDLE/.." && pwd)"

note() { osascript -e "display dialog \"$1\" buttons {\"OK\"} default button 1 with title \"Kara\" with icon caution" >/dev/null 2>&1; }

# GATEKEEPER APP TRANSLOCATION. A quarantined, unsigned app opened from where
# it was unzipped is COPIED to a read-only mount under /private/var/folders and
# run from there -- so the folder next to it, the one holding src/ and the
# trained voice model, is simply not there. The app appears to launch and then
# cannot find itself. The fix is for the user to move the folder once, which
# clears translocation, so say that rather than failing silently.
case "$BUNDLE" in
  */AppTranslocation/*)
    note "macOS is running Kara from a temporary copy, so it cannot reach its own files.\n\nMove the Kara folder to your Applications folder or your home folder, then open Kara again. You only need to do this once."
    exit 1 ;;
esac

if [ ! -f "$ROOT/src/gui.py" ]; then
  note "Kara cannot find its program files.\n\nKara.app has to stay inside the Kara folder, next to the src folder. If you moved it out on its own, put it back."
  exit 1
fi

# Clear the download flag from the whole folder so the second launch is not
# refused and nothing Kara later opens is treated as untrusted.
xattr -dr com.apple.quarantine "$ROOT" >/dev/null 2>&1 || true

VENV_PY="$ROOT/.venv/bin/python"

if [ ! -x "$VENV_PY" ]; then
  # FIRST RUN NEEDS A VISIBLE TERMINAL. Setup downloads about 3 GB and takes a
  # long time; run silently inside the bundle it would look like Kara simply
  # never opened. Hand it to Terminal so the progress is watchable, exactly as
  # double-clicking Kara.command does.
  osascript -e "tell application \"Terminal\"
    activate
    do script \"clear; bash '$ROOT/scripts/setup.sh' && echo && echo '  Setup finished. Opening Kara.' && open -a '$BUNDLE'\"
  end tell" >/dev/null 2>&1
  exit 0
fi

exec "$VENV_PY" "$ROOT/src/gui.py" "$@"
LAUNCH
chmod +x "$APP/Contents/MacOS/Kara"

# -------------------------------------------------------------------- icon
if [ ! -f "$ROOT/assets/kara.icns" ]; then
  echo "  no assets/kara.icns yet -- run: .venv/bin/python scripts/make_icon.py"
else
  cp "$ROOT/assets/kara.icns" "$APP/Contents/Resources/kara.icns"
fi

# ------------------------------------------------------------------- sign
# SIGNING IS THE LAST STEP, ALWAYS. A signature seals the bundle's contents:
# anything written inside it afterwards invalidates the seal, and macOS refuses
# a bundle with a BROKEN seal more firmly than one with no seal at all. chmod
# and xattr are fine (checked); editing a file inside is not.
#
# If a real Developer ID is installed, use it -- that is the signature that
# removes the "unidentified developer" warning, once the app is also notarised.
# Otherwise fall back to ad-hoc, which is free and needs no Apple account.
#
# AD-HOC DOES NOT SATISFY GATEKEEPER and is not pretending to. What it buys is
# a stable code identity: macOS records Microphone and Accessibility grants
# against it, so they survive a rebuild or a move instead of being silently
# forgotten and asked for again. For an app whose two permissions are the
# difference between working and not, that is worth having.
IDENTITY="$(security find-identity -v -p codesigning 2>/dev/null \
            | grep -o '"Developer ID Application: [^"]*"' | head -1 | tr -d '"')"

if [ -n "$IDENTITY" ]; then
  echo "  signing with: $IDENTITY"
  codesign --force --deep --options runtime --timestamp \
           --sign "$IDENTITY" "$APP" \
    || { echo "  FAIL: signing failed"; exit 1; }
  echo "  NOTE: a Developer ID signature only removes the Gatekeeper warning"
  echo "        once the zip has also been notarised. See scripts/NOTARIZING.md"
else
  codesign --force --deep --sign - "$APP" 2>/dev/null \
    || echo "  WARN: could not ad-hoc sign the bundle"
fi

# A broken seal is worse than none, so prove it is intact before shipping it.
if ! codesign --verify --deep --strict "$APP" 2>/dev/null; then
  echo "  FAIL: the bundle's signature does not verify. Refusing to ship a"
  echo "        bundle macOS would call damaged."
  exit 1
fi
codesign -dv --verbose=2 "$APP" 2>&1 | grep -E "^Identifier|^Signature" | sed 's/^/  /'

# Tells Finder the directory is a bundle straight away rather than after a
# rescan, which is what makes it show as one icon instead of a folder.
touch "$APP"

echo "built: $APP  (version $VERSION)"
