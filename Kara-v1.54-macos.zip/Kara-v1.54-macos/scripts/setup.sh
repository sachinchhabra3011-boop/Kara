#!/bin/bash
# Kara -- one-shot setup for a fresh Mac.
#
#   bash scripts/setup.sh           # app only
#   bash scripts/setup.sh --full    # + the training/eval stack
#
# Checks rather than assumes, for the same reason setup.ps1 does: the failures
# that matter are the ones that leave a broken-but-running install, which
# surface later as "it's slow" or "it can't hear me" rather than as an error.

set -u
FULL=0
SKIP_MODEL=0
for a in "$@"; do
  case "$a" in
    --full) FULL=1 ;;
    --skip-model) SKIP_MODEL=1 ;;
  esac
done

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT" || exit 1

say()  { printf '\n=== %s\n' "$1"; }
ok()   { printf '  OK   %s\n' "$1"; }
warn() { printf '  WARN %s\n' "$1"; }
die()  { printf '  FAIL %s\n' "$1"; exit 1; }

# ------------------------------------------------------------------ platform
say "This computer"
ARCH="$(uname -m)"
ok "macOS $(sw_vers -productVersion) on $ARCH"
if [ "$ARCH" != "arm64" ]; then
  warn "This is an Intel Mac. Kara will run, but every model is slower here"
  warn "and Apple's own acceleration is not available. Expect the smaller"
  warn "models to be the usable ones."
fi

# -------------------------------------------------------------------- Python
say "Python"
# KARA NEEDS 3.12, AND THIS MUST NOT REQUIRE AN ADMIN PASSWORD. The python.org
# installer is a .pkg -- it prompts for a password, which is a wall for exactly
# the person this app is for. Homebrew is not present on a stock Mac either.
# So: use whatever suitable Python is already here, and otherwise fetch a
# self-contained build into the user's own home directory with uv.
#
# 3.12 SPECIFICALLY, not "3.12 or newer". soxr and torch 2.5.1 publish no
# cp313 wheels, so a 3.13 venv tries to compile them from source and fails on
# a Mac with no build tools. Checked against PyPI, not assumed.
PY=""
for c in python3.12 python3.11 python3.10; do
  if command -v "$c" >/dev/null 2>&1; then
    v="$("$c" --version 2>&1)"
    case "$v" in
      "Python 3.1"[012]*) PY="$(command -v "$c")"; ok "$v  ($PY)"; break ;;
    esac
  fi
done

if [ -z "$PY" ]; then
  for k in "$HOME/.local/share/uv/python"/cpython-3.12*/bin/python3.12 \
           "/Library/Frameworks/Python.framework/Versions/3.12/bin/python3.12" \
           "/opt/homebrew/bin/python3.12" "/usr/local/bin/python3.12"; do
    [ -x "$k" ] && { PY="$k"; ok "$("$k" --version 2>&1)  ($k)"; break; }
  done
fi

if [ -z "$PY" ]; then
  printf '  no suitable Python found. Installing one just for Kara...\n'
  printf '  (into your home folder -- no password, nothing system-wide)\n'
  UV=""
  for u in "$HOME/.local/bin/uv" "$HOME/Library/Python/3.9/bin/uv" "$(command -v uv 2>/dev/null)"; do
    [ -n "$u" ] && [ -x "$u" ] && { UV="$u"; break; }
  done
  if [ -z "$UV" ]; then
    # uv comes from PyPI as a normal wheel, so this is a package install from
    # the standard index rather than piping a script from the web into a shell.
    /usr/bin/python3 -m pip install --user --quiet uv >/dev/null 2>&1
    for u in "$HOME/Library/Python/3.9/bin/uv" "$HOME/.local/bin/uv"; do
      [ -x "$u" ] && { UV="$u"; break; }
    done
  fi
  [ -z "$UV" ] && die "Could not install the Python fetcher (uv).
       Check the internet connection and try again, or install Python 3.12
       yourself from https://www.python.org/downloads/"
  "$UV" python install 3.12 || die "Could not download Python 3.12."
  for k in "$HOME/.local/share/uv/python"/cpython-3.12*/bin/python3.12; do
    [ -x "$k" ] && PY="$k"
  done
  [ -z "$PY" ] && die "Python 3.12 installed but could not be found afterwards."
  ok "$("$PY" --version 2>&1)  ($PY)"
fi

# --------------------------------------------------------- virtual environment
say "Virtual environment"
if [ -x "$ROOT/.venv/bin/python" ]; then
  ok ".venv already exists (delete it to rebuild from scratch)"
else
  "$PY" -m venv "$ROOT/.venv" || die "venv creation failed"
  [ -x "$ROOT/.venv/bin/python" ] || die "venv creation failed"
  ok "created .venv"
fi
VPY="$ROOT/.venv/bin/python"

# ------------------------------------------------------------------ hardware
say "Acceleration"
# NO CUDA EXISTS ON ANY MAC. Apple has not shipped an NVIDIA GPU since 2013 and
# CUDA has not supported macOS since 10.13, so the whole GPU/CPU branch that
# setup.ps1 agonises over collapses to one answer here: the CTranslate2 CPU
# engine, every time. That is not a downgrade -- it is the same engine the
# Windows build uses on any machine without an NVIDIA card, and Apple Silicon
# runs it well.
if [ "$ARCH" = "arm64" ]; then
  ok "Apple Silicon -- Kara uses the CPU engine (int8), which is quick here"
else
  ok "Intel -- Kara uses the CPU engine (int8)"
fi

say "PyTorch"
# PLAIN PyPI, NO CUDA INDEX. setup.ps1 must fetch torch from the cu121 index
# first or it silently gets a CPU-only build; on a Mac the PyPI wheel IS the
# right one and the CUDA index has nothing to offer.
if "$VPY" -c "import torch" >/dev/null 2>&1; then
  ok "torch already installed"
else
  printf '  installing torch (~100 MB, much smaller than the Windows CUDA build)\n'
  "$VPY" -m pip install --quiet --upgrade pip >/dev/null 2>&1
  "$VPY" -m pip install "torch==2.5.1" --progress-bar on || die "torch install failed"
fi

say "Dependencies"
REQ="requirements-mac.txt"
[ "$FULL" = "1" ] && [ -f "$ROOT/requirements.txt" ] && REQ="requirements.txt"
printf '  installing %s\n' "$REQ"
"$VPY" -m pip install -r "$ROOT/$REQ" --progress-bar on || die "dependency install failed"
ok "$REQ"

# ------------------------------------------------------------------- verify
say "Verifying the install actually works"
CHECK="$("$VPY" - <<'PYCHK' 2>&1
import sys
import torch, transformers
print('torch       ', torch.__version__)
print('transformers', transformers.__version__)
print('mps         ', torch.backends.mps.is_available())
try:
    import ctranslate2, faster_whisper
    print('ctranslate2 ', ctranslate2.__version__)
except Exception as e:
    print('CT2MISSING', e)
try:
    import PySide6, sounddevice, soundfile, soxr
    from PySide6 import QtCore
    print('PySide6     ', QtCore.__version__)
except Exception as e:
    print('QTMISSING', e)
try:
    import Quartz, AppKit
    from ApplicationServices import AXIsProcessTrusted
    print('pyobjc       ok')
except Exception as e:
    print('OBJCMISSING', e)
if not transformers.__version__.startswith('5'):
    print('BADVERSION'); sys.exit(2)
PYCHK
)"
printf '%s\n' "$CHECK" | sed 's/^/  /'
case "$CHECK" in
  *BADVERSION*)  die "transformers must be 5.x (see requirements-mac.txt)" ;;
  *CT2MISSING*)  die "CTranslate2 did not install -- Kara has no speech engine without it" ;;
  *QTMISSING*)   die "PySide6 did not install -- Kara has no window without it" ;;
  *OBJCMISSING*) warn "pyobjc is missing: Kara will run, but 'send to a document' and
       the Mac voices will not work. Re-run setup to try again." ;;
esac

# --------------------------------------------------------------- microphone
say "Microphone"
"$VPY" "$ROOT/src/record.py" --list-devices 2>&1 | head -12 | sed 's/^/  /'
warn "macOS asks for microphone permission the FIRST time Kara listens. The"
warn "request appears in the name of whatever launched Kara (Terminal, if you"
warn "double-clicked Kara). Say yes, or Kara hears silence with no error."

# ------------------------------------------------------------- permissions
say "Permission to type into other programs"
warn "Kara's 'send' puts your writing straight into Word, Mail or a browser."
warn "macOS requires Accessibility permission for that, and will not ask on"
warn "its own. Kara shows a button for it when you first use send."
warn "  System Settings > Privacy & Security > Accessibility"
warn "Until then, send still copies to the clipboard and you press Cmd+V."

# ------------------------------------------------------------------- model
if [ "$SKIP_MODEL" = "0" ]; then
  say "Preparing the speech model for this computer"
  # NOT OPTIONAL, exactly as on a Windows machine with no NVIDIA card: nothing
  # else downloads this later, so without it the first launch is KARA-2003.
  printf '  fetching the medium model built for the processor -- about 1.5 GB.\n'
  printf '  Skip with --skip-model.\n'
  if "$VPY" "$ROOT/src/cpu_engine.py" --fetch-base --model medium \
     && [ -f "$ROOT/models/ct2/_base-medium/model.bin" ]; then
    ok "speech model ready (models/ct2/_base-medium)"
  else
    warn "COULD NOT FETCH THE MODEL. Kara will start but will have no"
    warn "recogniser until this succeeds. Retry with:"
    warn "  .venv/bin/python src/cpu_engine.py --fetch-base --model medium"
  fi
fi

# ------------------------------------------------------------ registration
say "Making Kara an application"
# WITHOUT THIS STEP KARA IS NOT IN SPOTLIGHT. A .app is only an application
# once Launch Services has been told about it; until then macOS treats the
# folder as a folder, Spotlight will not offer it, and it gets no Dock identity
# of its own. Unzipping alone does not do this reliably -- the indexer picks
# new bundles up eventually and sometimes not at all in a folder it has already
# scanned, which is exactly how the first macOS build came to be invisible.
if [ ! -d "$ROOT/Kara.app" ]; then
  # A zip that somehow arrived without it, or a source checkout.
  if [ ! -f "$ROOT/assets/kara.icns" ] && [ -x "$VPY" ]; then
    "$VPY" "$ROOT/scripts/make_icon.py" >/dev/null 2>&1 || true
  fi
  [ -f "$ROOT/scripts/make_app.sh" ] && bash "$ROOT/scripts/make_app.sh" >/dev/null 2>&1 || true
fi

if [ -d "$ROOT/Kara.app" ]; then
  chmod +x "$ROOT/Kara.app/Contents/MacOS/Kara" 2>/dev/null || true
  # The download flag has to go before registering: Launch Services will not
  # index a quarantined bundle properly, and Gatekeeper would run it from a
  # read-only temporary copy instead of from the folder holding its files.
  xattr -dr com.apple.quarantine "$ROOT" >/dev/null 2>&1 || true
  LSREG="/System/Library/Frameworks/CoreServices.framework/Versions/A/Frameworks/LaunchServices.framework/Versions/A/Support/lsregister"
  if [ -x "$LSREG" ]; then
    "$LSREG" -f "$ROOT/Kara.app" >/dev/null 2>&1 && ok "registered with macOS" \
      || warn "could not register Kara with macOS; Spotlight may not find it"
  else
    warn "lsregister not found; Spotlight may take a while to notice Kara"
  fi
  # Prove it rather than assume it -- this is the check that was missing.
  KIND="$(mdls -name kMDItemKind -raw "$ROOT/Kara.app" 2>/dev/null || echo '')"
  if [ "$KIND" = "Application" ]; then
    ok "macOS lists Kara as an Application (press Cmd+Space and type Kara)"
  else
    warn "macOS reports Kara.app as '${KIND:-unknown}' rather than Application."
    warn "Spotlight indexing can lag; if Kara does not appear, move the folder"
    warn "to your Applications folder and open it once."
  fi
else
  warn "Kara.app was not built, so Kara will not appear in Spotlight."
  warn "Open Kara with the Kara file in this folder instead."
fi

say "Done"
printf '  Open it: press Cmd+Space, type Kara -- or double-click Kara in this folder.\n\n'
