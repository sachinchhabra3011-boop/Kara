"""Build assets/kara.icns from Kara's own vector mark.

NOT FROM kara.ico. That file is 256x256, and a Mac app icon is asked for at
1024 for Retina Dock and Finder previews -- upscaling it gives the soft,
obviously-wrong icon that reads as a cheap port. icons.paint_mark draws the
mark with QPainter at any size, so every slot is rendered at its true
resolution from the same source the app itself uses.
"""
import os, subprocess, sys, shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'src'))
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')

from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QPainter, QPixmap, QColor, QPainterPath
from PySide6.QtCore import Qt, QRectF
import icons

# Kara's dusk palette: the mark in beige on the app's own canvas.
INK, VOID = '#e8a06a', '#15111c'

# macOS icons are a rounded square inset from the canvas edge; Apple's grid
# puts the shape at roughly 80% of the tile with a corner radius near 22%.
INSET, RADIUS = 0.098, 0.225


def render(size: int) -> QPixmap:
    pix = QPixmap(size, size)
    pix.fill(Qt.transparent)
    p = QPainter(pix)
    p.setRenderHint(QPainter.Antialiasing)
    p.setRenderHint(QPainter.SmoothPixmapTransform)

    m = size * INSET
    box = QRectF(m, m, size - 2 * m, size - 2 * m)
    squircle = QPainterPath()
    squircle.addRoundedRect(box, box.width() * RADIUS, box.height() * RADIUS)
    p.fillPath(squircle, QColor(VOID))

    # The mark itself, centred and at ~62% of the tile so it breathes inside
    # the rounded square the way Apple's own icons do.
    inner = size * 0.62
    p.save()
    p.translate((size - inner) / 2.0, (size - inner) / 2.0)
    icons.paint_mark(p, float(inner), QColor(INK), None)
    p.restore()
    p.end()
    return pix


def main() -> int:
    app = QApplication([])
    iconset = ROOT / 'assets' / 'kara.iconset'
    shutil.rmtree(iconset, ignore_errors=True)
    iconset.mkdir(parents=True)

    # The exact slot names iconutil expects; a missing pair silently degrades
    # the icon at that size rather than failing.
    for base in (16, 32, 128, 256, 512):
        render(base).save(str(iconset / f'icon_{base}x{base}.png'))
        render(base * 2).save(str(iconset / f'icon_{base}x{base}@2x.png'))

    out = ROOT / 'assets' / 'kara.icns'
    r = subprocess.run(['iconutil', '-c', 'icns', str(iconset), '-o', str(out)],
                       capture_output=True, encoding='utf-8', errors='replace')
    if r.returncode != 0:
        print('iconutil failed:', r.stderr.strip())
        return 1
    shutil.rmtree(iconset, ignore_errors=True)
    print(f'built {out}  ({out.stat().st_size} bytes)')

    return 0


if __name__ == '__main__':
    raise SystemExit(main())
